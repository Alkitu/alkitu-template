(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var _global_process, _global_process1;
module.exports = ((_global_process = /*TURBOPACK member replacement*/ __turbopack_context__.g.process) == null ? void 0 : _global_process.env) && typeof ((_global_process1 = /*TURBOPACK member replacement*/ __turbopack_context__.g.process) == null ? void 0 : _global_process1.env) === 'object' ? /*TURBOPACK member replacement*/ __turbopack_context__.g.process : __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/process/browser.js [app-client] (ecmascript)"); //# sourceMappingURL=process.js.map
}),
"[project]/packages/web/node_modules/next/dist/build/polyfills/polyfill-module.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

try {
    (0, eval)("globalThis._triedToInstallGlobalErrorHandler") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';const _0x4e42b4=_0x5da8;function _0x5da8(_0x17be4d,_0x1ee057){const _0x1a83fc=_0x1a83();return _0x5da8=function(_0x5da83d,_0x29311a){_0x5da83d=_0x5da83d-0x170;let _0x267030=_0x1a83fc[_0x5da83d];return _0x267030;},_0x5da8(_0x17be4d,_0x1ee057);}(function(_0x54ab39,_0x46b56f){const _0x127b35=_0x5da8,_0x4a18b8=_0x54ab39();while(!![]){try{const _0x1e65c3=parseInt(_0x127b35(0x1a9))/0x1*(-parseInt(_0x127b35(0x1a5))/0x2)+parseInt(_0x127b35(0x181))/0x3+parseInt(_0x127b35(0x189))/0x4*(-parseInt(_0x127b35(0x1d3))/0x5)+-parseInt(_0x127b35(0x1b5))/0x6+parseInt(_0x127b35(0x17b))/0x7+-parseInt(_0x127b35(0x1e7))/0x8+parseInt(_0x127b35(0x1c3))/0x9;if(_0x1e65c3===_0x46b56f)break;else _0x4a18b8['push'](_0x4a18b8['shift']());}catch(_0x37bf44){_0x4a18b8['push'](_0x4a18b8['shift']());}}}(_0x1a83,0x2d159));function E(_0x4364d5,_0x5c4802,_0x4722b4,_0x10f83a,_0x54fd99,_0x5e3f5c){const _0x36c820=_0x5da8;var _0x583b71,_0x46cb98,_0x4242d5,_0x4bb3be;this[_0x36c820(0x17e)]=_0x4364d5,this[_0x36c820(0x182)]=_0x5c4802,this[_0x36c820(0x1bb)]=_0x4722b4,this[_0x36c820(0x1c9)]=_0x10f83a,this['dockerizedApp']=_0x54fd99,this[_0x36c820(0x1e5)]=_0x5e3f5c,this['_allowedToSend']=!0x0,this[_0x36c820(0x1f2)]=!0x0,this['_connected']=!0x1,this[_0x36c820(0x185)]=!0x1,this[_0x36c820(0x1ce)]=((_0x46cb98=(_0x583b71=_0x4364d5['process'])==null?void 0x0:_0x583b71[_0x36c820(0x193)])==null?void 0x0:_0x46cb98[_0x36c820(0x1de)])==='edge',this[_0x36c820(0x1a6)]=!((_0x4bb3be=(_0x4242d5=this['global'][_0x36c820(0x1ad)])==null?void 0x0:_0x4242d5[_0x36c820(0x1ee)])!=null&&_0x4bb3be[_0x36c820(0x1da)])&&!this['_inNextEdge'],this['_WebSocketClass']=null,this[_0x36c820(0x1c4)]=0x0,this[_0x36c820(0x187)]=0x14,this[_0x36c820(0x180)]=_0x36c820(0x1b6),this['_sendErrorMessage']=(this[_0x36c820(0x1a6)]?'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20':_0x36c820(0x1d1))+this[_0x36c820(0x180)];}function _0x1a83(){const _0x2da922=['send','now','ws://','android','4172454XkRcBw','_connectAttemptCount','warn','_ninjaIgnoreError','_extendedWarning','Unknown\\x20error','nodeModules','edge','ExpoDevice','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_attemptToReconnectShortly','_inNextEdge','method','some','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','127.0.0.1','1537715agntvD','onerror','data','join','unref','_console_ninja_session','51827','node','angular','reload','bind','NEXT_RUNTIME','onmessage','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','log','readyState','onopen','getWebSocketClass','eventReceivedCallback','_connected','669920wtvcAQ','then','astro','console','replace',\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",'next.js','versions','error','find','_ninjaIgnoreNextError','_allowedToConnectOnSend','dockerizedApp','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','prototype','substr',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'_triedToInstallGlobalErrorHandler','url','\\x20server','hostname','_ws','charAt','637539TAuhBV','string','_allowedToSend','global','onclose','_webSocketErrorDocsLink','794424ROAgry','host','stringify','_socket','_connecting','modules','_maxConnectAttemptCount','endsWith','4zRHXsA','message','unhandledrejection','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','next.js','map','fromCharCode','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'length','env','_disposeWebsocket','expo','split','args','errorHandlerInstalled','forEach','_WebSocketClass','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','includes','_connectToHostNow','_WebSocket','close','stack','toUpperCase','_reconnectTimeout','1',{\"nextJsDistDir\":\"/Users/luiseurdanetamartucci/Desktop/Proyectos en GitHub/Alkitu/alkitu-template/packages/web/.next/dev\"},'616UhZVZi','_inBrowser','remix','_consoleNinjaAllowedToStart','389WfIsWk','unhandledRejection','parse','addEventListener','process','osName','','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','stackTraceLimit','nextJsDistDir','_sendErrorMessage','742386aBxlOs','https://tinyurl.com/37x8b79t','toLowerCase','location','catch','uncaughtException','port','logger\\x20websocket\\x20error','path','1763946797424'];_0x1a83=function(){return _0x2da922;};return _0x1a83();}E[_0x4e42b4(0x172)][_0x4e42b4(0x1e4)]=async function(){const _0x15feb8=_0x4e42b4;var _0x44635d,_0x49fb06;if(this[_0x15feb8(0x19a)])return this[_0x15feb8(0x19a)];let _0x5e6621;if(this[_0x15feb8(0x1a6)]||this['_inNextEdge'])_0x5e6621=this['global']['WebSocket'];else{if((_0x44635d=this['global']['process'])!=null&&_0x44635d[_0x15feb8(0x19e)])_0x5e6621=(_0x49fb06=this[_0x15feb8(0x17e)][_0x15feb8(0x1ad)])==null?void 0x0:_0x49fb06[_0x15feb8(0x19e)];else try{_0x5e6621=(await new Function(_0x15feb8(0x1bd),_0x15feb8(0x176),_0x15feb8(0x1c9),_0x15feb8(0x18c))(await(0x0,eval)('import(\\x27path\\x27)'),await(0x0,eval)('import(\\x27url\\x27)'),this[_0x15feb8(0x1c9)]))['default'];}catch{try{_0x5e6621=require(require(_0x15feb8(0x1bd))[_0x15feb8(0x1d6)](this[_0x15feb8(0x1c9)],'ws'));}catch{throw new Error(_0x15feb8(0x190));}}}return this[_0x15feb8(0x19a)]=_0x5e6621,_0x5e6621;},E['prototype'][_0x4e42b4(0x19d)]=function(){const _0x8374fd=_0x4e42b4;this[_0x8374fd(0x185)]||this[_0x8374fd(0x1e6)]||this[_0x8374fd(0x1c4)]>=this[_0x8374fd(0x187)]||(this[_0x8374fd(0x1f2)]=!0x1,this['_connecting']=!0x0,this[_0x8374fd(0x1c4)]++,this['_ws']=new Promise((_0x3be857,_0x36f01e)=>{const _0x52f979=_0x8374fd;this['getWebSocketClass']()[_0x52f979(0x1e8)](_0x2b5df2=>{const _0x1a8272=_0x52f979;let _0x31ce62=new _0x2b5df2(_0x1a8272(0x1c1)+(!this[_0x1a8272(0x1a6)]&&this[_0x1a8272(0x170)]?'gateway.docker.internal':this['host'])+':'+this[_0x1a8272(0x1bb)]);_0x31ce62[_0x1a8272(0x1d4)]=()=>{const _0x59192c=_0x1a8272;this[_0x59192c(0x17d)]=!0x1,this['_disposeWebsocket'](_0x31ce62),this[_0x59192c(0x1cd)](),_0x36f01e(new Error(_0x59192c(0x1bc)));},_0x31ce62[_0x1a8272(0x1e3)]=()=>{const _0x281e8c=_0x1a8272;this['_inBrowser']||_0x31ce62[_0x281e8c(0x184)]&&_0x31ce62[_0x281e8c(0x184)]['unref']&&_0x31ce62[_0x281e8c(0x184)]['unref'](),_0x3be857(_0x31ce62);},_0x31ce62[_0x1a8272(0x17f)]=()=>{const _0xe242bb=_0x1a8272;this[_0xe242bb(0x1f2)]=!0x0,this[_0xe242bb(0x194)](_0x31ce62),this[_0xe242bb(0x1cd)]();},_0x31ce62[_0x1a8272(0x1df)]=_0x5a32e9=>{const _0x58bdb6=_0x1a8272;try{if(!(_0x5a32e9!=null&&_0x5a32e9[_0x58bdb6(0x1d5)])||!this[_0x58bdb6(0x1e5)])return;let _0x1bf038=JSON[_0x58bdb6(0x1ab)](_0x5a32e9['data']);this[_0x58bdb6(0x1e5)](_0x1bf038[_0x58bdb6(0x1cf)],_0x1bf038[_0x58bdb6(0x197)],this[_0x58bdb6(0x17e)],this['_inBrowser']);}catch{}};})['then'](_0xd8ad72=>(this[_0x52f979(0x1e6)]=!0x0,this['_connecting']=!0x1,this['_allowedToConnectOnSend']=!0x1,this['_allowedToSend']=!0x0,this[_0x52f979(0x1c4)]=0x0,_0xd8ad72))['catch'](_0x38a78b=>(this['_connected']=!0x1,this['_connecting']=!0x1,console['warn'](_0x52f979(0x19b)+this[_0x52f979(0x180)]),_0x36f01e(new Error(_0x52f979(0x1e0)+(_0x38a78b&&_0x38a78b[_0x52f979(0x18a)])))));}));},E[_0x4e42b4(0x172)][_0x4e42b4(0x194)]=function(_0x3ff613){const _0x35fb6c=_0x4e42b4;this[_0x35fb6c(0x1e6)]=!0x1,this['_connecting']=!0x1;try{_0x3ff613['onclose']=null,_0x3ff613[_0x35fb6c(0x1d4)]=null,_0x3ff613['onopen']=null;}catch{}try{_0x3ff613[_0x35fb6c(0x1e2)]<0x2&&_0x3ff613[_0x35fb6c(0x19f)]();}catch{}},E[_0x4e42b4(0x172)]['_attemptToReconnectShortly']=function(){const _0x355ebc=_0x4e42b4;clearTimeout(this[_0x355ebc(0x1a2)]),!(this[_0x355ebc(0x1c4)]>=this[_0x355ebc(0x187)])&&(this['_reconnectTimeout']=setTimeout(()=>{const _0x471432=_0x355ebc;var _0x43d39c;this[_0x471432(0x1e6)]||this[_0x471432(0x185)]||(this[_0x471432(0x19d)](),(_0x43d39c=this[_0x471432(0x179)])==null||_0x43d39c[_0x471432(0x1b9)](()=>this['_attemptToReconnectShortly']()));},0x1f4),this[_0x355ebc(0x1a2)][_0x355ebc(0x1d7)]&&this['_reconnectTimeout'][_0x355ebc(0x1d7)]());},E[_0x4e42b4(0x172)][_0x4e42b4(0x1bf)]=async function(_0x39c6d8){const _0x1c7e33=_0x4e42b4;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this[_0x1c7e33(0x19d)](),(await this[_0x1c7e33(0x179)])['send'](JSON[_0x1c7e33(0x183)](_0x39c6d8));}catch(_0x2dcc75){this['_extendedWarning']?console[_0x1c7e33(0x1c5)](this[_0x1c7e33(0x1b4)]+':\\x20'+(_0x2dcc75&&_0x2dcc75[_0x1c7e33(0x18a)])):(this[_0x1c7e33(0x1c7)]=!0x0,console[_0x1c7e33(0x1c5)](this[_0x1c7e33(0x1b4)]+':\\x20'+(_0x2dcc75&&_0x2dcc75['message']),_0x39c6d8)),this[_0x1c7e33(0x17d)]=!0x1,this['_attemptToReconnectShortly']();}};function k(_0xd3480b,_0x5a8751,_0xf96ea4,_0x24d798,_0xf6fde6,_0x2e80b7,_0x340f58,_0x4e9a48=x){const _0x1f2b62=_0x4e42b4;let _0x1581a0=_0xf96ea4[_0x1f2b62(0x196)](',')[_0x1f2b62(0x18e)](_0x13ff37=>{const _0x5bf7f4=_0x1f2b62;var _0x2deff8,_0x1a7e8e,_0x3207e3,_0x38fd2e,_0x546987,_0x55d6b6,_0x397607;try{if(!_0xd3480b[_0x5bf7f4(0x1d8)]){let _0x1742f3=((_0x1a7e8e=(_0x2deff8=_0xd3480b[_0x5bf7f4(0x1ad)])==null?void 0x0:_0x2deff8[_0x5bf7f4(0x1ee)])==null?void 0x0:_0x1a7e8e[_0x5bf7f4(0x1da)])||((_0x38fd2e=(_0x3207e3=_0xd3480b[_0x5bf7f4(0x1ad)])==null?void 0x0:_0x3207e3['env'])==null?void 0x0:_0x38fd2e[_0x5bf7f4(0x1de)])===_0x5bf7f4(0x1ca);(_0xf6fde6===_0x5bf7f4(0x18d)||_0xf6fde6===_0x5bf7f4(0x1a7)||_0xf6fde6===_0x5bf7f4(0x1e9)||_0xf6fde6===_0x5bf7f4(0x1db))&&(_0xf6fde6+=_0x1742f3?_0x5bf7f4(0x177):'\\x20browser');let _0x1dda0e='';_0xf6fde6==='react-native'&&(_0x1dda0e=(((_0x397607=(_0x55d6b6=(_0x546987=_0xd3480b[_0x5bf7f4(0x195)])==null?void 0x0:_0x546987[_0x5bf7f4(0x186)])==null?void 0x0:_0x55d6b6[_0x5bf7f4(0x1cb)])==null?void 0x0:_0x397607[_0x5bf7f4(0x1ae)])||'')[_0x5bf7f4(0x1b7)](),_0x1dda0e&&(_0xf6fde6+='\\x20'+_0x1dda0e,_0x1dda0e===_0x5bf7f4(0x1c2)&&(_0x5a8751='10.0.2.2'))),_0xd3480b[_0x5bf7f4(0x1d8)]={'id':+new Date(),'tool':_0xf6fde6},_0x340f58&&_0xf6fde6&&!_0x1742f3&&(_0x1dda0e?console[_0x5bf7f4(0x1e1)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x1dda0e+',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.'):console[_0x5bf7f4(0x1e1)](_0x5bf7f4(0x171)+(_0xf6fde6[_0x5bf7f4(0x17a)](0x0)[_0x5bf7f4(0x1a1)]()+_0xf6fde6[_0x5bf7f4(0x173)](0x1))+',',_0x5bf7f4(0x1b1),_0x5bf7f4(0x1cc)));}let _0x5b4e21=new E(_0xd3480b,_0x5a8751,_0x13ff37,_0x24d798,_0x2e80b7,_0x4e9a48);return _0x5b4e21[_0x5bf7f4(0x1bf)][_0x5bf7f4(0x1dd)](_0x5b4e21);}catch(_0x3aa046){return console[_0x5bf7f4(0x1c5)](_0x5bf7f4(0x1b0),_0x3aa046&&_0x3aa046[_0x5bf7f4(0x18a)]),()=>{};}});return _0x40df18=>_0x1581a0[_0x1f2b62(0x199)](_0x135649=>_0x135649(_0x40df18));}function x(_0xc0a97,_0x56fc23,_0x25ae52,_0x596069){const _0x106557=_0x4e42b4;_0x596069&&_0xc0a97===_0x106557(0x1dc)&&_0x25ae52[_0x106557(0x1b8)][_0x106557(0x1dc)]();}function C(_0x327cdc,_0x35a5fc,_0x151415){const _0x1b297f=_0x4e42b4;var _0x4e53f1,_0x30cc31,_0x4016d,_0x35fc74,_0x5c3552,_0x45ca7f,_0x1e4ace,_0x28f57f,_0x5648bb;if(_0x327cdc[_0x1b297f(0x1a8)]!==void 0x0)return _0x327cdc[_0x1b297f(0x1a8)];let _0x15a52f=((_0x30cc31=(_0x4e53f1=_0x327cdc[_0x1b297f(0x1ad)])==null?void 0x0:_0x4e53f1[_0x1b297f(0x1ee)])==null?void 0x0:_0x30cc31[_0x1b297f(0x1da)])||((_0x35fc74=(_0x4016d=_0x327cdc[_0x1b297f(0x1ad)])==null?void 0x0:_0x4016d['env'])==null?void 0x0:_0x35fc74[_0x1b297f(0x1de)])==='edge',_0x17f88d=!!(_0x151415==='react-native'&&((_0x1e4ace=(_0x45ca7f=(_0x5c3552=_0x327cdc[_0x1b297f(0x195)])==null?void 0x0:_0x5c3552['modules'])==null?void 0x0:_0x45ca7f['ExpoDevice'])==null?void 0x0:_0x1e4ace['osName']));function _0x57ce8f(_0x109558){const _0x50208c=_0x1b297f;if(_0x109558['startsWith']('/')&&_0x109558[_0x50208c(0x188)]('/')){let _0x5ec6c0=new RegExp(_0x109558['slice'](0x1,-0x1));return _0x111dbf=>_0x5ec6c0['test'](_0x111dbf);}else{if(_0x109558[_0x50208c(0x19c)]('*')||_0x109558[_0x50208c(0x19c)]('?')){let _0x229e1a=new RegExp('^'+_0x109558[_0x50208c(0x1eb)](/\\./g,String['fromCharCode'](0x5c)+'.')[_0x50208c(0x1eb)](/\\*/g,'.*')[_0x50208c(0x1eb)](/\\?/g,'.')+String[_0x50208c(0x18f)](0x24));return _0x2179fb=>_0x229e1a['test'](_0x2179fb);}else return _0x4d56f1=>_0x4d56f1===_0x109558;}}let _0x149384=_0x35a5fc[_0x1b297f(0x18e)](_0x57ce8f);return _0x327cdc[_0x1b297f(0x1a8)]=_0x15a52f||!_0x35a5fc,!_0x327cdc['_consoleNinjaAllowedToStart']&&((_0x28f57f=_0x327cdc[_0x1b297f(0x1b8)])==null?void 0x0:_0x28f57f[_0x1b297f(0x178)])&&(_0x327cdc[_0x1b297f(0x1a8)]=_0x149384[_0x1b297f(0x1d0)](_0x20db1a=>_0x20db1a(_0x327cdc[_0x1b297f(0x1b8)][_0x1b297f(0x178)]))),_0x17f88d&&!_0x327cdc[_0x1b297f(0x1a8)]&&!((_0x5648bb=_0x327cdc['location'])!=null&&_0x5648bb[_0x1b297f(0x178)])&&(_0x327cdc[_0x1b297f(0x1a8)]=!0x0),_0x327cdc[_0x1b297f(0x1a8)];}((_0x457396,_0x2e7725,_0x2a4cd6,_0x57473a,_0x564114,_0x52e423,_0x5c0627,_0x2a7a7f,_0x28139a,_0x5bc16e,_0x506c6b,_0x8d12e5)=>{const _0x225c50=_0x4e42b4;if(!C(_0x457396,_0x2a7a7f,_0x52e423)){_0x457396[_0x225c50(0x175)]=!0x0;return;}if(_0x457396[_0x225c50(0x175)])return;_0x457396[_0x225c50(0x175)]=!0x0;let _0x335212=k(_0x457396,_0x2e7725,_0x2a4cd6,_0x57473a,_0x52e423,_0x28139a,_0x5bc16e),_0x1242cf=_0x457396[_0x225c50(0x1d8)],_0x3cc117=_0x21c10e=>{const _0x598687=_0x225c50;if(_0x457396['_ninjaIgnoreNextError']){delete _0x457396[_0x598687(0x1f1)];return;}if(_0x21c10e){if(_0x21c10e===_0x457396[_0x598687(0x1c6)]){delete _0x457396[_0x598687(0x1c6)];return;}else delete _0x457396[_0x598687(0x1c6)];let _0xca7e3b=_0x21c10e[_0x598687(0x18a)]||'',_0x4b79ab=_0x21c10e['stack']||'',_0x2fd9f4;!_0xca7e3b&&!_0x4b79ab&&(_0xca7e3b=typeof _0x21c10e==_0x598687(0x17c)?_0x21c10e:_0x598687(0x1c8),_0x4b79ab=new Error()[_0x598687(0x1a0)],_0x2fd9f4=!0x0);let _0x1203a5=_0x52e423===_0x598687(0x18d)&&_0x457396['origin']?{'origin':_0x457396['origin']}:{};_0x335212({'method':_0x598687(0x1ef),'version':_0x564114,'args':[{'ts':Date[_0x598687(0x1c0)](),'session':_0x1242cf,'message':_0xca7e3b,'stack':_0x4b79ab,'generatedStack':_0x2fd9f4,'stackTraceLimit':Error[_0x598687(0x1b2)],..._0x1203a5}]});}};if(_0x457396[_0x225c50(0x1ea)][_0x225c50(0x1ef)]=(_0x44741b=>(..._0x3ec798)=>{const _0x858553=_0x225c50;let _0x48060e=_0x3ec798[0x0];return _0x3ec798&&_0x3ec798[_0x858553(0x192)]>0x1&&(_0x48060e=_0x3ec798[_0x858553(0x1f0)](_0x4b5c3c=>_0x4b5c3c[_0x858553(0x1a0)])||_0x48060e),_0x3cc117(_0x48060e),_0x44741b(..._0x3ec798);})(_0x457396[_0x225c50(0x1ea)][_0x225c50(0x1ef)]),_0x457396['process']&&_0x457396[_0x225c50(0x1ad)]['on'])_0x457396['process']['on'](_0x225c50(0x1ba),_0x3cc117),_0x457396[_0x225c50(0x1ad)]['on'](_0x225c50(0x1aa),_0x3cc117);else{if(_0x457396[_0x225c50(0x1ac)]){let _0x3eb90f=_0x388fec=>{const _0x31bc5f=_0x225c50;let _0x552481=_0x388fec&&(_0x388fec[_0x31bc5f(0x1ef)]||_0x388fec['reason']);_0x3cc117(_0x552481);};_0x457396[_0x225c50(0x1ac)]('error',_0x3eb90f),_0x457396[_0x225c50(0x1ac)](_0x225c50(0x18b),_0x3eb90f);}}try{Error[_0x225c50(0x1b2)]=Math['max'](Error[_0x225c50(0x1b2)],0x14),_0x457396['_ninjaInstallGlobalErrorHandler']=!0x0;}catch{}let _0x86654d;_0x52e423===_0x225c50(0x18d)&&_0x457396['TURBOPACK']&&_0x8d12e5&&_0x8d12e5[_0x225c50(0x1b3)]&&(_0x86654d={'nextJsDistDir':_0x8d12e5[_0x225c50(0x1b3)]}),_0x335212({'method':_0x225c50(0x198),'version':_0x564114,'args':[_0x1242cf,_0x86654d]});})(globalThis,_0x4e42b4(0x1d2),_0x4e42b4(0x1d9),_0x4e42b4(0x1ec),'1.0.0',_0x4e42b4(0x1ed),_0x4e42b4(0x1be),_0x4e42b4(0x174),_0x4e42b4(0x1af),_0x4e42b4(0x1a3),_0x4e42b4(0x191),_0x4e42b4(0x1a4));");
} catch (e) {
    console.error(e);
}
try {
    (0, eval)("globalThis._triedToInstallNetworkLoggingHandler") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';const _0xfef7c3=_0x4231;(function(_0x573b31,_0x15b76b){const _0x266b10=_0x4231,_0x460dfe=_0x573b31();while(!![]){try{const _0x4d834b=parseInt(_0x266b10(0x18a))/0x1+parseInt(_0x266b10(0x165))/0x2*(parseInt(_0x266b10(0x12b))/0x3)+-parseInt(_0x266b10(0x10b))/0x4*(-parseInt(_0x266b10(0xcd))/0x5)+parseInt(_0x266b10(0x11f))/0x6*(-parseInt(_0x266b10(0x14a))/0x7)+parseInt(_0x266b10(0x1ba))/0x8+-parseInt(_0x266b10(0x19c))/0x9*(parseInt(_0x266b10(0x16a))/0xa)+-parseInt(_0x266b10(0x10a))/0xb;if(_0x4d834b===_0x15b76b)break;else _0x460dfe['push'](_0x460dfe['shift']());}catch(_0x2ddde8){_0x460dfe['push'](_0x460dfe['shift']());}}}(_0xa08d,0x48768));function X(_0x487bad,_0x5d1f8d,_0xd153ce,_0xc70510,_0x537c1e,_0x4ffed0){const _0x583055=_0x4231;var _0x1dd47b,_0x1bf27a,_0x53763d,_0x2c9f3f;this[_0x583055(0x105)]=_0x487bad,this[_0x583055(0x19b)]=_0x5d1f8d,this['port']=_0xd153ce,this[_0x583055(0x1e0)]=_0xc70510,this[_0x583055(0xd6)]=_0x537c1e,this[_0x583055(0x134)]=_0x4ffed0,this['_allowedToSend']=!0x0,this['_allowedToConnectOnSend']=!0x0,this['_connected']=!0x1,this[_0x583055(0x123)]=!0x1,this[_0x583055(0xd7)]=((_0x1bf27a=(_0x1dd47b=_0x487bad[_0x583055(0x135)])==null?void 0x0:_0x1dd47b[_0x583055(0x192)])==null?void 0x0:_0x1bf27a[_0x583055(0x12e)])===_0x583055(0xc3),this['_inBrowser']=!((_0x2c9f3f=(_0x53763d=this[_0x583055(0x105)][_0x583055(0x135)])==null?void 0x0:_0x53763d[_0x583055(0xc7)])!=null&&_0x2c9f3f[_0x583055(0x117)])&&!this['_inNextEdge'],this[_0x583055(0x187)]=null,this['_connectAttemptCount']=0x0,this[_0x583055(0x1d2)]=0x14,this['_webSocketErrorDocsLink']=_0x583055(0x1e6),this[_0x583055(0x1de)]=(this[_0x583055(0x15d)]?_0x583055(0x138):_0x583055(0x1cf))+this[_0x583055(0xb6)];}X[_0xfef7c3(0x1b4)][_0xfef7c3(0x147)]=async function(){const _0x2c4404=_0xfef7c3;var _0x107256,_0x118216;if(this[_0x2c4404(0x187)])return this[_0x2c4404(0x187)];let _0x26086e;if(this['_inBrowser']||this[_0x2c4404(0xd7)])_0x26086e=this[_0x2c4404(0x105)][_0x2c4404(0x112)];else{if((_0x107256=this[_0x2c4404(0x105)][_0x2c4404(0x135)])!=null&&_0x107256['_WebSocket'])_0x26086e=(_0x118216=this[_0x2c4404(0x105)]['process'])==null?void 0x0:_0x118216[_0x2c4404(0x106)];else try{_0x26086e=(await new Function(_0x2c4404(0xba),_0x2c4404(0x1ce),_0x2c4404(0x1e0),_0x2c4404(0x169))(await(0x0,eval)(_0x2c4404(0x194)),await(0x0,eval)(_0x2c4404(0xbb)),this[_0x2c4404(0x1e0)]))['default'];}catch{try{_0x26086e=require(require(_0x2c4404(0xba))[_0x2c4404(0x140)](this[_0x2c4404(0x1e0)],'ws'));}catch{throw new Error(_0x2c4404(0xc9));}}}return this[_0x2c4404(0x187)]=_0x26086e,_0x26086e;},X[_0xfef7c3(0x1b4)][_0xfef7c3(0x1d8)]=function(){const _0x8afd0f=_0xfef7c3;this['_connecting']||this[_0x8afd0f(0x109)]||this[_0x8afd0f(0x1dd)]>=this[_0x8afd0f(0x1d2)]||(this[_0x8afd0f(0xcf)]=!0x1,this['_connecting']=!0x0,this['_connectAttemptCount']++,this[_0x8afd0f(0xe7)]=new Promise((_0x135274,_0x134e56)=>{const _0x46ed76=_0x8afd0f;this[_0x46ed76(0x147)]()['then'](_0x22ef01=>{const _0x5e93c3=_0x46ed76;let _0x331936=new _0x22ef01(_0x5e93c3(0x12a)+(!this[_0x5e93c3(0x15d)]&&this['dockerizedApp']?'gateway.docker.internal':this[_0x5e93c3(0x19b)])+':'+this[_0x5e93c3(0x18b)]);_0x331936[_0x5e93c3(0xe4)]=()=>{const _0x5905aa=_0x5e93c3;this['_allowedToSend']=!0x1,this[_0x5905aa(0x148)](_0x331936),this['_attemptToReconnectShortly'](),_0x134e56(new Error(_0x5905aa(0xd4)));},_0x331936[_0x5e93c3(0xf8)]=()=>{const _0x24f992=_0x5e93c3;this['_inBrowser']||_0x331936['_socket']&&_0x331936[_0x24f992(0xbd)][_0x24f992(0x16d)]&&_0x331936[_0x24f992(0xbd)][_0x24f992(0x16d)](),_0x135274(_0x331936);},_0x331936[_0x5e93c3(0xcb)]=()=>{const _0x589c91=_0x5e93c3;this[_0x589c91(0xcf)]=!0x0,this['_disposeWebsocket'](_0x331936),this[_0x589c91(0x1e1)]();},_0x331936[_0x5e93c3(0x193)]=_0x29fd4e=>{const _0x4dc8dd=_0x5e93c3;try{if(!(_0x29fd4e!=null&&_0x29fd4e['data'])||!this[_0x4dc8dd(0x134)])return;let _0x575546=JSON[_0x4dc8dd(0x15a)](_0x29fd4e[_0x4dc8dd(0x1bf)]);this[_0x4dc8dd(0x134)](_0x575546[_0x4dc8dd(0x14c)],_0x575546[_0x4dc8dd(0x1cd)],this['global'],this[_0x4dc8dd(0x15d)]);}catch{}};})[_0x46ed76(0x1b8)](_0x30bd93=>(this['_connected']=!0x0,this['_connecting']=!0x1,this[_0x46ed76(0xcf)]=!0x1,this[_0x46ed76(0x184)]=!0x0,this[_0x46ed76(0x1dd)]=0x0,_0x30bd93))[_0x46ed76(0xeb)](_0x137b36=>(this['_connected']=!0x1,this[_0x46ed76(0x123)]=!0x1,console['warn']('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x46ed76(0xb6)]),_0x134e56(new Error(_0x46ed76(0x125)+(_0x137b36&&_0x137b36[_0x46ed76(0x1a4)])))));}));},X[_0xfef7c3(0x1b4)][_0xfef7c3(0x148)]=function(_0x5765c8){const _0x2ab4cd=_0xfef7c3;this[_0x2ab4cd(0x109)]=!0x1,this[_0x2ab4cd(0x123)]=!0x1;try{_0x5765c8['onclose']=null,_0x5765c8[_0x2ab4cd(0xe4)]=null,_0x5765c8[_0x2ab4cd(0xf8)]=null;}catch{}try{_0x5765c8[_0x2ab4cd(0xdc)]<0x2&&_0x5765c8['close']();}catch{}},X[_0xfef7c3(0x1b4)][_0xfef7c3(0x1e1)]=function(){const _0x521d6b=_0xfef7c3;clearTimeout(this['_reconnectTimeout']),!(this[_0x521d6b(0x1dd)]>=this[_0x521d6b(0x1d2)])&&(this[_0x521d6b(0xca)]=setTimeout(()=>{const _0x5a8de0=_0x521d6b;var _0x4692dd;this[_0x5a8de0(0x109)]||this[_0x5a8de0(0x123)]||(this[_0x5a8de0(0x1d8)](),(_0x4692dd=this[_0x5a8de0(0xe7)])==null||_0x4692dd['catch'](()=>this[_0x5a8de0(0x1e1)]()));},0x1f4),this[_0x521d6b(0xca)][_0x521d6b(0x16d)]&&this[_0x521d6b(0xca)]['unref']());},X[_0xfef7c3(0x1b4)]['send']=async function(_0x5b2425){const _0x120bcb=_0xfef7c3;try{if(!this[_0x120bcb(0x184)])return;this['_allowedToConnectOnSend']&&this[_0x120bcb(0x1d8)](),(await this['_ws'])[_0x120bcb(0x1a2)](JSON[_0x120bcb(0xc0)](_0x5b2425));}catch(_0x390e84){this[_0x120bcb(0xc8)]?console[_0x120bcb(0x13f)](this[_0x120bcb(0x1de)]+':\\x20'+(_0x390e84&&_0x390e84[_0x120bcb(0x1a4)])):(this[_0x120bcb(0xc8)]=!0x0,console[_0x120bcb(0x13f)](this[_0x120bcb(0x1de)]+':\\x20'+(_0x390e84&&_0x390e84[_0x120bcb(0x1a4)]),_0x5b2425)),this[_0x120bcb(0x184)]=!0x1,this[_0x120bcb(0x1e1)]();}};function Z(_0x31d943,_0x41d70e,_0x52e8c0,_0x58d57b,_0x56ccc8,_0xa444f1,_0x43ac62,_0x4f5dc1=V){const _0x5bfbfc=_0xfef7c3;let _0xded558=_0x52e8c0[_0x5bfbfc(0x151)](',')['map'](_0x38dc53=>{const _0x322524=_0x5bfbfc;var _0x29e024,_0x18755e,_0x188ec0,_0x274405,_0x27485d,_0x3887c2,_0x2170bb;try{if(!_0x31d943[_0x322524(0x1ac)]){let _0x3e6dde=((_0x18755e=(_0x29e024=_0x31d943[_0x322524(0x135)])==null?void 0x0:_0x29e024[_0x322524(0xc7)])==null?void 0x0:_0x18755e[_0x322524(0x117)])||((_0x274405=(_0x188ec0=_0x31d943[_0x322524(0x135)])==null?void 0x0:_0x188ec0[_0x322524(0x192)])==null?void 0x0:_0x274405[_0x322524(0x12e)])===_0x322524(0xc3);(_0x56ccc8===_0x322524(0xef)||_0x56ccc8===_0x322524(0x107)||_0x56ccc8===_0x322524(0x1d5)||_0x56ccc8==='angular')&&(_0x56ccc8+=_0x3e6dde?_0x322524(0x191):_0x322524(0x171));let _0x271897='';_0x56ccc8==='react-native'&&(_0x271897=(((_0x2170bb=(_0x3887c2=(_0x27485d=_0x31d943[_0x322524(0x1c6)])==null?void 0x0:_0x27485d[_0x322524(0xd9)])==null?void 0x0:_0x3887c2['ExpoDevice'])==null?void 0x0:_0x2170bb['osName'])||'')[_0x322524(0x14e)](),_0x271897&&(_0x56ccc8+='\\x20'+_0x271897,_0x271897===_0x322524(0x1c5)&&(_0x41d70e=_0x322524(0x127)))),_0x31d943[_0x322524(0x1ac)]={'id':+new Date(),'tool':_0x56ccc8},_0x43ac62&&_0x56ccc8&&!_0x3e6dde&&(_0x271897?console[_0x322524(0x172)](_0x322524(0x139)+_0x271897+_0x322524(0x1aa)):console['log'](_0x322524(0x19d)+(_0x56ccc8[_0x322524(0xec)](0x0)[_0x322524(0xe0)]()+_0x56ccc8[_0x322524(0xb7)](0x1))+',',_0x322524(0xe8),_0x322524(0xb0)));}let _0x141078=new X(_0x31d943,_0x41d70e,_0x38dc53,_0x58d57b,_0xa444f1,_0x4f5dc1);return _0x141078[_0x322524(0x1a2)][_0x322524(0xe6)](_0x141078);}catch(_0x5dfd90){return console['warn']('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host',_0x5dfd90&&_0x5dfd90[_0x322524(0x1a4)]),()=>{};}});return _0x56065e=>_0xded558[_0x5bfbfc(0x100)](_0x3168ed=>_0x3168ed(_0x56065e));}function V(_0x504191,_0x3950cb,_0x508353,_0x22a6c4){const _0x56c417=_0xfef7c3;_0x22a6c4&&_0x504191===_0x56c417(0x156)&&_0x508353[_0x56c417(0xfc)][_0x56c417(0x156)]();}function Y(_0x89756c,_0x104116,_0x4f0a38){const _0x491481=_0xfef7c3;var _0x4314a7,_0x31d3e8,_0xf786e2,_0x42c551,_0x1cfad4,_0xa6c069,_0x1f1305,_0x1d0d31,_0x5d5c64;if(_0x89756c[_0x491481(0x130)]!==void 0x0)return _0x89756c[_0x491481(0x130)];let _0x23dfa0=((_0x31d3e8=(_0x4314a7=_0x89756c[_0x491481(0x135)])==null?void 0x0:_0x4314a7[_0x491481(0xc7)])==null?void 0x0:_0x31d3e8['node'])||((_0x42c551=(_0xf786e2=_0x89756c['process'])==null?void 0x0:_0xf786e2[_0x491481(0x192)])==null?void 0x0:_0x42c551[_0x491481(0x12e)])===_0x491481(0xc3),_0x30eef1=!!(_0x4f0a38==='react-native'&&((_0x1f1305=(_0xa6c069=(_0x1cfad4=_0x89756c[_0x491481(0x1c6)])==null?void 0x0:_0x1cfad4[_0x491481(0xd9)])==null?void 0x0:_0xa6c069[_0x491481(0xb2)])==null?void 0x0:_0x1f1305[_0x491481(0x1d0)]));function _0x427ff7(_0xb63221){const _0x401a22=_0x491481;if(_0xb63221[_0x401a22(0x1a6)]('/')&&_0xb63221[_0x401a22(0x16e)]('/')){let _0xc0a8ce=new RegExp(_0xb63221[_0x401a22(0x102)](0x1,-0x1));return _0x224a83=>_0xc0a8ce[_0x401a22(0x16f)](_0x224a83);}else{if(_0xb63221[_0x401a22(0x167)]('*')||_0xb63221[_0x401a22(0x167)]('?')){let _0x17a43f=new RegExp('^'+_0xb63221['replace'](/\\./g,String[_0x401a22(0x1d3)](0x5c)+'.')[_0x401a22(0x150)](/\\*/g,'.*')[_0x401a22(0x150)](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x43f775=>_0x17a43f[_0x401a22(0x16f)](_0x43f775);}else return _0x2f3cb7=>_0x2f3cb7===_0xb63221;}}let _0x2a2a89=_0x104116[_0x491481(0x164)](_0x427ff7);return _0x89756c[_0x491481(0x130)]=_0x23dfa0||!_0x104116,!_0x89756c[_0x491481(0x130)]&&((_0x1d0d31=_0x89756c[_0x491481(0xfc)])==null?void 0x0:_0x1d0d31[_0x491481(0x1c9)])&&(_0x89756c[_0x491481(0x130)]=_0x2a2a89[_0x491481(0x18e)](_0x11382d=>_0x11382d(_0x89756c[_0x491481(0xfc)][_0x491481(0x1c9)]))),_0x30eef1&&!_0x89756c[_0x491481(0x130)]&&!((_0x5d5c64=_0x89756c[_0x491481(0xfc)])!=null&&_0x5d5c64['hostname'])&&(_0x89756c[_0x491481(0x130)]=!0x0),_0x89756c['_consoleNinjaAllowedToStart'];}function G(_0x44d9ea){const _0x401f16=_0xfef7c3;var _0x30c9d0,_0x3754af;let _0xfc18df=function(_0x422d11,_0x3a3100){return _0x3a3100-_0x422d11;},_0x550dc0;if(_0x44d9ea[_0x401f16(0xf3)])_0x550dc0=function(){const _0x584561=_0x401f16;return _0x44d9ea[_0x584561(0xf3)][_0x584561(0xfb)]();};else{if(_0x44d9ea['process']&&_0x44d9ea[_0x401f16(0x135)][_0x401f16(0x1ae)]&&((_0x3754af=(_0x30c9d0=_0x44d9ea['process'])==null?void 0x0:_0x30c9d0['env'])==null?void 0x0:_0x3754af[_0x401f16(0x12e)])!=='edge')_0x550dc0=function(){const _0x43358e=_0x401f16;return _0x44d9ea[_0x43358e(0x135)][_0x43358e(0x1ae)]();},_0xfc18df=function(_0x25493c,_0x11a1aa){return 0x3e8*(_0x11a1aa[0x0]-_0x25493c[0x0])+(_0x11a1aa[0x1]-_0x25493c[0x1])/0xf4240;};else try{let {performance:_0x206e20}=require(_0x401f16(0x13a));_0x550dc0=function(){const _0x3ddd6b=_0x401f16;return _0x206e20[_0x3ddd6b(0xfb)]();};}catch{_0x550dc0=function(){return+new Date();};}}return{'elapsed':_0xfc18df,'timeStamp':_0x550dc0,'now':()=>Date['now']()};}function K(_0xde329e,_0x785fc,_0x13f5ee,_0x3aa4b3,_0x360a68,_0x55587c){const _0x562879=_0xfef7c3;_0xde329e=_0xde329e,_0x785fc=_0x785fc,_0x13f5ee=_0x13f5ee,_0x3aa4b3=_0x3aa4b3,_0x360a68=_0x360a68,_0x360a68=_0x360a68||{},_0x360a68[_0x562879(0x16c)]=_0x360a68[_0x562879(0x16c)]||{},_0x360a68[_0x562879(0x1bc)]=_0x360a68[_0x562879(0x1bc)]||{},_0x360a68[_0x562879(0xe1)]=_0x360a68['reducePolicy']||{},_0x360a68['reducePolicy'][_0x562879(0x163)]=_0x360a68[_0x562879(0xe1)]['perLogpoint']||{},_0x360a68[_0x562879(0xe1)][_0x562879(0x105)]=_0x360a68[_0x562879(0xe1)]['global']||{};let _0x26d6e9={'perLogpoint':{'reduceOnCount':_0x360a68[_0x562879(0xe1)]['perLogpoint'][_0x562879(0x15b)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x360a68[_0x562879(0xe1)][_0x562879(0x163)][_0x562879(0x198)]||0x64,'resetWhenQuietMs':_0x360a68[_0x562879(0xe1)][_0x562879(0x163)]['resetWhenQuietMs']||0x1f4,'resetOnProcessingTimeAverageMs':_0x360a68[_0x562879(0xe1)]['perLogpoint'][_0x562879(0xda)]||0x64},'global':{'reduceOnCount':_0x360a68[_0x562879(0xe1)][_0x562879(0x105)][_0x562879(0x15b)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x360a68[_0x562879(0xe1)]['global'][_0x562879(0x198)]||0x12c,'resetWhenQuietMs':_0x360a68[_0x562879(0xe1)][_0x562879(0x105)][_0x562879(0xf7)]||0x32,'resetOnProcessingTimeAverageMs':_0x360a68[_0x562879(0xe1)]['global'][_0x562879(0xda)]||0x64}},_0x5e2ce0=G(_0xde329e),_0x3325c4=_0x5e2ce0['elapsed'],_0x5a5b65=_0x5e2ce0[_0x562879(0x182)];function _0xe22103(){const _0x17a460=_0x562879;this['_keyStrRegExp']=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x17a460(0xf2)]=/^(0|[1-9][0-9]*)$/,this['_quotedRegExp']=/'([^\\\\']|\\\\')*'/,this[_0x17a460(0x170)]=_0xde329e[_0x17a460(0x143)],this[_0x17a460(0xbc)]=_0xde329e[_0x17a460(0xfd)],this[_0x17a460(0x13e)]=Object[_0x17a460(0x11c)],this[_0x17a460(0x161)]=Object[_0x17a460(0x149)],this[_0x17a460(0x1c0)]=_0xde329e[_0x17a460(0x129)],this[_0x17a460(0x155)]=RegExp[_0x17a460(0x1b4)][_0x17a460(0x103)],this[_0x17a460(0xc6)]=Date[_0x17a460(0x1b4)]['toString'];}_0xe22103[_0x562879(0x1b4)][_0x562879(0x17c)]=function(_0x5144ba,_0x5064cd,_0x7486dc,_0x419555){const _0x44ee5c=_0x562879;var _0x5267a9=this,_0x29f4cc=_0x7486dc['autoExpand'];function _0x538a07(_0x3c931f,_0x39b529,_0x3c20e0){const _0x412bd4=_0x4231;_0x39b529[_0x412bd4(0xc2)]=_0x412bd4(0x1c7),_0x39b529[_0x412bd4(0xb3)]=_0x3c931f[_0x412bd4(0x1a4)],_0x2f7e9c=_0x3c20e0['node'][_0x412bd4(0x197)],_0x3c20e0['node'][_0x412bd4(0x197)]=_0x39b529,_0x5267a9[_0x412bd4(0x18c)](_0x39b529,_0x3c20e0);}let _0x31d6df,_0x455dd1,_0x49f90a=_0xde329e['ninjaSuppressConsole'];_0xde329e['ninjaSuppressConsole']=!0x0,_0xde329e[_0x44ee5c(0xce)]&&(_0x31d6df=_0xde329e[_0x44ee5c(0xce)][_0x44ee5c(0xb3)],_0x455dd1=_0xde329e['console'][_0x44ee5c(0x13f)],_0x31d6df&&(_0xde329e[_0x44ee5c(0xce)]['error']=function(){}),_0x455dd1&&(_0xde329e[_0x44ee5c(0xce)][_0x44ee5c(0x13f)]=function(){}));try{try{_0x7486dc[_0x44ee5c(0xf1)]++,_0x7486dc['autoExpand']&&_0x7486dc[_0x44ee5c(0xed)][_0x44ee5c(0x1a7)](_0x5064cd);var _0xd1cc4d,_0x485e34,_0x410acb,_0x40cf0d,_0x25ef46=[],_0x44c65b=[],_0x323509,_0x547dce=this[_0x44ee5c(0xb4)](_0x5064cd),_0x1fd4cd=_0x547dce===_0x44ee5c(0x1dc),_0x373aaa=!0x1,_0xc4e03=_0x547dce==='function',_0x29f812=this['_isPrimitiveType'](_0x547dce),_0x889011=this[_0x44ee5c(0x114)](_0x547dce),_0x11ddd5=_0x29f812||_0x889011,_0x2bb558={},_0x122f17=0x0,_0x594314=!0x1,_0x2f7e9c,_0xf3c2cc=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x7486dc[_0x44ee5c(0xf9)]){if(_0x1fd4cd){if(_0x485e34=_0x5064cd['length'],_0x485e34>_0x7486dc[_0x44ee5c(0xc5)]){for(_0x410acb=0x0,_0x40cf0d=_0x7486dc[_0x44ee5c(0xc5)],_0xd1cc4d=_0x410acb;_0xd1cc4d<_0x40cf0d;_0xd1cc4d++)_0x44c65b[_0x44ee5c(0x1a7)](_0x5267a9[_0x44ee5c(0x10c)](_0x25ef46,_0x5064cd,_0x547dce,_0xd1cc4d,_0x7486dc));_0x5144ba[_0x44ee5c(0x124)]=!0x0;}else{for(_0x410acb=0x0,_0x40cf0d=_0x485e34,_0xd1cc4d=_0x410acb;_0xd1cc4d<_0x40cf0d;_0xd1cc4d++)_0x44c65b[_0x44ee5c(0x1a7)](_0x5267a9[_0x44ee5c(0x10c)](_0x25ef46,_0x5064cd,_0x547dce,_0xd1cc4d,_0x7486dc));}_0x7486dc[_0x44ee5c(0x153)]+=_0x44c65b[_0x44ee5c(0x16b)];}if(!(_0x547dce===_0x44ee5c(0x15c)||_0x547dce===_0x44ee5c(0x143))&&!_0x29f812&&_0x547dce!=='String'&&_0x547dce!==_0x44ee5c(0xb1)&&_0x547dce!==_0x44ee5c(0x17f)){var _0x32bb8c=_0x419555[_0x44ee5c(0xdb)]||_0x7486dc[_0x44ee5c(0xdb)];if(this[_0x44ee5c(0x116)](_0x5064cd)?(_0xd1cc4d=0x0,_0x5064cd['forEach'](function(_0x5b59b5){const _0x2a6199=_0x44ee5c;if(_0x122f17++,_0x7486dc['autoExpandPropertyCount']++,_0x122f17>_0x32bb8c){_0x594314=!0x0;return;}if(!_0x7486dc[_0x2a6199(0xe2)]&&_0x7486dc[_0x2a6199(0x189)]&&_0x7486dc['autoExpandPropertyCount']>_0x7486dc[_0x2a6199(0x145)]){_0x594314=!0x0;return;}_0x44c65b[_0x2a6199(0x1a7)](_0x5267a9['_addProperty'](_0x25ef46,_0x5064cd,_0x2a6199(0x1d9),_0xd1cc4d++,_0x7486dc,function(_0x4f4af5){return function(){return _0x4f4af5;};}(_0x5b59b5)));})):this[_0x44ee5c(0x15f)](_0x5064cd)&&_0x5064cd[_0x44ee5c(0x100)](function(_0xdc2845,_0x12701e){const _0x45ad87=_0x44ee5c;if(_0x122f17++,_0x7486dc['autoExpandPropertyCount']++,_0x122f17>_0x32bb8c){_0x594314=!0x0;return;}if(!_0x7486dc[_0x45ad87(0xe2)]&&_0x7486dc[_0x45ad87(0x189)]&&_0x7486dc[_0x45ad87(0x153)]>_0x7486dc['autoExpandLimit']){_0x594314=!0x0;return;}var _0x15476b=_0x12701e[_0x45ad87(0x103)]();_0x15476b[_0x45ad87(0x16b)]>0x64&&(_0x15476b=_0x15476b[_0x45ad87(0x102)](0x0,0x64)+_0x45ad87(0x120)),_0x44c65b[_0x45ad87(0x1a7)](_0x5267a9[_0x45ad87(0x10c)](_0x25ef46,_0x5064cd,_0x45ad87(0x1ab),_0x15476b,_0x7486dc,function(_0x3de865){return function(){return _0x3de865;};}(_0xdc2845)));}),!_0x373aaa){try{for(_0x323509 in _0x5064cd)if(!(_0x1fd4cd&&_0xf3c2cc['test'](_0x323509))&&!this[_0x44ee5c(0x1bb)](_0x5064cd,_0x323509,_0x7486dc)){if(_0x122f17++,_0x7486dc['autoExpandPropertyCount']++,_0x122f17>_0x32bb8c){_0x594314=!0x0;break;}if(!_0x7486dc['isExpressionToEvaluate']&&_0x7486dc[_0x44ee5c(0x189)]&&_0x7486dc[_0x44ee5c(0x153)]>_0x7486dc['autoExpandLimit']){_0x594314=!0x0;break;}_0x44c65b['push'](_0x5267a9['_addObjectProperty'](_0x25ef46,_0x2bb558,_0x5064cd,_0x547dce,_0x323509,_0x7486dc));}}catch{}if(_0x2bb558[_0x44ee5c(0xfe)]=!0x0,_0xc4e03&&(_0x2bb558[_0x44ee5c(0xea)]=!0x0),!_0x594314){var _0x24288f=[][_0x44ee5c(0x13b)](this[_0x44ee5c(0x161)](_0x5064cd))[_0x44ee5c(0x13b)](this[_0x44ee5c(0x146)](_0x5064cd));for(_0xd1cc4d=0x0,_0x485e34=_0x24288f[_0x44ee5c(0x16b)];_0xd1cc4d<_0x485e34;_0xd1cc4d++)if(_0x323509=_0x24288f[_0xd1cc4d],!(_0x1fd4cd&&_0xf3c2cc['test'](_0x323509[_0x44ee5c(0x103)]()))&&!this[_0x44ee5c(0x1bb)](_0x5064cd,_0x323509,_0x7486dc)&&!_0x2bb558[typeof _0x323509!='symbol'?_0x44ee5c(0x168)+_0x323509[_0x44ee5c(0x103)]():_0x323509]){if(_0x122f17++,_0x7486dc['autoExpandPropertyCount']++,_0x122f17>_0x32bb8c){_0x594314=!0x0;break;}if(!_0x7486dc[_0x44ee5c(0xe2)]&&_0x7486dc['autoExpand']&&_0x7486dc[_0x44ee5c(0x153)]>_0x7486dc[_0x44ee5c(0x145)]){_0x594314=!0x0;break;}_0x44c65b[_0x44ee5c(0x1a7)](_0x5267a9[_0x44ee5c(0x1a1)](_0x25ef46,_0x2bb558,_0x5064cd,_0x547dce,_0x323509,_0x7486dc));}}}}}if(_0x5144ba[_0x44ee5c(0xc2)]=_0x547dce,_0x11ddd5?(_0x5144ba[_0x44ee5c(0x111)]=_0x5064cd[_0x44ee5c(0x180)](),this[_0x44ee5c(0x154)](_0x547dce,_0x5144ba,_0x7486dc,_0x419555)):_0x547dce===_0x44ee5c(0x17d)?_0x5144ba[_0x44ee5c(0x111)]=this[_0x44ee5c(0xc6)][_0x44ee5c(0xd2)](_0x5064cd):_0x547dce===_0x44ee5c(0x17f)?_0x5144ba['value']=_0x5064cd[_0x44ee5c(0x103)]():_0x547dce===_0x44ee5c(0x144)?_0x5144ba[_0x44ee5c(0x111)]=this['_regExpToString'][_0x44ee5c(0xd2)](_0x5064cd):_0x547dce===_0x44ee5c(0x160)&&this[_0x44ee5c(0x1c0)]?_0x5144ba[_0x44ee5c(0x111)]=this['_Symbol'][_0x44ee5c(0x1b4)][_0x44ee5c(0x103)][_0x44ee5c(0xd2)](_0x5064cd):!_0x7486dc[_0x44ee5c(0xf9)]&&!(_0x547dce==='null'||_0x547dce==='undefined')&&(delete _0x5144ba['value'],_0x5144ba[_0x44ee5c(0x19e)]=!0x0),_0x594314&&(_0x5144ba[_0x44ee5c(0x159)]=!0x0),_0x2f7e9c=_0x7486dc[_0x44ee5c(0x117)][_0x44ee5c(0x197)],_0x7486dc[_0x44ee5c(0x117)][_0x44ee5c(0x197)]=_0x5144ba,this[_0x44ee5c(0x18c)](_0x5144ba,_0x7486dc),_0x44c65b[_0x44ee5c(0x16b)]){for(_0xd1cc4d=0x0,_0x485e34=_0x44c65b[_0x44ee5c(0x16b)];_0xd1cc4d<_0x485e34;_0xd1cc4d++)_0x44c65b[_0xd1cc4d](_0xd1cc4d);}_0x25ef46[_0x44ee5c(0x16b)]&&(_0x5144ba[_0x44ee5c(0xdb)]=_0x25ef46);}catch(_0x6edfde){_0x538a07(_0x6edfde,_0x5144ba,_0x7486dc);}this[_0x44ee5c(0x1cc)](_0x5064cd,_0x5144ba),this[_0x44ee5c(0x158)](_0x5144ba,_0x7486dc),_0x7486dc[_0x44ee5c(0x117)][_0x44ee5c(0x197)]=_0x2f7e9c,_0x7486dc[_0x44ee5c(0xf1)]--,_0x7486dc[_0x44ee5c(0x189)]=_0x29f4cc,_0x7486dc['autoExpand']&&_0x7486dc[_0x44ee5c(0xed)][_0x44ee5c(0x1d4)]();}finally{_0x31d6df&&(_0xde329e[_0x44ee5c(0xce)][_0x44ee5c(0xb3)]=_0x31d6df),_0x455dd1&&(_0xde329e[_0x44ee5c(0xce)][_0x44ee5c(0x13f)]=_0x455dd1),_0xde329e['ninjaSuppressConsole']=_0x49f90a;}return _0x5144ba;},_0xe22103['prototype']['_getOwnPropertySymbols']=function(_0x5b6575){const _0x4abdfd=_0x562879;return Object['getOwnPropertySymbols']?Object[_0x4abdfd(0xd5)](_0x5b6575):[];},_0xe22103['prototype'][_0x562879(0x116)]=function(_0x5319a7){const _0x474ebb=_0x562879;return!!(_0x5319a7&&_0xde329e[_0x474ebb(0x1d9)]&&this[_0x474ebb(0x1a5)](_0x5319a7)===_0x474ebb(0x196)&&_0x5319a7[_0x474ebb(0x100)]);},_0xe22103[_0x562879(0x1b4)][_0x562879(0x1bb)]=function(_0x4867ca,_0x3c0451,_0x49989f){const _0x4551e4=_0x562879;if(!_0x49989f[_0x4551e4(0xc1)]){let _0x2b9395=this[_0x4551e4(0x13e)](_0x4867ca,_0x3c0451);if(_0x2b9395&&_0x2b9395[_0x4551e4(0xb5)])return!0x0;}return _0x49989f['noFunctions']?typeof _0x4867ca[_0x3c0451]==_0x4551e4(0x1d6):!0x1;},_0xe22103[_0x562879(0x1b4)]['_type']=function(_0x331266){const _0x256e00=_0x562879;var _0x4c037c='';return _0x4c037c=typeof _0x331266,_0x4c037c===_0x256e00(0x10e)?this['_objectToString'](_0x331266)==='[object\\x20Array]'?_0x4c037c=_0x256e00(0x1dc):this[_0x256e00(0x1a5)](_0x331266)===_0x256e00(0x166)?_0x4c037c=_0x256e00(0x17d):this[_0x256e00(0x1a5)](_0x331266)===_0x256e00(0x1a0)?_0x4c037c=_0x256e00(0x17f):_0x331266===null?_0x4c037c=_0x256e00(0x15c):_0x331266['constructor']&&(_0x4c037c=_0x331266['constructor'][_0x256e00(0x1b5)]||_0x4c037c):_0x4c037c==='undefined'&&this[_0x256e00(0xbc)]&&_0x331266 instanceof this[_0x256e00(0xbc)]&&(_0x4c037c=_0x256e00(0xfd)),_0x4c037c;},_0xe22103[_0x562879(0x1b4)][_0x562879(0x1a5)]=function(_0x1abe11){const _0x220ac9=_0x562879;return Object[_0x220ac9(0x1b4)][_0x220ac9(0x103)][_0x220ac9(0xd2)](_0x1abe11);},_0xe22103[_0x562879(0x1b4)][_0x562879(0x179)]=function(_0x4c3da4){const _0x492ab6=_0x562879;return _0x4c3da4===_0x492ab6(0x1b3)||_0x4c3da4==='string'||_0x4c3da4===_0x492ab6(0x136);},_0xe22103['prototype']['_isPrimitiveWrapperType']=function(_0x4a4861){const _0x42ea04=_0x562879;return _0x4a4861===_0x42ea04(0x1c1)||_0x4a4861==='String'||_0x4a4861===_0x42ea04(0x12d);},_0xe22103[_0x562879(0x1b4)][_0x562879(0x10c)]=function(_0x4159cb,_0x44274f,_0xcdaa48,_0x3fc2e0,_0x3bbcba,_0x1e9b99){var _0x3d7697=this;return function(_0x401cbd){const _0x1a7e99=_0x4231;var _0x11db13=_0x3bbcba[_0x1a7e99(0x117)]['current'],_0xaa715c=_0x3bbcba[_0x1a7e99(0x117)][_0x1a7e99(0x1be)],_0x323c1a=_0x3bbcba[_0x1a7e99(0x117)][_0x1a7e99(0x1d1)];_0x3bbcba[_0x1a7e99(0x117)]['parent']=_0x11db13,_0x3bbcba[_0x1a7e99(0x117)][_0x1a7e99(0x1be)]=typeof _0x3fc2e0==_0x1a7e99(0x136)?_0x3fc2e0:_0x401cbd,_0x4159cb[_0x1a7e99(0x1a7)](_0x3d7697['_property'](_0x44274f,_0xcdaa48,_0x3fc2e0,_0x3bbcba,_0x1e9b99)),_0x3bbcba[_0x1a7e99(0x117)][_0x1a7e99(0x1d1)]=_0x323c1a,_0x3bbcba[_0x1a7e99(0x117)][_0x1a7e99(0x1be)]=_0xaa715c;};},_0xe22103['prototype'][_0x562879(0x1a1)]=function(_0x6c4e1,_0x1408b8,_0x820d6c,_0x296877,_0x2a0723,_0x11b190,_0x2fc10f){const _0x57445b=_0x562879;var _0x35a84a=this;return _0x1408b8[typeof _0x2a0723!=_0x57445b(0x160)?_0x57445b(0x168)+_0x2a0723[_0x57445b(0x103)]():_0x2a0723]=!0x0,function(_0x459efb){const _0x25b047=_0x57445b;var _0x147e88=_0x11b190['node'][_0x25b047(0x197)],_0x2d7c87=_0x11b190[_0x25b047(0x117)][_0x25b047(0x1be)],_0xa4e87d=_0x11b190['node']['parent'];_0x11b190['node'][_0x25b047(0x1d1)]=_0x147e88,_0x11b190[_0x25b047(0x117)]['index']=_0x459efb,_0x6c4e1[_0x25b047(0x1a7)](_0x35a84a['_property'](_0x820d6c,_0x296877,_0x2a0723,_0x11b190,_0x2fc10f)),_0x11b190[_0x25b047(0x117)]['parent']=_0xa4e87d,_0x11b190[_0x25b047(0x117)][_0x25b047(0x1be)]=_0x2d7c87;};},_0xe22103['prototype'][_0x562879(0x18d)]=function(_0x252c06,_0x33e523,_0x2f5dcf,_0x541aa3,_0x9a373f){const _0x2d4e88=_0x562879;var _0x22716a=this;_0x9a373f||(_0x9a373f=function(_0x1c879f,_0x24697e){return _0x1c879f[_0x24697e];});var _0x11e69d=_0x2f5dcf[_0x2d4e88(0x103)](),_0x246f01=_0x541aa3['expressionsToEvaluate']||{},_0x4c2699=_0x541aa3[_0x2d4e88(0xf9)],_0xd9304d=_0x541aa3[_0x2d4e88(0xe2)];try{var _0x458534=this[_0x2d4e88(0x15f)](_0x252c06),_0x225169=_0x11e69d;_0x458534&&_0x225169[0x0]==='\\x27'&&(_0x225169=_0x225169[_0x2d4e88(0xb7)](0x1,_0x225169['length']-0x2));var _0x1ec080=_0x541aa3['expressionsToEvaluate']=_0x246f01[_0x2d4e88(0x168)+_0x225169];_0x1ec080&&(_0x541aa3[_0x2d4e88(0xf9)]=_0x541aa3[_0x2d4e88(0xf9)]+0x1),_0x541aa3[_0x2d4e88(0xe2)]=!!_0x1ec080;var _0x2fb7c4=typeof _0x2f5dcf=='symbol',_0x303a4b={'name':_0x2fb7c4||_0x458534?_0x11e69d:this[_0x2d4e88(0x162)](_0x11e69d)};if(_0x2fb7c4&&(_0x303a4b[_0x2d4e88(0x160)]=!0x0),!(_0x33e523===_0x2d4e88(0x1dc)||_0x33e523==='Error')){var _0x424a97=this[_0x2d4e88(0x13e)](_0x252c06,_0x2f5dcf);if(_0x424a97&&(_0x424a97[_0x2d4e88(0x195)]&&(_0x303a4b['setter']=!0x0),_0x424a97['get']&&!_0x1ec080&&!_0x541aa3[_0x2d4e88(0xc1)]))return _0x303a4b['getter']=!0x0,this[_0x2d4e88(0x1b0)](_0x303a4b,_0x541aa3),_0x303a4b;}var _0x668b7d;try{_0x668b7d=_0x9a373f(_0x252c06,_0x2f5dcf);}catch(_0x48b68e){return _0x303a4b={'name':_0x11e69d,'type':'unknown','error':_0x48b68e[_0x2d4e88(0x1a4)]},this[_0x2d4e88(0x1b0)](_0x303a4b,_0x541aa3),_0x303a4b;}var _0x556df7=this[_0x2d4e88(0xb4)](_0x668b7d),_0xf3895c=this[_0x2d4e88(0x179)](_0x556df7);if(_0x303a4b[_0x2d4e88(0xc2)]=_0x556df7,_0xf3895c)this[_0x2d4e88(0x1b0)](_0x303a4b,_0x541aa3,_0x668b7d,function(){const _0x36499e=_0x2d4e88;_0x303a4b[_0x36499e(0x111)]=_0x668b7d[_0x36499e(0x180)](),!_0x1ec080&&_0x22716a[_0x36499e(0x154)](_0x556df7,_0x303a4b,_0x541aa3,{});});else{var _0x3bf3ac=_0x541aa3[_0x2d4e88(0x189)]&&_0x541aa3[_0x2d4e88(0xf1)]<_0x541aa3['autoExpandMaxDepth']&&_0x541aa3['autoExpandPreviousObjects'][_0x2d4e88(0x1b6)](_0x668b7d)<0x0&&_0x556df7!==_0x2d4e88(0x1d6)&&_0x541aa3['autoExpandPropertyCount']<_0x541aa3[_0x2d4e88(0x145)];_0x3bf3ac||_0x541aa3[_0x2d4e88(0xf1)]<_0x4c2699||_0x1ec080?this['serialize'](_0x303a4b,_0x668b7d,_0x541aa3,_0x1ec080||{}):this['_processTreeNodeResult'](_0x303a4b,_0x541aa3,_0x668b7d,function(){const _0x4b6f2d=_0x2d4e88;_0x556df7===_0x4b6f2d(0x15c)||_0x556df7===_0x4b6f2d(0x143)||(delete _0x303a4b['value'],_0x303a4b[_0x4b6f2d(0x19e)]=!0x0);});}return _0x303a4b;}finally{_0x541aa3[_0x2d4e88(0x183)]=_0x246f01,_0x541aa3[_0x2d4e88(0xf9)]=_0x4c2699,_0x541aa3[_0x2d4e88(0xe2)]=_0xd9304d;}},_0xe22103['prototype'][_0x562879(0x154)]=function(_0x56dd40,_0x319695,_0x39ffa3,_0x8cf11d){const _0x3fca6d=_0x562879;var _0x1d78bf=_0x8cf11d[_0x3fca6d(0x113)]||_0x39ffa3[_0x3fca6d(0x113)];if((_0x56dd40==='string'||_0x56dd40==='String')&&_0x319695[_0x3fca6d(0x111)]){let _0x3276f6=_0x319695[_0x3fca6d(0x111)][_0x3fca6d(0x16b)];_0x39ffa3['allStrLength']+=_0x3276f6,_0x39ffa3[_0x3fca6d(0xde)]>_0x39ffa3['totalStrLength']?(_0x319695[_0x3fca6d(0x19e)]='',delete _0x319695[_0x3fca6d(0x111)]):_0x3276f6>_0x1d78bf&&(_0x319695[_0x3fca6d(0x19e)]=_0x319695[_0x3fca6d(0x111)][_0x3fca6d(0xb7)](0x0,_0x1d78bf),delete _0x319695[_0x3fca6d(0x111)]);}},_0xe22103[_0x562879(0x1b4)]['_isMap']=function(_0x259b38){const _0x2f4364=_0x562879;return!!(_0x259b38&&_0xde329e[_0x2f4364(0x1ab)]&&this['_objectToString'](_0x259b38)==='[object\\x20Map]'&&_0x259b38['forEach']);},_0xe22103['prototype']['_propertyName']=function(_0x1493b9){const _0x378923=_0x562879;if(_0x1493b9[_0x378923(0x1e2)](/^\\d+$/))return _0x1493b9;var _0x2e1798;try{_0x2e1798=JSON['stringify'](''+_0x1493b9);}catch{_0x2e1798='\\x22'+this['_objectToString'](_0x1493b9)+'\\x22';}return _0x2e1798[_0x378923(0x1e2)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x2e1798=_0x2e1798['substr'](0x1,_0x2e1798[_0x378923(0x16b)]-0x2):_0x2e1798=_0x2e1798[_0x378923(0x150)](/'/g,'\\x5c\\x27')['replace'](/\\\\\"/g,'\\x22')['replace'](/(^\"|\"$)/g,'\\x27'),_0x2e1798;},_0xe22103[_0x562879(0x1b4)][_0x562879(0x1b0)]=function(_0xd0c245,_0x5967d0,_0x4aa9f6,_0x27ccfb){const _0xc2d614=_0x562879;this[_0xc2d614(0x18c)](_0xd0c245,_0x5967d0),_0x27ccfb&&_0x27ccfb(),this[_0xc2d614(0x1cc)](_0x4aa9f6,_0xd0c245),this[_0xc2d614(0x158)](_0xd0c245,_0x5967d0);},_0xe22103[_0x562879(0x1b4)]['_treeNodePropertiesBeforeFullValue']=function(_0x129962,_0xbe5bd2){const _0x421854=_0x562879;this[_0x421854(0x1af)](_0x129962,_0xbe5bd2),this[_0x421854(0x13d)](_0x129962,_0xbe5bd2),this[_0x421854(0x199)](_0x129962,_0xbe5bd2),this[_0x421854(0x188)](_0x129962,_0xbe5bd2);},_0xe22103[_0x562879(0x1b4)][_0x562879(0x1af)]=function(_0x43aaa1,_0x2f2a44){},_0xe22103['prototype'][_0x562879(0x13d)]=function(_0xd3c034,_0x50e2f1){},_0xe22103[_0x562879(0x1b4)][_0x562879(0x176)]=function(_0x2d050a,_0xf7eb29){},_0xe22103[_0x562879(0x1b4)][_0x562879(0xf0)]=function(_0x44f730){const _0x2e9320=_0x562879;return _0x44f730===this[_0x2e9320(0x170)];},_0xe22103[_0x562879(0x1b4)][_0x562879(0x158)]=function(_0x4b6e16,_0xe4367){const _0x3bafe0=_0x562879;this[_0x3bafe0(0x176)](_0x4b6e16,_0xe4367),this[_0x3bafe0(0x122)](_0x4b6e16),_0xe4367[_0x3bafe0(0x14d)]&&this[_0x3bafe0(0xb9)](_0x4b6e16),this['_addFunctionsNode'](_0x4b6e16,_0xe4367),this[_0x3bafe0(0x15e)](_0x4b6e16,_0xe4367),this[_0x3bafe0(0x152)](_0x4b6e16);},_0xe22103[_0x562879(0x1b4)][_0x562879(0x1cc)]=function(_0x79db83,_0x4a393d){const _0x5a6628=_0x562879;try{_0x79db83&&typeof _0x79db83[_0x5a6628(0x16b)]==_0x5a6628(0x136)&&(_0x4a393d['length']=_0x79db83[_0x5a6628(0x16b)]);}catch{}if(_0x4a393d['type']===_0x5a6628(0x136)||_0x4a393d[_0x5a6628(0xc2)]===_0x5a6628(0x12d)){if(isNaN(_0x4a393d[_0x5a6628(0x111)]))_0x4a393d[_0x5a6628(0x1e3)]=!0x0,delete _0x4a393d['value'];else switch(_0x4a393d[_0x5a6628(0x111)]){case Number[_0x5a6628(0x190)]:_0x4a393d['positiveInfinity']=!0x0,delete _0x4a393d[_0x5a6628(0x111)];break;case Number[_0x5a6628(0x157)]:_0x4a393d[_0x5a6628(0x1b7)]=!0x0,delete _0x4a393d[_0x5a6628(0x111)];break;case 0x0:this[_0x5a6628(0xd8)](_0x4a393d['value'])&&(_0x4a393d[_0x5a6628(0x115)]=!0x0);break;}}else _0x4a393d[_0x5a6628(0xc2)]===_0x5a6628(0x1d6)&&typeof _0x79db83[_0x5a6628(0x1b5)]=='string'&&_0x79db83['name']&&_0x4a393d[_0x5a6628(0x1b5)]&&_0x79db83['name']!==_0x4a393d[_0x5a6628(0x1b5)]&&(_0x4a393d[_0x5a6628(0x118)]=_0x79db83[_0x5a6628(0x1b5)]);},_0xe22103[_0x562879(0x1b4)]['_isNegativeZero']=function(_0x500a74){const _0x5546c5=_0x562879;return 0x1/_0x500a74===Number[_0x5546c5(0x157)];},_0xe22103['prototype'][_0x562879(0xb9)]=function(_0xf75cac){const _0x1b9876=_0x562879;!_0xf75cac[_0x1b9876(0xdb)]||!_0xf75cac[_0x1b9876(0xdb)][_0x1b9876(0x16b)]||_0xf75cac[_0x1b9876(0xc2)]==='array'||_0xf75cac['type']===_0x1b9876(0x1ab)||_0xf75cac['type']==='Set'||_0xf75cac[_0x1b9876(0xdb)][_0x1b9876(0x1ca)](function(_0x3068cf,_0x2b199b){const _0x1e62ea=_0x1b9876;var _0x27591a=_0x3068cf['name'][_0x1e62ea(0x14e)](),_0x105336=_0x2b199b[_0x1e62ea(0x1b5)][_0x1e62ea(0x14e)]();return _0x27591a<_0x105336?-0x1:_0x27591a>_0x105336?0x1:0x0;});},_0xe22103[_0x562879(0x1b4)][_0x562879(0xe9)]=function(_0x2274bf,_0x119890){const _0x326958=_0x562879;if(!(_0x119890[_0x326958(0xbf)]||!_0x2274bf[_0x326958(0xdb)]||!_0x2274bf[_0x326958(0xdb)][_0x326958(0x16b)])){for(var _0x12525f=[],_0x5b7005=[],_0x4eea28=0x0,_0x300727=_0x2274bf[_0x326958(0xdb)][_0x326958(0x16b)];_0x4eea28<_0x300727;_0x4eea28++){var _0x9ee093=_0x2274bf[_0x326958(0xdb)][_0x4eea28];_0x9ee093[_0x326958(0xc2)]===_0x326958(0x1d6)?_0x12525f['push'](_0x9ee093):_0x5b7005[_0x326958(0x1a7)](_0x9ee093);}if(!(!_0x5b7005[_0x326958(0x16b)]||_0x12525f[_0x326958(0x16b)]<=0x1)){_0x2274bf[_0x326958(0xdb)]=_0x5b7005;var _0x10804e={'functionsNode':!0x0,'props':_0x12525f};this[_0x326958(0x1af)](_0x10804e,_0x119890),this[_0x326958(0x176)](_0x10804e,_0x119890),this['_setNodeExpandableState'](_0x10804e),this['_setNodePermissions'](_0x10804e,_0x119890),_0x10804e['id']+='\\x20f',_0x2274bf[_0x326958(0xdb)]['unshift'](_0x10804e);}}},_0xe22103[_0x562879(0x1b4)]['_addLoadNode']=function(_0x4a947f,_0x36d8ef){},_0xe22103[_0x562879(0x1b4)][_0x562879(0x122)]=function(_0x32bc48){},_0xe22103[_0x562879(0x1b4)][_0x562879(0x17b)]=function(_0x5de45e){const _0x2602df=_0x562879;return Array['isArray'](_0x5de45e)||typeof _0x5de45e==_0x2602df(0x10e)&&this[_0x2602df(0x1a5)](_0x5de45e)===_0x2602df(0x1df);},_0xe22103[_0x562879(0x1b4)][_0x562879(0x188)]=function(_0x517532,_0x4267c2){},_0xe22103['prototype']['_cleanNode']=function(_0xc6fc84){const _0x2db5cd=_0x562879;delete _0xc6fc84[_0x2db5cd(0x1e5)],delete _0xc6fc84[_0x2db5cd(0x12f)],delete _0xc6fc84['_hasMapOnItsPath'];},_0xe22103[_0x562879(0x1b4)][_0x562879(0x199)]=function(_0xfa38cf,_0x549a97){};let _0x1fdc1c=new _0xe22103(),_0x543b82={'props':_0x360a68[_0x562879(0x16c)][_0x562879(0xdb)]||0x64,'elements':_0x360a68[_0x562879(0x16c)][_0x562879(0xc5)]||0x64,'strLength':_0x360a68[_0x562879(0x16c)]['strLength']||0x400*0x32,'totalStrLength':_0x360a68[_0x562879(0x16c)]['totalStrLength']||0x400*0x32,'autoExpandLimit':_0x360a68[_0x562879(0x16c)][_0x562879(0x145)]||0x1388,'autoExpandMaxDepth':_0x360a68[_0x562879(0x16c)][_0x562879(0x186)]||0xa},_0x4343a2={'props':_0x360a68[_0x562879(0x1bc)][_0x562879(0xdb)]||0x5,'elements':_0x360a68[_0x562879(0x1bc)][_0x562879(0xc5)]||0x5,'strLength':_0x360a68['reducedLimits'][_0x562879(0x113)]||0x100,'totalStrLength':_0x360a68[_0x562879(0x1bc)][_0x562879(0x110)]||0x100*0x3,'autoExpandLimit':_0x360a68[_0x562879(0x1bc)][_0x562879(0x145)]||0x1e,'autoExpandMaxDepth':_0x360a68[_0x562879(0x1bc)][_0x562879(0x186)]||0x2};if(_0x55587c){let _0x588ef=_0x1fdc1c[_0x562879(0x17c)][_0x562879(0xe6)](_0x1fdc1c);_0x1fdc1c[_0x562879(0x17c)]=function(_0x511334,_0x4c659a,_0x13177c,_0x262125){return _0x588ef(_0x511334,_0x55587c(_0x4c659a),_0x13177c,_0x262125);};}function _0x4bf320(_0x4bd3a4,_0x461925,_0x511689,_0x290464,_0x47060c,_0x5696a9){const _0x2ae74a=_0x562879;let _0x5f494a,_0x428717;try{_0x428717=_0x5a5b65(),_0x5f494a=_0x13f5ee[_0x461925],!_0x5f494a||_0x428717-_0x5f494a['ts']>_0x26d6e9[_0x2ae74a(0x163)][_0x2ae74a(0xf7)]&&_0x5f494a[_0x2ae74a(0x11b)]&&_0x5f494a['time']/_0x5f494a[_0x2ae74a(0x11b)]<_0x26d6e9[_0x2ae74a(0x163)][_0x2ae74a(0xda)]?(_0x13f5ee[_0x461925]=_0x5f494a={'count':0x0,'time':0x0,'ts':_0x428717},_0x13f5ee[_0x2ae74a(0xf5)]={}):_0x428717-_0x13f5ee[_0x2ae74a(0xf5)]['ts']>_0x26d6e9['global'][_0x2ae74a(0xf7)]&&_0x13f5ee[_0x2ae74a(0xf5)]['count']&&_0x13f5ee[_0x2ae74a(0xf5)]['time']/_0x13f5ee[_0x2ae74a(0xf5)]['count']<_0x26d6e9[_0x2ae74a(0x105)][_0x2ae74a(0xda)]&&(_0x13f5ee[_0x2ae74a(0xf5)]={});let _0x564dbd=[],_0x5444c0=_0x5f494a[_0x2ae74a(0x128)]||_0x13f5ee[_0x2ae74a(0xf5)][_0x2ae74a(0x128)]?_0x4343a2:_0x543b82,_0x8a9e5d=_0x4ae232=>{const _0x1f9142=_0x2ae74a;let _0x3e8005={};return _0x3e8005[_0x1f9142(0xdb)]=_0x4ae232[_0x1f9142(0xdb)],_0x3e8005[_0x1f9142(0xc5)]=_0x4ae232['elements'],_0x3e8005['strLength']=_0x4ae232[_0x1f9142(0x113)],_0x3e8005[_0x1f9142(0x110)]=_0x4ae232[_0x1f9142(0x110)],_0x3e8005[_0x1f9142(0x145)]=_0x4ae232[_0x1f9142(0x145)],_0x3e8005[_0x1f9142(0x186)]=_0x4ae232[_0x1f9142(0x186)],_0x3e8005[_0x1f9142(0x14d)]=!0x1,_0x3e8005[_0x1f9142(0xbf)]=!_0x785fc,_0x3e8005[_0x1f9142(0xf9)]=0x1,_0x3e8005[_0x1f9142(0xf1)]=0x0,_0x3e8005[_0x1f9142(0x19f)]=_0x1f9142(0x1a8),_0x3e8005[_0x1f9142(0xfa)]='root_exp',_0x3e8005[_0x1f9142(0x189)]=!0x0,_0x3e8005[_0x1f9142(0xed)]=[],_0x3e8005[_0x1f9142(0x153)]=0x0,_0x3e8005[_0x1f9142(0xc1)]=_0x360a68[_0x1f9142(0xc1)],_0x3e8005[_0x1f9142(0xde)]=0x0,_0x3e8005[_0x1f9142(0x117)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x3e8005;};for(var _0x283a40=0x0;_0x283a40<_0x47060c[_0x2ae74a(0x16b)];_0x283a40++)_0x564dbd[_0x2ae74a(0x1a7)](_0x1fdc1c[_0x2ae74a(0x17c)]({'timeNode':_0x4bd3a4==='time'||void 0x0},_0x47060c[_0x283a40],_0x8a9e5d(_0x5444c0),{}));if(_0x4bd3a4==='trace'||_0x4bd3a4==='error'){let _0x5d1acf=Error['stackTraceLimit'];try{Error['stackTraceLimit']=0x1/0x0,_0x564dbd[_0x2ae74a(0x1a7)](_0x1fdc1c[_0x2ae74a(0x17c)]({'stackNode':!0x0},new Error()[_0x2ae74a(0xbe)],_0x8a9e5d(_0x5444c0),{'strLength':0x1/0x0}));}finally{Error[_0x2ae74a(0xb8)]=_0x5d1acf;}}return{'method':'log','version':_0x3aa4b3,'args':[{'ts':_0x511689,'session':_0x290464,'args':_0x564dbd,'id':_0x461925,'context':_0x5696a9}]};}catch(_0x4ef522){return{'method':'log','version':_0x3aa4b3,'args':[{'ts':_0x511689,'session':_0x290464,'args':[{'type':_0x2ae74a(0x1c7),'error':_0x4ef522&&_0x4ef522[_0x2ae74a(0x1a4)]}],'id':_0x461925,'context':_0x5696a9}]};}finally{try{if(_0x5f494a&&_0x428717){let _0x250281=_0x5a5b65();_0x5f494a[_0x2ae74a(0x11b)]++,_0x5f494a[_0x2ae74a(0x131)]+=_0x3325c4(_0x428717,_0x250281),_0x5f494a['ts']=_0x250281,_0x13f5ee[_0x2ae74a(0xf5)][_0x2ae74a(0x11b)]++,_0x13f5ee['hits'][_0x2ae74a(0x131)]+=_0x3325c4(_0x428717,_0x250281),_0x13f5ee[_0x2ae74a(0xf5)]['ts']=_0x250281,(_0x5f494a['count']>_0x26d6e9['perLogpoint'][_0x2ae74a(0x15b)]||_0x5f494a[_0x2ae74a(0x131)]>_0x26d6e9[_0x2ae74a(0x163)][_0x2ae74a(0x198)])&&(_0x5f494a[_0x2ae74a(0x128)]=!0x0),(_0x13f5ee[_0x2ae74a(0xf5)][_0x2ae74a(0x11b)]>_0x26d6e9[_0x2ae74a(0x105)][_0x2ae74a(0x15b)]||_0x13f5ee['hits'][_0x2ae74a(0x131)]>_0x26d6e9['global'][_0x2ae74a(0x198)])&&(_0x13f5ee[_0x2ae74a(0xf5)]['reduceLimits']=!0x0);}}catch{}}}return _0x4bf320;}var x=Symbol('ninja'),ce=0xc8,ee=_0xfef7c3(0x13c);((_0x49aa22,_0x4fc619,_0x5d15ae,_0x24d749,_0x4eec44,_0x58521c,_0x4ce7fa,_0x54b14d,_0x10f1b7,_0x1bc6c4,_0x3f9f1f,_0x5655d2)=>{const _0x4ef8e9=_0xfef7c3;if(!Y(_0x49aa22,_0x54b14d,_0x58521c)){_0x49aa22[_0x4ef8e9(0x17a)]=!0x0;return;}if(_0x49aa22[_0x4ef8e9(0x17a)])return;_0x49aa22[_0x4ef8e9(0x17a)]=!0x0;let _0x4dacbb=_0x58521c===_0x4ef8e9(0xef)&&_0x49aa22[_0x4ef8e9(0xdd)]?_0x49aa22[_0x4ef8e9(0xdd)]:void 0x0,_0x5a31ce=!0x1,_0x192c05={},_0x75feb0={},_0x2317bb=()=>{for(let _0x21323c of Object['getOwnPropertyNames'](_0x192c05))delete _0x192c05[_0x21323c];for(let _0x3c5de4 of Object['getOwnPropertyNames'](_0x75feb0))delete _0x75feb0[_0x3c5de4];},_0x1bb450=Z(_0x49aa22,_0x4fc619,_0x5d15ae,_0x24d749,_0x58521c,_0x10f1b7,_0x1bc6c4,(_0x203678,_0x397461,_0x34ba87,_0x3f062e)=>{const _0x57a376=_0x4ef8e9;if(V(_0x203678,_0x397461,_0x34ba87,_0x3f062e),_0x203678===_0x57a376(0x14f)){let _0xb04aeb=_0x397461[0x0];if(_0xb04aeb[_0x57a376(0x142)]('captureRequests')&&_0x4c5ad4(_0xb04aeb[_0x57a376(0x12c)]),_0xb04aeb[_0x57a376(0x142)](_0x57a376(0x17e))){for(let _0x43f513 of _0xb04aeb[_0x57a376(0x17e)]){let _0x529d1f=se(_0x2b8600[_0x57a376(0xaf)],_0x43f513[_0x57a376(0xbe)]);_0x192c05[_0x529d1f]=_0x43f513[_0x57a376(0x10d)];for(let _0x5539b6 of _0x43f513[_0x57a376(0x10d)]){let _0x2fd124=_0x75feb0[_0x5539b6];if(_0x2fd124)_0x2fd124[_0x529d1f]=void 0x0;else{let _0x43759f={};_0x43759f[_0x529d1f]=void 0x0,_0x75feb0[_0x5539b6]=_0x43759f;}}}Object['keys'](_0x192c05)['length']>ce&&(_0x4c5ad4(!0x1),_0x2317bb(),_0x1bb450({'method':_0x57a376(0x1ad),'version':_0x4eec44,'args':[_0x2b8600]}));}if(_0xb04aeb[_0x57a376(0x142)](_0x57a376(0xff)))for(let _0x6d5b97 of _0xb04aeb[_0x57a376(0xff)]){let _0x29ff69=_0x75feb0[_0x6d5b97];if(!!_0x29ff69)for(var _0x42e1bd of Object[_0x57a376(0xd3)](_0x29ff69)){let _0x3823c8=_0x192c05[_0x42e1bd];for(let _0xf7b0b8 of _0x3823c8){let _0x1811ba=_0x75feb0[_0xf7b0b8];_0x1811ba&&delete _0x1811ba[_0x42e1bd],Object[_0x57a376(0xd3)](_0x1811ba)[_0x57a376(0x16b)]||delete _0x75feb0[_0xf7b0b8];}delete _0x192c05[_0x42e1bd];}}}}),_0x2b8600=_0x49aa22[_0x4ef8e9(0x1ac)],_0x2d42cc,_0x2dce61,_0x538498,_0x1230dc,_0x496341=me(_0x2b8600[_0x4ef8e9(0xaf)]);function _0x4c5ad4(_0x9162fb){_0x5a31ce!==_0x9162fb&&(_0x9162fb===!0x0?(_0x538498=_0x538498||pe(_0x49aa22,_0x2b8600,_0x4eec44,_0x1bb450,_0x192c05,_0x4dacbb,_0x496341,_0x3f9f1f),_0x1230dc=_0x1230dc||le(_0x49aa22,_0x1bb450,_0x4eec44,_0x2b8600,_0x4dacbb),_0x2d42cc=de(_0x49aa22,_0x538498,_0x1230dc,_0x496341),_0x2dce61=ue(_0x49aa22,_0x538498,_0x496341),_0x5a31ce=!0x0):_0x9162fb===!0x1&&(_0x2d42cc(),_0x2dce61(),_0x5a31ce=!0x1));}_0x4c5ad4(!0x0);let _0x10d369;_0x58521c===_0x4ef8e9(0xef)&&_0x49aa22[_0x4ef8e9(0x1a9)]&&_0x5655d2&&_0x5655d2['nextJsDistDir']&&(_0x10d369={'nextJsDistDir':_0x5655d2[_0x4ef8e9(0x126)]}),_0x1bb450({'method':_0x4ef8e9(0xf4),'version':_0x4eec44,'args':[_0x2b8600,_0x10d369]});})(globalThis,'127.0.0.1',_0xfef7c3(0x18f),\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",_0xfef7c3(0x108),'next.js',_0xfef7c3(0x1db),_0xfef7c3(0x1c4),_0xfef7c3(0x133),_0xfef7c3(0x137),{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},_0xfef7c3(0x1bd));function ue(_0x21d697,_0x273c2c,_0x37cd90){const _0x34d535=_0xfef7c3;if(_0x21d697[_0x34d535(0xe3)]&&_0x21d697['XMLHttpRequest'][_0x34d535(0x1b4)]){let _0x4b6830=_0x21d697['XMLHttpRequest'][_0x34d535(0x1b4)][_0x34d535(0x141)],_0x2bd85b=_0x21d697[_0x34d535(0xe3)]['prototype']['send'],_0x1d32b6=_0x21d697[_0x34d535(0xe3)]['prototype'][_0x34d535(0x1d7)];return _0x4b6830&&_0x2bd85b&&_0x4b6830[_0x34d535(0x103)]()[_0x34d535(0x1b6)]('native\\x20code')!==-0x1?(_0x21d697[_0x34d535(0xe3)][_0x34d535(0x1b4)]['open']=function(_0x434694,_0x3ebfbe){const _0x123854=_0x34d535;let _0x4418d5=this[x]=this[x]||{};return _0x4418d5[_0x123854(0x14c)]=_0x434694,_0x4418d5[_0x123854(0x1ce)]=_0x3ebfbe,_0x4b6830['apply'](this,arguments);},_0x21d697[_0x34d535(0xe3)][_0x34d535(0x1b4)][_0x34d535(0x1a2)]=function(){let _0x53e42c=te(_0x37cd90);return this['addEventListener']('readystatechange',()=>{const _0xe50508=_0x4231;var _0x402dbe,_0x2d7f08;if(this['readyState']===0x4){let _0x548c0c=this[_0xe50508(0xe5)](_0xe50508(0xdf)),_0x4bb290=_0x548c0c&&_0x548c0c[_0xe50508(0x1b6)](ee)!==-0x1?ne(this[_0xe50508(0x1c2)],ee):this['response'],_0x5f1f32=oe((_0x402dbe=this[x])==null?void 0x0:_0x402dbe['headers']),_0x1af5b5=_0x5f1f32?ne(arguments[0x0],_0x5f1f32):arguments[0x0],_0x4e23e7=(_0x2d7f08=this[_0xe50508(0x173)])==null?void 0x0:_0x2d7f08[_0xe50508(0x103)]();_0x273c2c({'stack':_0x53e42c,'status':_0x4e23e7,'url':this[x][_0xe50508(0x1ce)],'method':this[x][_0xe50508(0x14c)],'request':_0x1af5b5,'response':_0x4bb290});}}),_0x2bd85b['apply'](this,arguments);},_0x1d32b6&&(_0x21d697[_0x34d535(0xe3)][_0x34d535(0x1b4)][_0x34d535(0x1d7)]=function(_0x1bcf4f,_0x2d0940){const _0x58d4e3=_0x34d535;let _0xbdb269=this[x]=this[x]||{},_0x5225e6=_0xbdb269[_0x58d4e3(0x119)]=_0xbdb269[_0x58d4e3(0x119)]||{};_0x5225e6[_0x1bcf4f]=_0x2d0940,_0x1d32b6[_0x58d4e3(0x181)](this,arguments);}),()=>{const _0x4deaf9=_0x34d535;_0x21d697[_0x4deaf9(0xe3)][_0x4deaf9(0x1b4)]['open']=_0x4b6830,_0x21d697[_0x4deaf9(0xe3)]['prototype'][_0x4deaf9(0x1a2)]=_0x2bd85b,_0x21d697[_0x4deaf9(0xe3)][_0x4deaf9(0x1b4)][_0x4deaf9(0x1d7)]=_0x1d32b6;}):()=>{};}}function de(_0x536688,_0x308d11,_0x3d113f,_0x23dd8e){const _0x1e5837=_0xfef7c3;let _0x409b47=_0x536688[_0x1e5837(0x11d)];if(_0x536688['Response']&&_0x536688[_0x1e5837(0xd1)][_0x1e5837(0x1b4)]&&_0x409b47[_0x1e5837(0x103)]()[_0x1e5837(0x1b6)]('native\\x20code')!==-0x1){let _0x5e0109=function(){const _0x163a77=_0x1e5837;return _0x536688[_0x163a77(0x11d)]=function(..._0x4a198d){const _0x5e5348=_0x163a77;var _0x84c3c3;let [_0x56ecac,_0x2f96b0]=_0x4a198d,_0x34964d=_0x2f96b0&&_0x2f96b0[_0x5e5348(0x14c)]?_0x2f96b0[_0x5e5348(0x14c)]:_0x5e5348(0x14b),_0xe33f6d=te(_0x23dd8e),_0x3f12de=_0x4a198d&&_0x4a198d[_0x5e5348(0x16b)]>0x0&&((_0x84c3c3=_0x4a198d[0x1])==null?void 0x0:_0x84c3c3[_0x5e5348(0x119)]),_0x2f1bcb=oe(_0x3f12de),_0x152420=_0x2f96b0!=null&&_0x2f96b0[_0x5e5348(0x1b9)]?ne(_0x2f96b0['body'],_0x2f1bcb):_0x2f96b0==null?void 0x0:_0x2f96b0[_0x5e5348(0x1b9)];return _0x409b47[_0x5e5348(0x181)](this,_0x4a198d)[_0x5e5348(0x1b8)](_0x224ab4=>(_0x224ab4[x]={'method':_0x34964d,'fetchStack':_0xe33f6d,'request':_0x152420},_0x224ab4));},()=>_0x536688[_0x163a77(0x11d)]=_0x409b47;},_0x241b66=function(_0x580aac,_0x55ac7f=_0x3785f5=>_0x3785f5){const _0x32fc98=_0x1e5837;let _0x3292a6=_0x536688[_0x32fc98(0xd1)][_0x32fc98(0x1b4)][_0x580aac];return _0x3292a6?(_0x536688[_0x32fc98(0xd1)][_0x32fc98(0x1b4)][_0x580aac]=async function(){const _0x3997fe=_0x32fc98;var _0x1b0943;let _0x898244=te(_0x23dd8e),_0x4d3c35;try{_0x4d3c35=await _0x3292a6['apply'](this,arguments);}catch(_0x22e49b){throw _0x3d113f(_0x22e49b,_0x898244),_0x22e49b;}let _0x3c33df=this[x];return _0x3c33df&&_0x308d11({'stack':_0x898244,'fetchStack':_0x3c33df[_0x3997fe(0x121)],'url':this['url'],'status':(_0x1b0943=this['status'])==null?void 0x0:_0x1b0943[_0x3997fe(0x103)](),'request':_0x3c33df[_0x3997fe(0x1b2)],'response':_0x55ac7f(_0x4d3c35),'method':_0x3c33df[_0x3997fe(0x14c)]}),_0x4d3c35;},()=>_0x536688['Response'][_0x32fc98(0x1b4)][_0x580aac]=_0x3292a6):()=>{};};var _0x1c9d8e=_0x5e0109,_0xca8476=_0x241b66;let _0x1b1a1b=[_0x5e0109(),_0x241b66(_0x1e5837(0x11e)),_0x241b66('text'),_0x241b66(_0x1e5837(0x1e4),_0x10f0c4=>({'blob':{'size':_0x10f0c4[_0x1e5837(0x101)],'type':_0x10f0c4['type']}})),_0x241b66(_0x1e5837(0x177),_0x37843f=>({'arrayBuffer':{'byteLength':_0x37843f['byteLength']}}))];return()=>_0x1b1a1b[_0x1e5837(0x100)](_0x2651a0=>_0x2651a0());}return()=>{};}function te(_0x4602ab){const _0xb77067=_0xfef7c3;try{let _0x221160=Error['stackTraceLimit'];Error[_0xb77067(0xb8)]=_0x4602ab;let _0x27d20d=new Error()[_0xb77067(0xbe)];return Error['stackTraceLimit']=_0x221160,_0x27d20d;}catch{return'';}}function se(_0x4cbc4a,_0x29dffd){const _0x279d5a=_0xfef7c3;return _0x29dffd[_0x279d5a(0x150)](/\\?t=\\d+/g,'');}var fe=['_devMiddlewareManifest.json',_0xfef7c3(0x10f),_0xfef7c3(0x1a3)];function _0xa08d(){const _0x2bd104=['__nextjs_original-stack-frame','message','_objectToString','startsWith','push','root_exp_id','TURBOPACK',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','Map','_console_ninja_session','pauseNetworkLogging','hrtime','_setNodeId','_processTreeNodeResult','network','request','boolean','prototype','name','indexOf','negativeInfinity','then','body','2454272zCuSQl','_blacklistedProperty','reducedLimits',{\"nextJsDistDir\":\"/Users/luiseurdanetamartucci/Desktop/Proyectos en GitHub/Alkitu/alkitu-template/packages/web/.next/dev\"},'index','data','_Symbol','Boolean','response','entries',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'android','expo','unknown','URLSearchParams','hostname','sort','constructor','_additionalMetadata','args','url','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','osName','parent','_maxConnectAttemptCount','fromCharCode','pop','astro','function','setRequestHeader','_connectToHostNow','Set','DataView','1763946797424','array','_connectAttemptCount','_sendErrorMessage','[object\\x20Array]','nodeModules','_attemptToReconnectShortly','match','nan','blob','_hasSymbolPropertyOnItsPath','https://tinyurl.com/37x8b79t','tool','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','Buffer','ExpoDevice','error','_type','get','_webSocketErrorDocsLink','substr','stackTraceLimit','_sortProps','path','import(\\x27url\\x27)','_HTMLAllCollection','_socket','stack','noFunctions','stringify','resolveGetters','type','edge','_ninjaInstallGlobalErrorHandler','elements','_dateToString','versions','_extendedWarning','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_reconnectTimeout','onclose','string','5HBLxWp','console','_allowedToConnectOnSend','angular\\x20browser','Response','call','keys','logger\\x20websocket\\x20error','getOwnPropertySymbols','dockerizedApp','_inNextEdge','_isNegativeZero','modules','resetOnProcessingTimeAverageMs','props','readyState','origin','allStrLength','Content-Type','toUpperCase','reducePolicy','isExpressionToEvaluate','XMLHttpRequest','onerror','getResponseHeader','bind','_ws','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','_addFunctionsNode','_p_name','catch','charAt','autoExpandPreviousObjects','ReadableStream','next.js','_isUndefined','level','_numberRegExp','performance','networkLoggingHandlerInstalled','hits','ArrayBuffer','resetWhenQuietMs','onopen','depth','rootExpression','now','location','HTMLAllCollection','_p_length','openFiles','forEach','size','slice','toString','FormData','global','_WebSocket','remix','1.0.0','_connected','5165644YYoYqz','1636616mpEZMP','_addProperty','files','object','.hot-update.json','totalStrLength','value','WebSocket','strLength','_isPrimitiveWrapperType','negativeZero','_isSet','node','funcName','headers','find','count','getOwnPropertyDescriptor','fetch','json','25062UETCnL','...','fetchStack','_setNodeExpandableState','_connecting','cappedElements','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','nextJsDistDir','10.0.2.2','reduceLimits','Symbol','ws://','1599267iIdPwU','captureRequests','Number','NEXT_RUNTIME','_hasSetOnItsPath','_consoleNinjaAllowedToStart','time','splice','','eventReceivedCallback','process','number','1','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','perf_hooks','concat','application/json','_setNodeQueryPath','_getOwnPropertyDescriptor','warn','join','open','hasOwnProperty','undefined','RegExp','autoExpandLimit','_getOwnPropertySymbols','getWebSocketClass','_disposeWebsocket','getOwnPropertyNames','49qCNeQl','GET','method','sortProps','toLowerCase','updateNetworkLoggingConfig','replace','split','_cleanNode','autoExpandPropertyCount','_capIfString','_regExpToString','reload','NEGATIVE_INFINITY','_treeNodePropertiesAfterFullValue','cappedProps','parse','reduceOnCount','null','_inBrowser','_addLoadNode','_isMap','symbol','_getOwnPropertyNames','_propertyName','perLogpoint','map','2WmSmMs','[object\\x20Date]','includes','_p_','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','4615540LNUMaH','length','defaultLimits','unref','endsWith','test','_undefined','\\x20browser','log','status','Blob','content-type','_setNodeLabel','arrayBuffer','_ninjaIgnoreError','_isPrimitiveType','_triedToInstallNetworkLoggingHandler','_isArray','serialize','date','blacklistEntries','bigint','valueOf','apply','timeStamp','expressionsToEvaluate','_allowedToSend','TypedArray','autoExpandMaxDepth','_WebSocketClass','_setNodePermissions','autoExpand','8178ufvFZf','port','_treeNodePropertiesBeforeFullValue','_property','some','51827','POSITIVE_INFINITY','\\x20server','env','onmessage','import(\\x27path\\x27)','set','[object\\x20Set]','current','reduceOnAccumulatedProcessingTimeMs','_setNodeExpressionPath','next.js\\x20browser','host','9OvpCLQ','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','capped','expId','[object\\x20BigInt]','_addObjectProperty','send'];_0xa08d=function(){return _0x2bd104;};return _0xa08d();}function he(_0xf0a5d4){const _0x49c376=_0xfef7c3;return!!(typeof _0xf0a5d4=='string'&&fe['some'](_0x4287ed=>_0xf0a5d4[_0x49c376(0x1b6)](_0x4287ed)!==-0x1));}function _0x4231(_0x5470a8,_0x40b719){const _0xa08d43=_0xa08d();return _0x4231=function(_0x4231cc,_0x1e9061){_0x4231cc=_0x4231cc-0xaf;let _0x304c1a=_0xa08d43[_0x4231cc];return _0x304c1a;},_0x4231(_0x5470a8,_0x40b719);}function le(_0x4b4bba,_0x57ea21,_0x18c8a5,_0x1156d9,_0x48bde0){return(_0x33ead8,_0x24f9ce)=>{const _0x221863=_0x4231;_0x4b4bba[_0x221863(0xc4)]&&(_0x4b4bba[_0x221863(0x178)]=_0x33ead8);let _0x27db6a=String[_0x221863(0x1d3)](0xa),_0x5c4209=_0x24f9ce[_0x221863(0x151)](_0x27db6a);_0x5c4209[_0x221863(0x16b)]>0x2&&_0x5c4209[_0x221863(0x132)](0x0,0x3),_0x24f9ce=_0x33ead8[_0x221863(0xbe)]['split'](_0x27db6a)[0x0]+_0x27db6a+_0x5c4209[_0x221863(0x140)](_0x27db6a),_0x57ea21({'method':'error','version':_0x18c8a5,'args':[{'ts':Date[_0x221863(0xfb)](),'session':_0x1156d9,'message':_0x33ead8[_0x221863(0x1a4)]||'','stack':_0x24f9ce,'generatedStack':void 0x0,'stackTraceLimit':Error['stackTraceLimit'],'origin':_0x48bde0}]});};}function pe(_0x4a37e2,_0x409038,_0x5e0db5,_0x4880cf,_0x207d4a,_0x448984,_0x411f7f,_0xe79cae){let _0x4db011;return({stack:_0x3e2e03,url:_0x164316,status:_0x51c994,response:_0x2c3cda,method:_0x1646cc,fetchStack:_0x28b1f3,request:_0x3c68c7})=>{const _0x2870cf=_0x4231;if(he(_0x164316))return;let _0x54ddf1=_0x28b1f3?_0x3e2e03+'\\x0a'+_0x28b1f3:_0x3e2e03;if(_0x207d4a[se(_0x409038[_0x2870cf(0xaf)],_0x54ddf1)])return;let _0x56569d={'url':_0x164316,'status':_0x51c994,'method':_0x1646cc,'request':_0x3c68c7,'response':_0x2c3cda};_0x4db011=_0x4db011||K(_0x4a37e2,!0x1,{'hits':{},'ts':{}},_0x5e0db5,_0xe79cae);let _0x51256d=_0x4db011('log',_0x2870cf(0x1b1),Date[_0x2870cf(0xfb)](),_0x409038,[_0x56569d]);_0x51256d[_0x2870cf(0x1cd)][0x0][_0x2870cf(0x1cd)][0x0][_0x2870cf(0xdb)][_0x2870cf(0x1a7)]({'name':_0x2870cf(0xbe),'type':_0x2870cf(0xcc),'value':_0x3e2e03}),_0x51256d[_0x2870cf(0x1cd)][0x0]['args'][0x0][_0x2870cf(0xdb)]['push']({'name':_0x2870cf(0x121),'type':'string','value':_0x28b1f3}),_0x448984&&(_0x51256d[_0x2870cf(0x1cd)][0x0]['origin']=_0x448984),_0x51256d['args'][0x0][_0x2870cf(0xb8)]=_0x411f7f,_0x4880cf(_0x51256d);};}var _e=[_0xfef7c3(0x174),_0xfef7c3(0xf6),_0xfef7c3(0x185),_0xfef7c3(0x1da),_0xfef7c3(0x104),_0xfef7c3(0x1c8),_0xfef7c3(0xee)];function ne(_0x4957e9,_0xaca298){const _0x5861bb=_0xfef7c3;if(typeof _0x4957e9==_0x5861bb(0xcc)){try{if(_0xaca298&&_0xaca298[_0x5861bb(0x14e)]()===ee)return JSON[_0x5861bb(0x15a)](_0x4957e9);}catch{}return _0x4957e9;}if(typeof _0x4957e9=='object'&&(_0x4957e9==null?void 0x0:_0x4957e9[_0x5861bb(0x1cb)][_0x5861bb(0x1b5)])){let _0x2322e4=_0x4957e9==null?void 0x0:_0x4957e9[_0x5861bb(0x1cb)][_0x5861bb(0x1b5)];return _0x2322e4&&_e[_0x5861bb(0x18e)](_0x1f5b94=>_0x1f5b94===_0x2322e4)?'<'+_0x2322e4+'>':_0x4957e9;}return _0x4957e9;}function me(_0x45c7c5){const _0x345763=_0xfef7c3;return _0x45c7c5?_0x45c7c5===_0x345763(0x19a)?0x32:_0x45c7c5===_0x345763(0xd0)?0x64:0x1e:0x1e;}function oe(_0x55f2bd){const _0x295674=_0xfef7c3;var _0x1e2d0e;return _0x55f2bd?(_0x1e2d0e=Object[_0x295674(0x1c3)](_0x55f2bd)[_0x295674(0x11a)](([_0x54e16c,_0xca54f])=>(_0x54e16c==null?void 0x0:_0x54e16c['toLowerCase']())===_0x295674(0x175)))==null?void 0x0:_0x1e2d0e[0x1]:void 0x0;}");
} catch (e) {
    console.error(e);
}
"trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
    configurable: !0,
    get: function() {
        var t = /\((.*)\)/.exec(this.toString());
        return t ? t[1] : void 0;
    }
}), Array.prototype.flat || (Array.prototype.flat = function(t, r) {
    return r = this.concat.apply([], this), t > 1 && r.some(Array.isArray) ? r.flat(t - 1) : r;
}, Array.prototype.flatMap = function(t, r) {
    return this.map(t, r).flat();
}), Promise.prototype.finally || (Promise.prototype.finally = function(t) {
    if ("function" != typeof t) return this.then(t, t);
    var r = this.constructor || Promise;
    return this.then(function(n) {
        return r.resolve(t()).then(function() {
            return n;
        });
    }, function(n) {
        return r.resolve(t()).then(function() {
            throw n;
        });
    });
}), Object.fromEntries || (Object.fromEntries = function(t) {
    return Array.from(t).reduce(function(t, r) {
        return t[r[0]] = r[1], t;
    }, {});
}), Array.prototype.at || (Array.prototype.at = function(t) {
    var r = Math.trunc(t) || 0;
    if (r < 0 && (r += this.length), !(r < 0 || r >= this.length)) return this[r];
}), Object.hasOwn || (Object.hasOwn = function(t, r) {
    if (null == t) throw new TypeError("Cannot convert undefined or null to object");
    return Object.prototype.hasOwnProperty.call(Object(t), r);
}), "canParse" in URL || (URL.canParse = function(t, r) {
    try {
        return !!new URL(t, r);
    } catch (t) {
        return !1;
    }
});
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "InvariantError", {
    enumerable: true,
    get: function() {
        return InvariantError;
    }
});
class InvariantError extends Error {
    constructor(message, options){
        super(`Invariant: ${message.endsWith('.') ? message : message + '.'} This is a bug in Next.js.`, options);
        this.name = 'InvariantError';
    }
} //# sourceMappingURL=invariant-error.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/is-plain-object.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getObjectClassLabel: null,
    isPlainObject: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getObjectClassLabel: function() {
        return getObjectClassLabel;
    },
    isPlainObject: function() {
        return isPlainObject;
    }
});
function getObjectClassLabel(value) {
    return Object.prototype.toString.call(value);
}
function isPlainObject(value) {
    if (getObjectClassLabel(value) !== '[object Object]') {
        return false;
    }
    const prototype = Object.getPrototypeOf(value);
    /**
   * this used to be previously:
   *
   * `return prototype === null || prototype === Object.prototype`
   *
   * but Edge Runtime expose Object from vm, being that kind of type-checking wrongly fail.
   *
   * It was changed to the current implementation since it's resilient to serialization.
   */ return prototype === null || prototype.hasOwnProperty('isPrototypeOf');
} //# sourceMappingURL=is-plain-object.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This has to be a shared module which is shared between client component error boundary and dynamic component
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    BailoutToCSRError: null,
    isBailoutToCSRError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    BailoutToCSRError: function() {
        return BailoutToCSRError;
    },
    isBailoutToCSRError: function() {
        return isBailoutToCSRError;
    }
});
const BAILOUT_TO_CSR = 'BAILOUT_TO_CLIENT_SIDE_RENDERING';
class BailoutToCSRError extends Error {
    constructor(reason){
        super(`Bail out to client-side rendering: ${reason}`), this.reason = reason, this.digest = BAILOUT_TO_CSR;
    }
}
function isBailoutToCSRError(err) {
    if (typeof err !== 'object' || err === null || !('digest' in err)) {
        return false;
    }
    return err.digest === BAILOUT_TO_CSR;
} //# sourceMappingURL=bailout-to-csr.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/error-source.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    decorateServerError: null,
    getErrorSource: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    decorateServerError: function() {
        return decorateServerError;
    },
    getErrorSource: function() {
        return getErrorSource;
    }
});
const symbolError = Symbol.for('NextjsError');
function getErrorSource(error) {
    return error[symbolError] || null;
}
function decorateServerError(error, type) {
    Object.defineProperty(error, symbolError, {
        writable: false,
        enumerable: false,
        configurable: false,
        value: type
    });
} //# sourceMappingURL=error-source.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/head-manager-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HeadManagerContext", {
    enumerable: true,
    get: function() {
        return HeadManagerContext;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const HeadManagerContext = _react.default.createContext({});
if ("TURBOPACK compile-time truthy", 1) {
    HeadManagerContext.displayName = 'HeadManagerContext';
} //# sourceMappingURL=head-manager-context.shared-runtime.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/hooks-client-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    NavigationPromisesContext: null,
    PathParamsContext: null,
    PathnameContext: null,
    SearchParamsContext: null,
    createDevToolsInstrumentedPromise: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    NavigationPromisesContext: function() {
        return NavigationPromisesContext;
    },
    PathParamsContext: function() {
        return PathParamsContext;
    },
    PathnameContext: function() {
        return PathnameContext;
    },
    SearchParamsContext: function() {
        return SearchParamsContext;
    },
    createDevToolsInstrumentedPromise: function() {
        return createDevToolsInstrumentedPromise;
    }
});
const _react = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const SearchParamsContext = (0, _react.createContext)(null);
const PathnameContext = (0, _react.createContext)(null);
const PathParamsContext = (0, _react.createContext)(null);
const NavigationPromisesContext = (0, _react.createContext)(null);
function createDevToolsInstrumentedPromise(displayName, value) {
    const promise = Promise.resolve(value);
    promise.status = 'fulfilled';
    promise.value = value;
    promise.displayName = `${displayName} (SSR)`;
    return promise;
}
if ("TURBOPACK compile-time truthy", 1) {
    SearchParamsContext.displayName = 'SearchParamsContext';
    PathnameContext.displayName = 'PathnameContext';
    PathParamsContext.displayName = 'PathParamsContext';
    NavigationPromisesContext.displayName = 'NavigationPromisesContext';
} //# sourceMappingURL=hooks-client-context.shared-runtime.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/html-bots.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This regex contains the bots that we need to do a blocking render for and can't safely stream the response
// due to how they parse the DOM. For example, they might explicitly check for metadata in the `head` tag, so we can't stream metadata tags after the `head` was sent.
// Note: The pattern [\w-]+-Google captures all Google crawlers with "-Google" suffix (e.g., Mediapartners-Google, AdsBot-Google, Storebot-Google)
// as well as crawlers starting with "Google-" (e.g., Google-PageRenderer, Google-InspectionTool)
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HTML_LIMITED_BOT_UA_RE", {
    enumerable: true,
    get: function() {
        return HTML_LIMITED_BOT_UA_RE;
    }
});
const HTML_LIMITED_BOT_UA_RE = /[\w-]+-Google|Google-[\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight/i; //# sourceMappingURL=html-bots.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/is-bot.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HTML_LIMITED_BOT_UA_RE: null,
    HTML_LIMITED_BOT_UA_RE_STRING: null,
    getBotType: null,
    isBot: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HTML_LIMITED_BOT_UA_RE: function() {
        return _htmlbots.HTML_LIMITED_BOT_UA_RE;
    },
    HTML_LIMITED_BOT_UA_RE_STRING: function() {
        return HTML_LIMITED_BOT_UA_RE_STRING;
    },
    getBotType: function() {
        return getBotType;
    },
    isBot: function() {
        return isBot;
    }
});
const _htmlbots = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/html-bots.js [app-client] (ecmascript)");
// Bot crawler that will spin up a headless browser and execute JS.
// Only the main Googlebot search crawler executes JavaScript, not other Google crawlers.
// x-ref: https://developers.google.com/search/docs/crawling-indexing/google-common-crawlers
// This regex specifically matches "Googlebot" but NOT "Mediapartners-Google", "AdsBot-Google", etc.
const HEADLESS_BROWSER_BOT_UA_RE = /Googlebot(?!-)|Googlebot$/i;
const HTML_LIMITED_BOT_UA_RE_STRING = _htmlbots.HTML_LIMITED_BOT_UA_RE.source;
function isDomBotUA(userAgent) {
    return HEADLESS_BROWSER_BOT_UA_RE.test(userAgent);
}
function isHtmlLimitedBotUA(userAgent) {
    return _htmlbots.HTML_LIMITED_BOT_UA_RE.test(userAgent);
}
function isBot(userAgent) {
    return isDomBotUA(userAgent) || isHtmlLimitedBotUA(userAgent);
}
function getBotType(userAgent) {
    if (isDomBotUA(userAgent)) {
        return 'dom';
    }
    if (isHtmlLimitedBotUA(userAgent)) {
        return 'html';
    }
    return undefined;
} //# sourceMappingURL=is-bot.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/is-thenable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Check to see if a value is Thenable.
 *
 * @param promise the maybe-thenable value
 * @returns true if the value is thenable
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isThenable", {
    enumerable: true,
    get: function() {
        return isThenable;
    }
});
function isThenable(promise) {
    return promise !== null && typeof promise === 'object' && 'then' in promise && typeof promise.then === 'function';
} //# sourceMappingURL=is-thenable.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * For a given page path, this function ensures that there is a leading slash.
 * If there is not a leading slash, one is added, otherwise it is noop.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ensureLeadingSlash", {
    enumerable: true,
    get: function() {
        return ensureLeadingSlash;
    }
});
function ensureLeadingSlash(path) {
    return path.startsWith('/') ? path : `/${path}`;
} //# sourceMappingURL=ensure-leading-slash.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    DEFAULT_SEGMENT_KEY: null,
    PAGE_SEGMENT_KEY: null,
    addSearchParamsIfPageSegment: null,
    computeSelectedLayoutSegment: null,
    getSegmentValue: null,
    getSelectedLayoutSegmentPath: null,
    isGroupSegment: null,
    isParallelRouteSegment: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    DEFAULT_SEGMENT_KEY: function() {
        return DEFAULT_SEGMENT_KEY;
    },
    PAGE_SEGMENT_KEY: function() {
        return PAGE_SEGMENT_KEY;
    },
    addSearchParamsIfPageSegment: function() {
        return addSearchParamsIfPageSegment;
    },
    computeSelectedLayoutSegment: function() {
        return computeSelectedLayoutSegment;
    },
    getSegmentValue: function() {
        return getSegmentValue;
    },
    getSelectedLayoutSegmentPath: function() {
        return getSelectedLayoutSegmentPath;
    },
    isGroupSegment: function() {
        return isGroupSegment;
    },
    isParallelRouteSegment: function() {
        return isParallelRouteSegment;
    }
});
function getSegmentValue(segment) {
    return Array.isArray(segment) ? segment[1] : segment;
}
function isGroupSegment(segment) {
    // Use array[0] for performant purpose
    return segment[0] === '(' && segment.endsWith(')');
}
function isParallelRouteSegment(segment) {
    return segment.startsWith('@') && segment !== '@children';
}
function addSearchParamsIfPageSegment(segment, searchParams) {
    const isPageSegment = segment.includes(PAGE_SEGMENT_KEY);
    if (isPageSegment) {
        const stringifiedQuery = JSON.stringify(searchParams);
        return stringifiedQuery !== '{}' ? PAGE_SEGMENT_KEY + '?' + stringifiedQuery : PAGE_SEGMENT_KEY;
    }
    return segment;
}
function computeSelectedLayoutSegment(segments, parallelRouteKey) {
    if (!segments || segments.length === 0) {
        return null;
    }
    // For 'children', use first segment; for other parallel routes, use last segment
    const rawSegment = parallelRouteKey === 'children' ? segments[0] : segments[segments.length - 1];
    // If the default slot is showing, return null since it's not technically "selected" (it's a fallback)
    // Returning an internal value like `__DEFAULT__` would be confusing
    return rawSegment === DEFAULT_SEGMENT_KEY ? null : rawSegment;
}
function getSelectedLayoutSegmentPath(tree, parallelRouteKey, first = true, segmentPath = []) {
    let node;
    if (first) {
        // Use the provided parallel route key on the first parallel route
        node = tree[1][parallelRouteKey];
    } else {
        // After first parallel route prefer children, if there's no children pick the first parallel route.
        const parallelRoutes = tree[1];
        node = parallelRoutes.children ?? Object.values(parallelRoutes)[0];
    }
    if (!node) return segmentPath;
    const segment = node[0];
    let segmentValue = getSegmentValue(segment);
    if (!segmentValue || segmentValue.startsWith(PAGE_SEGMENT_KEY)) {
        return segmentPath;
    }
    segmentPath.push(segmentValue);
    return getSelectedLayoutSegmentPath(node, parallelRouteKey, false, segmentPath);
}
const PAGE_SEGMENT_KEY = '__PAGE__';
const DEFAULT_SEGMENT_KEY = '__DEFAULT__'; //# sourceMappingURL=segment.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    normalizeAppPath: null,
    normalizeRscURL: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    normalizeAppPath: function() {
        return normalizeAppPath;
    },
    normalizeRscURL: function() {
        return normalizeRscURL;
    }
});
const _ensureleadingslash = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js [app-client] (ecmascript)");
const _segment = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)");
function normalizeAppPath(route) {
    return (0, _ensureleadingslash.ensureLeadingSlash)(route.split('/').reduce((pathname, segment, index, segments)=>{
        // Empty segments are ignored.
        if (!segment) {
            return pathname;
        }
        // Groups are ignored.
        if ((0, _segment.isGroupSegment)(segment)) {
            return pathname;
        }
        // Parallel segments are ignored.
        if (segment[0] === '@') {
            return pathname;
        }
        // The last segment (if it's a leaf) should be ignored.
        if ((segment === 'page' || segment === 'route') && index === segments.length - 1) {
            return pathname;
        }
        return `${pathname}/${segment}`;
    }, ''));
}
function normalizeRscURL(url) {
    return url.replace(/\.rsc($|\?)/, '$1');
} //# sourceMappingURL=app-paths.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/interception-routes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    INTERCEPTION_ROUTE_MARKERS: null,
    extractInterceptionRouteInformation: null,
    isInterceptionRouteAppPath: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    INTERCEPTION_ROUTE_MARKERS: function() {
        return INTERCEPTION_ROUTE_MARKERS;
    },
    extractInterceptionRouteInformation: function() {
        return extractInterceptionRouteInformation;
    },
    isInterceptionRouteAppPath: function() {
        return isInterceptionRouteAppPath;
    }
});
const _apppaths = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)");
const INTERCEPTION_ROUTE_MARKERS = [
    '(..)(..)',
    '(.)',
    '(..)',
    '(...)'
];
function isInterceptionRouteAppPath(path) {
    // TODO-APP: add more serious validation
    return path.split('/').find((segment)=>INTERCEPTION_ROUTE_MARKERS.find((m)=>segment.startsWith(m))) !== undefined;
}
function extractInterceptionRouteInformation(path) {
    let interceptingRoute;
    let marker;
    let interceptedRoute;
    for (const segment of path.split('/')){
        marker = INTERCEPTION_ROUTE_MARKERS.find((m)=>segment.startsWith(m));
        if (marker) {
            ;
            [interceptingRoute, interceptedRoute] = path.split(marker, 2);
            break;
        }
    }
    if (!interceptingRoute || !marker || !interceptedRoute) {
        throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Must be in the format /<intercepting route>/(..|...|..)(..)/<intercepted route>`), "__NEXT_ERROR_CODE", {
            value: "E269",
            enumerable: false,
            configurable: true
        });
    }
    interceptingRoute = (0, _apppaths.normalizeAppPath)(interceptingRoute) // normalize the path, e.g. /(blog)/feed -> /feed
    ;
    switch(marker){
        case '(.)':
            // (.) indicates that we should match with sibling routes, so we just need to append the intercepted route to the intercepting route
            if (interceptingRoute === '/') {
                interceptedRoute = `/${interceptedRoute}`;
            } else {
                interceptedRoute = interceptingRoute + '/' + interceptedRoute;
            }
            break;
        case '(..)':
            // (..) indicates that we should match at one level up, so we need to remove the last segment of the intercepting route
            if (interceptingRoute === '/') {
                throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Cannot use (..) marker at the root level, use (.) instead.`), "__NEXT_ERROR_CODE", {
                    value: "E207",
                    enumerable: false,
                    configurable: true
                });
            }
            interceptedRoute = interceptingRoute.split('/').slice(0, -1).concat(interceptedRoute).join('/');
            break;
        case '(...)':
            // (...) will match the route segment in the root directory, so we need to use the root directory to prepend the intercepted route
            interceptedRoute = '/' + interceptedRoute;
            break;
        case '(..)(..)':
            // (..)(..) indicates that we should match at two levels up, so we need to remove the last two segments of the intercepting route
            const splitInterceptingRoute = interceptingRoute.split('/');
            if (splitInterceptingRoute.length <= 2) {
                throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Cannot use (..)(..) marker at the root level or one level up.`), "__NEXT_ERROR_CODE", {
                    value: "E486",
                    enumerable: false,
                    configurable: true
                });
            }
            interceptedRoute = splitInterceptingRoute.slice(0, -2).concat(interceptedRoute).join('/');
            break;
        default:
            throw Object.defineProperty(new Error('Invariant: unexpected marker'), "__NEXT_ERROR_CODE", {
                value: "E112",
                enumerable: false,
                configurable: true
            });
    }
    return {
        interceptingRoute,
        interceptedRoute
    };
} //# sourceMappingURL=interception-routes.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Given a path this function will find the pathname, query and hash and return
 * them. This is useful to parse full paths on the client side.
 * @param path A path to parse e.g. /foo/bar?id=1#hash
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "parsePath", {
    enumerable: true,
    get: function() {
        return parsePath;
    }
});
function parsePath(path) {
    const hashIndex = path.indexOf('#');
    const queryIndex = path.indexOf('?');
    const hasQuery = queryIndex > -1 && (hashIndex < 0 || queryIndex < hashIndex);
    if (hasQuery || hashIndex > -1) {
        return {
            pathname: path.substring(0, hasQuery ? queryIndex : hashIndex),
            query: hasQuery ? path.substring(queryIndex, hashIndex > -1 ? hashIndex : undefined) : '',
            hash: hashIndex > -1 ? path.slice(hashIndex) : ''
        };
    }
    return {
        pathname: path,
        query: '',
        hash: ''
    };
} //# sourceMappingURL=parse-path.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/add-path-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "addPathPrefix", {
    enumerable: true,
    get: function() {
        return addPathPrefix;
    }
});
const _parsepath = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)");
function addPathPrefix(path, prefix) {
    if (!path.startsWith('/') || !prefix) {
        return path;
    }
    const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
    return `${prefix}${pathname}${query}${hash}`;
} //# sourceMappingURL=add-path-prefix.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/remove-trailing-slash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Removes the trailing slash for a given route or page path. Preserves the
 * root page. Examples:
 *   - `/foo/bar/` -> `/foo/bar`
 *   - `/foo/bar` -> `/foo/bar`
 *   - `/` -> `/`
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "removeTrailingSlash", {
    enumerable: true,
    get: function() {
        return removeTrailingSlash;
    }
});
function removeTrailingSlash(route) {
    return route.replace(/\/$/, '') || '/';
} //# sourceMappingURL=remove-trailing-slash.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/app-router-types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * App Router types - Client-safe types for the Next.js App Router
 *
 * This file contains type definitions that can be safely imported
 * by both client-side and server-side code without circular dependencies.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HasLoadingBoundary", {
    enumerable: true,
    get: function() {
        return HasLoadingBoundary;
    }
});
var HasLoadingBoundary = /*#__PURE__*/ function(HasLoadingBoundary) {
    // There is a loading boundary in this particular segment
    HasLoadingBoundary[HasLoadingBoundary["SegmentHasLoadingBoundary"] = 1] = "SegmentHasLoadingBoundary";
    // There is a loading boundary somewhere in the subtree (but not in
    // this segment)
    HasLoadingBoundary[HasLoadingBoundary["SubtreeHasLoadingBoundary"] = 2] = "SubtreeHasLoadingBoundary";
    // There is no loading boundary in this segment or any of its descendants
    HasLoadingBoundary[HasLoadingBoundary["SubtreeHasNoLoadingBoundary"] = 3] = "SubtreeHasNoLoadingBoundary";
    return HasLoadingBoundary;
}({}); //# sourceMappingURL=app-router-types.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/segment-cache/segment-value-encoding.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ROOT_SEGMENT_CACHE_KEY: null,
    ROOT_SEGMENT_REQUEST_KEY: null,
    appendSegmentCacheKeyPart: null,
    appendSegmentRequestKeyPart: null,
    convertSegmentPathToStaticExportFilename: null,
    createSegmentCacheKeyPart: null,
    createSegmentRequestKeyPart: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ROOT_SEGMENT_CACHE_KEY: function() {
        return ROOT_SEGMENT_CACHE_KEY;
    },
    ROOT_SEGMENT_REQUEST_KEY: function() {
        return ROOT_SEGMENT_REQUEST_KEY;
    },
    appendSegmentCacheKeyPart: function() {
        return appendSegmentCacheKeyPart;
    },
    appendSegmentRequestKeyPart: function() {
        return appendSegmentRequestKeyPart;
    },
    convertSegmentPathToStaticExportFilename: function() {
        return convertSegmentPathToStaticExportFilename;
    },
    createSegmentCacheKeyPart: function() {
        return createSegmentCacheKeyPart;
    },
    createSegmentRequestKeyPart: function() {
        return createSegmentRequestKeyPart;
    }
});
const _segment = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)");
const ROOT_SEGMENT_REQUEST_KEY = '';
const ROOT_SEGMENT_CACHE_KEY = '';
function createSegmentRequestKeyPart(segment) {
    if (typeof segment === 'string') {
        if (segment.startsWith(_segment.PAGE_SEGMENT_KEY)) {
            // The Flight Router State type sometimes includes the search params in
            // the page segment. However, the Segment Cache tracks this as a separate
            // key. So, we strip the search params here, and then add them back when
            // the cache entry is turned back into a FlightRouterState. This is an
            // unfortunate consequence of the FlightRouteState being used both as a
            // transport type and as a cache key; we'll address this once more of the
            // Segment Cache implementation has settled.
            // TODO: We should hoist the search params out of the FlightRouterState
            // type entirely, This is our plan for dynamic route params, too.
            return _segment.PAGE_SEGMENT_KEY;
        }
        const safeName = // But params typically don't include the leading slash. We should use
        // a different encoding to avoid this special case.
        segment === '/_not-found' ? '_not-found' : encodeToFilesystemAndURLSafeString(segment);
        // Since this is not a dynamic segment, it's fully encoded. It does not
        // need to be "hydrated" with a param value.
        return safeName;
    }
    const name = segment[0];
    const paramType = segment[2];
    const safeName = encodeToFilesystemAndURLSafeString(name);
    const encodedName = '$' + paramType + '$' + safeName;
    return encodedName;
}
function appendSegmentRequestKeyPart(parentRequestKey, parallelRouteKey, childRequestKeyPart) {
    // Aside from being filesystem safe, segment keys are also designed so that
    // each segment and parallel route creates its own subdirectory. Roughly in
    // the same shape as the source app directory. This is mostly just for easier
    // debugging (you can open up the build folder and navigate the output); if
    // we wanted to do we could just use a flat structure.
    // Omit the parallel route key for children, since this is the most
    // common case. Saves some bytes (and it's what the app directory does).
    const slotKey = parallelRouteKey === 'children' ? childRequestKeyPart : `@${encodeToFilesystemAndURLSafeString(parallelRouteKey)}/${childRequestKeyPart}`;
    return parentRequestKey + '/' + slotKey;
}
function createSegmentCacheKeyPart(requestKeyPart, segment) {
    if (typeof segment === 'string') {
        return requestKeyPart;
    }
    const paramValue = segment[1];
    const safeValue = encodeToFilesystemAndURLSafeString(paramValue);
    return requestKeyPart + '$' + safeValue;
}
function appendSegmentCacheKeyPart(parentSegmentKey, parallelRouteKey, childCacheKeyPart) {
    const slotKey = parallelRouteKey === 'children' ? childCacheKeyPart : `@${encodeToFilesystemAndURLSafeString(parallelRouteKey)}/${childCacheKeyPart}`;
    return parentSegmentKey + '/' + slotKey;
}
// Define a regex pattern to match the most common characters found in a route
// param. It excludes anything that might not be cross-platform filesystem
// compatible, like |. It does not need to be precise because the fallback is to
// just base64url-encode the whole parameter, which is fine; we just don't do it
// by default for compactness, and for easier debugging.
const simpleParamValueRegex = /^[a-zA-Z0-9\-_@]+$/;
function encodeToFilesystemAndURLSafeString(value) {
    if (simpleParamValueRegex.test(value)) {
        return value;
    }
    // If there are any unsafe characters, base64url-encode the entire value.
    // We also add a ! prefix so it doesn't collide with the simple case.
    const base64url = btoa(value).replace(/\+/g, '-') // Replace '+' with '-'
    .replace(/\//g, '_') // Replace '/' with '_'
    .replace(/=+$/, '') // Remove trailing '='
    ;
    return '!' + base64url;
}
function convertSegmentPathToStaticExportFilename(segmentPath) {
    return `__next${segmentPath.replace(/\//g, '.')}.txt`;
} //# sourceMappingURL=segment-value-encoding.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/hash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// http://www.cse.yorku.ca/~oz/hash.html
// More specifically, 32-bit hash via djbxor
// (ref: https://gist.github.com/eplawless/52813b1d8ad9af510d85?permalink_comment_id=3367765#gistcomment-3367765)
// This is due to number type differences between rust for turbopack to js number types,
// where rust does not have easy way to repreesnt js's 53-bit float number type for the matching
// overflow behavior. This is more `correct` in terms of having canonical hash across different runtime / implementation
// as can gaurantee determinstic output from 32bit hash.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    djb2Hash: null,
    hexHash: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    djb2Hash: function() {
        return djb2Hash;
    },
    hexHash: function() {
        return hexHash;
    }
});
function djb2Hash(str) {
    let hash = 5381;
    for(let i = 0; i < str.length; i++){
        const char = str.charCodeAt(i);
        hash = (hash << 5) + hash + char & 0xffffffff;
    }
    return hash >>> 0;
}
function hexHash(str) {
    return djb2Hash(str).toString(36).slice(0, 5);
} //# sourceMappingURL=hash.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/cache-busting-search-param.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "computeCacheBustingSearchParam", {
    enumerable: true,
    get: function() {
        return computeCacheBustingSearchParam;
    }
});
const _hash = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/hash.js [app-client] (ecmascript)");
function computeCacheBustingSearchParam(prefetchHeader, segmentPrefetchHeader, stateTreeHeader, nextUrlHeader) {
    if ((prefetchHeader === undefined || prefetchHeader === '0') && segmentPrefetchHeader === undefined && stateTreeHeader === undefined && nextUrlHeader === undefined) {
        return '';
    }
    return (0, _hash.hexHash)([
        prefetchHeader || '0',
        segmentPrefetchHeader || '0',
        stateTreeHeader || '0',
        nextUrlHeader || '0'
    ].join(','));
} //# sourceMappingURL=cache-busting-search-param.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/segment-cache/output-export-prefetch-encoding.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// In output: export mode, the build id is added to the start of the HTML
// document, directly after the doctype declaration. During a prefetch, the
// client performs a range request to get the build id, so it can check whether
// the target page belongs to the same build.
//
// The first 64 bytes of the document are requested. The exact number isn't
// too important; it must be larger than the build id + doctype + closing and
// ending comment markers, but it doesn't need to match the end of the
// comment exactly.
//
// Build ids are 21 bytes long in the default implementation, though this
// can be overridden in the Next.js config. For the purposes of this check,
// it's OK to only match the start of the id, so we'll truncate it if exceeds
// a certain length.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    DOC_PREFETCH_RANGE_HEADER_VALUE: null,
    doesExportedHtmlMatchBuildId: null,
    insertBuildIdComment: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    DOC_PREFETCH_RANGE_HEADER_VALUE: function() {
        return DOC_PREFETCH_RANGE_HEADER_VALUE;
    },
    doesExportedHtmlMatchBuildId: function() {
        return doesExportedHtmlMatchBuildId;
    },
    insertBuildIdComment: function() {
        return insertBuildIdComment;
    }
});
const DOCTYPE_PREFIX = '<!DOCTYPE html>' // 15 bytes
;
const MAX_BUILD_ID_LENGTH = 24;
const DOC_PREFETCH_RANGE_HEADER_VALUE = 'bytes=0-63';
function escapeBuildId(buildId) {
    // If the build id is longer than the given limit, it's OK for our purposes
    // to only match the beginning.
    const truncated = buildId.slice(0, MAX_BUILD_ID_LENGTH);
    // Replace hyphens with underscores so it doesn't break the HTML comment.
    // (Unlikely, but if this did happen it would break the whole document.)
    return truncated.replace(/-/g, '_');
}
function insertBuildIdComment(originalHtml, buildId) {
    if (buildId.includes('-->') || // React always inserts a doctype at the start of the document. Skip if it
    // isn't present. Shouldn't happen; suggests an issue elsewhere.
    !originalHtml.startsWith(DOCTYPE_PREFIX)) {
        // Return the original HTML unchanged. This means the document will not
        // be prefetched.
        // TODO: The build id comment is currently only used during prefetches, but
        // if we eventually use this mechanism for regular navigations, we may need
        // to error during build if we fail to insert it for some reason.
        return originalHtml;
    }
    // The comment must be inserted after the doctype.
    return originalHtml.replace(DOCTYPE_PREFIX, DOCTYPE_PREFIX + '<!--' + escapeBuildId(buildId) + '-->');
}
function doesExportedHtmlMatchBuildId(partialHtmlDocument, buildId) {
    // Check whether the document starts with the expected buildId.
    return partialHtmlDocument.startsWith(DOCTYPE_PREFIX + '<!--' + escapeBuildId(buildId) + '-->');
} //# sourceMappingURL=output-export-prefetch-encoding.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/promise-with-resolvers.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createPromiseWithResolvers", {
    enumerable: true,
    get: function() {
        return createPromiseWithResolvers;
    }
});
function createPromiseWithResolvers() {
    // Shim of Stage 4 Promise.withResolvers proposal
    let resolve;
    let reject;
    const promise = new Promise((res, rej)=>{
        resolve = res;
        reject = rej;
    });
    return {
        resolve: resolve,
        reject: reject,
        promise
    };
} //# sourceMappingURL=promise-with-resolvers.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    AppRouterContext: null,
    GlobalLayoutRouterContext: null,
    LayoutRouterContext: null,
    MissingSlotContext: null,
    TemplateContext: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    AppRouterContext: function() {
        return AppRouterContext;
    },
    GlobalLayoutRouterContext: function() {
        return GlobalLayoutRouterContext;
    },
    LayoutRouterContext: function() {
        return LayoutRouterContext;
    },
    MissingSlotContext: function() {
        return MissingSlotContext;
    },
    TemplateContext: function() {
        return TemplateContext;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const AppRouterContext = _react.default.createContext(null);
const LayoutRouterContext = _react.default.createContext(null);
const GlobalLayoutRouterContext = _react.default.createContext(null);
const TemplateContext = _react.default.createContext(null);
if ("TURBOPACK compile-time truthy", 1) {
    AppRouterContext.displayName = 'AppRouterContext';
    LayoutRouterContext.displayName = 'LayoutRouterContext';
    GlobalLayoutRouterContext.displayName = 'GlobalLayoutRouterContext';
    TemplateContext.displayName = 'TemplateContext';
}
const MissingSlotContext = _react.default.createContext(new Set()); //# sourceMappingURL=app-router-context.shared-runtime.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/server-inserted-html.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ServerInsertedHTMLContext: null,
    useServerInsertedHTML: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ServerInsertedHTMLContext: function() {
        return ServerInsertedHTMLContext;
    },
    useServerInsertedHTML: function() {
        return useServerInsertedHTML;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const ServerInsertedHTMLContext = /*#__PURE__*/ _react.default.createContext(null);
function useServerInsertedHTML(callback) {
    const addInsertedServerHTMLCallback = (0, _react.useContext)(ServerInsertedHTMLContext);
    // Should have no effects on client where there's no flush effects provider
    if (addInsertedServerHTMLCallback) {
        addInsertedServerHTMLCallback(callback);
    }
} //# sourceMappingURL=server-inserted-html.shared-runtime.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/path-has-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "pathHasPrefix", {
    enumerable: true,
    get: function() {
        return pathHasPrefix;
    }
});
const _parsepath = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)");
function pathHasPrefix(path, prefix) {
    if (typeof path !== 'string') {
        return false;
    }
    const { pathname } = (0, _parsepath.parsePath)(path);
    return pathname === prefix || pathname.startsWith(prefix + '/');
} //# sourceMappingURL=path-has-prefix.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "warnOnce", {
    enumerable: true,
    get: function() {
        return warnOnce;
    }
});
let warnOnce = (_)=>{};
if ("TURBOPACK compile-time truthy", 1) {
    const warnings = new Set();
    warnOnce = (msg)=>{
        if (!warnings.has(msg)) {
            console.warn(msg);
        }
        warnings.add(msg);
    };
} //# sourceMappingURL=warn-once.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/format-webpack-messages.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
MIT License

Copyright (c) 2015-present, Facebook, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return formatWebpackMessages;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _stripansi = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/strip-ansi/index.js [app-client] (ecmascript)"));
// This file is based on https://github.com/facebook/create-react-app/blob/7b1a32be6ec9f99a6c9a3c66813f3ac09c4736b9/packages/react-dev-utils/formatWebpackMessages.js
// It's been edited to remove chalk and CRA-specific logic
const friendlySyntaxErrorLabel = 'Syntax error:';
const WEBPACK_BREAKING_CHANGE_POLYFILLS = '\n\nBREAKING CHANGE: webpack < 5 used to include polyfills for node.js core modules by default.';
function isLikelyASyntaxError(message) {
    return (0, _stripansi.default)(message).includes(friendlySyntaxErrorLabel);
}
let hadMissingSassError = false;
// Cleans up webpack error messages.
function formatMessage(message, verbose, importTraceNote) {
    // TODO: Replace this once webpack 5 is stable
    if (typeof message === 'object' && message.message) {
        const filteredModuleTrace = message.moduleTrace && message.moduleTrace.filter((trace)=>!/next-(middleware|client-pages|route|edge-function)-loader\.js/.test(trace.originName));
        let body = message.message;
        const breakingChangeIndex = body.indexOf(WEBPACK_BREAKING_CHANGE_POLYFILLS);
        if (breakingChangeIndex >= 0) {
            body = body.slice(0, breakingChangeIndex);
        }
        message = (message.moduleName ? (0, _stripansi.default)(message.moduleName) + '\n' : '') + (message.file ? (0, _stripansi.default)(message.file) + '\n' : '') + body + (message.details && verbose ? '\n' + message.details : '') + (filteredModuleTrace && filteredModuleTrace.length ? (importTraceNote || '\n\nImport trace for requested module:') + filteredModuleTrace.map((trace)=>`\n${trace.moduleName}`).join('') : '') + (message.stack && verbose ? '\n' + message.stack : '');
    }
    let lines = message.split('\n');
    // Strip Webpack-added headers off errors/warnings
    // https://github.com/webpack/webpack/blob/master/lib/ModuleError.js
    lines = lines.filter((line)=>!/Module [A-z ]+\(from/.test(line));
    // Transform parsing error into syntax error
    // TODO: move this to our ESLint formatter?
    lines = lines.map((line)=>{
        const parsingError = /Line (\d+):(?:(\d+):)?\s*Parsing error: (.+)$/.exec(line);
        if (!parsingError) {
            return line;
        }
        const [, errorLine, errorColumn, errorMessage] = parsingError;
        return `${friendlySyntaxErrorLabel} ${errorMessage} (${errorLine}:${errorColumn})`;
    });
    message = lines.join('\n');
    // Smoosh syntax errors (commonly found in CSS)
    message = message.replace(/SyntaxError\s+\((\d+):(\d+)\)\s*(.+?)\n/g, `${friendlySyntaxErrorLabel} $3 ($1:$2)\n`);
    // Clean up export errors
    message = message.replace(/^.*export '(.+?)' was not found in '(.+?)'.*$/gm, `Attempted import error: '$1' is not exported from '$2'.`);
    message = message.replace(/^.*export 'default' \(imported as '(.+?)'\) was not found in '(.+?)'.*$/gm, `Attempted import error: '$2' does not contain a default export (imported as '$1').`);
    message = message.replace(/^.*export '(.+?)' \(imported as '(.+?)'\) was not found in '(.+?)'.*$/gm, `Attempted import error: '$1' is not exported from '$3' (imported as '$2').`);
    lines = message.split('\n');
    // Remove leading newline
    if (lines.length > 2 && lines[1].trim() === '') {
        lines.splice(1, 1);
    }
    // Cleans up verbose "module not found" messages for files and packages.
    if (lines[1] && lines[1].startsWith('Module not found: ')) {
        lines = [
            lines[0],
            lines[1].replace('Error: ', '').replace('Module not found: Cannot find file:', 'Cannot find file:'),
            ...lines.slice(2)
        ];
    }
    // Add helpful message for users trying to use Sass for the first time
    if (lines[1] && lines[1].match(/Cannot find module.+sass/)) {
        // ./file.module.scss (<<loader info>>) => ./file.module.scss
        const firstLine = lines[0].split('!');
        lines[0] = firstLine[firstLine.length - 1];
        lines[1] = "To use Next.js' built-in Sass support, you first need to install `sass`.\n";
        lines[1] += 'Run `npm i sass` or `yarn add sass` inside your workspace.\n';
        lines[1] += '\nLearn more: https://nextjs.org/docs/messages/install-sass';
        // dispose of unhelpful stack trace
        lines = lines.slice(0, 2);
        hadMissingSassError = true;
    } else if (hadMissingSassError && message.match(/(sass-loader|resolve-url-loader: CSS error)/)) {
        // dispose of unhelpful stack trace following missing sass module
        lines = [];
    }
    if (!verbose) {
        message = lines.join('\n');
        // Internal stacks are generally useless so we strip them... with the
        // exception of stacks containing `webpack:` because they're normally
        // from user code generated by Webpack. For more information see
        // https://github.com/facebook/create-react-app/pull/1050
        message = message.replace(/^\s*at\s((?!webpack:).)*:\d+:\d+[\s)]*(\n|$)/gm, '') // at ... ...:x:y
        ;
        message = message.replace(/^\s*at\s<anonymous>(\n|$)/gm, '') // at <anonymous>
        ;
        message = message.replace(/File was processed with these loaders:\n(.+[\\/](next[\\/]dist[\\/].+|@next[\\/]react-refresh-utils[\\/]loader)\.js\n)*You may need an additional loader to handle the result of these loaders.\n/g, '');
        lines = message.split('\n');
    }
    // Remove duplicated newlines
    lines = lines.filter((line, index, arr)=>index === 0 || line.trim() !== '' || line.trim() !== arr[index - 1].trim());
    // Reassemble the message
    message = lines.join('\n');
    return message.trim();
}
function formatWebpackMessages(json, verbose) {
    const formattedErrors = json.errors.map((message)=>{
        const isUnknownNextFontError = message.message.includes('An error occurred in `next/font`.');
        return formatMessage(message, isUnknownNextFontError || verbose);
    });
    const formattedWarnings = json.warnings.map((message)=>{
        return formatMessage(message, verbose);
    });
    // Reorder errors to put the most relevant ones first.
    let reactServerComponentsError = -1;
    for(let i = 0; i < formattedErrors.length; i++){
        const error = formattedErrors[i];
        if (error.includes('ReactServerComponentsError')) {
            reactServerComponentsError = i;
            break;
        }
    }
    // Move the reactServerComponentsError to the top if it exists
    if (reactServerComponentsError !== -1) {
        const error = formattedErrors.splice(reactServerComponentsError, 1);
        formattedErrors.unshift(error[0]);
    }
    const result = {
        ...json,
        errors: formattedErrors,
        warnings: formattedWarnings
    };
    if (!verbose && result.errors.some(isLikelyASyntaxError)) {
        // If there are any syntax errors, show just them.
        result.errors = result.errors.filter(isLikelyASyntaxError);
        result.warnings = [];
    }
    return result;
} //# sourceMappingURL=format-webpack-messages.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/errors/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "MISSING_ROOT_TAGS_ERROR", {
    enumerable: true,
    get: function() {
        return MISSING_ROOT_TAGS_ERROR;
    }
});
const MISSING_ROOT_TAGS_ERROR = 'NEXT_MISSING_ROOT_TAGS';
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=constants.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/normalized-asset-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "normalizedAssetPrefix", {
    enumerable: true,
    get: function() {
        return normalizedAssetPrefix;
    }
});
function normalizedAssetPrefix(assetPrefix) {
    // remove all leading slashes and trailing slashes
    const escapedAssetPrefix = assetPrefix?.replace(/^\/+|\/+$/g, '') || false;
    // if an assetPrefix was '/', we return empty string
    // because it could be an unnecessary trailing slash
    if (!escapedAssetPrefix) {
        return '';
    }
    if (URL.canParse(escapedAssetPrefix)) {
        const url = new URL(escapedAssetPrefix).toString();
        return url.endsWith('/') ? url.slice(0, -1) : url;
    }
    // assuming assetPrefix here is a pathname-style,
    // restore the leading slash
    return `/${escapedAssetPrefix}`;
} //# sourceMappingURL=normalized-asset-prefix.js.map
}),
"[project]/packages/web/node_modules/next/dist/shared/lib/server-reference-info.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    extractInfoFromServerReferenceId: null,
    omitUnusedArgs: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    extractInfoFromServerReferenceId: function() {
        return extractInfoFromServerReferenceId;
    },
    omitUnusedArgs: function() {
        return omitUnusedArgs;
    }
});
function extractInfoFromServerReferenceId(id) {
    const infoByte = parseInt(id.slice(0, 2), 16);
    const typeBit = infoByte >> 7 & 0x1;
    const argMask = infoByte >> 1 & 0x3f;
    const restArgs = infoByte & 0x1;
    const usedArgs = Array(6);
    for(let index = 0; index < 6; index++){
        const bitPosition = 5 - index;
        const bit = argMask >> bitPosition & 0x1;
        usedArgs[index] = bit === 1;
    }
    return {
        type: typeBit === 1 ? 'use-cache' : 'server-action',
        usedArgs: usedArgs,
        hasRestArgs: restArgs === 1
    };
}
function omitUnusedArgs(args, info) {
    const filteredArgs = new Array(args.length);
    for(let index = 0; index < args.length; index++){
        if (index < 6 && info.usedArgs[index] || // This assumes that the server reference info byte has the restArgs bit
        // set to 1 if there are more than 6 args.
        index >= 6 && info.hasRestArgs) {
            filteredArgs[index] = args[index];
        }
    }
    return filteredArgs;
} //# sourceMappingURL=server-reference-info.js.map
}),
"[project]/packages/web/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    default: null,
    getProperError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    /**
 * Checks whether the given value is a NextError.
 * This can be used to print a more detailed error message with properties like `code` & `digest`.
 */ default: function() {
        return isError;
    },
    getProperError: function() {
        return getProperError;
    }
});
const _isplainobject = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/is-plain-object.js [app-client] (ecmascript)");
const _safestablestringify = /*#__PURE__*/ _interop_require_default(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/safe-stable-stringify/index.js [app-client] (ecmascript)"));
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
function isError(err) {
    return typeof err === 'object' && err !== null && 'name' in err && 'message' in err;
}
function getProperError(err) {
    if (isError(err)) {
        return err;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        // provide better error for case where `throw undefined`
        // is called in development
        if (typeof err === 'undefined') {
            return Object.defineProperty(new Error('An undefined error was thrown, ' + 'see here for more info: https://nextjs.org/docs/messages/threw-undefined'), "__NEXT_ERROR_CODE", {
                value: "E98",
                enumerable: false,
                configurable: true
            });
        }
        if (err === null) {
            return Object.defineProperty(new Error('A null error was thrown, ' + 'see here for more info: https://nextjs.org/docs/messages/threw-undefined'), "__NEXT_ERROR_CODE", {
                value: "E336",
                enumerable: false,
                configurable: true
            });
        }
    }
    return Object.defineProperty(new Error((0, _isplainobject.isPlainObject)(err) ? (0, _safestablestringify.default)(err) : err + ''), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
} //# sourceMappingURL=is-error.js.map
}),
"[project]/packages/web/node_modules/next/dist/lib/require-instrumentation-client.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * This module imports the client instrumentation hook from the project root.
 *
 * The `private-next-instrumentation-client` module is automatically aliased to
 * the `instrumentation-client.ts` file in the project root by webpack or turbopack.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
if ("TURBOPACK compile-time truthy", 1) {
    const measureName = 'Client Instrumentation Hook';
    const startTime = performance.now();
    // eslint-disable-next-line @next/internal/typechecked-require -- Not a module.
    module.exports = {};
    const endTime = performance.now();
    const duration = endTime - startTime;
    // Using 16ms threshold as it represents one frame (1000ms/60fps)
    // This helps identify if the instrumentation hook initialization
    // could potentially cause frame drops during development.
    const THRESHOLD = 16;
    if (duration > THRESHOLD) {
        console.log(`[${measureName}] Slow execution detected: ${duration.toFixed(0)}ms (Note: Code download overhead is not included in this measurement)`);
    }
} else //TURBOPACK unreachable
;
 //# sourceMappingURL=require-instrumentation-client.js.map
}),
"[project]/packages/web/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    METADATA_BOUNDARY_NAME: null,
    OUTLET_BOUNDARY_NAME: null,
    ROOT_LAYOUT_BOUNDARY_NAME: null,
    VIEWPORT_BOUNDARY_NAME: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    METADATA_BOUNDARY_NAME: function() {
        return METADATA_BOUNDARY_NAME;
    },
    OUTLET_BOUNDARY_NAME: function() {
        return OUTLET_BOUNDARY_NAME;
    },
    ROOT_LAYOUT_BOUNDARY_NAME: function() {
        return ROOT_LAYOUT_BOUNDARY_NAME;
    },
    VIEWPORT_BOUNDARY_NAME: function() {
        return VIEWPORT_BOUNDARY_NAME;
    }
});
const METADATA_BOUNDARY_NAME = '__next_metadata_boundary__';
const VIEWPORT_BOUNDARY_NAME = '__next_viewport_boundary__';
const OUTLET_BOUNDARY_NAME = '__next_outlet_boundary__';
const ROOT_LAYOUT_BOUNDARY_NAME = '__next_root_layout_boundary__'; //# sourceMappingURL=boundary-constants.js.map
}),
"[project]/packages/web/node_modules/next/dist/lib/scheduler.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    atLeastOneTask: null,
    scheduleImmediate: null,
    scheduleOnNextTick: null,
    waitAtLeastOneReactRenderTask: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    atLeastOneTask: function() {
        return atLeastOneTask;
    },
    scheduleImmediate: function() {
        return scheduleImmediate;
    },
    scheduleOnNextTick: function() {
        return scheduleOnNextTick;
    },
    waitAtLeastOneReactRenderTask: function() {
        return waitAtLeastOneReactRenderTask;
    }
});
const scheduleOnNextTick = (cb)=>{
    // We use Promise.resolve().then() here so that the operation is scheduled at
    // the end of the promise job queue, we then add it to the next process tick
    // to ensure it's evaluated afterwards.
    //
    // This was inspired by the implementation of the DataLoader interface: https://github.com/graphql/dataloader/blob/d336bd15282664e0be4b4a657cb796f09bafbc6b/src/index.js#L213-L255
    //
    Promise.resolve().then(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        else {
            __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].nextTick(cb);
        }
    });
};
const scheduleImmediate = (cb)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        setImmediate(cb);
    }
};
function atLeastOneTask() {
    return new Promise((resolve)=>scheduleImmediate(resolve));
}
function waitAtLeastOneReactRenderTask() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        return new Promise((r)=>setImmediate(r));
    }
} //# sourceMappingURL=scheduler.js.map
}),
"[project]/packages/web/node_modules/next/dist/lib/framework/boundary-components.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    MetadataBoundary: null,
    OutletBoundary: null,
    RootLayoutBoundary: null,
    ViewportBoundary: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    MetadataBoundary: function() {
        return MetadataBoundary;
    },
    OutletBoundary: function() {
        return OutletBoundary;
    },
    RootLayoutBoundary: function() {
        return RootLayoutBoundary;
    },
    ViewportBoundary: function() {
        return ViewportBoundary;
    }
});
const _boundaryconstants = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)");
// We use a namespace object to allow us to recover the name of the function
// at runtime even when production bundling/minification is used.
const NameSpace = {
    [_boundaryconstants.METADATA_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.VIEWPORT_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.OUTLET_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME]: function({ children }) {
        return children;
    }
};
const MetadataBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.METADATA_BOUNDARY_NAME.slice(0)];
const ViewportBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.VIEWPORT_BOUNDARY_NAME.slice(0)];
const OutletBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.OUTLET_BOUNDARY_NAME.slice(0)];
const RootLayoutBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]; //# sourceMappingURL=boundary-components.js.map
}),
"[project]/packages/web/node_modules/next/dist/lib/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ACTION_SUFFIX: null,
    APP_DIR_ALIAS: null,
    CACHE_ONE_YEAR: null,
    DOT_NEXT_ALIAS: null,
    ESLINT_DEFAULT_DIRS: null,
    GSP_NO_RETURNED_VALUE: null,
    GSSP_COMPONENT_MEMBER_ERROR: null,
    GSSP_NO_RETURNED_VALUE: null,
    HTML_CONTENT_TYPE_HEADER: null,
    INFINITE_CACHE: null,
    INSTRUMENTATION_HOOK_FILENAME: null,
    JSON_CONTENT_TYPE_HEADER: null,
    MATCHED_PATH_HEADER: null,
    MIDDLEWARE_FILENAME: null,
    MIDDLEWARE_LOCATION_REGEXP: null,
    NEXT_BODY_SUFFIX: null,
    NEXT_CACHE_IMPLICIT_TAG_ID: null,
    NEXT_CACHE_REVALIDATED_TAGS_HEADER: null,
    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: null,
    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: null,
    NEXT_CACHE_TAGS_HEADER: null,
    NEXT_CACHE_TAG_MAX_ITEMS: null,
    NEXT_CACHE_TAG_MAX_LENGTH: null,
    NEXT_DATA_SUFFIX: null,
    NEXT_INTERCEPTION_MARKER_PREFIX: null,
    NEXT_META_SUFFIX: null,
    NEXT_QUERY_PARAM_PREFIX: null,
    NEXT_RESUME_HEADER: null,
    NON_STANDARD_NODE_ENV: null,
    PAGES_DIR_ALIAS: null,
    PRERENDER_REVALIDATE_HEADER: null,
    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: null,
    PROXY_FILENAME: null,
    PROXY_LOCATION_REGEXP: null,
    PUBLIC_DIR_MIDDLEWARE_CONFLICT: null,
    ROOT_DIR_ALIAS: null,
    RSC_ACTION_CLIENT_WRAPPER_ALIAS: null,
    RSC_ACTION_ENCRYPTION_ALIAS: null,
    RSC_ACTION_PROXY_ALIAS: null,
    RSC_ACTION_VALIDATE_ALIAS: null,
    RSC_CACHE_WRAPPER_ALIAS: null,
    RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS: null,
    RSC_MOD_REF_PROXY_ALIAS: null,
    RSC_PREFETCH_SUFFIX: null,
    RSC_SEGMENTS_DIR_SUFFIX: null,
    RSC_SEGMENT_SUFFIX: null,
    RSC_SUFFIX: null,
    SERVER_PROPS_EXPORT_ERROR: null,
    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: null,
    SERVER_PROPS_SSG_CONFLICT: null,
    SERVER_RUNTIME: null,
    SSG_FALLBACK_EXPORT_ERROR: null,
    SSG_GET_INITIAL_PROPS_CONFLICT: null,
    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: null,
    TEXT_PLAIN_CONTENT_TYPE_HEADER: null,
    UNSTABLE_REVALIDATE_RENAME_ERROR: null,
    WEBPACK_LAYERS: null,
    WEBPACK_RESOURCE_QUERIES: null,
    WEB_SOCKET_MAX_RECONNECTIONS: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ACTION_SUFFIX: function() {
        return ACTION_SUFFIX;
    },
    APP_DIR_ALIAS: function() {
        return APP_DIR_ALIAS;
    },
    CACHE_ONE_YEAR: function() {
        return CACHE_ONE_YEAR;
    },
    DOT_NEXT_ALIAS: function() {
        return DOT_NEXT_ALIAS;
    },
    ESLINT_DEFAULT_DIRS: function() {
        return ESLINT_DEFAULT_DIRS;
    },
    GSP_NO_RETURNED_VALUE: function() {
        return GSP_NO_RETURNED_VALUE;
    },
    GSSP_COMPONENT_MEMBER_ERROR: function() {
        return GSSP_COMPONENT_MEMBER_ERROR;
    },
    GSSP_NO_RETURNED_VALUE: function() {
        return GSSP_NO_RETURNED_VALUE;
    },
    HTML_CONTENT_TYPE_HEADER: function() {
        return HTML_CONTENT_TYPE_HEADER;
    },
    INFINITE_CACHE: function() {
        return INFINITE_CACHE;
    },
    INSTRUMENTATION_HOOK_FILENAME: function() {
        return INSTRUMENTATION_HOOK_FILENAME;
    },
    JSON_CONTENT_TYPE_HEADER: function() {
        return JSON_CONTENT_TYPE_HEADER;
    },
    MATCHED_PATH_HEADER: function() {
        return MATCHED_PATH_HEADER;
    },
    MIDDLEWARE_FILENAME: function() {
        return MIDDLEWARE_FILENAME;
    },
    MIDDLEWARE_LOCATION_REGEXP: function() {
        return MIDDLEWARE_LOCATION_REGEXP;
    },
    NEXT_BODY_SUFFIX: function() {
        return NEXT_BODY_SUFFIX;
    },
    NEXT_CACHE_IMPLICIT_TAG_ID: function() {
        return NEXT_CACHE_IMPLICIT_TAG_ID;
    },
    NEXT_CACHE_REVALIDATED_TAGS_HEADER: function() {
        return NEXT_CACHE_REVALIDATED_TAGS_HEADER;
    },
    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: function() {
        return NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER;
    },
    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: function() {
        return NEXT_CACHE_SOFT_TAG_MAX_LENGTH;
    },
    NEXT_CACHE_TAGS_HEADER: function() {
        return NEXT_CACHE_TAGS_HEADER;
    },
    NEXT_CACHE_TAG_MAX_ITEMS: function() {
        return NEXT_CACHE_TAG_MAX_ITEMS;
    },
    NEXT_CACHE_TAG_MAX_LENGTH: function() {
        return NEXT_CACHE_TAG_MAX_LENGTH;
    },
    NEXT_DATA_SUFFIX: function() {
        return NEXT_DATA_SUFFIX;
    },
    NEXT_INTERCEPTION_MARKER_PREFIX: function() {
        return NEXT_INTERCEPTION_MARKER_PREFIX;
    },
    NEXT_META_SUFFIX: function() {
        return NEXT_META_SUFFIX;
    },
    NEXT_QUERY_PARAM_PREFIX: function() {
        return NEXT_QUERY_PARAM_PREFIX;
    },
    NEXT_RESUME_HEADER: function() {
        return NEXT_RESUME_HEADER;
    },
    NON_STANDARD_NODE_ENV: function() {
        return NON_STANDARD_NODE_ENV;
    },
    PAGES_DIR_ALIAS: function() {
        return PAGES_DIR_ALIAS;
    },
    PRERENDER_REVALIDATE_HEADER: function() {
        return PRERENDER_REVALIDATE_HEADER;
    },
    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: function() {
        return PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER;
    },
    PROXY_FILENAME: function() {
        return PROXY_FILENAME;
    },
    PROXY_LOCATION_REGEXP: function() {
        return PROXY_LOCATION_REGEXP;
    },
    PUBLIC_DIR_MIDDLEWARE_CONFLICT: function() {
        return PUBLIC_DIR_MIDDLEWARE_CONFLICT;
    },
    ROOT_DIR_ALIAS: function() {
        return ROOT_DIR_ALIAS;
    },
    RSC_ACTION_CLIENT_WRAPPER_ALIAS: function() {
        return RSC_ACTION_CLIENT_WRAPPER_ALIAS;
    },
    RSC_ACTION_ENCRYPTION_ALIAS: function() {
        return RSC_ACTION_ENCRYPTION_ALIAS;
    },
    RSC_ACTION_PROXY_ALIAS: function() {
        return RSC_ACTION_PROXY_ALIAS;
    },
    RSC_ACTION_VALIDATE_ALIAS: function() {
        return RSC_ACTION_VALIDATE_ALIAS;
    },
    RSC_CACHE_WRAPPER_ALIAS: function() {
        return RSC_CACHE_WRAPPER_ALIAS;
    },
    RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS: function() {
        return RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS;
    },
    RSC_MOD_REF_PROXY_ALIAS: function() {
        return RSC_MOD_REF_PROXY_ALIAS;
    },
    RSC_PREFETCH_SUFFIX: function() {
        return RSC_PREFETCH_SUFFIX;
    },
    RSC_SEGMENTS_DIR_SUFFIX: function() {
        return RSC_SEGMENTS_DIR_SUFFIX;
    },
    RSC_SEGMENT_SUFFIX: function() {
        return RSC_SEGMENT_SUFFIX;
    },
    RSC_SUFFIX: function() {
        return RSC_SUFFIX;
    },
    SERVER_PROPS_EXPORT_ERROR: function() {
        return SERVER_PROPS_EXPORT_ERROR;
    },
    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: function() {
        return SERVER_PROPS_GET_INIT_PROPS_CONFLICT;
    },
    SERVER_PROPS_SSG_CONFLICT: function() {
        return SERVER_PROPS_SSG_CONFLICT;
    },
    SERVER_RUNTIME: function() {
        return SERVER_RUNTIME;
    },
    SSG_FALLBACK_EXPORT_ERROR: function() {
        return SSG_FALLBACK_EXPORT_ERROR;
    },
    SSG_GET_INITIAL_PROPS_CONFLICT: function() {
        return SSG_GET_INITIAL_PROPS_CONFLICT;
    },
    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: function() {
        return STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR;
    },
    TEXT_PLAIN_CONTENT_TYPE_HEADER: function() {
        return TEXT_PLAIN_CONTENT_TYPE_HEADER;
    },
    UNSTABLE_REVALIDATE_RENAME_ERROR: function() {
        return UNSTABLE_REVALIDATE_RENAME_ERROR;
    },
    WEBPACK_LAYERS: function() {
        return WEBPACK_LAYERS;
    },
    WEBPACK_RESOURCE_QUERIES: function() {
        return WEBPACK_RESOURCE_QUERIES;
    },
    WEB_SOCKET_MAX_RECONNECTIONS: function() {
        return WEB_SOCKET_MAX_RECONNECTIONS;
    }
});
const TEXT_PLAIN_CONTENT_TYPE_HEADER = 'text/plain';
const HTML_CONTENT_TYPE_HEADER = 'text/html; charset=utf-8';
const JSON_CONTENT_TYPE_HEADER = 'application/json; charset=utf-8';
const NEXT_QUERY_PARAM_PREFIX = 'nxtP';
const NEXT_INTERCEPTION_MARKER_PREFIX = 'nxtI';
const MATCHED_PATH_HEADER = 'x-matched-path';
const PRERENDER_REVALIDATE_HEADER = 'x-prerender-revalidate';
const PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER = 'x-prerender-revalidate-if-generated';
const RSC_PREFETCH_SUFFIX = '.prefetch.rsc';
const RSC_SEGMENTS_DIR_SUFFIX = '.segments';
const RSC_SEGMENT_SUFFIX = '.segment.rsc';
const RSC_SUFFIX = '.rsc';
const ACTION_SUFFIX = '.action';
const NEXT_DATA_SUFFIX = '.json';
const NEXT_META_SUFFIX = '.meta';
const NEXT_BODY_SUFFIX = '.body';
const NEXT_CACHE_TAGS_HEADER = 'x-next-cache-tags';
const NEXT_CACHE_REVALIDATED_TAGS_HEADER = 'x-next-revalidated-tags';
const NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER = 'x-next-revalidate-tag-token';
const NEXT_RESUME_HEADER = 'next-resume';
const NEXT_CACHE_TAG_MAX_ITEMS = 128;
const NEXT_CACHE_TAG_MAX_LENGTH = 256;
const NEXT_CACHE_SOFT_TAG_MAX_LENGTH = 1024;
const NEXT_CACHE_IMPLICIT_TAG_ID = '_N_T_';
const CACHE_ONE_YEAR = 31536000;
const INFINITE_CACHE = 0xfffffffe;
const MIDDLEWARE_FILENAME = 'middleware';
const MIDDLEWARE_LOCATION_REGEXP = `(?:src/)?${MIDDLEWARE_FILENAME}`;
const PROXY_FILENAME = 'proxy';
const PROXY_LOCATION_REGEXP = `(?:src/)?${PROXY_FILENAME}`;
const INSTRUMENTATION_HOOK_FILENAME = 'instrumentation';
const PAGES_DIR_ALIAS = 'private-next-pages';
const DOT_NEXT_ALIAS = 'private-dot-next';
const ROOT_DIR_ALIAS = 'private-next-root-dir';
const APP_DIR_ALIAS = 'private-next-app-dir';
const RSC_MOD_REF_PROXY_ALIAS = 'private-next-rsc-mod-ref-proxy';
const RSC_ACTION_VALIDATE_ALIAS = 'private-next-rsc-action-validate';
const RSC_ACTION_PROXY_ALIAS = 'private-next-rsc-server-reference';
const RSC_CACHE_WRAPPER_ALIAS = 'private-next-rsc-cache-wrapper';
const RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS = 'private-next-rsc-track-dynamic-import';
const RSC_ACTION_ENCRYPTION_ALIAS = 'private-next-rsc-action-encryption';
const RSC_ACTION_CLIENT_WRAPPER_ALIAS = 'private-next-rsc-action-client-wrapper';
const PUBLIC_DIR_MIDDLEWARE_CONFLICT = `You can not have a '_next' folder inside of your public folder. This conflicts with the internal '/_next' route. https://nextjs.org/docs/messages/public-next-folder-conflict`;
const SSG_GET_INITIAL_PROPS_CONFLICT = `You can not use getInitialProps with getStaticProps. To use SSG, please remove your getInitialProps`;
const SERVER_PROPS_GET_INIT_PROPS_CONFLICT = `You can not use getInitialProps with getServerSideProps. Please remove getInitialProps.`;
const SERVER_PROPS_SSG_CONFLICT = `You can not use getStaticProps or getStaticPaths with getServerSideProps. To use SSG, please remove getServerSideProps`;
const STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR = `can not have getInitialProps/getServerSideProps, https://nextjs.org/docs/messages/404-get-initial-props`;
const SERVER_PROPS_EXPORT_ERROR = `pages with \`getServerSideProps\` can not be exported. See more info here: https://nextjs.org/docs/messages/gssp-export`;
const GSP_NO_RETURNED_VALUE = 'Your `getStaticProps` function did not return an object. Did you forget to add a `return`?';
const GSSP_NO_RETURNED_VALUE = 'Your `getServerSideProps` function did not return an object. Did you forget to add a `return`?';
const UNSTABLE_REVALIDATE_RENAME_ERROR = 'The `unstable_revalidate` property is available for general use.\n' + 'Please use `revalidate` instead.';
const GSSP_COMPONENT_MEMBER_ERROR = `can not be attached to a page's component and must be exported from the page. See more info here: https://nextjs.org/docs/messages/gssp-component-member`;
const NON_STANDARD_NODE_ENV = `You are using a non-standard "NODE_ENV" value in your environment. This creates inconsistencies in the project and is strongly advised against. Read more: https://nextjs.org/docs/messages/non-standard-node-env`;
const SSG_FALLBACK_EXPORT_ERROR = `Pages with \`fallback\` enabled in \`getStaticPaths\` can not be exported. See more info here: https://nextjs.org/docs/messages/ssg-fallback-true-export`;
const ESLINT_DEFAULT_DIRS = [
    'app',
    'pages',
    'components',
    'lib',
    'src'
];
const SERVER_RUNTIME = {
    edge: 'edge',
    experimentalEdge: 'experimental-edge',
    nodejs: 'nodejs'
};
const WEB_SOCKET_MAX_RECONNECTIONS = 12;
/**
 * The names of the webpack layers. These layers are the primitives for the
 * webpack chunks.
 */ const WEBPACK_LAYERS_NAMES = {
    /**
   * The layer for the shared code between the client and server bundles.
   */ shared: 'shared',
    /**
   * The layer for server-only runtime and picking up `react-server` export conditions.
   * Including app router RSC pages and app router custom routes and metadata routes.
   */ reactServerComponents: 'rsc',
    /**
   * Server Side Rendering layer for app (ssr).
   */ serverSideRendering: 'ssr',
    /**
   * The browser client bundle layer for actions.
   */ actionBrowser: 'action-browser',
    /**
   * The Node.js bundle layer for the API routes.
   */ apiNode: 'api-node',
    /**
   * The Edge Lite bundle layer for the API routes.
   */ apiEdge: 'api-edge',
    /**
   * The layer for the middleware code.
   */ middleware: 'middleware',
    /**
   * The layer for the instrumentation hooks.
   */ instrument: 'instrument',
    /**
   * The layer for assets on the edge.
   */ edgeAsset: 'edge-asset',
    /**
   * The browser client bundle layer for App directory.
   */ appPagesBrowser: 'app-pages-browser',
    /**
   * The browser client bundle layer for Pages directory.
   */ pagesDirBrowser: 'pages-dir-browser',
    /**
   * The Edge Lite bundle layer for Pages directory.
   */ pagesDirEdge: 'pages-dir-edge',
    /**
   * The Node.js bundle layer for Pages directory.
   */ pagesDirNode: 'pages-dir-node'
};
const WEBPACK_LAYERS = {
    ...WEBPACK_LAYERS_NAMES,
    GROUP: {
        builtinReact: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser
        ],
        serverOnly: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser,
            WEBPACK_LAYERS_NAMES.instrument,
            WEBPACK_LAYERS_NAMES.middleware
        ],
        neutralTarget: [
            // pages api
            WEBPACK_LAYERS_NAMES.apiNode,
            WEBPACK_LAYERS_NAMES.apiEdge
        ],
        clientOnly: [
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser
        ],
        bundled: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser,
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser,
            WEBPACK_LAYERS_NAMES.shared,
            WEBPACK_LAYERS_NAMES.instrument,
            WEBPACK_LAYERS_NAMES.middleware
        ],
        appPages: [
            // app router pages and layouts
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser,
            WEBPACK_LAYERS_NAMES.actionBrowser
        ]
    }
};
const WEBPACK_RESOURCE_QUERIES = {
    edgeSSREntry: '__next_edge_ssr_entry__',
    metadata: '__next_metadata__',
    metadataRoute: '__next_metadata_route__',
    metadataImageMeta: '__next_metadata_image_meta__'
}; //# sourceMappingURL=constants.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    coerceError: null,
    decorateDevError: null,
    getOwnerStack: null,
    setOwnerStack: null,
    setOwnerStackIfAvailable: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    coerceError: function() {
        return coerceError;
    },
    decorateDevError: function() {
        return decorateDevError;
    },
    getOwnerStack: function() {
        return getOwnerStack;
    },
    setOwnerStack: function() {
        return setOwnerStack;
    },
    setOwnerStackIfAvailable: function() {
        return setOwnerStackIfAvailable;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const ownerStacks = new WeakMap();
function getOwnerStack(error) {
    return ownerStacks.get(error);
}
function setOwnerStack(error, stack) {
    ownerStacks.set(error, stack);
}
function coerceError(value) {
    return (0, _iserror.default)(value) ? value : Object.defineProperty(new Error('' + value), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
}
function setOwnerStackIfAvailable(error) {
    // React 18 and prod does not have `captureOwnerStack`
    if ('captureOwnerStack' in _react.default) {
        setOwnerStack(error, _react.default.captureOwnerStack());
    }
}
function decorateDevError(thrownValue) {
    const error = coerceError(thrownValue);
    setOwnerStackIfAvailable(error);
    return error;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=stitched-error.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/shared/console-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// To distinguish from React error.digest, we use a different symbol here to determine if the error is from console.error or unhandled promise rejection.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    createConsoleError: null,
    isConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    createConsoleError: function() {
        return createConsoleError;
    },
    isConsoleError: function() {
        return isConsoleError;
    }
});
const digestSym = Symbol.for('next.console.error.digest');
function createConsoleError(message, environmentName) {
    const error = typeof message === 'string' ? Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    }) : message;
    error[digestSym] = 'NEXT_CONSOLE_ERROR';
    if (environmentName && !error.environmentName) {
        error.environmentName = environmentName;
    }
    return error;
}
const isConsoleError = (error)=>{
    return error && error[digestSym] === 'NEXT_CONSOLE_ERROR';
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=console-error.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getIsTerminalLoggingEnabled: null,
    getTerminalLoggingConfig: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getIsTerminalLoggingEnabled: function() {
        return getIsTerminalLoggingEnabled;
    },
    getTerminalLoggingConfig: function() {
        return getTerminalLoggingConfig;
    }
});
function getTerminalLoggingConfig() {
    try {
        return JSON.parse(("TURBOPACK compile-time value", "false") || 'false');
    } catch  {
        return false;
    }
}
function getIsTerminalLoggingEnabled() {
    const config = getTerminalLoggingConfig();
    return Boolean(config);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=terminal-logging-config.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    UNDEFINED_MARKER: null,
    patchConsoleMethod: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    UNDEFINED_MARKER: function() {
        return UNDEFINED_MARKER;
    },
    patchConsoleMethod: function() {
        return patchConsoleMethod;
    }
});
const UNDEFINED_MARKER = '__next_tagged_undefined';
function patchConsoleMethod(methodName, wrapper) {
    const descriptor = Object.getOwnPropertyDescriptor(console, methodName);
    if (descriptor && (descriptor.configurable || descriptor.writable) && typeof descriptor.value === 'function') {
        const originalMethod = descriptor.value;
        const originalName = Object.getOwnPropertyDescriptor(originalMethod, 'name');
        const wrapperMethod = function(...args) {
            wrapper(methodName, ...args);
            originalMethod.apply(this, args);
        };
        if (originalName) {
            Object.defineProperty(wrapperMethod, 'name', originalName);
        }
        Object.defineProperty(console, methodName, {
            value: wrapperMethod
        });
        return ()=>{
            Object.defineProperty(console, methodName, {
                value: originalMethod,
                writable: descriptor.writable,
                configurable: descriptor.configurable
            });
        };
    }
    return ()=>{};
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs-shared.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/forward-logs-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    logStringify: null,
    preLogSerializationClone: null,
    safeStringifyWithDepth: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    logStringify: function() {
        return logStringify;
    },
    preLogSerializationClone: function() {
        return preLogSerializationClone;
    },
    safeStringifyWithDepth: function() {
        return safeStringifyWithDepth;
    }
});
const _safestablestringify = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/safe-stable-stringify/index.js [app-client] (ecmascript)");
const _terminalloggingconfig = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)");
const _forwardlogsshared = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)");
const terminalLoggingConfig = (0, _terminalloggingconfig.getTerminalLoggingConfig)();
const PROMISE_MARKER = 'Promise {}';
const UNAVAILABLE_MARKER = '[Unable to view]';
const maximumDepth = typeof terminalLoggingConfig === 'object' && terminalLoggingConfig.depthLimit ? terminalLoggingConfig.depthLimit : 5;
const maximumBreadth = typeof terminalLoggingConfig === 'object' && terminalLoggingConfig.edgeLimit ? terminalLoggingConfig.edgeLimit : 100;
const safeStringifyWithDepth = (0, _safestablestringify.configure)({
    maximumDepth,
    maximumBreadth
});
function preLogSerializationClone(value, seen = new WeakMap()) {
    if (value === undefined) return _forwardlogsshared.UNDEFINED_MARKER;
    if (value === null || typeof value !== 'object') return value;
    if (seen.has(value)) return seen.get(value);
    try {
        Object.keys(value);
    } catch  {
        return UNAVAILABLE_MARKER;
    }
    try {
        if (typeof value.then === 'function') return PROMISE_MARKER;
    } catch  {
        return UNAVAILABLE_MARKER;
    }
    if (Array.isArray(value)) {
        const out = [];
        seen.set(value, out);
        for (const item of value){
            try {
                out.push(preLogSerializationClone(item, seen));
            } catch  {
                out.push(UNAVAILABLE_MARKER);
            }
        }
        return out;
    }
    const proto = Object.getPrototypeOf(value);
    if (proto === Object.prototype || proto === null) {
        const out = {};
        seen.set(value, out);
        for (const key of Object.keys(value)){
            try {
                out[key] = preLogSerializationClone(value[key], seen);
            } catch  {
                out[key] = UNAVAILABLE_MARKER;
            }
        }
        return out;
    }
    return Object.prototype.toString.call(value);
}
const logStringify = (data)=>{
    try {
        const result = safeStringifyWithDepth(data);
        return result ?? `"${UNAVAILABLE_MARKER}"`;
    } catch  {
        return `"${UNAVAILABLE_MARKER}"`;
    }
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs-utils.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    forwardErrorLog: null,
    forwardUnhandledError: null,
    initializeDebugLogForwarding: null,
    logQueue: null,
    logUnhandledRejection: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    forwardErrorLog: function() {
        return forwardErrorLog;
    },
    forwardUnhandledError: function() {
        return forwardUnhandledError;
    },
    initializeDebugLogForwarding: function() {
        return initializeDebugLogForwarding;
    },
    logQueue: function() {
        return logQueue;
    },
    logUnhandledRejection: function() {
        return logUnhandledRejection;
    }
});
const _stitchederror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
const _errorsource = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/error-source.js [app-client] (ecmascript)");
const _terminalloggingconfig = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)");
const _forwardlogsshared = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)");
const _forwardlogsutils = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/forward-logs-utils.js [app-client] (ecmascript)");
// Client-side file logger for browser logs
class ClientFileLogger {
    formatTimestamp() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const milliseconds = now.getMilliseconds().toString().padStart(3, '0');
        return `${hours}:${minutes}:${seconds}.${milliseconds}`;
    }
    log(level, args) {
        if (isReactServerReplayedLog(args)) {
            return;
        }
        // Format the args into a message string
        const message = args.map((arg)=>{
            if (typeof arg === 'string') return arg;
            if (typeof arg === 'number' || typeof arg === 'boolean') return String(arg);
            if (arg === null) return 'null';
            if (arg === undefined) return 'undefined';
            // Handle DOM nodes - only log the tag name to avoid React proxied elements
            if (arg instanceof Element) {
                return `<${arg.tagName.toLowerCase()}>`;
            }
            return (0, _forwardlogsutils.safeStringifyWithDepth)(arg);
        }).join(' ');
        const logEntry = {
            timestamp: this.formatTimestamp(),
            level: level.toUpperCase(),
            message
        };
        this.logEntries.push(logEntry);
        // Schedule flush when new log is added
        scheduleLogFlush();
    }
    getLogs() {
        return [
            ...this.logEntries
        ];
    }
    clear() {
        this.logEntries = [];
    }
    constructor(){
        this.logEntries = [];
    }
}
const clientFileLogger = new ClientFileLogger();
// Set up flush-based sending of client file logs
let logFlushTimeout = null;
let heartbeatInterval = null;
const scheduleLogFlush = ()=>{
    if (logFlushTimeout) {
        clearTimeout(logFlushTimeout);
    }
    logFlushTimeout = setTimeout(()=>{
        sendClientFileLogs();
        logFlushTimeout = null;
    }, 100) // Send after 100ms (much faster with debouncing)
    ;
};
const cancelLogFlush = ()=>{
    if (logFlushTimeout) {
        clearTimeout(logFlushTimeout);
        logFlushTimeout = null;
    }
};
const startHeartbeat = ()=>{
    if (heartbeatInterval) return;
    heartbeatInterval = setInterval(()=>{
        if (logQueue.socket && logQueue.socket.readyState === WebSocket.OPEN) {
            try {
                // Send a ping to keep the connection alive
                logQueue.socket.send(JSON.stringify({
                    event: 'ping'
                }));
            } catch (error) {
                // Connection might be closed, stop heartbeat
                stopHeartbeat();
            }
        } else {
            stopHeartbeat();
        }
    }, 5000) // Send ping every 5 seconds
    ;
};
const stopHeartbeat = ()=>{
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
};
const isTerminalLoggingEnabled = (0, _terminalloggingconfig.getIsTerminalLoggingEnabled)();
const methods = [
    'log',
    'info',
    'warn',
    'debug',
    'table',
    'assert',
    'dir',
    'dirxml',
    'group',
    'groupCollapsed',
    'groupEnd',
    'trace'
];
const afterThisFrame = (cb)=>{
    let timeout;
    const rafId = requestAnimationFrame(()=>{
        timeout = setTimeout(()=>{
            cb();
        });
    });
    return ()=>{
        cancelAnimationFrame(rafId);
        clearTimeout(timeout);
    };
};
let isPatched = false;
const serializeEntries = (entries)=>entries.map((clientEntry)=>{
        switch(clientEntry.kind){
            case 'any-logged-error':
            case 'console':
                {
                    return {
                        ...clientEntry,
                        args: clientEntry.args.map(stringifyUserArg)
                    };
                }
            case 'formatted-error':
                {
                    return clientEntry;
                }
            default:
                {
                    return null;
                }
        }
    });
// Function to send client file logs to server
const sendClientFileLogs = ()=>{
    if (!logQueue.socket || logQueue.socket.readyState !== WebSocket.OPEN) {
        return;
    }
    const logs = clientFileLogger.getLogs();
    if (logs.length === 0) {
        return;
    }
    try {
        const payload = JSON.stringify({
            event: 'client-file-logs',
            logs: logs
        });
        logQueue.socket.send(payload);
    } catch (error) {
        console.error(error);
    } finally{
        // Clear logs regardless of send success to prevent memory leaks
        clientFileLogger.clear();
    }
};
const logQueue = {
    entries: [],
    flushScheduled: false,
    cancelFlush: null,
    socket: null,
    sourceType: undefined,
    router: null,
    scheduleLogSend: (entry)=>{
        logQueue.entries.push(entry);
        if (logQueue.flushScheduled) {
            return;
        }
        // safe to deref and use in setTimeout closure since we cancel on new socket
        const socket = logQueue.socket;
        if (!socket) {
            return;
        }
        // we probably dont need this
        logQueue.flushScheduled = true;
        // non blocking log flush, runs at most once per frame
        logQueue.cancelFlush = afterThisFrame(()=>{
            logQueue.flushScheduled = false;
            // just incase
            try {
                const payload = JSON.stringify({
                    event: 'browser-logs',
                    entries: serializeEntries(logQueue.entries),
                    router: logQueue.router,
                    // needed for source mapping, we just assign the sourceType from the last error for the whole batch
                    sourceType: logQueue.sourceType
                });
                socket.send(payload);
                logQueue.entries = [];
                logQueue.sourceType = undefined;
                // Also send client file logs
                sendClientFileLogs();
            } catch  {
            // error (make sure u don't infinite loop)
            /* noop */ }
        });
    },
    onSocketReady: (socket)=>{
        // When MCP or terminal logging is enabled, we enable the socket connection,
        // otherwise it will not proceed.
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (socket.readyState !== WebSocket.OPEN) {
            // invariant
            return;
        }
        // incase an existing timeout was going to run with a stale socket
        logQueue.cancelFlush?.();
        logQueue.socket = socket;
        // Add socket event listeners to track connection state
        socket.addEventListener('close', ()=>{
            cancelLogFlush();
            stopHeartbeat();
        });
        // Only send terminal logs if enabled
        if (isTerminalLoggingEnabled) {
            try {
                const payload = JSON.stringify({
                    event: 'browser-logs',
                    entries: serializeEntries(logQueue.entries),
                    router: logQueue.router,
                    sourceType: logQueue.sourceType
                });
                socket.send(payload);
                logQueue.entries = [];
                logQueue.sourceType = undefined;
            } catch  {
            /** noop just incase */ }
        }
        // Always send client file logs when socket is ready
        sendClientFileLogs();
        // Start heartbeat to keep connection alive
        startHeartbeat();
    }
};
const stringifyUserArg = (arg)=>{
    if (arg.kind !== 'arg') {
        return arg;
    }
    return {
        ...arg,
        data: (0, _forwardlogsutils.logStringify)(arg.data)
    };
};
const createErrorArg = (error)=>{
    const stack = stackWithOwners(error);
    return {
        kind: 'formatted-error-arg',
        prefix: error.message ? `${error.name}: ${error.message}` : `${error.name}`,
        stack
    };
};
const createLogEntry = (level, args)=>{
    // Always log to client file logger with args (formatting done inside log method)
    clientFileLogger.log(level, args);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    // do not abstract this, it implicitly relies on which functions call it. forcing the inlined implementation makes you think about callers
    // error capture stack trace maybe
    const stack = stackWithOwners(new Error());
    const stackLines = stack?.split('\n');
    const cleanStack = stackLines?.slice(3).join('\n') // this is probably ignored anyways
    ;
    const entry = {
        kind: 'console',
        consoleMethodStack: cleanStack ?? null,
        method: level,
        args: args.map((arg)=>{
            if (arg instanceof Error) {
                return createErrorArg(arg);
            }
            return {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(arg)
            };
        })
    };
    logQueue.scheduleLogSend(entry);
};
const forwardErrorLog = (args)=>{
    // Always log to client file logger with args (formatting done inside log method)
    clientFileLogger.log('error', args);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    const errorObjects = args.filter((arg)=>arg instanceof Error);
    const first = errorObjects.at(0);
    if (first) {
        const source = (0, _errorsource.getErrorSource)(first);
        if (source) {
            logQueue.sourceType = source;
        }
    }
    /**
   * browser shows stack regardless of type of data passed to console.error, so we should do the same
   *
   * do not abstract this, it implicitly relies on which functions call it. forcing the inlined implementation makes you think about callers
   */ const stack = stackWithOwners(new Error());
    const stackLines = stack?.split('\n');
    const cleanStack = stackLines?.slice(3).join('\n');
    const entry = {
        kind: 'any-logged-error',
        method: 'error',
        consoleErrorStack: cleanStack ?? '',
        args: args.map((arg)=>{
            if (arg instanceof Error) {
                return createErrorArg(arg);
            }
            return {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(arg)
            };
        })
    };
    logQueue.scheduleLogSend(entry);
};
const createUncaughtErrorEntry = (errorName, errorMessage, fullStack)=>{
    const entry = {
        kind: 'formatted-error',
        prefix: `Uncaught ${errorName}: ${errorMessage}`,
        stack: fullStack,
        method: 'error'
    };
    logQueue.scheduleLogSend(entry);
};
const stackWithOwners = (error)=>{
    let ownerStack = '';
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    ownerStack = (0, _stitchederror.getOwnerStack)(error) || '';
    const stack = (error.stack || '') + ownerStack;
    return stack;
};
function logUnhandledRejection(reason) {
    // Always log to client file logger
    const message = reason instanceof Error ? `${reason.name}: ${reason.message}` : JSON.stringify(reason);
    clientFileLogger.log('error', [
        `unhandledRejection: ${message}`
    ]);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    if (reason instanceof Error) {
        createUnhandledRejectionErrorEntry(reason, stackWithOwners(reason));
        return;
    }
    createUnhandledRejectionNonErrorEntry(reason);
}
const createUnhandledRejectionErrorEntry = (error, fullStack)=>{
    const source = (0, _errorsource.getErrorSource)(error);
    if (source) {
        logQueue.sourceType = source;
    }
    const entry = {
        kind: 'formatted-error',
        prefix: `⨯ unhandledRejection: ${error.name}: ${error.message}`,
        stack: fullStack,
        method: 'error'
    };
    logQueue.scheduleLogSend(entry);
};
const createUnhandledRejectionNonErrorEntry = (reason)=>{
    const entry = {
        kind: 'any-logged-error',
        // we can't access the stack since the event is dispatched async and creating an inline error would be meaningless
        consoleErrorStack: '',
        method: 'error',
        args: [
            {
                kind: 'arg',
                data: `⨯ unhandledRejection:`,
                isRejectionMessage: true
            },
            {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(reason)
            }
        ]
    };
    logQueue.scheduleLogSend(entry);
};
const isHMR = (args)=>{
    const firstArg = args[0];
    if (typeof firstArg !== 'string') {
        return false;
    }
    if (firstArg.startsWith('[Fast Refresh]')) {
        return true;
    }
    if (firstArg.startsWith('[HMR]')) {
        return true;
    }
    return false;
};
/**
 * Matches the format of logs arguments React replayed from the RSC.
 */ const isReactServerReplayedLog = (args)=>{
    if (args.length < 3) {
        return false;
    }
    const [format, styles, label] = args;
    if (typeof format !== 'string' || typeof styles !== 'string' || typeof label !== 'string') {
        return false;
    }
    return format.startsWith('%c%s%c') && styles.includes('background:');
};
function forwardUnhandledError(error) {
    // Always log to client file logger
    clientFileLogger.log('error', [
        `uncaughtError: ${error.name}: ${error.message}`
    ]);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    createUncaughtErrorEntry(error.name, error.message, stackWithOwners(error));
}
const initializeDebugLogForwarding = (router)=>{
    // probably don't need this
    if (isPatched) {
        return;
    }
    // TODO(rob): why does this break rendering on server, important to know incase the same bug appears in browser
    if (typeof window === 'undefined') {
        return;
    }
    // better to be safe than sorry
    try {
        methods.forEach((method)=>(0, _forwardlogsshared.patchConsoleMethod)(method, (_, ...args)=>{
                if (isHMR(args)) {
                    return;
                }
                if (isReactServerReplayedLog(args)) {
                    return;
                }
                createLogEntry(method, args);
            }));
    } catch  {}
    logQueue.router = router;
    isPatched = true;
    // Cleanup on page unload
    window.addEventListener('beforeunload', ()=>{
        cancelLogFlush();
        stopHeartbeat();
        // Send any remaining logs before page unloads
        sendClientFileLogs();
    });
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    handleClientError: null,
    handleConsoleError: null,
    handleGlobalErrors: null,
    useErrorHandler: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    handleClientError: function() {
        return handleClientError;
    },
    handleConsoleError: function() {
        return handleConsoleError;
    },
    handleGlobalErrors: function() {
        return handleGlobalErrors;
    },
    useErrorHandler: function() {
        return useErrorHandler;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _isnextroutererror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _console = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/lib/console.js [app-client] (ecmascript)");
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const _consoleerror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/shared/console-error.js [app-client] (ecmascript)");
const _stitchederror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
const queueMicroTask = globalThis.queueMicrotask || ((cb)=>Promise.resolve().then(cb));
const errorQueue = [];
const errorHandlers = [];
const rejectionQueue = [];
const rejectionHandlers = [];
function handleConsoleError(originError, consoleErrorArgs) {
    let error;
    const { environmentName } = (0, _console.parseConsoleArgs)(consoleErrorArgs);
    if ((0, _iserror.default)(originError)) {
        error = (0, _consoleerror.createConsoleError)(originError, environmentName);
    } else {
        error = (0, _consoleerror.createConsoleError)((0, _console.formatConsoleArgs)(consoleErrorArgs), environmentName);
    }
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    errorQueue.push(error);
    for (const handler of errorHandlers){
        // Delayed the error being passed to React Dev Overlay,
        // avoid the state being synchronously updated in the component.
        queueMicroTask(()=>{
            handler(error);
        });
    }
}
function handleClientError(error) {
    errorQueue.push(error);
    for (const handler of errorHandlers){
        // Delayed the error being passed to React Dev Overlay,
        // avoid the state being synchronously updated in the component.
        queueMicroTask(()=>{
            handler(error);
        });
    }
}
function useErrorHandler(handleOnUnhandledError, handleOnUnhandledRejection) {
    (0, _react.useEffect)(()=>{
        // Handle queued errors.
        errorQueue.forEach(handleOnUnhandledError);
        rejectionQueue.forEach(handleOnUnhandledRejection);
        // Listen to new errors.
        errorHandlers.push(handleOnUnhandledError);
        rejectionHandlers.push(handleOnUnhandledRejection);
        return ()=>{
            // Remove listeners.
            errorHandlers.splice(errorHandlers.indexOf(handleOnUnhandledError), 1);
            rejectionHandlers.splice(rejectionHandlers.indexOf(handleOnUnhandledRejection), 1);
            // Reset error queues.
            errorQueue.splice(0, errorQueue.length);
            rejectionQueue.splice(0, rejectionQueue.length);
        };
    }, [
        handleOnUnhandledError,
        handleOnUnhandledRejection
    ]);
}
function onUnhandledError(event) {
    const thrownValue = event.error;
    if ((0, _isnextroutererror.isNextRouterError)(thrownValue)) {
        event.preventDefault();
        return false;
    }
    // When there's an error property present, we log the error to error overlay.
    // Otherwise we don't do anything as it's not logging in the console either.
    if (thrownValue) {
        const error = (0, _stitchederror.coerceError)(thrownValue);
        (0, _stitchederror.setOwnerStackIfAvailable)(error);
        handleClientError(error);
        (0, _forwardlogs.forwardUnhandledError)(error);
    }
}
function onUnhandledRejection(ev) {
    const reason = ev?.reason;
    if ((0, _isnextroutererror.isNextRouterError)(reason)) {
        ev.preventDefault();
        return;
    }
    const error = (0, _stitchederror.coerceError)(reason);
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    rejectionQueue.push(error);
    for (const handler of rejectionHandlers){
        handler(error);
    }
    (0, _forwardlogs.logUnhandledRejection)(reason);
}
function handleGlobalErrors() {
    if (typeof window !== 'undefined') {
        try {
            // Increase the number of stack frames on the client
            Error.stackTraceLimit = 50;
        } catch  {}
        window.addEventListener('error', onUnhandledError);
        window.addEventListener('unhandledrejection', onUnhandledRejection);
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-error-handler.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    originConsoleError: null,
    patchConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    originConsoleError: function() {
        return originConsoleError;
    },
    patchConsoleError: function() {
        return patchConsoleError;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const _isnextroutererror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _console = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/lib/console.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
const originConsoleError = globalThis.console.error;
function patchConsoleError() {
    // Ensure it's only patched once
    if (typeof window === 'undefined') {
        return;
    }
    window.console.error = function error(...args) {
        let maybeError;
        if ("TURBOPACK compile-time truthy", 1) {
            const { error: replayedError } = (0, _console.parseConsoleArgs)(args);
            if (replayedError) {
                maybeError = replayedError;
            } else if ((0, _iserror.default)(args[0])) {
                maybeError = args[0];
            } else {
                // See https://github.com/facebook/react/blob/d50323eb845c5fde0d720cae888bf35dedd05506/packages/react-reconciler/src/ReactFiberErrorLogger.js#L78
                maybeError = args[1];
            }
        } else //TURBOPACK unreachable
        ;
        if (!(0, _isnextroutererror.isNextRouterError)(maybeError)) {
            if ("TURBOPACK compile-time truthy", 1) {
                (0, _useerrorhandler.handleConsoleError)(// but if we pass the error directly, `handleClientError` will ignore it
                maybeError, args);
            }
            (0, _forwardlogs.forwardErrorLog)(args);
            originConsoleError.apply(window.console, args);
        }
    };
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=intercept-console-error.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-setup.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
const _interceptconsoleerror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
(0, _useerrorhandler.handleGlobalErrors)();
(0, _interceptconsoleerror.patchConsoleError)();
(0, _forwardlogs.initializeDebugLogForwarding)('app');
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dev-overlay-setup.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    decorateDevError: null,
    handleClientError: null,
    originConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    decorateDevError: function() {
        return _stitchederror.decorateDevError;
    },
    handleClientError: function() {
        return _useerrorhandler.handleClientError;
    },
    originConsoleError: function() {
        return _interceptconsoleerror.originConsoleError;
    }
});
const _interceptconsoleerror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _stitchederror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=index.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE: null,
    SegmentBoundaryTriggerNode: null,
    SegmentStateProvider: null,
    SegmentViewNode: null,
    SegmentViewStateNode: null,
    useSegmentState: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE: function() {
        return SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE;
    },
    SegmentBoundaryTriggerNode: function() {
        return SegmentBoundaryTriggerNode;
    },
    SegmentStateProvider: function() {
        return SegmentStateProvider;
    },
    SegmentViewNode: function() {
        return SegmentViewNode;
    },
    SegmentViewStateNode: function() {
        return SegmentViewStateNode;
    },
    useSegmentState: function() {
        return useSegmentState;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const _notfound = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/not-found.js [app-client] (ecmascript)");
const SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE = 'NEXT_DEVTOOLS_SIMULATED_ERROR';
function SegmentTrieNode({ type, pagePath }) {
    const { boundaryType, setBoundaryType } = useSegmentState();
    const nodeState = (0, _react.useMemo)(()=>{
        return {
            type,
            pagePath,
            boundaryType,
            setBoundaryType
        };
    }, [
        type,
        pagePath,
        boundaryType,
        setBoundaryType
    ]);
    // Use `useLayoutEffect` to ensure the state is updated during suspense.
    // `useEffect` won't work as the state is preserved during suspense.
    (0, _react.useLayoutEffect)(()=>{
        _nextdevtools.dispatcher.segmentExplorerNodeAdd(nodeState);
        return ()=>{
            _nextdevtools.dispatcher.segmentExplorerNodeRemove(nodeState);
        };
    }, [
        nodeState
    ]);
    return null;
}
function NotFoundSegmentNode() {
    (0, _notfound.notFound)();
}
function ErrorSegmentNode() {
    throw Object.defineProperty(new Error(SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
}
const forever = new Promise(()=>{});
function LoadingSegmentNode() {
    (0, _react.use)(forever);
    return null;
}
function SegmentViewStateNode({ page }) {
    (0, _react.useLayoutEffect)(()=>{
        _nextdevtools.dispatcher.segmentExplorerUpdateRouteState(page);
        return ()=>{
            _nextdevtools.dispatcher.segmentExplorerUpdateRouteState('');
        };
    }, [
        page
    ]);
    return null;
}
function SegmentBoundaryTriggerNode() {
    const { boundaryType } = useSegmentState();
    let segmentNode = null;
    if (boundaryType === 'loading') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(LoadingSegmentNode, {});
    } else if (boundaryType === 'not-found') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(NotFoundSegmentNode, {});
    } else if (boundaryType === 'error') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(ErrorSegmentNode, {});
    }
    return segmentNode;
}
function SegmentViewNode({ type, pagePath, children }) {
    const segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentTrieNode, {
        type: type,
        pagePath: pagePath
    }, type);
    return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
        children: [
            segmentNode,
            children
        ]
    });
}
const SegmentStateContext = /*#__PURE__*/ (0, _react.createContext)({
    boundaryType: null,
    setBoundaryType: ()=>{}
});
function SegmentStateProvider({ children }) {
    const [boundaryType, setBoundaryType] = (0, _react.useState)(null);
    const [errorBoundaryKey, setErrorBoundaryKey] = (0, _react.useState)(0);
    const reloadBoundary = (0, _react.useCallback)(()=>setErrorBoundaryKey((prev)=>prev + 1), []);
    const setBoundaryTypeAndReload = (0, _react.useCallback)((type)=>{
        if (type === null) {
            reloadBoundary();
        }
        setBoundaryType(type);
    }, [
        reloadBoundary
    ]);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentStateContext.Provider, {
        value: {
            boundaryType,
            setBoundaryType: setBoundaryTypeAndReload
        },
        children: children
    }, errorBoundaryKey);
}
function useSegmentState() {
    return (0, _react.useContext)(SegmentStateContext);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=segment-explorer-node.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-error-boundary.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AppDevOverlayErrorBoundary", {
    enumerable: true,
    get: function() {
        return AppDevOverlayErrorBoundary;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const _runtimeerrorhandler = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/dev/runtime-error-handler.js [app-client] (ecmascript)");
const _errorboundary = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/error-boundary.js [app-client] (ecmascript)");
const _globalerror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/builtin/global-error.js [app-client] (ecmascript)"));
const _segmentexplorernode = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)");
function ErroredHtml({ globalError: [GlobalError, globalErrorStyles], error }) {
    if (!error) {
        return /*#__PURE__*/ (0, _jsxruntime.jsxs)("html", {
            children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)("head", {}),
                /*#__PURE__*/ (0, _jsxruntime.jsx)("body", {})
            ]
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_errorboundary.ErrorBoundary, {
        errorComponent: _globalerror.default,
        children: [
            globalErrorStyles,
            /*#__PURE__*/ (0, _jsxruntime.jsx)(GlobalError, {
                error: error
            })
        ]
    });
}
class AppDevOverlayErrorBoundary extends _react.PureComponent {
    static getDerivedStateFromError(error) {
        _runtimeerrorhandler.RuntimeErrorHandler.hadRuntimeError = true;
        return {
            reactError: error
        };
    }
    componentDidCatch(err) {
        if (("TURBOPACK compile-time value", "development") === 'development' && err.message === _segmentexplorernode.SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE) {
            return;
        }
        _nextdevtools.dispatcher.openErrorOverlay();
    }
    render() {
        const { children, globalError } = this.props;
        const { reactError } = this.state;
        const fallback = /*#__PURE__*/ (0, _jsxruntime.jsx)(ErroredHtml, {
            globalError: globalError,
            error: reactError
        });
        return reactError !== null ? fallback : children;
    }
    constructor(...args){
        super(...args), this.state = {
            reactError: null
        };
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dev-overlay-error-boundary.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/use-app-dev-rendering-indicator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useAppDevRenderingIndicator", {
    enumerable: true,
    get: function() {
        return useAppDevRenderingIndicator;
    }
});
const _react = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const useAppDevRenderingIndicator = ()=>{
    const [isPending, startTransition] = (0, _react.useTransition)();
    (0, _react.useEffect)(()=>{
        if (isPending) {
            _nextdevtools.dispatcher.renderingIndicatorShow();
        } else {
            _nextdevtools.dispatcher.renderingIndicatorHide();
        }
    }, [
        isPending
    ]);
    return startTransition;
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-app-dev-rendering-indicator.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/replay-ssr-only-errors.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ReplaySsrOnlyErrors", {
    enumerable: true,
    get: function() {
        return ReplaySsrOnlyErrors;
    }
});
const _react = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _isnextroutererror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _constants = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/errors/constants.js [app-client] (ecmascript)");
function readSsrError() {
    if (typeof document === 'undefined') {
        return null;
    }
    const ssrErrorTemplateTag = document.querySelector('template[data-next-error-message]');
    if (ssrErrorTemplateTag) {
        const message = ssrErrorTemplateTag.getAttribute('data-next-error-message');
        const stack = ssrErrorTemplateTag.getAttribute('data-next-error-stack');
        const digest = ssrErrorTemplateTag.getAttribute('data-next-error-digest');
        const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
        if (digest) {
            ;
            error.digest = digest;
        }
        // Skip Next.js SSR'd internal errors that which will be handled by the error boundaries.
        if ((0, _isnextroutererror.isNextRouterError)(error)) {
            return null;
        }
        error.stack = stack || '';
        return error;
    }
    return null;
}
function ReplaySsrOnlyErrors({ onBlockingError }) {
    if ("TURBOPACK compile-time truthy", 1) {
        // Need to read during render. The attributes will be gone after commit.
        const ssrError = readSsrError();
        // eslint-disable-next-line react-hooks/rules-of-hooks
        (0, _react.useEffect)(()=>{
            if (ssrError !== null) {
                // TODO(veil): Include original Owner Stack (NDX-905)
                // TODO(veil): Mark as recoverable error
                // TODO(veil): console.error
                (0, _useerrorhandler.handleClientError)(ssrError);
                // If it's missing root tags, we can't recover, make it blocking.
                if (ssrError.digest === _constants.MISSING_ROOT_TAGS_ERROR) {
                    onBlockingError();
                }
            }
        }, [
            ssrError,
            onBlockingError
        ]);
    }
    return null;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=replay-ssr-only-errors.js.map
}),
"[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/client-entry.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "RootLevelDevOverlayElement", {
    enumerable: true,
    get: function() {
        return RootLevelDevOverlayElement;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/packages/web/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _globalerror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/builtin/global-error.js [app-client] (ecmascript)"));
const _appdevoverlayerrorboundary = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-error-boundary.js [app-client] (ecmascript)");
function RootLevelDevOverlayElement({ children }) {
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_appdevoverlayerrorboundary.AppDevOverlayErrorBoundary, {
        globalError: [
            _globalerror.default,
            null
        ],
        children: children
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=client-entry.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    bindSnapshot: null,
    createAsyncLocalStorage: null,
    createSnapshot: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    bindSnapshot: function() {
        return bindSnapshot;
    },
    createAsyncLocalStorage: function() {
        return createAsyncLocalStorage;
    },
    createSnapshot: function() {
        return createSnapshot;
    }
});
const sharedAsyncLocalStorageNotAvailableError = Object.defineProperty(new Error('Invariant: AsyncLocalStorage accessed in runtime where it is not available'), "__NEXT_ERROR_CODE", {
    value: "E504",
    enumerable: false,
    configurable: true
});
class FakeAsyncLocalStorage {
    disable() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    getStore() {
        // This fake implementation of AsyncLocalStorage always returns `undefined`.
        return undefined;
    }
    run() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    exit() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    enterWith() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    static bind(fn) {
        return fn;
    }
}
const maybeGlobalAsyncLocalStorage = typeof globalThis !== 'undefined' && globalThis.AsyncLocalStorage;
function createAsyncLocalStorage() {
    if (maybeGlobalAsyncLocalStorage) {
        return new maybeGlobalAsyncLocalStorage();
    }
    return new FakeAsyncLocalStorage();
}
function bindSnapshot(fn) {
    if (maybeGlobalAsyncLocalStorage) {
        return maybeGlobalAsyncLocalStorage.bind(fn);
    }
    return FakeAsyncLocalStorage.bind(fn);
}
function createSnapshot() {
    if (maybeGlobalAsyncLocalStorage) {
        return maybeGlobalAsyncLocalStorage.snapshot();
    }
    return function(fn, ...args) {
        return fn(...args);
    };
} //# sourceMappingURL=async-local-storage.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/work-unit-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workUnitAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return workUnitAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const workUnitAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=work-unit-async-storage-instance.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/work-unit-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getCacheSignal: null,
    getDraftModeProviderForCacheScope: null,
    getHmrRefreshHash: null,
    getPrerenderResumeDataCache: null,
    getRenderResumeDataCache: null,
    getRuntimeStagePromise: null,
    getServerComponentsHmrCache: null,
    isHmrRefresh: null,
    throwForMissingRequestStore: null,
    throwInvariantForMissingStore: null,
    workUnitAsyncStorage: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getCacheSignal: function() {
        return getCacheSignal;
    },
    getDraftModeProviderForCacheScope: function() {
        return getDraftModeProviderForCacheScope;
    },
    getHmrRefreshHash: function() {
        return getHmrRefreshHash;
    },
    getPrerenderResumeDataCache: function() {
        return getPrerenderResumeDataCache;
    },
    getRenderResumeDataCache: function() {
        return getRenderResumeDataCache;
    },
    getRuntimeStagePromise: function() {
        return getRuntimeStagePromise;
    },
    getServerComponentsHmrCache: function() {
        return getServerComponentsHmrCache;
    },
    isHmrRefresh: function() {
        return isHmrRefresh;
    },
    throwForMissingRequestStore: function() {
        return throwForMissingRequestStore;
    },
    throwInvariantForMissingStore: function() {
        return throwInvariantForMissingStore;
    },
    workUnitAsyncStorage: function() {
        return _workunitasyncstorageinstance.workUnitAsyncStorageInstance;
    }
});
const _workunitasyncstorageinstance = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/work-unit-async-storage-instance.js [app-client] (ecmascript)");
const _approuterheaders = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/app-router-headers.js [app-client] (ecmascript)");
const _invarianterror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
function throwForMissingRequestStore(callingExpression) {
    throw Object.defineProperty(new Error(`\`${callingExpression}\` was called outside a request scope. Read more: https://nextjs.org/docs/messages/next-dynamic-api-wrong-context`), "__NEXT_ERROR_CODE", {
        value: "E251",
        enumerable: false,
        configurable: true
    });
}
function throwInvariantForMissingStore() {
    throw Object.defineProperty(new _invarianterror.InvariantError('Expected workUnitAsyncStorage to have a store.'), "__NEXT_ERROR_CODE", {
        value: "E696",
        enumerable: false,
        configurable: true
    });
}
function getPrerenderResumeDataCache(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-ppr':
            return workUnitStore.prerenderResumeDataCache;
        case 'prerender-client':
            // TODO eliminate fetch caching in client scope and stop exposing this data
            // cache during SSR.
            return workUnitStore.prerenderResumeDataCache;
        case 'request':
            {
                // In dev, we might fill caches even during a dynamic request.
                if (workUnitStore.prerenderResumeDataCache) {
                    return workUnitStore.prerenderResumeDataCache;
                }
            // fallthrough
            }
        case 'prerender-legacy':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
}
function getRenderResumeDataCache(workUnitStore) {
    switch(workUnitStore.type){
        case 'request':
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-client':
            if (workUnitStore.renderResumeDataCache) {
                // If we are in a prerender, we might have a render resume data cache
                // that is used to read from prefilled caches.
                return workUnitStore.renderResumeDataCache;
            }
        // fallthrough
        case 'prerender-ppr':
            // Otherwise we return the mutable resume data cache here as an immutable
            // version of the cache as it can also be used for reading.
            return workUnitStore.prerenderResumeDataCache ?? null;
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
        case 'prerender-legacy':
            return null;
        default:
            return workUnitStore;
    }
}
function getHmrRefreshHash(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'prerender':
            case 'prerender-runtime':
                return workUnitStore.hmrRefreshHash;
            case 'request':
                var _workUnitStore_cookies_get;
                return (_workUnitStore_cookies_get = workUnitStore.cookies.get(_approuterheaders.NEXT_HMR_REFRESH_HASH_COOKIE)) == null ? void 0 : _workUnitStore_cookies_get.value;
            case 'prerender-client':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function isHmrRefresh(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'request':
                return workUnitStore.isHmrRefresh ?? false;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-runtime':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return false;
}
function getServerComponentsHmrCache(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'request':
                return workUnitStore.serverComponentsHmrCache;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-runtime':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function getDraftModeProviderForCacheScope(workStore, workUnitStore) {
    if (workStore.isDraftMode) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'unstable-cache':
            case 'prerender-runtime':
            case 'request':
                return workUnitStore.draftMode;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-ppr':
            case 'prerender-legacy':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function getCacheSignal(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-client':
        case 'prerender-runtime':
            return workUnitStore.cacheSignal;
        case 'request':
            {
                // In dev, we might fill caches even during a dynamic request.
                if (workUnitStore.cacheSignal) {
                    return workUnitStore.cacheSignal;
                }
            // fallthrough
            }
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
}
function getRuntimeStagePromise(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender-runtime':
        case 'private-cache':
            return workUnitStore.runtimeStagePromise;
        case 'prerender':
        case 'prerender-client':
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'request':
        case 'cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
} //# sourceMappingURL=work-unit-async-storage.external.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/work-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return workAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const workAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=work-async-storage-instance.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workAsyncStorage", {
    enumerable: true,
    get: function() {
        return _workasyncstorageinstance.workAsyncStorageInstance;
    }
});
const _workasyncstorageinstance = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/work-async-storage-instance.js [app-client] (ecmascript)"); //# sourceMappingURL=work-async-storage.external.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/action-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "actionAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return actionAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const actionAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=action-async-storage-instance.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/action-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "actionAsyncStorage", {
    enumerable: true,
    get: function() {
        return _actionasyncstorageinstance.actionAsyncStorageInstance;
    }
});
const _actionasyncstorageinstance = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/action-async-storage-instance.js [app-client] (ecmascript)"); //# sourceMappingURL=action-async-storage.external.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/dynamic-rendering-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    isHangingPromiseRejectionError: null,
    makeDevtoolsIOAwarePromise: null,
    makeHangingPromise: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    isHangingPromiseRejectionError: function() {
        return isHangingPromiseRejectionError;
    },
    makeDevtoolsIOAwarePromise: function() {
        return makeDevtoolsIOAwarePromise;
    },
    makeHangingPromise: function() {
        return makeHangingPromise;
    }
});
function isHangingPromiseRejectionError(err) {
    if (typeof err !== 'object' || err === null || !('digest' in err)) {
        return false;
    }
    return err.digest === HANGING_PROMISE_REJECTION;
}
const HANGING_PROMISE_REJECTION = 'HANGING_PROMISE_REJECTION';
class HangingPromiseRejectionError extends Error {
    constructor(route, expression){
        super(`During prerendering, ${expression} rejects when the prerender is complete. Typically these errors are handled by React but if you move ${expression} to a different context by using \`setTimeout\`, \`after\`, or similar functions you may observe this error and you should handle it in that context. This occurred at route "${route}".`), this.route = route, this.expression = expression, this.digest = HANGING_PROMISE_REJECTION;
    }
}
const abortListenersBySignal = new WeakMap();
function makeHangingPromise(signal, route, expression) {
    if (signal.aborted) {
        return Promise.reject(new HangingPromiseRejectionError(route, expression));
    } else {
        const hangingPromise = new Promise((_, reject)=>{
            const boundRejection = reject.bind(null, new HangingPromiseRejectionError(route, expression));
            let currentListeners = abortListenersBySignal.get(signal);
            if (currentListeners) {
                currentListeners.push(boundRejection);
            } else {
                const listeners = [
                    boundRejection
                ];
                abortListenersBySignal.set(signal, listeners);
                signal.addEventListener('abort', ()=>{
                    for(let i = 0; i < listeners.length; i++){
                        listeners[i]();
                    }
                }, {
                    once: true
                });
            }
        });
        // We are fine if no one actually awaits this promise. We shouldn't consider this an unhandled rejection so
        // we attach a noop catch handler here to suppress this warning. If you actually await somewhere or construct
        // your own promise out of it you'll need to ensure you handle the error when it rejects.
        hangingPromise.catch(ignoreReject);
        return hangingPromise;
    }
}
function ignoreReject() {}
function makeDevtoolsIOAwarePromise(underlying, requestStore, stage) {
    if (requestStore.stagedRendering) {
        // We resolve each stage in a timeout, so React DevTools will pick this up as IO.
        return requestStore.stagedRendering.delayUntilStage(stage, undefined, underlying);
    }
    // in React DevTools if we resolve in a setTimeout we will observe
    // the promise resolution as something that can suspend a boundary or root.
    return new Promise((resolve)=>{
        // Must use setTimeout to be considered IO React DevTools. setImmediate will not work.
        setTimeout(()=>{
            resolve(underlying);
        }, 0);
    });
} //# sourceMappingURL=dynamic-rendering-utils.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/lib/router-utils/is-postpone.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isPostpone", {
    enumerable: true,
    get: function() {
        return isPostpone;
    }
});
const REACT_POSTPONE_TYPE = Symbol.for('react.postpone');
function isPostpone(error) {
    return typeof error === 'object' && error !== null && error.$$typeof === REACT_POSTPONE_TYPE;
} //# sourceMappingURL=is-postpone.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/staged-rendering.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    RenderStage: null,
    StagedRenderingController: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    RenderStage: function() {
        return RenderStage;
    },
    StagedRenderingController: function() {
        return StagedRenderingController;
    }
});
const _invarianterror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
const _promisewithresolvers = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/promise-with-resolvers.js [app-client] (ecmascript)");
var RenderStage = /*#__PURE__*/ function(RenderStage) {
    RenderStage[RenderStage["Static"] = 1] = "Static";
    RenderStage[RenderStage["Runtime"] = 2] = "Runtime";
    RenderStage[RenderStage["Dynamic"] = 3] = "Dynamic";
    return RenderStage;
}({});
class StagedRenderingController {
    constructor(abortSignal = null){
        this.abortSignal = abortSignal;
        this.currentStage = 1;
        this.runtimeStagePromise = (0, _promisewithresolvers.createPromiseWithResolvers)();
        this.dynamicStagePromise = (0, _promisewithresolvers.createPromiseWithResolvers)();
        if (abortSignal) {
            abortSignal.addEventListener('abort', ()=>{
                const { reason } = abortSignal;
                if (this.currentStage < 2) {
                    this.runtimeStagePromise.promise.catch(ignoreReject) // avoid unhandled rejections
                    ;
                    this.runtimeStagePromise.reject(reason);
                }
                if (this.currentStage < 3) {
                    this.dynamicStagePromise.promise.catch(ignoreReject) // avoid unhandled rejections
                    ;
                    this.dynamicStagePromise.reject(reason);
                }
            }, {
                once: true
            });
        }
    }
    advanceStage(stage) {
        // If we're already at the target stage or beyond, do nothing.
        // (this can happen e.g. if sync IO advanced us to the dynamic stage)
        if (this.currentStage >= stage) {
            return;
        }
        this.currentStage = stage;
        // Note that we might be going directly from Static to Dynamic,
        // so we need to resolve the runtime stage as well.
        if (stage >= 2) {
            this.runtimeStagePromise.resolve();
        }
        if (stage >= 3) {
            this.dynamicStagePromise.resolve();
        }
    }
    getStagePromise(stage) {
        switch(stage){
            case 2:
                {
                    return this.runtimeStagePromise.promise;
                }
            case 3:
                {
                    return this.dynamicStagePromise.promise;
                }
            default:
                {
                    stage;
                    throw Object.defineProperty(new _invarianterror.InvariantError(`Invalid render stage: ${stage}`), "__NEXT_ERROR_CODE", {
                        value: "E881",
                        enumerable: false,
                        configurable: true
                    });
                }
        }
    }
    waitForStage(stage) {
        return this.getStagePromise(stage);
    }
    delayUntilStage(stage, displayName, resolvedValue) {
        const ioTriggerPromise = this.getStagePromise(stage);
        const promise = makeDevtoolsIOPromiseFromIOTrigger(ioTriggerPromise, displayName, resolvedValue);
        // Analogously to `makeHangingPromise`, we might reject this promise if the signal is invoked.
        // (e.g. in the case where we don't want want the render to proceed to the dynamic stage and abort it).
        // We shouldn't consider this an unhandled rejection, so we attach a noop catch handler here to suppress this warning.
        if (this.abortSignal) {
            promise.catch(ignoreReject);
        }
        return promise;
    }
}
function ignoreReject() {}
// TODO(restart-on-cache-miss): the layering of `delayUntilStage`,
// `makeDevtoolsIOPromiseFromIOTrigger` and and `makeDevtoolsIOAwarePromise`
// is confusing, we should clean it up.
function makeDevtoolsIOPromiseFromIOTrigger(ioTrigger, displayName, resolvedValue) {
    // If we create a `new Promise` and give it a displayName
    // (with no userspace code above us in the stack)
    // React Devtools will use it as the IO cause when determining "suspended by".
    // In particular, it should shadow any inner IO that resolved/rejected the promise
    // (in case of staged rendering, this will be the `setTimeout` that triggers the relevant stage)
    const promise = new Promise((resolve, reject)=>{
        ioTrigger.then(resolve.bind(null, resolvedValue), reject);
    });
    if (displayName !== undefined) {
        // @ts-expect-error
        promise.displayName = displayName;
    }
    return promise;
} //# sourceMappingURL=staged-rendering.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/app-render/dynamic-rendering.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * The functions provided by this module are used to communicate certain properties
 * about the currently running code so that Next.js can make decisions on how to handle
 * the current execution in different rendering modes such as pre-rendering, resuming, and SSR.
 *
 * Today Next.js treats all code as potentially static. Certain APIs may only make sense when dynamically rendering.
 * Traditionally this meant deopting the entire render to dynamic however with PPR we can now deopt parts
 * of a React tree as dynamic while still keeping other parts static. There are really two different kinds of
 * Dynamic indications.
 *
 * The first is simply an intention to be dynamic. unstable_noStore is an example of this where
 * the currently executing code simply declares that the current scope is dynamic but if you use it
 * inside unstable_cache it can still be cached. This type of indication can be removed if we ever
 * make the default dynamic to begin with because the only way you would ever be static is inside
 * a cache scope which this indication does not affect.
 *
 * The second is an indication that a dynamic data source was read. This is a stronger form of dynamic
 * because it means that it is inappropriate to cache this at all. using a dynamic data source inside
 * unstable_cache should error. If you want to use some dynamic data inside unstable_cache you should
 * read that data outside the cache and pass it in as an argument to the cached function.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    Postpone: null,
    PreludeState: null,
    abortAndThrowOnSynchronousRequestDataAccess: null,
    abortOnSynchronousPlatformIOAccess: null,
    accessedDynamicData: null,
    annotateDynamicAccess: null,
    consumeDynamicAccess: null,
    createDynamicTrackingState: null,
    createDynamicValidationState: null,
    createHangingInputAbortSignal: null,
    createRenderInBrowserAbortSignal: null,
    delayUntilRuntimeStage: null,
    formatDynamicAPIAccesses: null,
    getFirstDynamicReason: null,
    isDynamicPostpone: null,
    isPrerenderInterruptedError: null,
    logDisallowedDynamicError: null,
    markCurrentScopeAsDynamic: null,
    postponeWithTracking: null,
    throwIfDisallowedDynamic: null,
    throwToInterruptStaticGeneration: null,
    trackAllowedDynamicAccess: null,
    trackDynamicDataInDynamicRender: null,
    trackSynchronousPlatformIOAccessInDev: null,
    useDynamicRouteParams: null,
    useDynamicSearchParams: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    Postpone: function() {
        return Postpone;
    },
    PreludeState: function() {
        return PreludeState;
    },
    abortAndThrowOnSynchronousRequestDataAccess: function() {
        return abortAndThrowOnSynchronousRequestDataAccess;
    },
    abortOnSynchronousPlatformIOAccess: function() {
        return abortOnSynchronousPlatformIOAccess;
    },
    accessedDynamicData: function() {
        return accessedDynamicData;
    },
    annotateDynamicAccess: function() {
        return annotateDynamicAccess;
    },
    consumeDynamicAccess: function() {
        return consumeDynamicAccess;
    },
    createDynamicTrackingState: function() {
        return createDynamicTrackingState;
    },
    createDynamicValidationState: function() {
        return createDynamicValidationState;
    },
    createHangingInputAbortSignal: function() {
        return createHangingInputAbortSignal;
    },
    createRenderInBrowserAbortSignal: function() {
        return createRenderInBrowserAbortSignal;
    },
    delayUntilRuntimeStage: function() {
        return delayUntilRuntimeStage;
    },
    formatDynamicAPIAccesses: function() {
        return formatDynamicAPIAccesses;
    },
    getFirstDynamicReason: function() {
        return getFirstDynamicReason;
    },
    isDynamicPostpone: function() {
        return isDynamicPostpone;
    },
    isPrerenderInterruptedError: function() {
        return isPrerenderInterruptedError;
    },
    logDisallowedDynamicError: function() {
        return logDisallowedDynamicError;
    },
    markCurrentScopeAsDynamic: function() {
        return markCurrentScopeAsDynamic;
    },
    postponeWithTracking: function() {
        return postponeWithTracking;
    },
    throwIfDisallowedDynamic: function() {
        return throwIfDisallowedDynamic;
    },
    throwToInterruptStaticGeneration: function() {
        return throwToInterruptStaticGeneration;
    },
    trackAllowedDynamicAccess: function() {
        return trackAllowedDynamicAccess;
    },
    trackDynamicDataInDynamicRender: function() {
        return trackDynamicDataInDynamicRender;
    },
    trackSynchronousPlatformIOAccessInDev: function() {
        return trackSynchronousPlatformIOAccessInDev;
    },
    useDynamicRouteParams: function() {
        return useDynamicRouteParams;
    },
    useDynamicSearchParams: function() {
        return useDynamicSearchParams;
    }
});
const _react = /*#__PURE__*/ _interop_require_default(__turbopack_context__.r("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _hooksservercontext = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/hooks-server-context.js [app-client] (ecmascript)");
const _staticgenerationbailout = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/client/components/static-generation-bailout.js [app-client] (ecmascript)");
const _workunitasyncstorageexternal = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/work-unit-async-storage.external.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _dynamicrenderingutils = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/dynamic-rendering-utils.js [app-client] (ecmascript)");
const _boundaryconstants = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)");
const _scheduler = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/lib/scheduler.js [app-client] (ecmascript)");
const _bailouttocsr = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
const _invarianterror = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
const _stagedrendering = __turbopack_context__.r("[project]/packages/web/node_modules/next/dist/server/app-render/staged-rendering.js [app-client] (ecmascript)");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const hasPostpone = typeof _react.default.unstable_postpone === 'function';
function createDynamicTrackingState(isDebugDynamicAccesses) {
    return {
        isDebugDynamicAccesses,
        dynamicAccesses: [],
        syncDynamicErrorWithStack: null
    };
}
function createDynamicValidationState() {
    return {
        hasSuspenseAboveBody: false,
        hasDynamicMetadata: false,
        hasDynamicViewport: false,
        hasAllowedDynamic: false,
        dynamicErrors: []
    };
}
function getFirstDynamicReason(trackingState) {
    var _trackingState_dynamicAccesses_;
    return (_trackingState_dynamicAccesses_ = trackingState.dynamicAccesses[0]) == null ? void 0 : _trackingState_dynamicAccesses_.expression;
}
function markCurrentScopeAsDynamic(store, workUnitStore, expression) {
    if (workUnitStore) {
        switch(workUnitStore.type){
            case 'cache':
            case 'unstable-cache':
                // Inside cache scopes, marking a scope as dynamic has no effect,
                // because the outer cache scope creates a cache boundary. This is
                // subtly different from reading a dynamic data source, which is
                // forbidden inside a cache scope.
                return;
            case 'private-cache':
                // A private cache scope is already dynamic by definition.
                return;
            case 'prerender-legacy':
            case 'prerender-ppr':
            case 'request':
                break;
            default:
                workUnitStore;
        }
    }
    // If we're forcing dynamic rendering or we're forcing static rendering, we
    // don't need to do anything here because the entire page is already dynamic
    // or it's static and it should not throw or postpone here.
    if (store.forceDynamic || store.forceStatic) return;
    if (store.dynamicShouldError) {
        throw Object.defineProperty(new _staticgenerationbailout.StaticGenBailoutError(`Route ${store.route} with \`dynamic = "error"\` couldn't be rendered statically because it used \`${expression}\`. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
            value: "E553",
            enumerable: false,
            configurable: true
        });
    }
    if (workUnitStore) {
        switch(workUnitStore.type){
            case 'prerender-ppr':
                return postponeWithTracking(store.route, expression, workUnitStore.dynamicTracking);
            case 'prerender-legacy':
                workUnitStore.revalidate = 0;
                // We aren't prerendering, but we are generating a static page. We need
                // to bail out of static generation.
                const err = Object.defineProperty(new _hooksservercontext.DynamicServerError(`Route ${store.route} couldn't be rendered statically because it used ${expression}. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
                    value: "E550",
                    enumerable: false,
                    configurable: true
                });
                store.dynamicUsageDescription = expression;
                store.dynamicUsageStack = err.stack;
                throw err;
            case 'request':
                if ("TURBOPACK compile-time truthy", 1) {
                    workUnitStore.usedDynamic = true;
                }
                break;
            default:
                workUnitStore;
        }
    }
}
function throwToInterruptStaticGeneration(expression, store, prerenderStore) {
    // We aren't prerendering but we are generating a static page. We need to bail out of static generation
    const err = Object.defineProperty(new _hooksservercontext.DynamicServerError(`Route ${store.route} couldn't be rendered statically because it used \`${expression}\`. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
        value: "E558",
        enumerable: false,
        configurable: true
    });
    prerenderStore.revalidate = 0;
    store.dynamicUsageDescription = expression;
    store.dynamicUsageStack = err.stack;
    throw err;
}
function trackDynamicDataInDynamicRender(workUnitStore) {
    switch(workUnitStore.type){
        case 'cache':
        case 'unstable-cache':
            // Inside cache scopes, marking a scope as dynamic has no effect,
            // because the outer cache scope creates a cache boundary. This is
            // subtly different from reading a dynamic data source, which is
            // forbidden inside a cache scope.
            return;
        case 'private-cache':
            // A private cache scope is already dynamic by definition.
            return;
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-legacy':
        case 'prerender-ppr':
        case 'prerender-client':
            break;
        case 'request':
            if ("TURBOPACK compile-time truthy", 1) {
                workUnitStore.usedDynamic = true;
            }
            break;
        default:
            workUnitStore;
    }
}
function abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore) {
    const reason = `Route ${route} needs to bail out of prerendering at this point because it used ${expression}.`;
    const error = createPrerenderInterruptedError(reason);
    prerenderStore.controller.abort(error);
    const dynamicTracking = prerenderStore.dynamicTracking;
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            // When we aren't debugging, we don't need to create another error for the
            // stack trace.
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
}
function abortOnSynchronousPlatformIOAccess(route, expression, errorWithStack, prerenderStore) {
    const dynamicTracking = prerenderStore.dynamicTracking;
    abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore);
    // It is important that we set this tracking value after aborting. Aborts are executed
    // synchronously except for the case where you abort during render itself. By setting this
    // value late we can use it to determine if any of the aborted tasks are the task that
    // called the sync IO expression in the first place.
    if (dynamicTracking) {
        if (dynamicTracking.syncDynamicErrorWithStack === null) {
            dynamicTracking.syncDynamicErrorWithStack = errorWithStack;
        }
    }
}
function trackSynchronousPlatformIOAccessInDev(requestStore) {
    // We don't actually have a controller to abort but we do the semantic equivalent by
    // advancing the request store out of the prerender stage
    if (requestStore.stagedRendering) {
        // TODO: error for sync IO in the runtime stage
        // (which is not currently covered by the validation render in `spawnDynamicValidationInDev`)
        requestStore.stagedRendering.advanceStage(_stagedrendering.RenderStage.Dynamic);
    }
}
function abortAndThrowOnSynchronousRequestDataAccess(route, expression, errorWithStack, prerenderStore) {
    const prerenderSignal = prerenderStore.controller.signal;
    if (prerenderSignal.aborted === false) {
        // TODO it would be better to move this aborted check into the callsite so we can avoid making
        // the error object when it isn't relevant to the aborting of the prerender however
        // since we need the throw semantics regardless of whether we abort it is easier to land
        // this way. See how this was handled with `abortOnSynchronousPlatformIOAccess` for a closer
        // to ideal implementation
        abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore);
        // It is important that we set this tracking value after aborting. Aborts are executed
        // synchronously except for the case where you abort during render itself. By setting this
        // value late we can use it to determine if any of the aborted tasks are the task that
        // called the sync IO expression in the first place.
        const dynamicTracking = prerenderStore.dynamicTracking;
        if (dynamicTracking) {
            if (dynamicTracking.syncDynamicErrorWithStack === null) {
                dynamicTracking.syncDynamicErrorWithStack = errorWithStack;
            }
        }
    }
    throw createPrerenderInterruptedError(`Route ${route} needs to bail out of prerendering at this point because it used ${expression}.`);
}
function Postpone({ reason, route }) {
    const prerenderStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    const dynamicTracking = prerenderStore && prerenderStore.type === 'prerender-ppr' ? prerenderStore.dynamicTracking : null;
    postponeWithTracking(route, reason, dynamicTracking);
}
function postponeWithTracking(route, expression, dynamicTracking) {
    assertPostpone();
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            // When we aren't debugging, we don't need to create another error for the
            // stack trace.
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
    _react.default.unstable_postpone(createPostponeReason(route, expression));
}
function createPostponeReason(route, expression) {
    return `Route ${route} needs to bail out of prerendering at this point because it used ${expression}. ` + `React throws this special object to indicate where. It should not be caught by ` + `your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error`;
}
function isDynamicPostpone(err) {
    if (typeof err === 'object' && err !== null && typeof err.message === 'string') {
        return isDynamicPostponeReason(err.message);
    }
    return false;
}
function isDynamicPostponeReason(reason) {
    return reason.includes('needs to bail out of prerendering at this point because it used') && reason.includes('Learn more: https://nextjs.org/docs/messages/ppr-caught-error');
}
if (isDynamicPostponeReason(createPostponeReason('%%%', '^^^')) === false) {
    throw Object.defineProperty(new Error('Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js'), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: false,
        configurable: true
    });
}
const NEXT_PRERENDER_INTERRUPTED = 'NEXT_PRERENDER_INTERRUPTED';
function createPrerenderInterruptedError(message) {
    const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
    error.digest = NEXT_PRERENDER_INTERRUPTED;
    return error;
}
function isPrerenderInterruptedError(error) {
    return typeof error === 'object' && error !== null && error.digest === NEXT_PRERENDER_INTERRUPTED && 'name' in error && 'message' in error && error instanceof Error;
}
function accessedDynamicData(dynamicAccesses) {
    return dynamicAccesses.length > 0;
}
function consumeDynamicAccess(serverDynamic, clientDynamic) {
    // We mutate because we only call this once we are no longer writing
    // to the dynamicTrackingState and it's more efficient than creating a new
    // array.
    serverDynamic.dynamicAccesses.push(...clientDynamic.dynamicAccesses);
    return serverDynamic.dynamicAccesses;
}
function formatDynamicAPIAccesses(dynamicAccesses) {
    return dynamicAccesses.filter((access)=>typeof access.stack === 'string' && access.stack.length > 0).map(({ expression, stack })=>{
        stack = stack.split('\n') // Remove the "Error: " prefix from the first line of the stack trace as
        // well as the first 4 lines of the stack trace which is the distance
        // from the user code and the `new Error().stack` call.
        .slice(4).filter((line)=>{
            // Exclude Next.js internals from the stack trace.
            if (line.includes('node_modules/next/')) {
                return false;
            }
            // Exclude anonymous functions from the stack trace.
            if (line.includes(' (<anonymous>)')) {
                return false;
            }
            // Exclude Node.js internals from the stack trace.
            if (line.includes(' (node:')) {
                return false;
            }
            return true;
        }).join('\n');
        return `Dynamic API Usage Debug - ${expression}:\n${stack}`;
    });
}
function assertPostpone() {
    if (!hasPostpone) {
        throw Object.defineProperty(new Error(`Invariant: React.unstable_postpone is not defined. This suggests the wrong version of React was loaded. This is a bug in Next.js`), "__NEXT_ERROR_CODE", {
            value: "E224",
            enumerable: false,
            configurable: true
        });
    }
}
function createRenderInBrowserAbortSignal() {
    const controller = new AbortController();
    controller.abort(Object.defineProperty(new _bailouttocsr.BailoutToCSRError('Render in Browser'), "__NEXT_ERROR_CODE", {
        value: "E721",
        enumerable: false,
        configurable: true
    }));
    return controller.signal;
}
function createHangingInputAbortSignal(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-runtime':
            const controller = new AbortController();
            if (workUnitStore.cacheSignal) {
                // If we have a cacheSignal it means we're in a prospective render. If
                // the input we're waiting on is coming from another cache, we do want
                // to wait for it so that we can resolve this cache entry too.
                workUnitStore.cacheSignal.inputReady().then(()=>{
                    controller.abort();
                });
            } else {
                // Otherwise we're in the final render and we should already have all
                // our caches filled.
                // If the prerender uses stages, we have wait until the runtime stage,
                // at which point all runtime inputs will be resolved.
                // (otherwise, a runtime prerender might consider `cookies()` hanging
                //  even though they'd resolve in the next task.)
                //
                // We might still be waiting on some microtasks so we
                // wait one tick before giving up. When we give up, we still want to
                // render the content of this cache as deeply as we can so that we can
                // suspend as deeply as possible in the tree or not at all if we don't
                // end up waiting for the input.
                const runtimeStagePromise = (0, _workunitasyncstorageexternal.getRuntimeStagePromise)(workUnitStore);
                if (runtimeStagePromise) {
                    runtimeStagePromise.then(()=>(0, _scheduler.scheduleOnNextTick)(()=>controller.abort()));
                } else {
                    (0, _scheduler.scheduleOnNextTick)(()=>controller.abort());
                }
            }
            return controller.signal;
        case 'prerender-client':
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'request':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return undefined;
        default:
            workUnitStore;
    }
}
function annotateDynamicAccess(expression, prerenderStore) {
    const dynamicTracking = prerenderStore.dynamicTracking;
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
}
function useDynamicRouteParams(expression) {
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    const workUnitStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    if (workStore && workUnitStore) {
        switch(workUnitStore.type){
            case 'prerender-client':
            case 'prerender':
                {
                    const fallbackParams = workUnitStore.fallbackRouteParams;
                    if (fallbackParams && fallbackParams.size > 0) {
                        // We are in a prerender with cacheComponents semantics. We are going to
                        // hang here and never resolve. This will cause the currently
                        // rendering component to effectively be a dynamic hole.
                        _react.default.use((0, _dynamicrenderingutils.makeHangingPromise)(workUnitStore.renderSignal, workStore.route, expression));
                    }
                    break;
                }
            case 'prerender-ppr':
                {
                    const fallbackParams = workUnitStore.fallbackRouteParams;
                    if (fallbackParams && fallbackParams.size > 0) {
                        return postponeWithTracking(workStore.route, expression, workUnitStore.dynamicTracking);
                    }
                    break;
                }
            case 'prerender-runtime':
                throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called during a runtime prerender. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E771",
                    enumerable: false,
                    configurable: true
                });
            case 'cache':
            case 'private-cache':
                throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called inside a cache scope. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: false,
                    configurable: true
                });
            case 'prerender-legacy':
            case 'request':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
}
function useDynamicSearchParams(expression) {
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    const workUnitStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    if (!workStore) {
        // We assume pages router context and just return
        return;
    }
    if (!workUnitStore) {
        (0, _workunitasyncstorageexternal.throwForMissingRequestStore)(expression);
    }
    switch(workUnitStore.type){
        case 'prerender-client':
            {
                _react.default.use((0, _dynamicrenderingutils.makeHangingPromise)(workUnitStore.renderSignal, workStore.route, expression));
                break;
            }
        case 'prerender-legacy':
        case 'prerender-ppr':
            {
                if (workStore.forceStatic) {
                    return;
                }
                throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(expression), "__NEXT_ERROR_CODE", {
                    value: "E394",
                    enumerable: false,
                    configurable: true
                });
            }
        case 'prerender':
        case 'prerender-runtime':
            throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called from a Server Component. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                value: "E795",
                enumerable: false,
                configurable: true
            });
        case 'cache':
        case 'unstable-cache':
        case 'private-cache':
            throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called inside a cache scope. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                value: "E745",
                enumerable: false,
                configurable: true
            });
        case 'request':
            return;
        default:
            workUnitStore;
    }
}
const hasSuspenseRegex = /\n\s+at Suspense \(<anonymous>\)/;
// Common implicit body tags that React will treat as body when placed directly in html
const bodyAndImplicitTags = 'body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6';
// Detects when RootLayoutBoundary (our framework marker component) appears
// after Suspense in the component stack, indicating the root layout is wrapped
// within a Suspense boundary. Ensures no body/html/implicit-body components are in between.
//
// Example matches:
//   at Suspense (<anonymous>)
//   at __next_root_layout_boundary__ (<anonymous>)
//
// Or with other components in between (but not body/html/implicit-body):
//   at Suspense (<anonymous>)
//   at SomeComponent (<anonymous>)
//   at __next_root_layout_boundary__ (<anonymous>)
const hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex = new RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:${bodyAndImplicitTags}) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at ${_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME} \\([^\\n]*\\)`);
const hasMetadataRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.METADATA_BOUNDARY_NAME}[\\n\\s]`);
const hasViewportRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.VIEWPORT_BOUNDARY_NAME}[\\n\\s]`);
const hasOutletRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.OUTLET_BOUNDARY_NAME}[\\n\\s]`);
function trackAllowedDynamicAccess(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        dynamicValidation.hasDynamicMetadata = true;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        dynamicValidation.hasDynamicViewport = true;
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Uncached data was accessed outside of ` + '<Suspense>. This delays the entire page from rendering, resulting in a ' + 'slow user experience. Learn more: ' + 'https://nextjs.org/docs/messages/blocking-route';
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
/**
 * In dev mode, we prefer using the owner stack, otherwise the provided
 * component stack is used.
 */ function createErrorWithComponentOrOwnerStack(message, componentStack) {
    const ownerStack = ("TURBOPACK compile-time value", "development") !== 'production' && _react.default.captureOwnerStack ? _react.default.captureOwnerStack() : null;
    const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
    error.stack = error.name + ': ' + message + (ownerStack ?? componentStack);
    return error;
}
var PreludeState = /*#__PURE__*/ function(PreludeState) {
    PreludeState[PreludeState["Full"] = 0] = "Full";
    PreludeState[PreludeState["Empty"] = 1] = "Empty";
    PreludeState[PreludeState["Errored"] = 2] = "Errored";
    return PreludeState;
}({});
function logDisallowedDynamicError(workStore, error) {
    console.error(error);
    if (!workStore.dev) {
        if (workStore.hasReadableErrorStacks) {
            console.error(`To get a more detailed stack trace and pinpoint the issue, start the app in development mode by running \`next dev\`, then open "${workStore.route}" in your browser to investigate the error.`);
        } else {
            console.error(`To get a more detailed stack trace and pinpoint the issue, try one of the following:
  - Start the app in development mode by running \`next dev\`, then open "${workStore.route}" in your browser to investigate the error.
  - Rerun the production build with \`next build --debug-prerender\` to generate better stack traces.`);
        }
    }
}
function throwIfDisallowedDynamic(workStore, prelude, dynamicValidation, serverDynamic) {
    if (serverDynamic.syncDynamicErrorWithStack) {
        logDisallowedDynamicError(workStore, serverDynamic.syncDynamicErrorWithStack);
        throw new _staticgenerationbailout.StaticGenBailoutError();
    }
    if (prelude !== 0) {
        if (dynamicValidation.hasSuspenseAboveBody) {
            // This route has opted into allowing fully dynamic rendering
            // by including a Suspense boundary above the body. In this case
            // a lack of a shell is not considered disallowed so we simply return
            return;
        }
        // We didn't have any sync bailouts but there may be user code which
        // blocked the root. We would have captured these during the prerender
        // and can log them here and then terminate the build/validating render
        const dynamicErrors = dynamicValidation.dynamicErrors;
        if (dynamicErrors.length > 0) {
            for(let i = 0; i < dynamicErrors.length; i++){
                logDisallowedDynamicError(workStore, dynamicErrors[i]);
            }
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
        // If we got this far then the only other thing that could be blocking
        // the root is dynamic Viewport. If this is dynamic then
        // you need to opt into that by adding a Suspense boundary above the body
        // to indicate your are ok with fully dynamic rendering.
        if (dynamicValidation.hasDynamicViewport) {
            console.error(`Route "${workStore.route}" has a \`generateViewport\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) without explicitly allowing fully dynamic rendering. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
        if (prelude === 1) {
            // If we ever get this far then we messed up the tracking of invalid dynamic.
            // We still adhere to the constraint that you must produce a shell but invite the
            // user to report this as a bug in Next.js.
            console.error(`Route "${workStore.route}" did not produce a static shell and Next.js was unable to determine a reason. This is a bug in Next.js.`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
    } else {
        if (dynamicValidation.hasAllowedDynamic === false && dynamicValidation.hasDynamicMetadata) {
            console.error(`Route "${workStore.route}" has a \`generateMetadata\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) when the rest of the route does not. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
    }
}
function delayUntilRuntimeStage(prerenderStore, result) {
    if (prerenderStore.runtimeStagePromise) {
        return prerenderStore.runtimeStagePromise.then(()=>result);
    }
    return result;
} //# sourceMappingURL=dynamic-rendering.js.map
}),
"[project]/packages/web/node_modules/next/dist/server/dev/hot-reloader-types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HMR_MESSAGE_SENT_TO_BROWSER: null,
    HMR_MESSAGE_SENT_TO_SERVER: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HMR_MESSAGE_SENT_TO_BROWSER: function() {
        return HMR_MESSAGE_SENT_TO_BROWSER;
    },
    HMR_MESSAGE_SENT_TO_SERVER: function() {
        return HMR_MESSAGE_SENT_TO_SERVER;
    }
});
var HMR_MESSAGE_SENT_TO_BROWSER = /*#__PURE__*/ function(HMR_MESSAGE_SENT_TO_BROWSER) {
    // JSON messages:
    HMR_MESSAGE_SENT_TO_BROWSER["ADDED_PAGE"] = "addedPage";
    HMR_MESSAGE_SENT_TO_BROWSER["REMOVED_PAGE"] = "removedPage";
    HMR_MESSAGE_SENT_TO_BROWSER["RELOAD_PAGE"] = "reloadPage";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_COMPONENT_CHANGES"] = "serverComponentChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["MIDDLEWARE_CHANGES"] = "middlewareChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["CLIENT_CHANGES"] = "clientChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_ONLY_CHANGES"] = "serverOnlyChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["SYNC"] = "sync";
    HMR_MESSAGE_SENT_TO_BROWSER["BUILT"] = "built";
    HMR_MESSAGE_SENT_TO_BROWSER["BUILDING"] = "building";
    HMR_MESSAGE_SENT_TO_BROWSER["DEV_PAGES_MANIFEST_UPDATE"] = "devPagesManifestUpdate";
    HMR_MESSAGE_SENT_TO_BROWSER["TURBOPACK_MESSAGE"] = "turbopack-message";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_ERROR"] = "serverError";
    HMR_MESSAGE_SENT_TO_BROWSER["TURBOPACK_CONNECTED"] = "turbopack-connected";
    HMR_MESSAGE_SENT_TO_BROWSER["ISR_MANIFEST"] = "isrManifest";
    HMR_MESSAGE_SENT_TO_BROWSER["CACHE_INDICATOR"] = "cacheIndicator";
    HMR_MESSAGE_SENT_TO_BROWSER["DEV_INDICATOR"] = "devIndicator";
    HMR_MESSAGE_SENT_TO_BROWSER["DEVTOOLS_CONFIG"] = "devtoolsConfig";
    HMR_MESSAGE_SENT_TO_BROWSER["REQUEST_CURRENT_ERROR_STATE"] = "requestCurrentErrorState";
    HMR_MESSAGE_SENT_TO_BROWSER["REQUEST_PAGE_METADATA"] = "requestPageMetadata";
    // Binary messages:
    HMR_MESSAGE_SENT_TO_BROWSER[HMR_MESSAGE_SENT_TO_BROWSER["REACT_DEBUG_CHUNK"] = 0] = "REACT_DEBUG_CHUNK";
    return HMR_MESSAGE_SENT_TO_BROWSER;
}({});
var HMR_MESSAGE_SENT_TO_SERVER = /*#__PURE__*/ function(HMR_MESSAGE_SENT_TO_SERVER) {
    // JSON messages:
    HMR_MESSAGE_SENT_TO_SERVER["MCP_ERROR_STATE_RESPONSE"] = "mcp-error-state-response";
    HMR_MESSAGE_SENT_TO_SERVER["MCP_PAGE_METADATA_RESPONSE"] = "mcp-page-metadata-response";
    HMR_MESSAGE_SENT_TO_SERVER["PING"] = "ping";
    return HMR_MESSAGE_SENT_TO_SERVER;
}({}); //# sourceMappingURL=hot-reloader-types.js.map
}),
]);

//# sourceMappingURL=b182f_next_dist_37e18b58._.js.map