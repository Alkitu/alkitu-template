(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/packages_web_src_app_[lang]_globals_76abd72e.css",
  "static/chunks/packages_web_src_b558976a._.js",
  "static/chunks/node_modules_@tanstack_query-core_build_modern_666ad07a._.js",
  "static/chunks/node_modules_@trpc_client_dist_cf74d837._.js",
  "static/chunks/node_modules_@trpc_server_dist_1f29c184._.js",
  "static/chunks/node_modules_culori_src_f5724671._.js",
  "static/chunks/_1ffbabfa._.js"
],
    source: "dynamic"
});
