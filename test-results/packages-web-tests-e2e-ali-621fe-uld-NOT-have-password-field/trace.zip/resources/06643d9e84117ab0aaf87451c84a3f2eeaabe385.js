(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PreviewImageMolecule",
    ()=>PreviewImageMolecule,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/image.js [app-client] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ImageOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/image-off.js [app-client] (ecmascript) <export default as ImageOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/loader-circle.js [app-client] (ecmascript) <export default as Loader2>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function PreviewImageMolecule({ src, alt = '', aspectRatio = 'auto', customRatio, size = 'md', radius = 'md', loading = false, placeholder, objectFit = 'cover', className = '', style = {}, onClick, onError, onLoad, showOverlay = false, overlayContent, interactive = false, ...props }) {
    _s();
    const [imageLoading, setImageLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [imageError, setImageError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [imageLoaded, setImageLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isHovered, setIsHovered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Get aspect ratio value
    const getAspectRatio = ()=>{
        if (customRatio) return customRatio;
        const ratioMap = {
            'square': '1',
            '1:1': '1',
            '4:3': '4/3',
            '16:9': '16/9',
            '3:2': '3/2',
            '2:1': '2/1',
            'auto': 'auto'
        };
        return ratioMap[aspectRatio];
    };
    // Get size dimensions
    const getSizeDimensions = ()=>{
        const sizeMap = {
            'xs': {
                width: '64px',
                height: '64px'
            },
            'sm': {
                width: '96px',
                height: '96px'
            },
            'md': {
                width: '128px',
                height: '128px'
            },
            'lg': {
                width: '192px',
                height: '192px'
            },
            'xl': {
                width: '256px',
                height: '256px'
            },
            '2xl': {
                width: '384px',
                height: '384px'
            }
        };
        return sizeMap[size];
    };
    // Get border radius using CSS variables
    const getBorderRadius = ()=>{
        if (radius === 'none') return '0';
        if (radius === 'full') return '50%';
        const radiusMap = {
            'sm': 'var(--radius-sm, 4px)',
            'md': 'var(--radius, 8px)',
            'lg': 'var(--radius-lg, 12px)'
        };
        return radiusMap[radius] || 'var(--radius, 8px)';
    };
    // Handle image load start
    const handleLoadStart = ()=>{
        setImageLoading(true);
        setImageError(false);
        setImageLoaded(false);
    };
    // Handle image load success
    const handleLoad = ()=>{
        setImageLoading(false);
        setImageLoaded(true);
        setImageError(false);
        onLoad?.();
    };
    // Handle image load error
    const handleError = ()=>{
        setImageLoading(false);
        setImageError(true);
        setImageLoaded(false);
        onError?.();
    };
    // Handle mouse enter (molecule-specific)
    const handleMouseEnter = ()=>{
        if (interactive) {
            setIsHovered(true);
        }
    };
    // Handle mouse leave (molecule-specific)
    const handleMouseLeave = ()=>{
        if (interactive) {
            setIsHovered(false);
        }
    };
    const dimensions = getSizeDimensions();
    const ratio = getAspectRatio();
    const borderRadius = getBorderRadius();
    // Container styles with CSS variables
    const containerStyle = {
        position: 'relative',
        width: aspectRatio === 'auto' ? dimensions.width : '100%',
        height: aspectRatio === 'auto' ? dimensions.height : 'auto',
        aspectRatio: aspectRatio !== 'auto' ? ratio : undefined,
        borderRadius,
        overflow: 'hidden',
        backgroundColor: 'var(--color-muted)',
        border: '1px solid var(--color-border)',
        cursor: onClick ? 'pointer' : 'default',
        transition: interactive ? 'transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out' : 'none',
        transform: interactive && isHovered ? 'scale(1.02)' : 'scale(1)',
        boxShadow: interactive && isHovered ? 'var(--shadow-lg, 0 10px 15px -3px rgba(0, 0, 0, 0.1))' : 'none',
        ...style
    };
    // Image styles
    const imageStyle = {
        width: '100%',
        height: '100%',
        objectFit,
        transition: 'opacity 0.2s ease-in-out'
    };
    // Overlay styles (molecule-specific)
    const overlayStyle = {
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(to bottom, transparent 0%, rgba(0, 0, 0, 0.6) 100%)',
        opacity: showOverlay && isHovered || loading || imageLoading ? 1 : 0,
        transition: 'opacity 0.3s ease-in-out',
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
        padding: 'var(--spacing-4, 1rem)',
        borderRadius
    };
    // Show loading or error state
    const showPlaceholder = loading || imageLoading || imageError || !src;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `preview-image-molecule ${interactive ? 'interactive' : ''} ${className}`,
        style: containerStyle,
        onClick: onClick,
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        ...props,
        children: [
            src && !imageError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                src: src,
                alt: alt,
                style: {
                    ...imageStyle,
                    opacity: imageLoaded ? 1 : 0
                },
                onLoadStart: handleLoadStart,
                onLoad: handleLoad,
                onError: handleError
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                lineNumber: 263,
                columnNumber: 9
            }, this),
            showPlaceholder && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 flex items-center justify-center",
                children: loading || imageLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$loader$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Loader2$3e$__["Loader2"],
                            variant: "muted",
                            size: "lg",
                            className: "animate-spin"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                            lineNumber: 281,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs",
                            style: {
                                color: 'var(--color-muted-foreground)'
                            },
                            children: "Cargando..."
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                            lineNumber: 287,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                    lineNumber: 280,
                    columnNumber: 13
                }, this) : imageError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2d$off$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ImageOff$3e$__["ImageOff"],
                            variant: "muted",
                            size: "lg"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                            lineNumber: 298,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-center px-2",
                            style: {
                                color: 'var(--color-muted-foreground)'
                            },
                            children: "Error al cargar"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                            lineNumber: 303,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                    lineNumber: 297,
                    columnNumber: 13
                }, this) : !src ? placeholder || /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"],
                            variant: "muted",
                            size: "lg"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                            lineNumber: 315,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-xs text-center px-2",
                            style: {
                                color: 'var(--color-muted-foreground)'
                            },
                            children: "Sin imagen"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                            lineNumber: 320,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                    lineNumber: 314,
                    columnNumber: 15
                }, this) : null
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                lineNumber: 278,
                columnNumber: 9
            }, this),
            (showOverlay || overlayContent) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: overlayStyle,
                children: overlayContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-white text-sm font-medium text-center",
                    style: {
                        color: 'var(--color-primary-foreground, white)'
                    },
                    children: overlayContent
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                    lineNumber: 338,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                lineNumber: 336,
                columnNumber: 9
            }, this),
            (loading || imageLoading) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 backdrop-blur-sm",
                style: {
                    backgroundColor: 'var(--color-background, rgba(0, 0, 0, 0.2))',
                    borderRadius
                }
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
                lineNumber: 352,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PreviewImageMolecule.tsx",
        lineNumber: 253,
        columnNumber: 5
    }, this);
}
_s(PreviewImageMolecule, "dOBrXKNDjwKzKOjaxTncDQX1dE0=");
_c = PreviewImageMolecule;
const __TURBOPACK__default__export__ = PreviewImageMolecule;
var _c;
__turbopack_context__.k.register(_c, "PreviewImageMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChipMolecule",
    ()=>ChipMolecule,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Icon.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
'use client';
;
;
;
function ChipMolecule({ children, variant = 'default', size = 'md', removable = false, selected = false, disabled = false, startIcon: StartIcon, endIcon: EndIcon, avatar, onClick, onRemove, className = '', style = {}, ...props }) {
    // Get variant styles using only CSS variables
    const getVariantStyles = ()=>{
        const baseStyles = {
            transition: 'all 0.15s ease-in-out',
            cursor: onClick && !disabled ? 'pointer' : 'default',
            opacity: disabled ? 0.6 : 1,
            pointerEvents: disabled ? 'none' : 'auto'
        };
        if (selected) {
            switch(variant){
                case 'primary':
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-primary)',
                        color: 'var(--color-primary-foreground)',
                        border: '1px solid var(--color-primary)'
                    };
                case 'secondary':
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-secondary)',
                        color: 'var(--color-secondary-foreground)',
                        border: '1px solid var(--color-secondary)'
                    };
                case 'accent':
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-accent)',
                        color: 'var(--color-accent-foreground)',
                        border: '1px solid var(--color-accent)'
                    };
                case 'destructive':
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-destructive)',
                        color: 'var(--color-destructive-foreground)',
                        border: '1px solid var(--color-destructive)'
                    };
                case 'warning':
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-warning)',
                        color: 'var(--color-warning-foreground)',
                        border: '1px solid var(--color-warning)'
                    };
                case 'success':
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-success)',
                        color: 'var(--color-success-foreground)',
                        border: '1px solid var(--color-success)'
                    };
                default:
                    return {
                        ...baseStyles,
                        backgroundColor: 'var(--color-foreground)',
                        color: 'var(--color-background)',
                        border: '1px solid var(--color-foreground)'
                    };
            }
        }
        // Non-selected states using CSS variables with alpha
        switch(variant){
            case 'primary':
                return {
                    ...baseStyles,
                    backgroundColor: 'color-mix(in srgb, var(--color-primary) 20%, transparent)',
                    color: 'var(--color-primary)',
                    border: '1px solid var(--color-primary)'
                };
            case 'secondary':
                return {
                    ...baseStyles,
                    backgroundColor: 'color-mix(in srgb, var(--color-secondary) 20%, transparent)',
                    color: 'var(--color-secondary)',
                    border: '1px solid var(--color-secondary)'
                };
            case 'accent':
                return {
                    ...baseStyles,
                    backgroundColor: 'color-mix(in srgb, var(--color-accent) 20%, transparent)',
                    color: 'var(--color-accent)',
                    border: '1px solid var(--color-accent)'
                };
            case 'destructive':
                return {
                    ...baseStyles,
                    backgroundColor: 'color-mix(in srgb, var(--color-destructive) 20%, transparent)',
                    color: 'var(--color-destructive)',
                    border: '1px solid var(--color-destructive)'
                };
            case 'warning':
                return {
                    ...baseStyles,
                    backgroundColor: 'color-mix(in srgb, var(--color-warning) 20%, transparent)',
                    color: 'var(--color-warning)',
                    border: '1px solid var(--color-warning)'
                };
            case 'success':
                return {
                    ...baseStyles,
                    backgroundColor: 'color-mix(in srgb, var(--color-success) 20%, transparent)',
                    color: 'var(--color-success)',
                    border: '1px solid var(--color-success)'
                };
            case 'outline':
                return {
                    ...baseStyles,
                    backgroundColor: 'transparent',
                    color: 'var(--color-foreground)',
                    border: '1px solid var(--color-border)'
                };
            default:
                return {
                    ...baseStyles,
                    backgroundColor: 'var(--color-muted)',
                    color: 'var(--color-muted-foreground)',
                    border: '1px solid var(--color-border)'
                };
        }
    };
    // Get size styles
    const getSizeStyles = ()=>{
        switch(size){
            case 'sm':
                return {
                    height: '24px',
                    padding: '0 8px',
                    fontSize: '12px',
                    gap: '4px'
                };
            case 'lg':
                return {
                    height: '40px',
                    padding: '0 16px',
                    fontSize: '16px',
                    gap: '8px'
                };
            default:
                return {
                    height: '32px',
                    padding: '0 12px',
                    fontSize: '14px',
                    gap: '6px'
                };
        }
    };
    // Get icon size based on chip size
    const getIconSize = ()=>{
        switch(size){
            case 'sm':
                return 'xs';
            case 'lg':
                return 'sm';
            default:
                return 'xs';
        }
    };
    const variantStyles = getVariantStyles();
    const sizeStyles = getSizeStyles();
    const iconSize = getIconSize();
    // Handle remove click
    const handleRemoveClick = (e)=>{
        e.stopPropagation();
        onRemove?.();
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `chip-molecule inline-flex items-center ${className}`,
        style: {
            borderRadius: 'var(--radius-chip, var(--radius, 6px))',
            fontWeight: '500',
            lineHeight: '1',
            userSelect: 'none',
            fontFamily: 'var(--typography-emphasis-font-family)',
            ...variantStyles,
            ...sizeStyles,
            ...style
        },
        onClick: onClick && !disabled ? onClick : undefined,
        ...props,
        children: [
            avatar && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-shrink-0",
                style: {
                    marginLeft: '-4px',
                    marginRight: sizeStyles.gap
                },
                children: avatar
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
                lineNumber: 284,
                columnNumber: 9
            }, this),
            StartIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                icon: StartIcon,
                size: iconSize,
                style: {
                    color: 'currentColor'
                }
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
                lineNumber: 297,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "truncate",
                children: children
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
                lineNumber: 305,
                columnNumber: 7
            }, this),
            EndIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                icon: EndIcon,
                size: iconSize,
                style: {
                    color: 'currentColor'
                }
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
                lineNumber: 311,
                columnNumber: 9
            }, this),
            removable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleRemoveClick,
                disabled: disabled,
                className: "flex-shrink-0 hover:opacity-70 transition-opacity",
                style: {
                    background: 'none',
                    border: 'none',
                    padding: '2px',
                    marginLeft: '2px',
                    marginRight: '-4px',
                    cursor: 'pointer',
                    borderRadius: '2px',
                    color: 'currentColor'
                },
                "aria-label": "Remove",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Icon$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Icon"], {
                    icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"],
                    size: iconSize,
                    style: {
                        color: 'currentColor'
                    }
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
                    lineNumber: 336,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
                lineNumber: 320,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ChipMolecule.tsx",
        lineNumber: 267,
        columnNumber: 5
    }, this);
}
_c = ChipMolecule;
const __TURBOPACK__default__export__ = ChipMolecule;
var _c;
__turbopack_context__.k.register(_c, "ChipMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionMolecule",
    ()=>AccordionMolecule,
    "AccordionPresets",
    ()=>AccordionPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$accordion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/accordion.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Accordion$2f$Accordion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Accordion/Accordion.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function AccordionMolecule({ items, variant = 'default', multiple = false, animated = true, collapsible = true, className = '' }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // State for controlled accordion
    const [openItems, setOpenItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(items.filter({
        "AccordionMolecule.useState": (item)=>item.defaultOpen
    }["AccordionMolecule.useState"]).map({
        "AccordionMolecule.useState": (item)=>item.id
    }["AccordionMolecule.useState"]));
    const handleValueChange = (value)=>{
        if (multiple) {
            setOpenItems(Array.isArray(value) ? value : [
                value
            ]);
        } else {
            setOpenItems(Array.isArray(value) ? value : [
                value
            ]);
        }
    };
    // Enhanced variant styles
    const getVariantStyles = ()=>{
        const baseStyles = {
            borderRadius: 'var(--radius-card, 12px)',
            transition: animated ? 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)' : 'none',
            overflow: 'hidden'
        };
        switch(variant){
            case 'card':
                return {
                    ...baseStyles,
                    background: colors?.card?.value || 'var(--color-card)',
                    border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                    boxShadow: shadows?.shadowMd || 'var(--shadow-md)',
                    padding: '4px' // Inner padding for items
                };
            case 'bordered':
                return {
                    ...baseStyles,
                    border: `2px solid ${colors?.border?.value || 'var(--color-border)'}`,
                    background: colors?.background?.value || 'var(--color-background)',
                    padding: '2px'
                };
            case 'minimal':
                return {
                    ...baseStyles,
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '8px'
                };
            default:
                return {
                    ...baseStyles,
                    background: colors?.background?.value || 'var(--color-background)',
                    border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                    padding: '2px'
                };
        }
    };
    const getTriggerStyles = (isOpen, disabled)=>({
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            padding: variant === 'minimal' ? '12px 0' : `${smallSpacing} ${smallSpacing}`,
            background: 'transparent',
            border: 'none',
            cursor: disabled ? 'not-allowed' : 'pointer',
            borderRadius: 'var(--radius, 8px)',
            transition: animated ? 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)' : 'none',
            opacity: disabled ? 0.5 : 1,
            fontFamily: 'var(--typography-h4-font-family)',
            fontSize: 'var(--typography-h4-font-size)',
            fontWeight: isOpen ? 'var(--typography-h3-font-weight)' : 'var(--typography-h4-font-weight)',
            color: isOpen ? colors?.primary?.value || 'var(--color-primary)' : colors?.foreground?.value || 'var(--color-foreground)',
            position: 'relative'
        });
    const getContentStyles = ()=>({
            padding: variant === 'minimal' ? `${mediumSpacing} 0` : `0 ${smallSpacing} ${mediumSpacing} ${smallSpacing}`,
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: 'var(--typography-paragraph-font-size)',
            fontWeight: 'var(--typography-paragraph-font-weight)',
            lineHeight: 'var(--typography-paragraph-line-height)',
            color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
            borderTop: variant === 'bordered' ? `1px solid ${colors?.border?.value || 'var(--color-border)'}` : 'none',
            marginTop: variant === 'minimal' ? '8px' : '0',
            position: 'relative',
            // Smooth content animation
            transition: animated ? 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)' : 'none'
        });
    // New function for icon container styles
    const getIconStyles = (isOpen, isCustomIcon)=>({
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '20px',
            height: '20px',
            borderRadius: '4px',
            backgroundColor: isOpen ? (colors?.primary?.value || 'var(--color-primary)') + '20' : 'transparent',
            transition: animated ? 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)' : 'none',
            transform: animated ? isCustomIcon ? isOpen ? 'rotate(90deg) scale(1.1)' : 'rotate(0deg) scale(1)' : isOpen ? 'rotate(180deg) scale(1.1)' : 'rotate(0deg) scale(1)' : 'none'
        });
    const accordionType = multiple ? 'multiple' : 'single';
    const accordionValue = multiple ? openItems : openItems[0] || '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        style: {
            ...getVariantStyles(),
            marginBottom: largeSpacing // Large spacing between accordion sections
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Accordion$2f$Accordion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Accordion"], {
            type: accordionType,
            value: accordionValue,
            onValueChange: handleValueChange,
            collapsible: collapsible,
            children: items.map((item, index)=>{
                const isOpen = openItems.includes(item.id);
                const isLast = index === items.length - 1;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Accordion$2f$Accordion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionItem"], {
                    value: item.id,
                    style: {
                        borderBottom: !isLast && variant !== 'minimal' ? `1px solid ${colors?.border?.value || 'var(--color-border)'}` : 'none',
                        marginBottom: variant === 'minimal' ? mediumSpacing : '0'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Accordion$2f$Accordion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionTrigger"], {
                            disabled: item.disabled,
                            style: getTriggerStyles(isOpen, item.disabled || false),
                            className: `
                  group hover:no-underline focus:no-underline
                  ${!item.disabled ? 'hover:bg-accent/50 focus:bg-accent/50 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2' : ''}
                  ${isOpen ? 'bg-accent/30' : ''}
                  rounded-lg transition-all duration-300 ease-out
                `,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center",
                                style: {
                                    flex: 1,
                                    gap: '12px',
                                    minHeight: '44px' // Better touch target
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: getIconStyles(isOpen, !!item.icon),
                                        children: item.icon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                color: isOpen ? colors?.primary?.value || 'var(--color-primary)' : colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                                width: '16px',
                                                height: '16px',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            },
                                            children: item.icon
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                            lineNumber: 237,
                                            columnNumber: 23
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                            className: "h-4 w-4 shrink-0",
                                            style: {
                                                color: isOpen ? colors?.primary?.value || 'var(--color-primary)' : colors?.mutedForeground?.value || 'var(--color-muted-foreground)'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                            lineNumber: 250,
                                            columnNumber: 23
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                        lineNumber: 235,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            flex: 1,
                                            textAlign: 'left',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            gap: '2px'
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontWeight: isOpen ? 600 : 500,
                                                transition: animated ? 'font-weight 0.3s ease' : 'none'
                                            },
                                            children: item.title
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                            lineNumber: 269,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                        lineNumber: 262,
                                        columnNumber: 19
                                    }, this),
                                    item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                        variant: item.badge.variant || 'outline',
                                        size: "sm",
                                        style: {
                                            flexShrink: 0,
                                            opacity: animated ? isOpen ? 0.9 : 1 : 1,
                                            transform: animated ? isOpen ? 'scale(0.95)' : 'scale(1)' : 'none',
                                            transition: animated ? 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)' : 'none'
                                        },
                                        children: item.badge.text
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                        lineNumber: 280,
                                        columnNumber: 21
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                lineNumber: 229,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                            lineNumber: 219,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Accordion$2f$Accordion$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionContent"], {
                            style: getContentStyles(),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    position: 'relative',
                                    paddingLeft: '32px',
                                    animation: animated && isOpen ? 'fadeInUp 0.3s cubic-bezier(0.4, 0, 0.2, 1)' : 'none'
                                },
                                children: typeof item.content === 'string' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    style: {
                                        margin: 0,
                                        lineHeight: 1.6,
                                        fontSize: '14px',
                                        color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)'
                                    },
                                    children: item.content
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                    lineNumber: 303,
                                    columnNumber: 21
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        '& > *:first-child': {
                                            marginTop: 0
                                        },
                                        '& > *:last-child': {
                                            marginBottom: 0
                                        }
                                    },
                                    children: item.content
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                    lineNumber: 312,
                                    columnNumber: 21
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                                lineNumber: 297,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                            lineNumber: 296,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.id, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
                    lineNumber: 209,
                    columnNumber: 13
                }, this);
            })
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
            lineNumber: 198,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/AccordionMolecule.tsx",
        lineNumber: 191,
        columnNumber: 5
    }, this);
}
_s(AccordionMolecule, "ia7u7+75qEhuw4zY4MeNHpyDurg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = AccordionMolecule;
const AccordionPresets = {
    basic: {
        variant: 'default',
        multiple: false,
        animated: true,
        collapsible: true
    },
    card: {
        variant: 'card',
        multiple: false,
        animated: true,
        collapsible: true
    },
    multiSelect: {
        variant: 'bordered',
        multiple: true,
        animated: true,
        collapsible: true
    },
    minimal: {
        variant: 'minimal',
        multiple: false,
        animated: false,
        collapsible: true
    }
};
var _c;
__turbopack_context__.k.register(_c, "AccordionMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CardMolecule",
    ()=>CardMolecule,
    "CardPresets",
    ()=>CardPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript) <export default as MoreHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/card.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Card/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function CardMolecule({ title, description, content, image, imageAlt, badge, actions, variant = 'default', closeable = false, onClose, footer, className = '', loading = false, disabled = false, href, target = '_self' }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // Variant styles
    const getVariantStyles = ()=>{
        const baseStyles = {
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            marginBottom: largeSpacing,
            opacity: disabled ? 0.6 : 1,
            cursor: disabled ? 'not-allowed' : href ? 'pointer' : 'default',
            position: 'relative',
            overflow: 'hidden'
        };
        switch(variant){
            case 'elevated':
                return {
                    ...baseStyles,
                    boxShadow: shadows?.shadowLg || 'var(--shadow-lg)',
                    transform: 'translateY(-2px)',
                    border: `1px solid ${colors?.border?.value || 'var(--color-border)'}40`
                };
            case 'interactive':
                return {
                    ...baseStyles,
                    cursor: 'pointer',
                    '&:hover': {
                        transform: 'translateY(-4px)',
                        boxShadow: shadows?.shadowXl || 'var(--shadow-xl)'
                    }
                };
            case 'compact':
                return {
                    ...baseStyles,
                    padding: smallSpacing
                };
            case 'featured':
                return {
                    ...baseStyles,
                    background: `linear-gradient(135deg, ${colors?.primary?.value || 'var(--color-primary)'}10, ${colors?.accent?.value || 'var(--color-accent)'}10)`,
                    border: `2px solid ${colors?.primary?.value || 'var(--color-primary)'}20`,
                    boxShadow: `0 0 0 1px ${colors?.primary?.value || 'var(--color-primary)'}10, ${shadows?.shadowMd || 'var(--shadow-md)'}`
                };
            default:
                return baseStyles;
        }
    };
    const CardWrapper = href ? 'a' : 'div';
    const wrapperProps = href ? {
        href,
        target,
        rel: target === '_blank' ? 'noopener noreferrer' : undefined
    } : {};
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(CardWrapper, {
        ...wrapperProps,
        className: className,
        style: {
            textDecoration: 'none'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
            className: `text-foreground max-sm:mx-2 max-sm:max-w-[calc(100vw-1rem)] ${variant === 'interactive' ? 'hover:shadow-lg hover:scale-[1.02] transition-all duration-300' : ''}`,
            style: getVariantStyles(),
            children: [
                loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: 'absolute',
                        inset: 0,
                        background: `${colors?.background?.value || 'var(--color-background)'}ee`,
                        backdropFilter: 'blur(4px)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        zIndex: 10
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "animate-spin rounded-full h-8 w-8 border-b-2 border-primary"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                        lineNumber: 157,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 147,
                    columnNumber: 11
                }, this),
                image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        width: '100%',
                        height: variant === 'compact' ? '150px' : '200px',
                        overflow: 'hidden',
                        borderRadius: 'var(--radius-card, 12px) var(--radius-card, 12px) 0 0',
                        position: 'relative'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: image,
                            alt: imageAlt || title || 'Card image',
                            style: {
                                width: '100%',
                                height: '100%',
                                objectFit: 'cover',
                                transition: 'transform 0.3s ease'
                            },
                            className: variant === 'interactive' ? 'hover:scale-110' : ''
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                            lineNumber: 170,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                position: 'absolute',
                                bottom: 0,
                                left: 0,
                                right: 0,
                                height: '50%',
                                background: 'linear-gradient(to top, rgba(0,0,0,0.6) 0%, transparent 100%)',
                                pointerEvents: 'none'
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                            lineNumber: 182,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, this),
                (title || description || badge || closeable) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                    style: {
                        padding: smallSpacing
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            alignItems: 'flex-start',
                            gap: '12px'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    flex: 1
                                },
                                children: [
                                    title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '8px',
                                            marginBottom: '8px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                                                className: "text-foreground",
                                                style: {
                                                    fontSize: variant === 'compact' ? '16px' : '18px',
                                                    fontWeight: 600,
                                                    lineHeight: 1.4
                                                },
                                                children: title
                                            }, void 0, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                                lineNumber: 202,
                                                columnNumber: 21
                                            }, this),
                                            badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                variant: badge.variant || 'outline',
                                                size: "sm",
                                                style: {
                                                    flexShrink: 0,
                                                    opacity: 0.9
                                                },
                                                children: badge.text
                                            }, void 0, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                                lineNumber: 210,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                        lineNumber: 201,
                                        columnNumber: 19
                                    }, this),
                                    description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardDescription"], {
                                        className: "text-muted-foreground",
                                        style: {
                                            fontSize: '14px',
                                            lineHeight: 1.5,
                                            opacity: 0.8
                                        },
                                        children: description
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                        lineNumber: 226,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                lineNumber: 198,
                                columnNumber: 15
                            }, this),
                            closeable && onClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                size: "sm",
                                onClick: (e)=>{
                                    e.preventDefault();
                                    e.stopPropagation();
                                    onClose();
                                },
                                style: {
                                    width: '32px',
                                    height: '32px',
                                    padding: 0,
                                    borderRadius: '50%',
                                    flexShrink: 0
                                },
                                className: "hover:bg-destructive/20 hover:text-destructive",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                    lineNumber: 255,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                lineNumber: 238,
                                columnNumber: 17
                            }, this),
                            !closeable && variant === 'featured' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                size: "sm",
                                style: {
                                    width: '32px',
                                    height: '32px',
                                    padding: 0,
                                    borderRadius: '50%',
                                    flexShrink: 0
                                },
                                className: "hover:bg-accent",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__["MoreHorizontal"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                    lineNumber: 273,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                lineNumber: 261,
                                columnNumber: 17
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                        lineNumber: 197,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 196,
                    columnNumber: 11
                }, this),
                content && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "text-foreground",
                    style: {
                        padding: smallSpacing,
                        paddingTop: title || description ? 0 : smallSpacing
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            fontSize: '14px',
                            lineHeight: 1.6,
                            color: colors?.foreground?.value || 'var(--color-foreground)'
                        },
                        children: content
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                        lineNumber: 286,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 282,
                    columnNumber: 11
                }, this),
                actions && actions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                    style: {
                        padding: smallSpacing,
                        paddingTop: 0,
                        display: 'flex',
                        flexWrap: 'wrap',
                        gap: '8px'
                    },
                    className: "max-sm:flex-col max-sm:gap-2",
                    children: actions.map((action, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: action.variant || (index === 0 ? 'default' : 'outline'),
                            size: variant === 'compact' ? 'sm' : 'default',
                            onClick: (e)=>{
                                e.preventDefault();
                                e.stopPropagation();
                                action.onClick();
                            },
                            disabled: disabled,
                            style: {
                                flex: actions.length <= 2 ? 1 : 'none',
                                minWidth: actions.length > 2 ? '100px' : undefined
                            },
                            className: "max-sm:w-full max-sm:flex-1",
                            children: [
                                action.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        marginRight: '4px'
                                    },
                                    children: action.icon
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                                    lineNumber: 325,
                                    columnNumber: 33
                                }, this),
                                action.label
                            ]
                        }, index, true, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                            lineNumber: 309,
                            columnNumber: 15
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 298,
                    columnNumber: 11
                }, this),
                footer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardFooter"], {
                    className: "text-muted-foreground",
                    style: {
                        padding: smallSpacing,
                        paddingTop: 0,
                        borderTop: `1px solid ${colors?.border?.value || 'var(--color-border)'}40`,
                        background: `${colors?.accent?.value || 'var(--color-accent)'}10`
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            width: '100%',
                            fontSize: '13px',
                            opacity: 0.8
                        },
                        children: footer
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                        lineNumber: 340,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 334,
                    columnNumber: 11
                }, this),
                variant === 'featured' && !disabled && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        position: 'absolute',
                        inset: 0,
                        background: `linear-gradient(135deg, ${colors?.primary?.value || 'var(--color-primary)'}00, ${colors?.primary?.value || 'var(--color-primary)'}10)`,
                        opacity: 0,
                        transition: 'opacity 0.3s ease',
                        pointerEvents: 'none'
                    },
                    className: "hover:opacity-100"
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
                    lineNumber: 352,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
            lineNumber: 141,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/CardMolecule.tsx",
        lineNumber: 140,
        columnNumber: 5
    }, this);
}
_s(CardMolecule, "mIRfWfYBCLkiT9fCCRUByvPsoVU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = CardMolecule;
const CardPresets = {
    basic: {
        variant: 'default'
    },
    elevated: {
        variant: 'elevated'
    },
    interactive: {
        variant: 'interactive',
        href: '#'
    },
    compact: {
        variant: 'compact'
    },
    featured: {
        variant: 'featured',
        badge: {
            text: 'Featured',
            variant: 'default'
        }
    },
    withImage: {
        variant: 'default',
        image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=400&fit=crop'
    },
    closeable: {
        variant: 'default',
        closeable: true
    }
};
var _c;
__turbopack_context__.k.register(_c, "CardMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DatePickerMolecule",
    ()=>DatePickerMolecule,
    "DatePickerPresets",
    ()=>DatePickerPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/calendar.js [app-client] (ecmascript) <export default as Calendar>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/clock.js [app-client] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/popover.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/popover-local.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$calendar$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/calendar-local.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
function DatePickerMolecule({ value, onChange, placeholder = 'Seleccionar fecha', format: dateFormat = 'PPP', variant = 'default', disabled = false, clearable = true, showToday = true, minDate, maxDate, className = '', error, label, required = false }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // Local state
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [time, setTime] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        hours: '12',
        minutes: '00'
    });
    // Refs
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Enhanced date formatting helper with range support
    const formatDate = (dateValue, format = 'PPP')=>{
        if (!dateValue) return '';
        // Handle range values
        if (typeof dateValue === 'object' && 'from' in dateValue) {
            const range = dateValue;
            if (!range.from) return '';
            const fromFormatted = formatSingleDate(range.from, format);
            if (range.to) {
                const toFormatted = formatSingleDate(range.to, format);
                return `${fromFormatted} - ${toFormatted}`;
            }
            return fromFormatted + ' (Select end date)';
        }
        // Handle single date
        return formatSingleDate(dateValue, format);
    };
    const formatSingleDate = (date, format = 'PPP')=>{
        if (!date || isNaN(date.getTime())) return '';
        try {
            if (format === 'PPP pp' || variant === 'datetime') {
                return date.toLocaleString('es-ES', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }
            return date.toLocaleDateString('es-ES', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        } catch  {
            return date.toISOString().split('T')[0];
        }
    };
    const parseDate = (dateString)=>{
        if (!dateString) return null;
        try {
            const date = new Date(dateString);
            return isNaN(date.getTime()) ? null : date;
        } catch  {
            return null;
        }
    };
    // Update input value when external value changes - Enhanced for range support
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DatePickerMolecule.useEffect": ()=>{
            const formatted = formatDate(value, dateFormat);
            setInputValue(formatted);
            // Handle datetime for single dates only
            if (variant === 'datetime' && value && typeof value === 'object' && 'getTime' in value) {
                const date = value;
                if (!isNaN(date.getTime())) {
                    setTime({
                        hours: date.getHours().toString().padStart(2, '0'),
                        minutes: date.getMinutes().toString().padStart(2, '0')
                    });
                }
            }
        }
    }["DatePickerMolecule.useEffect"], [
        value,
        dateFormat,
        variant
    ]);
    // Enhanced date selection handler with range support
    const handleDateSelect = (selected)=>{
        if (!selected) {
            onChange?.(undefined);
            setInputValue('');
            setIsOpen(false);
            return;
        }
        if (variant === 'range') {
            onChange?.(selected);
            // Keep popover open until range is complete
            const range = selected;
            if (range.from && range.to && variant !== 'inline') {
                setIsOpen(false);
            }
        } else {
            const selectedDate = selected;
            let finalDate = selectedDate;
            // Add time for datetime variant
            if (variant === 'datetime') {
                finalDate = new Date(selectedDate);
                finalDate.setHours(parseInt(time.hours), parseInt(time.minutes));
            }
            onChange?.(finalDate);
            // Close popover for non-inline variants
            if (variant !== 'inline') {
                setIsOpen(false);
            }
        }
    };
    // Handle manual input
    const handleInputChange = (event)=>{
        const inputVal = event.target.value;
        setInputValue(inputVal);
        const parsed = parseDate(inputVal);
        if (parsed) {
            onChange?.(parsed);
        }
    };
    // Clear date
    const handleClear = ()=>{
        onChange?.(undefined);
        setInputValue('');
        setIsOpen(false);
    };
    // Select today
    const handleToday = ()=>{
        const today = new Date();
        handleDateSelect(today);
    };
    // Handle time change for datetime variant
    const handleTimeChange = (type, timeValue)=>{
        const newTime = {
            ...time,
            [type]: timeValue
        };
        setTime(newTime);
        if (value) {
            const updatedDate = new Date(value);
            updatedDate.setHours(parseInt(newTime.hours), parseInt(newTime.minutes));
            onChange?.(updatedDate);
        }
    };
    // Styles
    const getContainerStyles = ()=>({
            display: 'flex',
            flexDirection: 'column',
            gap: mediumSpacing,
            marginBottom: largeSpacing
        });
    const getLabelStyles = ()=>({
            fontFamily: 'var(--typography-emphasis-font-family)',
            fontSize: 'var(--typography-emphasis-font-size)',
            fontWeight: 'var(--typography-emphasis-font-weight)',
            color: colors?.foreground?.value || 'var(--color-foreground)',
            marginBottom: smallSpacing
        });
    const getInputContainerStyles = ()=>({
            position: 'relative',
            display: 'flex',
            alignItems: 'center',
            gap: '8px'
        });
    const getErrorStyles = ()=>({
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: 'calc(var(--typography-paragraph-font-size) * 0.875)',
            color: colors?.destructive?.value || 'var(--color-destructive)',
            marginTop: '4px'
        });
    const getPopoverContentStyles = ()=>({
            padding: mediumSpacing,
            background: colors?.popover?.value || 'var(--color-popover)',
            border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            borderRadius: 'var(--radius-popover, 12px)',
            boxShadow: `${shadows?.shadowLg || 'var(--shadow-lg)'}, 0 0 0 1px ${colors?.border?.value || 'var(--color-border)'}20`,
            minWidth: variant === 'datetime' ? 'min(340px, calc(100vw - 40px))' : 'min(300px, calc(100vw - 40px))',
            maxWidth: 'calc(100vw - 20px)',
            backdropFilter: 'blur(8px)',
            background: `${colors?.popover?.value || 'var(--color-popover)'}f8`,
            animation: 'slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            transformOrigin: 'var(--radix-popover-content-transform-origin)'
        });
    const getTimeInputStyles = ()=>({
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '12px',
            marginTop: mediumSpacing,
            padding: `12px ${smallSpacing}`,
            background: `${colors?.accent?.value || 'var(--color-accent)'}40`,
            borderRadius: 'var(--radius, 8px)',
            border: `1px solid ${colors?.border?.value || 'var(--color-border)'}60`,
            backdropFilter: 'blur(4px)',
            transition: 'all 0.3s ease'
        });
    // Render time inputs for datetime variant
    const renderTimeInputs = ()=>{
        if (variant !== 'datetime') return null;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: getTimeInputStyles(),
            className: "max-sm:flex-col max-sm:items-stretch max-sm:gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                    className: "h-4 w-4 max-sm:self-center",
                    style: {
                        color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)'
                    }
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 288,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '4px'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            style: {
                                fontSize: '11px',
                                fontWeight: 600,
                                color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                textTransform: 'uppercase',
                                letterSpacing: '0.5px'
                            },
                            children: "Hora"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 295,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "number",
                            min: "0",
                            max: "23",
                            value: time.hours,
                            onChange: (e)=>handleTimeChange('hours', e.target.value),
                            style: {
                                width: '50px',
                                height: '36px',
                                padding: '6px 8px',
                                border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                                borderRadius: 'var(--radius, 6px)',
                                background: colors?.background?.value || 'var(--color-background)',
                                color: colors?.foreground?.value || 'var(--color-foreground)',
                                fontFamily: 'var(--typography-paragraph-font-family)',
                                fontSize: '14px',
                                fontWeight: 500,
                                textAlign: 'center',
                                transition: 'all 0.3s ease',
                                boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.1)'
                            },
                            className: "focus:border-primary focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:outline-none"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 302,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 289,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        fontSize: '18px',
                        fontWeight: 600,
                        color: colors?.primary?.value || 'var(--color-primary)',
                        marginTop: '16px'
                    },
                    children: ":"
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 326,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '4px'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            style: {
                                fontSize: '11px',
                                fontWeight: 600,
                                color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                textTransform: 'uppercase',
                                letterSpacing: '0.5px'
                            },
                            children: "Min"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 338,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "number",
                            min: "0",
                            max: "59",
                            value: time.minutes,
                            onChange: (e)=>handleTimeChange('minutes', e.target.value),
                            style: {
                                width: '50px',
                                height: '36px',
                                padding: '6px 8px',
                                border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                                borderRadius: 'var(--radius, 6px)',
                                background: colors?.background?.value || 'var(--color-background)',
                                color: colors?.foreground?.value || 'var(--color-foreground)',
                                fontFamily: 'var(--typography-paragraph-font-family)',
                                fontSize: '14px',
                                fontWeight: 500,
                                textAlign: 'center',
                                transition: 'all 0.3s ease',
                                boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.1)'
                            },
                            className: "focus:border-primary focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:outline-none"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 345,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 332,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
            lineNumber: 287,
            columnNumber: 7
        }, this);
    };
    // Inline variant renders calendar directly
    if (variant === 'inline') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: className,
            style: getContainerStyles(),
            children: [
                label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    style: getLabelStyles(),
                    children: [
                        label,
                        required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                color: colors?.destructive?.value || 'var(--color-destructive)'
                            },
                            children: "*"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 380,
                            columnNumber: 26
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 378,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                        borderRadius: 'var(--radius-card, 8px)',
                        padding: mediumSpacing,
                        background: colors?.background?.value || 'var(--color-background)'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$calendar$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Calendar"], {
                            mode: variant === 'range' ? 'range' : 'single',
                            selected: value,
                            onSelect: handleDateSelect,
                            disabled: disabled,
                            fromDate: minDate,
                            toDate: maxDate
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 390,
                            columnNumber: 11
                        }, this),
                        renderTimeInputs(),
                        showToday && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                marginTop: mediumSpacing,
                                display: 'flex',
                                gap: '8px',
                                justifyContent: 'space-between'
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "outline",
                                    size: "sm",
                                    onClick: handleToday,
                                    children: "Hoy"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                    lineNumber: 403,
                                    columnNumber: 15
                                }, this),
                                clearable && value && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "ghost",
                                    size: "sm",
                                    onClick: handleClear,
                                    children: "Limpiar"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                    lineNumber: 407,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                            lineNumber: 402,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 384,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: getErrorStyles(),
                    children: error
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                    lineNumber: 415,
                    columnNumber: 19
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
            lineNumber: 376,
            columnNumber: 7
        }, this);
    }
    // Default popover variant
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        style: getContainerStyles(),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                style: getLabelStyles(),
                children: [
                    label,
                    required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            color: colors?.destructive?.value || 'var(--color-destructive)'
                        },
                        children: "*"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                        lineNumber: 426,
                        columnNumber: 24
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                lineNumber: 424,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: getInputContainerStyles(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
                        open: isOpen,
                        onOpenChange: setIsOpen,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverTrigger"], {
                                asChild: true,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    variant: "outline",
                                    disabled: disabled,
                                    style: {
                                        width: '100%',
                                        justifyContent: 'space-between',
                                        fontWeight: inputValue ? 500 : 400,
                                        color: inputValue ? colors?.foreground?.value || 'var(--color-foreground)' : colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                        minHeight: '40px',
                                        padding: `8px ${smallSpacing}`,
                                        borderRadius: 'var(--radius, 8px)',
                                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                                        border: isOpen ? `2px solid ${colors?.primary?.value || 'var(--color-primary)'}` : `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                                        boxShadow: isOpen ? `0 0 0 2px ${colors?.primary?.value || 'var(--color-primary)'}20` : 'none'
                                    },
                                    className: `
                group relative overflow-hidden
                ${!disabled ? 'hover:bg-accent/50 hover:scale-[0.99] active:scale-[0.98]' : ''}
                ${isOpen ? 'bg-accent/30' : ''}
                transition-all duration-300 ease-out
              `,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '8px',
                                                flex: 1,
                                                minWidth: 0
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$calendar$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Calendar$3e$__["Calendar"], {
                                                    className: "h-4 w-4",
                                                    style: {
                                                        color: inputValue ? colors?.primary?.value || 'var(--color-primary)' : colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                                        flexShrink: 0,
                                                        transition: 'color 0.3s ease'
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                    lineNumber: 468,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    style: {
                                                        truncate: 'true',
                                                        fontSize: '14px',
                                                        lineHeight: 1.4
                                                    },
                                                    children: inputValue || placeholder
                                                }, void 0, false, {
                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                    lineNumber: 478,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                            lineNumber: 461,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: '6px',
                                                flexShrink: 0
                                            },
                                            children: clearable && inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                size: "sm",
                                                onClick: (e)=>{
                                                    e.stopPropagation();
                                                    handleClear();
                                                },
                                                style: {
                                                    width: '20px',
                                                    height: '20px',
                                                    padding: '0',
                                                    borderRadius: '4px',
                                                    transition: 'all 0.2s ease',
                                                    background: 'transparent'
                                                },
                                                className: "hover:bg-destructive/20 hover:scale-110 active:scale-95",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                    className: "h-3 w-3",
                                                    style: {
                                                        color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                                        transition: 'color 0.2s ease'
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                    lineNumber: 510,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                lineNumber: 493,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                            lineNumber: 486,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                    lineNumber: 433,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                lineNumber: 432,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverContent"], {
                                style: getPopoverContentStyles(),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$calendar$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Calendar"], {
                                        mode: variant === 'range' ? 'range' : 'single',
                                        selected: value,
                                        onSelect: handleDateSelect,
                                        fromDate: minDate,
                                        toDate: maxDate,
                                        initialFocus: true
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                        lineNumber: 521,
                                        columnNumber: 13
                                    }, this),
                                    renderTimeInputs(),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            marginTop: mediumSpacing,
                                            display: 'flex',
                                            gap: '8px',
                                            justifyContent: 'space-between',
                                            paddingTop: '12px',
                                            borderTop: `1px solid ${colors?.border?.value || 'var(--color-border)'}40`
                                        },
                                        children: [
                                            showToday && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "outline",
                                                size: "sm",
                                                onClick: handleToday,
                                                style: {
                                                    borderRadius: '6px',
                                                    fontWeight: 500,
                                                    fontSize: '13px',
                                                    transition: 'all 0.3s ease',
                                                    background: `${colors?.primary?.value || 'var(--color-primary)'}10`,
                                                    borderColor: `${colors?.primary?.value || 'var(--color-primary)'}40`,
                                                    color: colors?.primary?.value || 'var(--color-primary)'
                                                },
                                                className: "hover:scale-105 hover:shadow-sm active:scale-95",
                                                children: "Hoy"
                                            }, void 0, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                lineNumber: 541,
                                                columnNumber: 17
                                            }, this),
                                            clearable && value && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                                variant: "ghost",
                                                size: "sm",
                                                onClick: handleClear,
                                                style: {
                                                    borderRadius: '6px',
                                                    fontWeight: 500,
                                                    fontSize: '13px',
                                                    transition: 'all 0.3s ease',
                                                    color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)'
                                                },
                                                className: "hover:scale-105 hover:bg-destructive/20 hover:text-destructive active:scale-95",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                        className: "h-3 w-3",
                                                        style: {
                                                            marginRight: '4px'
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                        lineNumber: 573,
                                                        columnNumber: 19
                                                    }, this),
                                                    "Limpiar"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                                lineNumber: 560,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                        lineNumber: 532,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                                lineNumber: 520,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                        lineNumber: 431,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                        ref: inputRef,
                        type: "text",
                        value: inputValue,
                        onChange: handleInputChange,
                        placeholder: "dd/mm/yyyy",
                        disabled: disabled,
                        style: {
                            width: '160px',
                            fontFamily: 'var(--typography-paragraph-font-family)',
                            fontSize: '14px',
                            fontWeight: 500,
                            borderRadius: 'var(--radius, 8px)',
                            transition: 'all 0.3s ease',
                            background: colors?.background?.value || 'var(--color-background)',
                            borderColor: colors?.border?.value || 'var(--color-border)'
                        },
                        className: "focus:border-primary focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:outline-none hover:border-primary/60"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                        lineNumber: 582,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                lineNumber: 430,
                columnNumber: 7
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: getErrorStyles(),
                children: error
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
                lineNumber: 603,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DatePickerMolecule.tsx",
        lineNumber: 422,
        columnNumber: 5
    }, this);
}
_s(DatePickerMolecule, "VlPcglnNSNCjZoBcGgChe+krTks=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = DatePickerMolecule;
const DatePickerPresets = {
    basic: {
        variant: 'default',
        clearable: true,
        showToday: true
    },
    datetime: {
        variant: 'datetime',
        format: 'PPP pp',
        clearable: true,
        showToday: true
    },
    inline: {
        variant: 'inline',
        clearable: true,
        showToday: true
    },
    range: {
        variant: 'range',
        placeholder: 'Select date range...',
        clearable: true,
        showToday: true
    }
};
var _c;
__turbopack_context__.k.register(_c, "DatePickerMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaginationMolecule",
    ()=>PaginationMolecule,
    "PaginationPresets",
    ()=>PaginationPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevrons$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronsLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevrons-left.js [app-client] (ecmascript) <export default as ChevronsLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevrons$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronsRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevrons-right.js [app-client] (ecmascript) <export default as ChevronsRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/pagination-local.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function PaginationMolecule({ currentPage, totalPages, onPageChange, variant = 'default', showFirstLast = true, showPageSize = false, pageSize = 10, onPageSizeChange, pageSizeOptions = [
    5,
    10,
    20,
    50,
    100
], showTotal = false, totalItems, siblingCount = 1, boundaryCount = 1, disabled = false, className = '' }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // Calculate page range
    const pageRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PaginationMolecule.useMemo[pageRange]": ()=>{
            const range = [];
            const start = Math.max(1, currentPage - siblingCount);
            const end = Math.min(totalPages, currentPage + siblingCount);
            // Add first boundary
            for(let i = 1; i <= Math.min(boundaryCount, totalPages); i++){
                range.push(i);
            }
            // Add ellipsis if needed
            if (start > boundaryCount + 2) {
                range.push('start-ellipsis');
            } else if (start === boundaryCount + 2) {
                range.push(boundaryCount + 1);
            }
            // Add middle pages
            for(let i = start; i <= end; i++){
                if (i > boundaryCount && i <= totalPages - boundaryCount) {
                    range.push(i);
                }
            }
            // Add ellipsis if needed
            if (end < totalPages - boundaryCount - 1) {
                range.push('end-ellipsis');
            } else if (end === totalPages - boundaryCount - 1) {
                range.push(totalPages - boundaryCount);
            }
            // Add last boundary
            for(let i = Math.max(totalPages - boundaryCount + 1, boundaryCount + 1); i <= totalPages; i++){
                range.push(i);
            }
            // Remove duplicates and sort
            return [
                ...new Set(range)
            ];
        }
    }["PaginationMolecule.useMemo[pageRange]"], [
        currentPage,
        totalPages,
        siblingCount,
        boundaryCount
    ]);
    // Handlers
    const handlePageChange = (page)=>{
        if (disabled || page < 1 || page > totalPages || page === currentPage) return;
        onPageChange(page);
    };
    const handlePageSizeChange = (newPageSize)=>{
        if (onPageSizeChange) {
            onPageSizeChange(newPageSize);
        }
    };
    // Styles
    const getContainerStyles = ()=>({
            display: 'flex',
            flexDirection: 'column',
            gap: mediumSpacing,
            alignItems: 'center',
            marginBottom: largeSpacing
        });
    const getInfoStyles = ()=>({
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: '14px',
            fontWeight: 500,
            color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
            textAlign: 'center',
            background: `${colors?.accent?.value || 'var(--color-accent)'}30`,
            padding: '8px 16px',
            borderRadius: 'var(--radius, 8px)',
            border: `1px solid ${colors?.border?.value || 'var(--color-border)'}40`,
            backdropFilter: 'blur(4px)'
        });
    const getControlsStyles = ()=>({
            display: 'flex',
            flexWrap: 'wrap',
            alignItems: 'center',
            gap: mediumSpacing,
            justifyContent: 'center'
        });
    const getPageSizeStyles = ()=>({
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: 'var(--typography-paragraph-font-size)',
            color: colors?.foreground?.value || 'var(--color-foreground)'
        });
    // Calculate display info
    const startItem = totalItems ? (currentPage - 1) * pageSize + 1 : 0;
    const endItem = totalItems ? Math.min(currentPage * pageSize, totalItems) : 0;
    // Compact variant
    if (variant === 'compact') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${className} flex flex-col items-center gap-4`,
            style: getContainerStyles(),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap items-center justify-center gap-2 sm:gap-1",
                style: getControlsStyles(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "outline",
                        size: "sm",
                        onClick: ()=>handlePageChange(currentPage - 1),
                        disabled: disabled || currentPage === 1,
                        style: {
                            borderRadius: 'var(--radius, 8px)',
                            minWidth: '40px',
                            minHeight: '40px',
                            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                            background: colors?.background?.value || 'var(--color-background)',
                            borderColor: colors?.border?.value || 'var(--color-border)'
                        },
                        className: `
              group relative overflow-hidden
              ${!disabled && currentPage !== 1 ? 'hover:bg-accent/60 hover:scale-105 hover:shadow-md active:scale-95' : ''}
              transition-all duration-300 ease-out
              sm:min-w-8 sm:h-8 sm:p-1
            `,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                            className: "h-4 w-4",
                            style: {
                                transition: 'transform 0.3s ease',
                                color: disabled || currentPage === 1 ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.foreground?.value || 'var(--color-foreground)'
                            },
                            className: "group-hover:scale-110"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 204,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 184,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                        variant: "outline",
                        style: {
                            minWidth: '90px',
                            textAlign: 'center',
                            fontSize: '14px',
                            fontWeight: 600,
                            padding: '8px 16px',
                            borderRadius: 'var(--radius, 8px)',
                            background: `linear-gradient(135deg, ${colors?.primary?.value || 'var(--color-primary)'}15, ${colors?.primary?.value || 'var(--color-primary)'}05)`,
                            borderColor: `${colors?.primary?.value || 'var(--color-primary)'}40`,
                            color: colors?.primary?.value || 'var(--color-primary)',
                            transition: 'all 0.3s ease',
                            backdropFilter: 'blur(4px)'
                        },
                        className: "hover:scale-105 hover:shadow-sm sm:text-xs sm:px-2 sm:py-1",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    color: colors?.primary?.value || 'var(--color-primary)'
                                },
                                children: currentPage
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 233,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                    margin: '0 4px'
                                },
                                children: "/"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 236,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                style: {
                                    color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)'
                                },
                                children: totalPages
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 240,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 216,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "outline",
                        size: "sm",
                        onClick: ()=>handlePageChange(currentPage + 1),
                        disabled: disabled || currentPage === totalPages,
                        style: {
                            borderRadius: 'var(--radius, 8px)',
                            minWidth: '40px',
                            minHeight: '40px',
                            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                            background: colors?.background?.value || 'var(--color-background)',
                            borderColor: colors?.border?.value || 'var(--color-border)'
                        },
                        className: `
              group relative overflow-hidden
              ${!disabled && currentPage !== totalPages ? 'hover:bg-accent/60 hover:scale-105 hover:shadow-md active:scale-95' : ''}
              transition-all duration-300 ease-out
              sm:min-w-8 sm:h-8 sm:p-1
            `,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                            className: "h-4 w-4",
                            style: {
                                transition: 'transform 0.3s ease',
                                color: disabled || currentPage === totalPages ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.foreground?.value || 'var(--color-foreground)'
                            },
                            className: "group-hover:scale-110"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 265,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 245,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                lineNumber: 183,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
            lineNumber: 182,
            columnNumber: 7
        }, this);
    }
    // Simple variant
    if (variant === 'simple') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `${className} flex flex-col items-center gap-4`,
            style: getContainerStyles(),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pagination"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationContent"], {
                    className: "flex items-center gap-1 sm:gap-0.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationPrevious"], {
                                onClick: ()=>handlePageChange(currentPage - 1),
                                disabled: disabled || currentPage === 1
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 288,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 287,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm sm:text-xs px-3 py-1 sm:px-2",
                                style: getInfoStyles(),
                                children: [
                                    "Página ",
                                    currentPage,
                                    " de ",
                                    totalPages
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 294,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 293,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationNext"], {
                                onClick: ()=>handlePageChange(currentPage + 1),
                                disabled: disabled || currentPage === totalPages
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 299,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 298,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                    lineNumber: 286,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                lineNumber: 285,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
            lineNumber: 284,
            columnNumber: 7
        }, this);
    }
    // Default and detailed variants
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${className} flex flex-col items-center gap-4`,
        style: getContainerStyles(),
        children: [
            showTotal && totalItems && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-sm sm:text-xs px-4 py-2 sm:px-2 sm:py-1 text-center",
                style: getInfoStyles(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sm:hidden",
                        children: [
                            "Mostrando ",
                            startItem,
                            " a ",
                            endItem,
                            " de ",
                            totalItems.toLocaleString(),
                            " resultados"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 316,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "hidden sm:inline",
                        children: [
                            startItem,
                            "-",
                            endItem,
                            " de ",
                            totalItems.toLocaleString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 317,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                lineNumber: 315,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Pagination"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationContent"], {
                    className: "flex flex-wrap items-center justify-center gap-1 sm:gap-0.5 sm:scale-90",
                    children: [
                        showFirstLast && currentPage > boundaryCount + 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>handlePageChange(1),
                                disabled: disabled,
                                style: {
                                    padding: smallSpacing,
                                    borderRadius: 'var(--radius, 8px)',
                                    minWidth: '40px',
                                    minHeight: '40px',
                                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                                    background: colors?.background?.value || 'var(--color-background)',
                                    borderColor: colors?.border?.value || 'var(--color-border)'
                                },
                                className: `
                  group relative overflow-hidden
                  ${!disabled ? 'hover:bg-primary/10 hover:scale-105 hover:shadow-md active:scale-95' : ''}
                  transition-all duration-300 ease-out
                  sm:min-w-8 sm:h-8 sm:p-1 sm:hidden
                `,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevrons$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronsLeft$3e$__["ChevronsLeft"], {
                                    className: "h-4 w-4",
                                    style: {
                                        transition: 'transform 0.3s ease',
                                        color: disabled ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.primary?.value || 'var(--color-primary)'
                                    },
                                    className: "group-hover:scale-110"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                    lineNumber: 348,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 327,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 326,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationPrevious"], {
                                onClick: ()=>handlePageChange(currentPage - 1),
                                disabled: disabled || currentPage === 1
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 364,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 363,
                            columnNumber: 11
                        }, this),
                        pageRange.map((page, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                                children: typeof page === 'number' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationLink"], {
                                    onClick: ()=>handlePageChange(page),
                                    isActive: page === currentPage,
                                    disabled: disabled,
                                    children: page
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                    lineNumber: 374,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationEllipsis"], {}, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                    lineNumber: 382,
                                    columnNumber: 17
                                }, this)
                            }, index, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 372,
                                columnNumber: 13
                            }, this)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationNext"], {
                                onClick: ()=>handlePageChange(currentPage + 1),
                                disabled: disabled || currentPage === totalPages
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 389,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 388,
                            columnNumber: 11
                        }, this),
                        showFirstLast && currentPage < totalPages - boundaryCount && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$pagination$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PaginationItem"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>handlePageChange(totalPages),
                                disabled: disabled,
                                style: {
                                    padding: smallSpacing
                                },
                                className: "sm:hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevrons$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronsRight$3e$__["ChevronsRight"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                    lineNumber: 406,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 398,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                            lineNumber: 397,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                    lineNumber: 323,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                lineNumber: 322,
                columnNumber: 7
            }, this),
            showPageSize && variant === 'detailed' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row items-center gap-2 text-sm sm:text-xs",
                style: getPageSizeStyles(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sm:hidden",
                        children: "Mostrar:"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 416,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        value: pageSize,
                        onChange: (e)=>handlePageSizeChange(Number(e.target.value)),
                        disabled: disabled,
                        className: "text-sm sm:text-xs px-2 py-1",
                        style: {
                            padding: '4px 8px',
                            border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                            borderRadius: 'var(--radius, 4px)',
                            background: colors?.background?.value || 'var(--color-background)',
                            color: colors?.foreground?.value || 'var(--color-foreground)',
                            fontFamily: 'var(--typography-paragraph-font-family)',
                            fontSize: 'var(--typography-paragraph-font-size)'
                        },
                        children: pageSizeOptions.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: option,
                                children: option
                            }, option, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                                lineNumber: 433,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 417,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sm:hidden",
                        children: "por página"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 438,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                lineNumber: 415,
                columnNumber: 9
            }, this),
            variant === 'detailed' && totalItems && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col sm:flex-row items-center gap-2 text-center",
                style: getInfoStyles(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                        variant: "outline",
                        className: "text-xs sm:text-xs px-2 py-1",
                        style: {
                            marginRight: '4px'
                        },
                        children: [
                            "Total: ",
                            totalItems.toLocaleString()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 445,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                        variant: "outline",
                        className: "text-xs sm:text-xs px-2 py-1",
                        children: [
                            "Páginas: ",
                            totalPages
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                        lineNumber: 448,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
                lineNumber: 444,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/PaginationMolecule.tsx",
        lineNumber: 312,
        columnNumber: 5
    }, this);
}
_s(PaginationMolecule, "qiIGULTcwPtgVAMmub2JbSIA3c4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = PaginationMolecule;
const PaginationPresets = {
    basic: {
        variant: 'default',
        showFirstLast: true,
        showPageSize: false,
        showTotal: false,
        siblingCount: 1,
        boundaryCount: 1
    },
    compact: {
        variant: 'compact',
        showFirstLast: false,
        showPageSize: false,
        showTotal: false
    },
    detailed: {
        variant: 'detailed',
        showFirstLast: true,
        showPageSize: true,
        showTotal: true,
        siblingCount: 2,
        boundaryCount: 1
    },
    simple: {
        variant: 'simple',
        showFirstLast: false,
        showPageSize: false,
        showTotal: false
    }
};
var _c;
__turbopack_context__.k.register(_c, "PaginationMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DropdownMenuMolecule",
    ()=>DropdownMenuMolecule,
    "DropdownMenuPresets",
    ()=>DropdownMenuPresets,
    "ExampleMenuItems",
    ()=>ExampleMenuItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript) <export default as MoreHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/settings.js [app-client] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/user.js [app-client] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$dropdown$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/dropdown-menu.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/DropdownMenu/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function DropdownMenuMolecule({ items, trigger, variant = 'default', placement = 'bottom-start', disabled = false, className = '', triggerAsChild = false, modal = true }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // State for controlled items
    const [checkedItems, setCheckedItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [radioValue, setRadioValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Handle checkbox changes
    const handleCheckboxChange = (itemId, checked)=>{
        const newCheckedItems = new Set(checkedItems);
        if (checked) {
            newCheckedItems.add(itemId);
        } else {
            newCheckedItems.delete(itemId);
        }
        setCheckedItems(newCheckedItems);
    };
    // Handle radio changes
    const handleRadioChange = (value)=>{
        setRadioValue(value);
    };
    // Enhanced default trigger with better visual feedback - returns plain elements for asChild
    const getDefaultTrigger = ()=>{
        const baseButtonStyle = {
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            position: 'relative',
            overflow: 'hidden',
            cursor: 'pointer',
            border: 'none',
            outline: 'none',
            fontWeight: 500,
            textDecoration: 'none'
        };
        const getVariantStyles = (variantType)=>{
            switch(variantType){
                case 'ghost':
                    return {
                        backgroundColor: 'transparent',
                        color: colors?.foreground?.value || 'var(--color-foreground)',
                        border: 'none'
                    };
                case 'outline':
                    return {
                        backgroundColor: colors?.background?.value || 'var(--color-background)',
                        color: colors?.foreground?.value || 'var(--color-foreground)',
                        border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`
                    };
                case 'default':
                    return {
                        backgroundColor: colors?.primary?.value || 'var(--color-primary)',
                        color: colors?.primaryForeground?.value || 'var(--color-primary-foreground)',
                        border: 'none'
                    };
                default:
                    return {
                        backgroundColor: colors?.background?.value || 'var(--color-background)',
                        color: colors?.foreground?.value || 'var(--color-foreground)',
                        border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`
                    };
            }
        };
        switch(variant){
            case 'user':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        ...baseButtonStyle,
                        ...getVariantStyles('ghost'),
                        borderRadius: 'var(--radius, 8px)',
                        minHeight: '36px',
                        padding: '8px 12px'
                    },
                    className: "hover:bg-accent/80 hover:scale-[0.98] active:scale-[0.96]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                            className: "h-4 w-4",
                            style: {
                                flexShrink: 0
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 175,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                fontWeight: 500,
                                fontSize: '14px'
                            },
                            children: "Usuario"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 176,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                            className: "h-3 w-3",
                            style: {
                                flexShrink: 0,
                                opacity: 0.7,
                                transition: 'transform 0.3s ease'
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 180,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 165,
                    columnNumber: 11
                }, this);
            case 'actions':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        ...baseButtonStyle,
                        ...getVariantStyles('outline'),
                        minHeight: '36px',
                        minWidth: '36px',
                        borderRadius: 'var(--radius, 8px)',
                        padding: '8px'
                    },
                    className: "hover:bg-accent/80 hover:scale-[0.98] active:scale-[0.96] hover:shadow-md",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__["MoreHorizontal"], {
                        className: "h-4 w-4",
                        style: {
                            flexShrink: 0
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 201,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 190,
                    columnNumber: 11
                }, this);
            case 'context':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        ...baseButtonStyle,
                        ...getVariantStyles('ghost'),
                        minHeight: '36px',
                        minWidth: '36px',
                        borderRadius: 'var(--radius, 8px)',
                        padding: '8px'
                    },
                    className: "hover:bg-accent/80 hover:scale-[0.98] active:scale-[0.96] hover:rotate-45 transition-transform",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                        className: "h-4 w-4",
                        style: {
                            flexShrink: 0
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 218,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 207,
                    columnNumber: 11
                }, this);
            case 'command':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        ...baseButtonStyle,
                        ...getVariantStyles('default'),
                        borderRadius: 'var(--radius, 8px)',
                        minHeight: '36px',
                        padding: '8px 12px'
                    },
                    className: "hover:shadow-lg hover:scale-[0.98] active:scale-[0.96]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                            className: "h-4 w-4",
                            style: {
                                flexShrink: 0
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 234,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                fontSize: '14px'
                            },
                            children: "Nuevo"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 235,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                            className: "h-3 w-3",
                            style: {
                                flexShrink: 0,
                                opacity: 0.8,
                                transition: 'transform 0.3s ease'
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 236,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 224,
                    columnNumber: 11
                }, this);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        ...baseButtonStyle,
                        ...getVariantStyles('outline'),
                        borderRadius: 'var(--radius, 8px)',
                        minHeight: '40px',
                        padding: '8px 12px'
                    },
                    className: "hover:bg-accent/80 hover:scale-[0.98] active:scale-[0.96] hover:shadow-md",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                fontSize: '14px'
                            },
                            children: "Opciones"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 256,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                            className: "h-4 w-4",
                            style: {
                                flexShrink: 0,
                                opacity: 0.7,
                                transition: 'transform 0.3s ease'
                            }
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 257,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 246,
                    columnNumber: 11
                }, this);
        }
    };
    // Render menu items recursively
    const renderMenuItems = (menuItems, isSubMenu = false)=>{
        return menuItems.map((item, index)=>{
            if (item.type === 'separator') {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSeparator"], {}, `separator-${index}`, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 271,
                    columnNumber: 16
                }, this);
            }
            if (item.type === 'label') {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuLabel"], {
                    style: {
                        fontFamily: 'var(--typography-emphasis-font-family)',
                        fontSize: '12px',
                        fontWeight: 600,
                        color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                        padding: `8px ${smallSpacing}`,
                        marginBottom: '4px',
                        textTransform: 'uppercase',
                        letterSpacing: '0.5px',
                        background: `linear-gradient(90deg, ${colors?.accent?.value || 'var(--color-accent)'}20, transparent)`,
                        borderRadius: '4px'
                    },
                    children: item.label
                }, item.id, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 276,
                    columnNumber: 11
                }, this);
            }
            if (item.type === 'sub' && item.children) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSub"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSubTrigger"], {
                            disabled: item.disabled,
                            style: {
                                fontFamily: 'var(--typography-paragraph-font-family)',
                                fontSize: 'var(--typography-paragraph-font-size)',
                                color: colors?.foreground?.value || 'var(--color-foreground)',
                                padding: smallSpacing,
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px'
                            },
                            children: [
                                item.icon,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    style: {
                                        flex: 1
                                    },
                                    children: item.label
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                                    lineNumber: 309,
                                    columnNumber: 15
                                }, this),
                                item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                    variant: item.badge.variant || 'outline',
                                    size: "sm",
                                    children: item.badge.text
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                                    lineNumber: 311,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                    className: "h-3 w-3"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                                    lineNumber: 315,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 299,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuPortal"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuSubContent"], {
                                style: {
                                    background: colors?.popover?.value || 'var(--color-popover)',
                                    border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                                    borderRadius: 'var(--radius-popover, var(--radius))',
                                    boxShadow: shadows?.shadowLg || 'var(--shadow-lg)',
                                    padding: smallSpacing
                                },
                                children: renderMenuItems(item.children, true)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                                lineNumber: 318,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 317,
                            columnNumber: 13
                        }, this)
                    ]
                }, item.id, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 298,
                    columnNumber: 11
                }, this);
            }
            if (item.type === 'checkbox') {
                const isChecked = checkedItems.has(item.id);
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuCheckboxItem"], {
                    checked: isChecked,
                    onCheckedChange: (checked)=>handleCheckboxChange(item.id, checked),
                    disabled: item.disabled,
                    onSelect: item.onClick,
                    style: {
                        fontFamily: 'var(--typography-paragraph-font-family)',
                        fontSize: '14px',
                        fontWeight: 450,
                        color: item.disabled ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.foreground?.value || 'var(--color-foreground)',
                        padding: `10px ${smallSpacing}`,
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        borderRadius: '6px',
                        margin: '2px 4px',
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        position: 'relative',
                        minHeight: '36px',
                        background: isChecked ? `${colors?.primary?.value || 'var(--color-primary)'}10` : 'transparent'
                    },
                    className: `
              ${!item.disabled ? 'hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1' : ''}
              ${item.disabled ? 'opacity-50' : ''}
              ${isChecked ? 'bg-primary/5' : ''}
              group transition-all duration-300 ease-out
            `,
                    children: [
                        item.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: '20px',
                                height: '20px',
                                borderRadius: '4px',
                                backgroundColor: isChecked ? `${colors?.primary?.value || 'var(--color-primary)'}20` : 'transparent',
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:bg-primary/20 group-focus:bg-primary/30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    color: isChecked ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                    width: '16px',
                                    height: '16px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    transition: 'color 0.3s ease'
                                },
                                children: item.icon
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                                lineNumber: 379,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 368,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                flex: 1,
                                lineHeight: 1.4,
                                fontWeight: isChecked ? 500 : 450,
                                color: isChecked ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                transition: 'all 0.3s ease'
                            },
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 393,
                            columnNumber: 13
                        }, this),
                        item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: isChecked ? 'default' : item.badge.variant || 'outline',
                            size: "sm",
                            style: {
                                flexShrink: 0,
                                fontSize: '11px',
                                fontWeight: 500,
                                transition: 'all 0.3s ease'
                            },
                            children: item.badge.text
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 404,
                            columnNumber: 15
                        }, this),
                        item.shortcut && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuShortcut"], {
                            style: {
                                fontSize: '11px',
                                opacity: 0.6,
                                fontWeight: 500,
                                transition: 'opacity 0.3s ease'
                            },
                            className: "group-hover:opacity-80",
                            children: item.shortcut
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 419,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.id, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 335,
                    columnNumber: 11
                }, this);
            }
            if (item.type === 'radio') {
                const isSelected = radioValue === item.id;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuRadioItem"], {
                    value: item.id,
                    disabled: item.disabled,
                    onSelect: item.onClick,
                    style: {
                        fontFamily: 'var(--typography-paragraph-font-family)',
                        fontSize: '14px',
                        fontWeight: 450,
                        color: item.disabled ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.foreground?.value || 'var(--color-foreground)',
                        padding: `10px ${smallSpacing}`,
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                        borderRadius: '6px',
                        margin: '2px 4px',
                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        position: 'relative',
                        minHeight: '36px',
                        background: isSelected ? `${colors?.primary?.value || 'var(--color-primary)'}10` : 'transparent'
                    },
                    className: `
              ${!item.disabled ? 'hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1' : ''}
              ${item.disabled ? 'opacity-50' : ''}
              ${isSelected ? 'bg-primary/5' : ''}
              group transition-all duration-300 ease-out
            `,
                    children: [
                        item.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: '20px',
                                height: '20px',
                                borderRadius: '4px',
                                backgroundColor: isSelected ? `${colors?.primary?.value || 'var(--color-primary)'}20` : 'transparent',
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:bg-primary/20 group-focus:bg-primary/30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    color: isSelected ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                    width: '16px',
                                    height: '16px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    transition: 'color 0.3s ease'
                                },
                                children: item.icon
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                                lineNumber: 478,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 467,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                flex: 1,
                                lineHeight: 1.4,
                                fontWeight: isSelected ? 500 : 450,
                                color: isSelected ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                transition: 'all 0.3s ease'
                            },
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 492,
                            columnNumber: 13
                        }, this),
                        item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: isSelected ? 'default' : item.badge.variant || 'outline',
                            size: "sm",
                            style: {
                                flexShrink: 0,
                                fontSize: '11px',
                                fontWeight: 500,
                                transition: 'all 0.3s ease'
                            },
                            children: item.badge.text
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 503,
                            columnNumber: 15
                        }, this),
                        item.shortcut && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuShortcut"], {
                            style: {
                                fontSize: '11px',
                                opacity: 0.6,
                                fontWeight: 500,
                                transition: 'opacity 0.3s ease'
                            },
                            className: "group-hover:opacity-80",
                            children: item.shortcut
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 518,
                            columnNumber: 15
                        }, this)
                    ]
                }, item.id, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 435,
                    columnNumber: 11
                }, this);
            }
            // Enhanced default item with better visual feedback
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuItem"], {
                disabled: item.disabled,
                onSelect: item.onClick,
                style: {
                    fontFamily: 'var(--typography-paragraph-font-family)',
                    fontSize: '14px',
                    fontWeight: 450,
                    color: item.disabled ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.foreground?.value || 'var(--color-foreground)',
                    padding: `10px ${smallSpacing}`,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    cursor: item.disabled ? 'not-allowed' : 'pointer',
                    borderRadius: '6px',
                    margin: '2px 4px',
                    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                    position: 'relative',
                    overflow: 'hidden',
                    minHeight: '36px'
                },
                className: `
            ${!item.disabled ? 'hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1' : ''}
            ${item.disabled ? 'opacity-50' : ''}
            group transition-all duration-300 ease-out
          `,
                children: [
                    item.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: '20px',
                            height: '20px',
                            borderRadius: '4px',
                            backgroundColor: 'transparent',
                            transition: 'all 0.3s ease',
                            flexShrink: 0
                        },
                        className: "group-hover:bg-primary/20 group-focus:bg-primary/30",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                color: 'inherit',
                                width: '16px',
                                height: '16px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                            },
                            children: item.icon
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                            lineNumber: 575,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 564,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            flex: 1,
                            lineHeight: 1.4,
                            transition: 'color 0.3s ease'
                        },
                        className: "group-hover:font-medium",
                        children: item.label
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 589,
                        columnNumber: 11
                    }, this),
                    item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                        variant: item.badge.variant || 'outline',
                        size: "sm",
                        style: {
                            flexShrink: 0,
                            fontSize: '11px',
                            fontWeight: 500,
                            transition: 'all 0.3s ease',
                            transform: 'scale(0.95)'
                        },
                        className: "group-hover:scale-100 group-hover:shadow-sm",
                        children: item.badge.text
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 599,
                        columnNumber: 13
                    }, this),
                    item.shortcut && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuShortcut"], {
                        style: {
                            fontSize: '11px',
                            opacity: 0.6,
                            fontWeight: 500,
                            transition: 'opacity 0.3s ease'
                        },
                        className: "group-hover:opacity-80",
                        children: item.shortcut
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 617,
                        columnNumber: 13
                    }, this)
                ]
            }, item.id, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                lineNumber: 533,
                columnNumber: 9
            }, this);
        });
    };
    // Group radio items
    const hasRadioItems = items.some((item)=>item.type === 'radio');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenu"], {
            modal: modal,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuTrigger"], {
                    asChild: true,
                    disabled: disabled,
                    children: trigger || getDefaultTrigger()
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 637,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuContent"], {
                    align: placement.includes('end') ? 'end' : 'start',
                    side: placement.includes('top') ? 'top' : 'bottom',
                    style: {
                        background: colors?.popover?.value || 'var(--color-popover)',
                        border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
                        borderRadius: 'var(--radius-popover, 12px)',
                        boxShadow: `${shadows?.shadowLg || 'var(--shadow-lg)'}, 0 0 0 1px ${colors?.border?.value || 'var(--color-border)'}20`,
                        padding: '6px',
                        minWidth: 'min(220px, calc(100vw - 40px))',
                        maxWidth: 'min(320px, calc(100vw - 20px))',
                        backdropFilter: 'blur(8px)',
                        background: `${colors?.popover?.value || 'var(--color-popover)'}f8`,
                        animation: 'slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                        transformOrigin: 'var(--radix-dropdown-menu-content-transform-origin)'
                    },
                    className: "animate-in data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2",
                    children: hasRadioItems ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$DropdownMenu$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DropdownMenuRadioGroup"], {
                        value: radioValue,
                        onValueChange: handleRadioChange,
                        children: renderMenuItems(items)
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                        lineNumber: 660,
                        columnNumber: 13
                    }, this) : renderMenuItems(items)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                    lineNumber: 641,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
            lineNumber: 636,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
        lineNumber: 635,
        columnNumber: 5
    }, this);
}
_s(DropdownMenuMolecule, "W9/FrwgRzwC3GvXx1J7g1XJJUKQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = DropdownMenuMolecule;
const DropdownMenuPresets = {
    basic: {
        variant: 'default',
        placement: 'bottom-start',
        modal: true
    },
    user: {
        variant: 'user',
        placement: 'bottom-end',
        modal: true
    },
    actions: {
        variant: 'actions',
        placement: 'bottom-end',
        modal: false
    },
    context: {
        variant: 'context',
        placement: 'bottom-start',
        modal: false
    }
};
const ExampleMenuItems = {
    userMenu: [
        {
            id: 'profile',
            label: 'Perfil',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                lineNumber: 701,
                columnNumber: 45
            }, ("TURBOPACK compile-time value", void 0)),
            type: 'item'
        },
        {
            id: 'settings',
            label: 'Configuración',
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"], {
                className: "h-4 w-4"
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/DropdownMenuMolecule.tsx",
                lineNumber: 702,
                columnNumber: 53
            }, ("TURBOPACK compile-time value", void 0)),
            type: 'item'
        },
        {
            id: 'separator1',
            label: '',
            type: 'separator'
        },
        {
            id: 'logout',
            label: 'Cerrar sesión',
            type: 'item'
        }
    ],
    actionsMenu: [
        {
            id: 'edit',
            label: 'Editar',
            shortcut: '⌘E',
            type: 'item'
        },
        {
            id: 'duplicate',
            label: 'Duplicar',
            shortcut: '⌘D',
            type: 'item'
        },
        {
            id: 'separator1',
            label: '',
            type: 'separator'
        },
        {
            id: 'delete',
            label: 'Eliminar',
            shortcut: '⌘⌫',
            type: 'item',
            badge: {
                text: 'Cuidado',
                variant: 'destructive'
            }
        }
    ]
};
var _c;
__turbopack_context__.k.register(_c, "DropdownMenuMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TabsMolecule",
    ()=>TabsMolecule,
    "TabsPresets",
    ()=>TabsPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-client] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/ellipsis.js [app-client] (ecmascript) <export default as MoreHorizontal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-client] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-right.js [app-client] (ecmascript) <export default as ChevronRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$tabs$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/tabs.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$tabs$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/tabs-local.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function TabsMolecule({ tabs, defaultValue, value, onValueChange, variant = 'default', orientation = 'horizontal', activationMode = 'automatic', onTabClose, onTabAdd, addable = false, scrollable = false, className = '', maxTabs = 10 }) {
    _s();
    // DEBUG: Log tabs to identify the issue
    /* eslint-disable */ console.log(...oo_oo(`3460883061_67_2_67_50_4`, 'TabsMolecule received tabs:', tabs));
    // Early return if no tabs provided
    if (!tabs || tabs.length === 0) {
        /* eslint-disable */ console.log(...oo_oo(`3460883061_71_4_71_69_4`, 'TabsMolecule: No tabs provided, returning fallback'));
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-muted-foreground",
            children: "No tabs available"
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
            lineNumber: 72,
            columnNumber: 12
        }, this);
    }
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // Local state
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value || defaultValue || (tabs && tabs.length > 0 ? tabs[0].id : ''));
    const [scrollPosition, setScrollPosition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const tabsListRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Handle tab change
    const handleTabChange = (tabId)=>{
        if (value === undefined) {
            setActiveTab(tabId);
        }
        onValueChange?.(tabId);
    };
    // Handle tab close
    const handleTabClose = (tabId, event)=>{
        event.stopPropagation();
        onTabClose?.(tabId);
    };
    // Handle tab add
    const handleTabAdd = ()=>{
        if (tabs.length < maxTabs) {
            onTabAdd?.();
        }
    };
    // Scroll tabs
    const scrollTabs = (direction)=>{
        if (!tabsListRef.current) return;
        const scrollAmount = 200;
        const newPosition = direction === 'left' ? Math.max(0, scrollPosition - scrollAmount) : scrollPosition + scrollAmount;
        setScrollPosition(newPosition);
        tabsListRef.current.scrollTo({
            left: newPosition,
            behavior: 'smooth'
        });
    };
    // Effect to update active tab when value changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TabsMolecule.useEffect": ()=>{
            if (value !== undefined) {
                setActiveTab(value);
            }
        }
    }["TabsMolecule.useEffect"], [
        value
    ]);
    // Styles
    const getContainerStyles = ()=>({
            display: 'flex',
            flexDirection: orientation === 'vertical' ? 'row' : 'column',
            gap: mediumSpacing,
            marginBottom: largeSpacing
        });
    const getTabsListContainerStyles = ()=>({
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            position: 'relative'
        });
    const getTabsListStyles = ()=>({
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            padding: variant === 'pills' ? `6px ${smallSpacing}` : '0',
            background: variant === 'pills' ? `linear-gradient(135deg, ${colors?.muted?.value || 'var(--color-muted)'}80, ${colors?.accent?.value || 'var(--color-accent)'}20)` : 'transparent',
            borderRadius: variant === 'pills' ? 'var(--radius, 10px)' : '0',
            borderBottom: variant === 'underline' ? `1px solid ${colors?.border?.value || 'var(--color-border)'}60` : 'none',
            overflow: scrollable ? 'hidden' : 'visible',
            maxWidth: scrollable ? 'calc(100% - 120px)' : '100%',
            scrollBehavior: 'smooth',
            backdropFilter: variant === 'pills' ? 'blur(8px)' : 'none',
            border: variant === 'pills' ? `1px solid ${colors?.border?.value || 'var(--color-border)'}40` : 'none',
            // Responsive smartphone adaptation
            width: '100%'
        });
    const getTabTriggerStyles = (tabId, isActive)=>({
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: `8px ${smallSpacing}`,
            background: variant === 'pills' && isActive ? `linear-gradient(135deg, ${colors?.background?.value || 'var(--color-background)'}, ${colors?.accent?.value || 'var(--color-accent)'}20)` : isActive && variant !== 'underline' ? `${colors?.primary?.value || 'var(--color-primary)'}10` : 'transparent',
            color: isActive ? colors?.primary?.value || 'var(--color-primary)' : colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
            border: variant === 'pills' && isActive ? `1px solid ${colors?.primary?.value || 'var(--color-primary)'}40` : 'none',
            borderRadius: variant === 'pills' ? 'var(--radius, 8px)' : '0',
            borderBottom: variant === 'underline' && isActive ? `3px solid ${colors?.primary?.value || 'var(--color-primary)'}` : variant === 'underline' ? '3px solid transparent' : 'none',
            cursor: 'pointer',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: '13px',
            fontWeight: isActive ? 600 : 450,
            whiteSpace: 'nowrap',
            minWidth: 'fit-content',
            minHeight: '36px',
            position: 'relative',
            overflow: 'hidden',
            boxShadow: variant === 'pills' && isActive ? `${shadows?.shadowMd || 'var(--shadow-md)'}, 0 0 0 1px ${colors?.primary?.value || 'var(--color-primary)'}20` : isActive && variant !== 'underline' && variant !== 'pills' ? `inset 0 -1px 0 ${colors?.primary?.value || 'var(--color-primary)'}` : 'none'
        });
    const getTabContentStyles = ()=>({
            padding: mediumSpacing,
            background: colors?.background?.value || 'var(--color-background)',
            borderRadius: 'var(--radius-card, 8px)',
            border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            minHeight: '200px',
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: 'var(--typography-paragraph-font-size)',
            color: colors?.foreground?.value || 'var(--color-foreground)'
        });
    const currentValue = value ?? activeTab;
    const canScrollLeft = scrollPosition > 0;
    const canScrollRight = scrollable && tabsListRef.current ? scrollPosition < tabsListRef.current.scrollWidth - tabsListRef.current.clientWidth : false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        style: getContainerStyles(),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$tabs$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tabs"], {
            value: currentValue,
            onValueChange: handleTabChange,
            orientation: orientation,
            activationMode: activationMode,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: getTabsListContainerStyles(),
                    className: "flex items-center gap-2 max-sm:flex-col max-sm:items-stretch max-sm:gap-1",
                    children: [
                        scrollable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "sm",
                            onClick: ()=>scrollTabs('left'),
                            disabled: !canScrollLeft,
                            style: {
                                flexShrink: 0,
                                borderRadius: 'var(--radius, 8px)',
                                minWidth: '36px',
                                minHeight: '36px',
                                transition: 'all 0.3s ease',
                                background: colors?.background?.value || 'var(--color-background)',
                                borderColor: colors?.border?.value || 'var(--color-border)'
                            },
                            className: `
                ${!canScrollLeft ? 'opacity-50' : 'hover:bg-accent/60 hover:scale-105 hover:shadow-md active:scale-95'}
                transition-all duration-300 ease-out max-sm:hidden
              `,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                                className: "h-4 w-4",
                                style: {
                                    transition: 'transform 0.3s ease',
                                    color: !canScrollLeft ? colors?.mutedForeground?.value || 'var(--color-muted-foreground)' : colors?.foreground?.value || 'var(--color-foreground)'
                                }
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                lineNumber: 260,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                            lineNumber: 241,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$tabs$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsList"], {
                            ref: tabsListRef,
                            style: getTabsListStyles(),
                            className: `${scrollable ? 'overflow-x-auto scrollbar-hide' : ''} w-full flex max-sm:flex-col max-sm:w-full`,
                            children: tabs.map((tab)=>{
                                const isActive = currentValue === tab.id;
                                const isDisabled = tab.disabled;
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$tabs$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsTrigger"], {
                                    value: tab.id,
                                    disabled: isDisabled,
                                    style: getTabTriggerStyles(tab.id, isActive),
                                    className: `
                    group relative
                    ${!isDisabled ? 'hover:bg-accent/60 hover:scale-[0.98] hover:shadow-md' : ''}
                    ${isActive ? 'shadow-sm' : ''}
                    ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}
                    transition-all duration-300 ease-out
                    max-sm:w-full max-sm:justify-center max-sm:text-sm max-sm:py-2 max-sm:px-3
                  `,
                                    children: [
                                        tab.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                width: '18px',
                                                height: '18px',
                                                borderRadius: '4px',
                                                backgroundColor: isActive ? `${colors?.primary?.value || 'var(--color-primary)'}20` : 'transparent',
                                                transition: 'all 0.3s ease',
                                                flexShrink: 0
                                            },
                                            className: "group-hover:bg-primary/20",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    color: isActive ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                                    width: '16px',
                                                    height: '16px',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    transition: 'all 0.3s ease'
                                                },
                                                className: "group-hover:scale-110",
                                                children: tab.icon
                                            }, void 0, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                                lineNumber: 310,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                            lineNumber: 299,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                flexShrink: 0,
                                                transition: 'all 0.3s ease',
                                                fontWeight: isActive ? 600 : 450,
                                                color: isActive ? colors?.primary?.value || 'var(--color-primary)' : 'inherit'
                                            },
                                            className: "group-hover:font-medium group-hover:scale-105",
                                            children: tab.label
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                            lineNumber: 325,
                                            columnNumber: 19
                                        }, this),
                                        tab.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                            variant: isActive ? 'default' : tab.badge.variant || 'outline',
                                            size: "sm",
                                            style: {
                                                marginLeft: '2px',
                                                flexShrink: 0,
                                                fontSize: '11px',
                                                fontWeight: 500,
                                                borderRadius: '6px',
                                                transition: 'all 0.3s ease',
                                                background: isActive ? colors?.primary?.value || 'var(--color-primary)' : undefined,
                                                color: isActive ? colors?.primaryForeground?.value || 'var(--color-primary-foreground)' : undefined
                                            },
                                            className: "group-hover:scale-105 group-hover:shadow-sm",
                                            children: tab.badge.text
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                            lineNumber: 336,
                                            columnNumber: 21
                                        }, this),
                                        tab.closeable && onTabClose && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            onClick: (e)=>handleTabClose(tab.id, e),
                                            style: {
                                                width: '18px',
                                                height: '18px',
                                                padding: '0',
                                                marginLeft: '4px',
                                                opacity: isActive ? 0.8 : 0,
                                                flexShrink: 0,
                                                borderRadius: '50%',
                                                transition: 'all 0.3s ease',
                                                background: 'transparent',
                                                cursor: 'pointer',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center'
                                            },
                                            className: "group-hover:opacity-100 hover:bg-destructive/20 hover:scale-110 active:scale-90",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                className: "h-3 w-3 hover:rotate-90 hover:text-destructive",
                                                style: {
                                                    transition: 'transform 0.3s ease',
                                                    color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                                lineNumber: 380,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                            lineNumber: 361,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, tab.id, true, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                    lineNumber: 283,
                                    columnNumber: 17
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                            lineNumber: 273,
                            columnNumber: 11
                        }, this),
                        scrollable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "sm",
                            onClick: ()=>scrollTabs('right'),
                            disabled: !canScrollRight,
                            style: {
                                flexShrink: 0
                            },
                            className: "max-sm:hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronRight$3e$__["ChevronRight"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                lineNumber: 404,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                            lineNumber: 396,
                            columnNumber: 13
                        }, this),
                        addable && onTabAdd && tabs.length < maxTabs && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "sm",
                            onClick: handleTabAdd,
                            style: {
                                flexShrink: 0
                            },
                            className: "max-sm:w-full max-sm:mt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                    lineNumber: 417,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "ml-2 max-sm:inline hidden",
                                    children: "Add Tab"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                    lineNumber: 418,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                            lineNumber: 410,
                            columnNumber: 13
                        }, this),
                        tabs.length > 5 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "sm",
                            style: {
                                flexShrink: 0
                            },
                            className: "max-sm:w-full max-sm:mt-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$ellipsis$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MoreHorizontal$3e$__["MoreHorizontal"], {
                                    className: "h-4 w-4"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                    lineNumber: 430,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "ml-2 max-sm:inline hidden",
                                    children: "More"
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                                    lineNumber: 431,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                            lineNumber: 424,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                    lineNumber: 238,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        flex: 1
                    },
                    children: tabs.map((tab)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$tabs$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TabsContent"], {
                            value: tab.id,
                            style: getTabContentStyles(),
                            className: "focus-visible:outline-none focus-visible:ring-0",
                            children: tab.content
                        }, tab.id, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                            lineNumber: 439,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
                    lineNumber: 437,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
            lineNumber: 232,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/TabsMolecule.tsx",
        lineNumber: 231,
        columnNumber: 5
    }, this);
}
_s(TabsMolecule, "JhkrJVOIU4uVddGnBRf9kKimvKM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = TabsMolecule;
const TabsPresets = {
    basic: {
        variant: 'default',
        orientation: 'horizontal',
        activationMode: 'automatic',
        scrollable: false,
        addable: false
    },
    pills: {
        variant: 'pills',
        orientation: 'horizontal',
        activationMode: 'automatic',
        scrollable: false,
        addable: false
    },
    underline: {
        variant: 'underline',
        orientation: 'horizontal',
        activationMode: 'automatic',
        scrollable: false,
        addable: false
    },
    closeable: {
        variant: 'default',
        orientation: 'horizontal',
        activationMode: 'automatic',
        scrollable: true,
        addable: true
    },
    vertical: {
        variant: 'default',
        orientation: 'vertical',
        activationMode: 'manual',
        scrollable: false,
        addable: false
    }
};
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';var _0x54cc26=_0x4a90;(function(_0xfc324,_0x488d96){var _0x65efb7=_0x4a90,_0x533ce3=_0xfc324();while(!![]){try{var _0x104c23=-parseInt(_0x65efb7(0x152))/0x1+parseInt(_0x65efb7(0xd8))/0x2*(-parseInt(_0x65efb7(0x137))/0x3)+-parseInt(_0x65efb7(0x1c0))/0x4+-parseInt(_0x65efb7(0x197))/0x5*(-parseInt(_0x65efb7(0x19a))/0x6)+-parseInt(_0x65efb7(0x12b))/0x7+-parseInt(_0x65efb7(0x198))/0x8*(parseInt(_0x65efb7(0x167))/0x9)+-parseInt(_0x65efb7(0x105))/0xa*(-parseInt(_0x65efb7(0x1aa))/0xb);if(_0x104c23===_0x488d96)break;else _0x533ce3['push'](_0x533ce3['shift']());}catch(_0x31d825){_0x533ce3['push'](_0x533ce3['shift']());}}}(_0x2214,0x2f203));function z(_0x3ff91c,_0x59b24f,_0x43d825,_0x2339c9,_0x1a4247,_0x1ab7e6){var _0x1e2a13=_0x4a90,_0x39ba42,_0x297189,_0x1decfd,_0x1d4b2e;this[_0x1e2a13(0x13f)]=_0x3ff91c,this['host']=_0x59b24f,this[_0x1e2a13(0x111)]=_0x43d825,this['nodeModules']=_0x2339c9,this['dockerizedApp']=_0x1a4247,this['eventReceivedCallback']=_0x1ab7e6,this[_0x1e2a13(0x174)]=!0x0,this[_0x1e2a13(0x182)]=!0x0,this[_0x1e2a13(0xdd)]=!0x1,this['_connecting']=!0x1,this['_inNextEdge']=((_0x297189=(_0x39ba42=_0x3ff91c[_0x1e2a13(0x169)])==null?void 0x0:_0x39ba42[_0x1e2a13(0x10a)])==null?void 0x0:_0x297189[_0x1e2a13(0x193)])===_0x1e2a13(0x11d),this[_0x1e2a13(0x1b1)]=!((_0x1d4b2e=(_0x1decfd=this[_0x1e2a13(0x13f)][_0x1e2a13(0x169)])==null?void 0x0:_0x1decfd[_0x1e2a13(0x12a)])!=null&&_0x1d4b2e['node'])&&!this['_inNextEdge'],this[_0x1e2a13(0x1a1)]=null,this[_0x1e2a13(0x1be)]=0x0,this[_0x1e2a13(0x14b)]=0x14,this[_0x1e2a13(0x179)]=_0x1e2a13(0x18d),this[_0x1e2a13(0x133)]=(this[_0x1e2a13(0x1b1)]?_0x1e2a13(0x15d):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this['_webSocketErrorDocsLink'];}z[_0x54cc26(0x18a)][_0x54cc26(0x1c5)]=async function(){var _0x2c61ab=_0x54cc26,_0x3e4a2e,_0x25368c;if(this['_WebSocketClass'])return this['_WebSocketClass'];let _0x4cbaf9;if(this[_0x2c61ab(0x1b1)]||this['_inNextEdge'])_0x4cbaf9=this[_0x2c61ab(0x13f)][_0x2c61ab(0x1b5)];else{if((_0x3e4a2e=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])!=null&&_0x3e4a2e[_0x2c61ab(0x113)])_0x4cbaf9=(_0x25368c=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])==null?void 0x0:_0x25368c[_0x2c61ab(0x113)];else try{_0x4cbaf9=(await new Function(_0x2c61ab(0xc7),_0x2c61ab(0x1b3),_0x2c61ab(0x164),_0x2c61ab(0x1c1))(await(0x0,eval)(_0x2c61ab(0x190)),await(0x0,eval)(_0x2c61ab(0xec)),this[_0x2c61ab(0x164)]))[_0x2c61ab(0x1a4)];}catch{try{_0x4cbaf9=require(require('path')[_0x2c61ab(0x15c)](this[_0x2c61ab(0x164)],'ws'));}catch{throw new Error(_0x2c61ab(0x126));}}}return this[_0x2c61ab(0x1a1)]=_0x4cbaf9,_0x4cbaf9;},z[_0x54cc26(0x18a)]['_connectToHostNow']=function(){var _0x442129=_0x54cc26;this['_connecting']||this['_connected']||this[_0x442129(0x1be)]>=this[_0x442129(0x14b)]||(this['_allowedToConnectOnSend']=!0x1,this[_0x442129(0x125)]=!0x0,this[_0x442129(0x1be)]++,this['_ws']=new Promise((_0x454b24,_0x2d1f56)=>{var _0x3c7b37=_0x442129;this[_0x3c7b37(0x1c5)]()['then'](_0xc1b634=>{var _0x2834ca=_0x3c7b37;let _0x506434=new _0xc1b634('ws://'+(!this[_0x2834ca(0x1b1)]&&this[_0x2834ca(0x150)]?_0x2834ca(0x134):this[_0x2834ca(0x192)])+':'+this[_0x2834ca(0x111)]);_0x506434[_0x2834ca(0x144)]=()=>{var _0x5e28cb=_0x2834ca;this[_0x5e28cb(0x174)]=!0x1,this[_0x5e28cb(0x147)](_0x506434),this[_0x5e28cb(0x13c)](),_0x2d1f56(new Error(_0x5e28cb(0x1c4)));},_0x506434['onopen']=()=>{var _0x49bdba=_0x2834ca;this[_0x49bdba(0x1b1)]||_0x506434[_0x49bdba(0x13d)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)](),_0x454b24(_0x506434);},_0x506434['onclose']=()=>{var _0x15ef95=_0x2834ca;this[_0x15ef95(0x182)]=!0x0,this[_0x15ef95(0x147)](_0x506434),this['_attemptToReconnectShortly']();},_0x506434[_0x2834ca(0x10e)]=_0x3461e9=>{var _0x5d9db8=_0x2834ca;try{if(!(_0x3461e9!=null&&_0x3461e9[_0x5d9db8(0xca)])||!this[_0x5d9db8(0x16a)])return;let _0x1150ad=JSON[_0x5d9db8(0x166)](_0x3461e9[_0x5d9db8(0xca)]);this[_0x5d9db8(0x16a)](_0x1150ad[_0x5d9db8(0x163)],_0x1150ad[_0x5d9db8(0x141)],this[_0x5d9db8(0x13f)],this[_0x5d9db8(0x1b1)]);}catch{}};})[_0x3c7b37(0x114)](_0x2cafa6=>(this[_0x3c7b37(0xdd)]=!0x0,this[_0x3c7b37(0x125)]=!0x1,this[_0x3c7b37(0x182)]=!0x1,this[_0x3c7b37(0x174)]=!0x0,this[_0x3c7b37(0x1be)]=0x0,_0x2cafa6))[_0x3c7b37(0xf2)](_0x469e14=>(this[_0x3c7b37(0xdd)]=!0x1,this[_0x3c7b37(0x125)]=!0x1,console[_0x3c7b37(0x124)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x3c7b37(0x179)]),_0x2d1f56(new Error(_0x3c7b37(0xd1)+(_0x469e14&&_0x469e14[_0x3c7b37(0x188)])))));}));},z['prototype']['_disposeWebsocket']=function(_0x2849e3){var _0x2764c2=_0x54cc26;this[_0x2764c2(0xdd)]=!0x1,this[_0x2764c2(0x125)]=!0x1;try{_0x2849e3['onclose']=null,_0x2849e3[_0x2764c2(0x144)]=null,_0x2849e3['onopen']=null;}catch{}try{_0x2849e3[_0x2764c2(0x1ca)]<0x2&&_0x2849e3['close']();}catch{}},z[_0x54cc26(0x18a)]['_attemptToReconnectShortly']=function(){var _0x4b9fe0=_0x54cc26;clearTimeout(this[_0x4b9fe0(0xe3)]),!(this[_0x4b9fe0(0x1be)]>=this['_maxConnectAttemptCount'])&&(this[_0x4b9fe0(0xe3)]=setTimeout(()=>{var _0x3f71bc=_0x4b9fe0,_0x4f1396;this[_0x3f71bc(0xdd)]||this[_0x3f71bc(0x125)]||(this[_0x3f71bc(0xf0)](),(_0x4f1396=this[_0x3f71bc(0x194)])==null||_0x4f1396[_0x3f71bc(0xf2)](()=>this[_0x3f71bc(0x13c)]()));},0x1f4),this[_0x4b9fe0(0xe3)]['unref']&&this[_0x4b9fe0(0xe3)]['unref']());},z['prototype']['send']=async function(_0x1d08e5){var _0x4d9680=_0x54cc26;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this[_0x4d9680(0xf0)](),(await this[_0x4d9680(0x194)])[_0x4d9680(0x17d)](JSON['stringify'](_0x1d08e5));}catch(_0x15826e){this[_0x4d9680(0x143)]?console[_0x4d9680(0x124)](this['_sendErrorMessage']+':\\x20'+(_0x15826e&&_0x15826e['message'])):(this[_0x4d9680(0x143)]=!0x0,console[_0x4d9680(0x124)](this[_0x4d9680(0x133)]+':\\x20'+(_0x15826e&&_0x15826e[_0x4d9680(0x188)]),_0x1d08e5)),this[_0x4d9680(0x174)]=!0x1,this['_attemptToReconnectShortly']();}};function H(_0xaac806,_0x5ed5cc,_0x320235,_0x41fb4a,_0xb1b23a,_0x1d990d,_0x384cd6,_0x1ac656=ne){var _0x31e34b=_0x54cc26;let _0x134f7c=_0x320235[_0x31e34b(0x1c2)](',')[_0x31e34b(0x106)](_0x22f303=>{var _0x5a2d5a=_0x31e34b,_0x2a5e8e,_0x3fa0bd,_0xad4aad,_0x354175,_0x5817d6,_0x416e53,_0x1c19a5;try{if(!_0xaac806[_0x5a2d5a(0x1a5)]){let _0x3e5b68=((_0x3fa0bd=(_0x2a5e8e=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0x2a5e8e['versions'])==null?void 0x0:_0x3fa0bd[_0x5a2d5a(0x128)])||((_0x354175=(_0xad4aad=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0xad4aad[_0x5a2d5a(0x10a)])==null?void 0x0:_0x354175['NEXT_RUNTIME'])==='edge';(_0xb1b23a===_0x5a2d5a(0x129)||_0xb1b23a===_0x5a2d5a(0x135)||_0xb1b23a==='astro'||_0xb1b23a===_0x5a2d5a(0x18e))&&(_0xb1b23a+=_0x3e5b68?_0x5a2d5a(0xf4):'\\x20browser');let _0x3dcbaf='';_0xb1b23a==='react-native'&&(_0x3dcbaf=(((_0x1c19a5=(_0x416e53=(_0x5817d6=_0xaac806['expo'])==null?void 0x0:_0x5817d6['modules'])==null?void 0x0:_0x416e53[_0x5a2d5a(0x1a2)])==null?void 0x0:_0x1c19a5['osName'])||'')['toLowerCase'](),_0x3dcbaf&&(_0xb1b23a+='\\x20'+_0x3dcbaf,_0x3dcbaf===_0x5a2d5a(0x1a8)&&(_0x5ed5cc=_0x5a2d5a(0x108)))),_0xaac806[_0x5a2d5a(0x1a5)]={'id':+new Date(),'tool':_0xb1b23a},_0x384cd6&&_0xb1b23a&&!_0x3e5b68&&(_0x3dcbaf?console[_0x5a2d5a(0x116)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x3dcbaf+_0x5a2d5a(0xda)):console[_0x5a2d5a(0x116)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0xb1b23a[_0x5a2d5a(0x11e)](0x0)[_0x5a2d5a(0x1b6)]()+_0xb1b23a[_0x5a2d5a(0x172)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)',_0x5a2d5a(0x170)));}let _0x31b88=new z(_0xaac806,_0x5ed5cc,_0x22f303,_0x41fb4a,_0x1d990d,_0x1ac656);return _0x31b88['send']['bind'](_0x31b88);}catch(_0x1dd37f){return console['warn'](_0x5a2d5a(0xf8),_0x1dd37f&&_0x1dd37f['message']),()=>{};}});return _0x1bab8d=>_0x134f7c['forEach'](_0xf9f6fe=>_0xf9f6fe(_0x1bab8d));}function ne(_0x215577,_0x1d2815,_0x27483d,_0x2f114f){var _0xdebb60=_0x54cc26;_0x2f114f&&_0x215577===_0xdebb60(0x13e)&&_0x27483d[_0xdebb60(0x101)][_0xdebb60(0x13e)]();}function b(_0x4bf85c){var _0x402023=_0x54cc26,_0x39f3be,_0x1b82fe;let _0xcdf938=function(_0x5b8299,_0x5b1c4e){return _0x5b1c4e-_0x5b8299;},_0xa22518;if(_0x4bf85c[_0x402023(0x100)])_0xa22518=function(){var _0x1b3c2a=_0x402023;return _0x4bf85c[_0x1b3c2a(0x100)][_0x1b3c2a(0x1a6)]();};else{if(_0x4bf85c[_0x402023(0x169)]&&_0x4bf85c[_0x402023(0x169)][_0x402023(0xde)]&&((_0x1b82fe=(_0x39f3be=_0x4bf85c[_0x402023(0x169)])==null?void 0x0:_0x39f3be[_0x402023(0x10a)])==null?void 0x0:_0x1b82fe['NEXT_RUNTIME'])!==_0x402023(0x11d))_0xa22518=function(){var _0xdb951a=_0x402023;return _0x4bf85c[_0xdb951a(0x169)][_0xdb951a(0xde)]();},_0xcdf938=function(_0xbcdac7,_0x1f8e63){return 0x3e8*(_0x1f8e63[0x0]-_0xbcdac7[0x0])+(_0x1f8e63[0x1]-_0xbcdac7[0x1])/0xf4240;};else try{let {performance:_0x4cdf5e}=require('perf_hooks');_0xa22518=function(){var _0x194844=_0x402023;return _0x4cdf5e[_0x194844(0x1a6)]();};}catch{_0xa22518=function(){return+new Date();};}}return{'elapsed':_0xcdf938,'timeStamp':_0xa22518,'now':()=>Date[_0x402023(0x1a6)]()};}function X(_0x59955b,_0x3967e7,_0x2cce88){var _0x4215b2=_0x54cc26,_0x244b03,_0x3c8740,_0x47936d,_0x52231b,_0x3b5f0a,_0x4a40d4,_0x5240c0,_0x4c6114,_0xd96b4;if(_0x59955b[_0x4215b2(0xfa)]!==void 0x0)return _0x59955b[_0x4215b2(0xfa)];let _0xf3157d=((_0x3c8740=(_0x244b03=_0x59955b['process'])==null?void 0x0:_0x244b03[_0x4215b2(0x12a)])==null?void 0x0:_0x3c8740['node'])||((_0x52231b=(_0x47936d=_0x59955b[_0x4215b2(0x169)])==null?void 0x0:_0x47936d['env'])==null?void 0x0:_0x52231b[_0x4215b2(0x193)])===_0x4215b2(0x11d),_0x3b4db8=!!(_0x2cce88===_0x4215b2(0xd6)&&((_0x5240c0=(_0x4a40d4=(_0x3b5f0a=_0x59955b[_0x4215b2(0xcd)])==null?void 0x0:_0x3b5f0a[_0x4215b2(0x160)])==null?void 0x0:_0x4a40d4[_0x4215b2(0x1a2)])==null?void 0x0:_0x5240c0['osName']));function _0x2b6750(_0x48746a){var _0x18b065=_0x4215b2;if(_0x48746a['startsWith']('/')&&_0x48746a[_0x18b065(0x140)]('/')){let _0x45480e=new RegExp(_0x48746a[_0x18b065(0x162)](0x1,-0x1));return _0x496074=>_0x45480e['test'](_0x496074);}else{if(_0x48746a['includes']('*')||_0x48746a[_0x18b065(0x153)]('?')){let _0x3c8416=new RegExp('^'+_0x48746a[_0x18b065(0x154)](/\\./g,String['fromCharCode'](0x5c)+'.')[_0x18b065(0x154)](/\\*/g,'.*')[_0x18b065(0x154)](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x472a9d=>_0x3c8416[_0x18b065(0x10f)](_0x472a9d);}else return _0x2615bb=>_0x2615bb===_0x48746a;}}let _0x1eca1e=_0x3967e7[_0x4215b2(0x106)](_0x2b6750);return _0x59955b['_consoleNinjaAllowedToStart']=_0xf3157d||!_0x3967e7,!_0x59955b[_0x4215b2(0xfa)]&&((_0x4c6114=_0x59955b[_0x4215b2(0x101)])==null?void 0x0:_0x4c6114[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=_0x1eca1e['some'](_0x3ccb07=>_0x3ccb07(_0x59955b['location'][_0x4215b2(0x183)]))),_0x3b4db8&&!_0x59955b[_0x4215b2(0xfa)]&&!((_0xd96b4=_0x59955b[_0x4215b2(0x101)])!=null&&_0xd96b4[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=!0x0),_0x59955b['_consoleNinjaAllowedToStart'];}function J(_0x31f20b,_0x5c577b,_0x1f3bee,_0x4a0483,_0x469d82,_0x2514c8){var _0x4934b8=_0x54cc26;_0x31f20b=_0x31f20b,_0x5c577b=_0x5c577b,_0x1f3bee=_0x1f3bee,_0x4a0483=_0x4a0483,_0x469d82=_0x469d82,_0x469d82=_0x469d82||{},_0x469d82[_0x4934b8(0x1cc)]=_0x469d82[_0x4934b8(0x1cc)]||{},_0x469d82['reducedLimits']=_0x469d82[_0x4934b8(0x138)]||{},_0x469d82[_0x4934b8(0xe2)]=_0x469d82[_0x4934b8(0xe2)]||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)]=_0x469d82[_0x4934b8(0xe2)]['perLogpoint']||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]=_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]||{};let _0x141946={'perLogpoint':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0x12d)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint']['reduceOnAccumulatedProcessingTimeMs']||0x64,'resetWhenQuietMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0xe6)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint'][_0x4934b8(0x1b0)]||0x64},'global':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)]['global'][_0x4934b8(0x12d)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['reduceOnAccumulatedProcessingTimeMs']||0x12c,'resetWhenQuietMs':_0x469d82['reducePolicy'][_0x4934b8(0x13f)][_0x4934b8(0xe6)]||0x32,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['resetOnProcessingTimeAverageMs']||0x64}},_0x42f773=b(_0x31f20b),_0x42fb36=_0x42f773[_0x4934b8(0x168)],_0x223738=_0x42f773[_0x4934b8(0xd0)];function _0x568c0c(){var _0x1fa2cb=_0x4934b8;this[_0x1fa2cb(0x13a)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x1fa2cb(0x109)]=/^(0|[1-9][0-9]*)$/,this[_0x1fa2cb(0x159)]=/'([^\\\\']|\\\\')*'/,this[_0x1fa2cb(0x12f)]=_0x31f20b[_0x1fa2cb(0xc5)],this[_0x1fa2cb(0x161)]=_0x31f20b[_0x1fa2cb(0x1ab)],this[_0x1fa2cb(0xcf)]=Object[_0x1fa2cb(0x11a)],this[_0x1fa2cb(0x17a)]=Object[_0x1fa2cb(0x14e)],this[_0x1fa2cb(0x178)]=_0x31f20b[_0x1fa2cb(0x19f)],this[_0x1fa2cb(0xd5)]=RegExp[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)],this[_0x1fa2cb(0x132)]=Date[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)];}_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x158)]=function(_0x48d78e,_0x348dcf,_0x4a6d96,_0x5a5f89){var _0x19e5e6=_0x4934b8,_0xc6b12f=this,_0x55a7d2=_0x4a6d96['autoExpand'];function _0x42e97b(_0x3952f9,_0x2bc656,_0x8c85ef){var _0x2f1a2f=_0x4a90;_0x2bc656[_0x2f1a2f(0x151)]=_0x2f1a2f(0x16e),_0x2bc656[_0x2f1a2f(0x1bb)]=_0x3952f9[_0x2f1a2f(0x188)],_0x2b7b1a=_0x8c85ef[_0x2f1a2f(0x128)][_0x2f1a2f(0xea)],_0x8c85ef['node'][_0x2f1a2f(0xea)]=_0x2bc656,_0xc6b12f[_0x2f1a2f(0xc8)](_0x2bc656,_0x8c85ef);}let _0xcd7ba5,_0x5307f1,_0x34239a=_0x31f20b[_0x19e5e6(0xd9)];_0x31f20b[_0x19e5e6(0xd9)]=!0x0,_0x31f20b['console']&&(_0xcd7ba5=_0x31f20b[_0x19e5e6(0x176)]['error'],_0x5307f1=_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)],_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=function(){}),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)]=function(){}));try{try{_0x4a6d96[_0x19e5e6(0x115)]++,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96['autoExpandPreviousObjects'][_0x19e5e6(0xff)](_0x348dcf);var _0x6adee3,_0xa868ce,_0x4c1789,_0x127a28,_0x1bef2c=[],_0x4dd8f0=[],_0x47c5d8,_0x18b1eb=this[_0x19e5e6(0x1ad)](_0x348dcf),_0x481e55=_0x18b1eb==='array',_0x57133b=!0x1,_0x5ca399=_0x18b1eb===_0x19e5e6(0x196),_0xbd7d8f=this['_isPrimitiveType'](_0x18b1eb),_0x417ea6=this[_0x19e5e6(0x146)](_0x18b1eb),_0x273a7e=_0xbd7d8f||_0x417ea6,_0x2a289a={},_0xcd0938=0x0,_0x14ebf7=!0x1,_0x2b7b1a,_0x30046f=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x4a6d96[_0x19e5e6(0x15f)]){if(_0x481e55){if(_0xa868ce=_0x348dcf['length'],_0xa868ce>_0x4a6d96['elements']){for(_0x4c1789=0x0,_0x127a28=_0x4a6d96['elements'],_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0xcc)](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));_0x48d78e[_0x19e5e6(0x1b9)]=!0x0;}else{for(_0x4c1789=0x0,_0x127a28=_0xa868ce,_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f['_addProperty'](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));}_0x4a6d96[_0x19e5e6(0x186)]+=_0x4dd8f0[_0x19e5e6(0xfc)];}if(!(_0x18b1eb==='null'||_0x18b1eb===_0x19e5e6(0xc5))&&!_0xbd7d8f&&_0x18b1eb!==_0x19e5e6(0x1c8)&&_0x18b1eb!=='Buffer'&&_0x18b1eb!==_0x19e5e6(0xed)){var _0x482677=_0x5a5f89['props']||_0x4a6d96[_0x19e5e6(0xfd)];if(this[_0x19e5e6(0x119)](_0x348dcf)?(_0x6adee3=0x0,_0x348dcf[_0x19e5e6(0x1ba)](function(_0x316011){var _0x3d6007=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0x3d6007(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0x3d6007(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x3d6007(0x186)]>_0x4a6d96[_0x3d6007(0x1a7)]){_0x14ebf7=!0x0;return;}_0x4dd8f0[_0x3d6007(0xff)](_0xc6b12f[_0x3d6007(0xcc)](_0x1bef2c,_0x348dcf,_0x3d6007(0xeb),_0x6adee3++,_0x4a6d96,function(_0x2dd991){return function(){return _0x2dd991;};}(_0x316011)));})):this[_0x19e5e6(0x1a3)](_0x348dcf)&&_0x348dcf[_0x19e5e6(0x1ba)](function(_0x4e9669,_0x2865be){var _0xe99383=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0xe99383(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0xe99383(0x11c)]&&_0x4a6d96[_0xe99383(0x104)]&&_0x4a6d96[_0xe99383(0x186)]>_0x4a6d96[_0xe99383(0x1a7)]){_0x14ebf7=!0x0;return;}var _0x4c2eff=_0x2865be[_0xe99383(0xdf)]();_0x4c2eff[_0xe99383(0xfc)]>0x64&&(_0x4c2eff=_0x4c2eff[_0xe99383(0x162)](0x0,0x64)+_0xe99383(0xe4)),_0x4dd8f0[_0xe99383(0xff)](_0xc6b12f[_0xe99383(0xcc)](_0x1bef2c,_0x348dcf,_0xe99383(0xd7),_0x4c2eff,_0x4a6d96,function(_0x38d848){return function(){return _0x38d848;};}(_0x4e9669)));}),!_0x57133b){try{for(_0x47c5d8 in _0x348dcf)if(!(_0x481e55&&_0x30046f[_0x19e5e6(0x10f)](_0x47c5d8))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0['push'](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}catch{}if(_0x2a289a['_p_length']=!0x0,_0x5ca399&&(_0x2a289a[_0x19e5e6(0xfe)]=!0x0),!_0x14ebf7){var _0x507ca6=[][_0x19e5e6(0x112)](this['_getOwnPropertyNames'](_0x348dcf))[_0x19e5e6(0x112)](this['_getOwnPropertySymbols'](_0x348dcf));for(_0x6adee3=0x0,_0xa868ce=_0x507ca6['length'];_0x6adee3<_0xa868ce;_0x6adee3++)if(_0x47c5d8=_0x507ca6[_0x6adee3],!(_0x481e55&&_0x30046f['test'](_0x47c5d8[_0x19e5e6(0xdf)]()))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)&&!_0x2a289a[typeof _0x47c5d8!=_0x19e5e6(0x10b)?_0x19e5e6(0x17e)+_0x47c5d8[_0x19e5e6(0xdf)]():_0x47c5d8]){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}}}}if(_0x48d78e['type']=_0x18b1eb,_0x273a7e?(_0x48d78e['value']=_0x348dcf[_0x19e5e6(0x122)](),this[_0x19e5e6(0x139)](_0x18b1eb,_0x48d78e,_0x4a6d96,_0x5a5f89)):_0x18b1eb===_0x19e5e6(0x103)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x132)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0xed)?_0x48d78e[_0x19e5e6(0xc4)]=_0x348dcf[_0x19e5e6(0xdf)]():_0x18b1eb===_0x19e5e6(0x142)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0xd5)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0x10b)&&this[_0x19e5e6(0x178)]?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x178)][_0x19e5e6(0x18a)]['toString'][_0x19e5e6(0x195)](_0x348dcf):!_0x4a6d96[_0x19e5e6(0x15f)]&&!(_0x18b1eb===_0x19e5e6(0xd3)||_0x18b1eb==='undefined')&&(delete _0x48d78e[_0x19e5e6(0xc4)],_0x48d78e[_0x19e5e6(0x1ae)]=!0x0),_0x14ebf7&&(_0x48d78e[_0x19e5e6(0x13b)]=!0x0),_0x2b7b1a=_0x4a6d96[_0x19e5e6(0x128)][_0x19e5e6(0xea)],_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x48d78e,this[_0x19e5e6(0xc8)](_0x48d78e,_0x4a6d96),_0x4dd8f0['length']){for(_0x6adee3=0x0,_0xa868ce=_0x4dd8f0[_0x19e5e6(0xfc)];_0x6adee3<_0xa868ce;_0x6adee3++)_0x4dd8f0[_0x6adee3](_0x6adee3);}_0x1bef2c[_0x19e5e6(0xfc)]&&(_0x48d78e[_0x19e5e6(0xfd)]=_0x1bef2c);}catch(_0x3ae5b6){_0x42e97b(_0x3ae5b6,_0x48d78e,_0x4a6d96);}this[_0x19e5e6(0x1c9)](_0x348dcf,_0x48d78e),this[_0x19e5e6(0x136)](_0x48d78e,_0x4a6d96),_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x2b7b1a,_0x4a6d96[_0x19e5e6(0x115)]--,_0x4a6d96[_0x19e5e6(0x104)]=_0x55a7d2,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x1b4)]['pop']();}finally{_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=_0xcd7ba5),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)]['warn']=_0x5307f1),_0x31f20b[_0x19e5e6(0xd9)]=_0x34239a;}return _0x48d78e;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12e)]=function(_0x46f99b){var _0x55ee4f=_0x4934b8;return Object['getOwnPropertySymbols']?Object[_0x55ee4f(0x16b)](_0x46f99b):[];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x119)]=function(_0x259646){var _0x583570=_0x4934b8;return!!(_0x259646&&_0x31f20b[_0x583570(0xeb)]&&this['_objectToString'](_0x259646)===_0x583570(0x17f)&&_0x259646[_0x583570(0x1ba)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xce)]=function(_0x469950,_0x43a4d0,_0x3e7028){var _0x44d134=_0x4934b8;if(!_0x3e7028[_0x44d134(0xcb)]){let _0x5e446a=this[_0x44d134(0xcf)](_0x469950,_0x43a4d0);if(_0x5e446a&&_0x5e446a[_0x44d134(0xf5)])return!0x0;}return _0x3e7028[_0x44d134(0x1bf)]?typeof _0x469950[_0x43a4d0]==_0x44d134(0x196):!0x1;},_0x568c0c[_0x4934b8(0x18a)]['_type']=function(_0x21f464){var _0x5b73d0=_0x4934b8,_0x1012e4='';return _0x1012e4=typeof _0x21f464,_0x1012e4===_0x5b73d0(0x118)?this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x14c)?_0x1012e4=_0x5b73d0(0xfb):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x1b8)?_0x1012e4=_0x5b73d0(0x103):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x149)?_0x1012e4=_0x5b73d0(0xed):_0x21f464===null?_0x1012e4='null':_0x21f464[_0x5b73d0(0x14f)]&&(_0x1012e4=_0x21f464['constructor'][_0x5b73d0(0x1c3)]||_0x1012e4):_0x1012e4===_0x5b73d0(0xc5)&&this[_0x5b73d0(0x161)]&&_0x21f464 instanceof this['_HTMLAllCollection']&&(_0x1012e4='HTMLAllCollection'),_0x1012e4;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1c7)]=function(_0x23706a){var _0xb5b3ca=_0x4934b8;return Object[_0xb5b3ca(0x18a)][_0xb5b3ca(0xdf)]['call'](_0x23706a);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19d)]=function(_0x94e0c5){var _0x4b2537=_0x4934b8;return _0x94e0c5===_0x4b2537(0x157)||_0x94e0c5==='string'||_0x94e0c5===_0x4b2537(0x1b2);},_0x568c0c['prototype']['_isPrimitiveWrapperType']=function(_0x2f3e62){var _0x16ad9e=_0x4934b8;return _0x2f3e62===_0x16ad9e(0x199)||_0x2f3e62==='String'||_0x2f3e62===_0x16ad9e(0xe7);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xcc)]=function(_0x1db57d,_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7){var _0x2fcbd8=this;return function(_0x2a2b77){var _0xce493a=_0x4a90,_0x174862=_0x3015c5['node'][_0xce493a(0xea)],_0x4a97c=_0x3015c5[_0xce493a(0x128)]['index'],_0x2b4936=_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)];_0x3015c5['node'][_0xce493a(0x120)]=_0x174862,_0x3015c5['node'][_0xce493a(0x14a)]=typeof _0x19ed12==_0xce493a(0x1b2)?_0x19ed12:_0x2a2b77,_0x1db57d[_0xce493a(0xff)](_0x2fcbd8[_0xce493a(0x12c)](_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7)),_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)]=_0x2b4936,_0x3015c5['node']['index']=_0x4a97c;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x117)]=function(_0x4469e5,_0x3fa37e,_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f){var _0x516d33=_0x4934b8,_0x396018=this;return _0x3fa37e[typeof _0x2f3742!=_0x516d33(0x10b)?_0x516d33(0x17e)+_0x2f3742['toString']():_0x2f3742]=!0x0,function(_0xd7fcb0){var _0x3226db=_0x516d33,_0x39117a=_0x36532d[_0x3226db(0x128)][_0x3226db(0xea)],_0x50a11a=_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)],_0x4eb0c0=_0x36532d['node'][_0x3226db(0x120)];_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x39117a,_0x36532d['node'][_0x3226db(0x14a)]=_0xd7fcb0,_0x4469e5[_0x3226db(0xff)](_0x396018[_0x3226db(0x12c)](_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f)),_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x4eb0c0,_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)]=_0x50a11a;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12c)]=function(_0x453099,_0x4eadbd,_0x11f35a,_0x40815b,_0xa2b7cb){var _0x4b84a8=_0x4934b8,_0x5e86b1=this;_0xa2b7cb||(_0xa2b7cb=function(_0x5cea02,_0x58268c){return _0x5cea02[_0x58268c];});var _0x362525=_0x11f35a['toString'](),_0x3c06dc=_0x40815b[_0x4b84a8(0x1ce)]||{},_0x142239=_0x40815b['depth'],_0x26bf80=_0x40815b[_0x4b84a8(0x11c)];try{var _0x3aca2e=this[_0x4b84a8(0x1a3)](_0x453099),_0x4aabb3=_0x362525;_0x3aca2e&&_0x4aabb3[0x0]==='\\x27'&&(_0x4aabb3=_0x4aabb3[_0x4b84a8(0x172)](0x1,_0x4aabb3[_0x4b84a8(0xfc)]-0x2));var _0x12d722=_0x40815b['expressionsToEvaluate']=_0x3c06dc[_0x4b84a8(0x17e)+_0x4aabb3];_0x12d722&&(_0x40815b['depth']=_0x40815b['depth']+0x1),_0x40815b[_0x4b84a8(0x11c)]=!!_0x12d722;var _0x56e733=typeof _0x11f35a=='symbol',_0xa051ca={'name':_0x56e733||_0x3aca2e?_0x362525:this[_0x4b84a8(0x131)](_0x362525)};if(_0x56e733&&(_0xa051ca[_0x4b84a8(0x10b)]=!0x0),!(_0x4eadbd===_0x4b84a8(0xfb)||_0x4eadbd===_0x4b84a8(0x11b))){var _0x5b5697=this[_0x4b84a8(0xcf)](_0x453099,_0x11f35a);if(_0x5b5697&&(_0x5b5697[_0x4b84a8(0x185)]&&(_0xa051ca['setter']=!0x0),_0x5b5697[_0x4b84a8(0xf5)]&&!_0x12d722&&!_0x40815b[_0x4b84a8(0xcb)]))return _0xa051ca[_0x4b84a8(0x17b)]=!0x0,this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x51fae3;try{_0x51fae3=_0xa2b7cb(_0x453099,_0x11f35a);}catch(_0x4f78cc){return _0xa051ca={'name':_0x362525,'type':_0x4b84a8(0x16e),'error':_0x4f78cc[_0x4b84a8(0x188)]},this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x310e5a=this['_type'](_0x51fae3),_0x3e58ae=this[_0x4b84a8(0x19d)](_0x310e5a);if(_0xa051ca['type']=_0x310e5a,_0x3e58ae)this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x2623ba=_0x4b84a8;_0xa051ca[_0x2623ba(0xc4)]=_0x51fae3['valueOf'](),!_0x12d722&&_0x5e86b1[_0x2623ba(0x139)](_0x310e5a,_0xa051ca,_0x40815b,{});});else{var _0x87c7d8=_0x40815b[_0x4b84a8(0x104)]&&_0x40815b[_0x4b84a8(0x115)]<_0x40815b[_0x4b84a8(0x189)]&&_0x40815b[_0x4b84a8(0x1b4)][_0x4b84a8(0x121)](_0x51fae3)<0x0&&_0x310e5a!==_0x4b84a8(0x196)&&_0x40815b['autoExpandPropertyCount']<_0x40815b[_0x4b84a8(0x1a7)];_0x87c7d8||_0x40815b[_0x4b84a8(0x115)]<_0x142239||_0x12d722?this['serialize'](_0xa051ca,_0x51fae3,_0x40815b,_0x12d722||{}):this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x48a268=_0x4b84a8;_0x310e5a===_0x48a268(0xd3)||_0x310e5a===_0x48a268(0xc5)||(delete _0xa051ca[_0x48a268(0xc4)],_0xa051ca['capped']=!0x0);});}return _0xa051ca;}finally{_0x40815b[_0x4b84a8(0x1ce)]=_0x3c06dc,_0x40815b[_0x4b84a8(0x15f)]=_0x142239,_0x40815b[_0x4b84a8(0x11c)]=_0x26bf80;}},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x139)]=function(_0x5e0732,_0x1bfe86,_0xda28d7,_0x491a14){var _0x60e05=_0x4934b8,_0x33f831=_0x491a14[_0x60e05(0x110)]||_0xda28d7[_0x60e05(0x110)];if((_0x5e0732===_0x60e05(0x1a9)||_0x5e0732==='String')&&_0x1bfe86['value']){let _0x1eacb7=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0xfc)];_0xda28d7['allStrLength']+=_0x1eacb7,_0xda28d7[_0x60e05(0xd4)]>_0xda28d7[_0x60e05(0x191)]?(_0x1bfe86['capped']='',delete _0x1bfe86[_0x60e05(0xc4)]):_0x1eacb7>_0x33f831&&(_0x1bfe86[_0x60e05(0x1ae)]=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0x172)](0x0,_0x33f831),delete _0x1bfe86[_0x60e05(0xc4)]);}},_0x568c0c['prototype']['_isMap']=function(_0x251695){var _0x2d4790=_0x4934b8;return!!(_0x251695&&_0x31f20b[_0x2d4790(0xd7)]&&this[_0x2d4790(0x1c7)](_0x251695)===_0x2d4790(0x16d)&&_0x251695['forEach']);},_0x568c0c[_0x4934b8(0x18a)]['_propertyName']=function(_0x2e0688){var _0x2c8644=_0x4934b8;if(_0x2e0688[_0x2c8644(0x11f)](/^\\d+$/))return _0x2e0688;var _0x91094;try{_0x91094=JSON[_0x2c8644(0x175)](''+_0x2e0688);}catch{_0x91094='\\x22'+this['_objectToString'](_0x2e0688)+'\\x22';}return _0x91094[_0x2c8644(0x11f)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x91094=_0x91094['substr'](0x1,_0x91094[_0x2c8644(0xfc)]-0x2):_0x91094=_0x91094[_0x2c8644(0x154)](/'/g,'\\x5c\\x27')[_0x2c8644(0x154)](/\\\\\"/g,'\\x22')[_0x2c8644(0x154)](/(^\"|\"$)/g,'\\x27'),_0x91094;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1a0)]=function(_0x232cbb,_0x29085f,_0x1650af,_0x1c890e){var _0x16a2a5=_0x4934b8;this[_0x16a2a5(0xc8)](_0x232cbb,_0x29085f),_0x1c890e&&_0x1c890e(),this[_0x16a2a5(0x1c9)](_0x1650af,_0x232cbb),this[_0x16a2a5(0x136)](_0x232cbb,_0x29085f);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xc8)]=function(_0x49291a,_0x33bdc6){var _0x52d41e=_0x4934b8;this[_0x52d41e(0x127)](_0x49291a,_0x33bdc6),this['_setNodeQueryPath'](_0x49291a,_0x33bdc6),this[_0x52d41e(0x15a)](_0x49291a,_0x33bdc6),this[_0x52d41e(0xe0)](_0x49291a,_0x33bdc6);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x127)]=function(_0x3ffba9,_0x308291){},_0x568c0c[_0x4934b8(0x18a)]['_setNodeQueryPath']=function(_0x4befcf,_0x340320){},_0x568c0c['prototype'][_0x4934b8(0x19c)]=function(_0x6d004b,_0x3e0efe){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19e)]=function(_0x3b2948){var _0x1c5336=_0x4934b8;return _0x3b2948===this[_0x1c5336(0x12f)];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x136)]=function(_0x571a40,_0x11152b){var _0x17c82d=_0x4934b8;this[_0x17c82d(0x19c)](_0x571a40,_0x11152b),this[_0x17c82d(0x16c)](_0x571a40),_0x11152b['sortProps']&&this[_0x17c82d(0x1af)](_0x571a40),this['_addFunctionsNode'](_0x571a40,_0x11152b),this['_addLoadNode'](_0x571a40,_0x11152b),this['_cleanNode'](_0x571a40);},_0x568c0c[_0x4934b8(0x18a)]['_additionalMetadata']=function(_0x25d425,_0x376ba0){var _0x4c6175=_0x4934b8;try{_0x25d425&&typeof _0x25d425[_0x4c6175(0xfc)]==_0x4c6175(0x1b2)&&(_0x376ba0[_0x4c6175(0xfc)]=_0x25d425[_0x4c6175(0xfc)]);}catch{}if(_0x376ba0[_0x4c6175(0x151)]===_0x4c6175(0x1b2)||_0x376ba0['type']===_0x4c6175(0xe7)){if(isNaN(_0x376ba0['value']))_0x376ba0[_0x4c6175(0xe5)]=!0x0,delete _0x376ba0[_0x4c6175(0xc4)];else switch(_0x376ba0[_0x4c6175(0xc4)]){case Number[_0x4c6175(0x102)]:_0x376ba0[_0x4c6175(0x130)]=!0x0,delete _0x376ba0['value'];break;case Number[_0x4c6175(0xf6)]:_0x376ba0[_0x4c6175(0x184)]=!0x0,delete _0x376ba0['value'];break;case 0x0:this['_isNegativeZero'](_0x376ba0['value'])&&(_0x376ba0[_0x4c6175(0xc3)]=!0x0);break;}}else _0x376ba0['type']==='function'&&typeof _0x25d425[_0x4c6175(0x1c3)]=='string'&&_0x25d425['name']&&_0x376ba0[_0x4c6175(0x1c3)]&&_0x25d425[_0x4c6175(0x1c3)]!==_0x376ba0[_0x4c6175(0x1c3)]&&(_0x376ba0[_0x4c6175(0x145)]=_0x25d425[_0x4c6175(0x1c3)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x187)]=function(_0x3d5c0c){var _0x21909c=_0x4934b8;return 0x1/_0x3d5c0c===Number[_0x21909c(0xf6)];},_0x568c0c['prototype'][_0x4934b8(0x1af)]=function(_0xaf6d85){var _0x257f6e=_0x4934b8;!_0xaf6d85[_0x257f6e(0xfd)]||!_0xaf6d85['props'][_0x257f6e(0xfc)]||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xfb)||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xd7)||_0xaf6d85[_0x257f6e(0x151)]==='Set'||_0xaf6d85[_0x257f6e(0xfd)][_0x257f6e(0xee)](function(_0xcc5a49,_0x33a07){var _0x3d0ac0=_0x257f6e,_0x216c86=_0xcc5a49[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)](),_0x52e92d=_0x33a07[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)]();return _0x216c86<_0x52e92d?-0x1:_0x216c86>_0x52e92d?0x1:0x0;});},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x18c)]=function(_0x26dd9a,_0x367b0a){var _0x3fb806=_0x4934b8;if(!(_0x367b0a[_0x3fb806(0x1bf)]||!_0x26dd9a['props']||!_0x26dd9a[_0x3fb806(0xfd)]['length'])){for(var _0x558538=[],_0x1e34a7=[],_0x4cf6c3=0x0,_0x496b22=_0x26dd9a[_0x3fb806(0xfd)]['length'];_0x4cf6c3<_0x496b22;_0x4cf6c3++){var _0x286ad8=_0x26dd9a[_0x3fb806(0xfd)][_0x4cf6c3];_0x286ad8[_0x3fb806(0x151)]===_0x3fb806(0x196)?_0x558538[_0x3fb806(0xff)](_0x286ad8):_0x1e34a7[_0x3fb806(0xff)](_0x286ad8);}if(!(!_0x1e34a7[_0x3fb806(0xfc)]||_0x558538[_0x3fb806(0xfc)]<=0x1)){_0x26dd9a[_0x3fb806(0xfd)]=_0x1e34a7;var _0x589572={'functionsNode':!0x0,'props':_0x558538};this[_0x3fb806(0x127)](_0x589572,_0x367b0a),this[_0x3fb806(0x19c)](_0x589572,_0x367b0a),this['_setNodeExpandableState'](_0x589572),this[_0x3fb806(0xe0)](_0x589572,_0x367b0a),_0x589572['id']+='\\x20f',_0x26dd9a['props'][_0x3fb806(0x1ac)](_0x589572);}}},_0x568c0c['prototype'][_0x4934b8(0xf9)]=function(_0x3a8156,_0x31dbc6){},_0x568c0c['prototype']['_setNodeExpandableState']=function(_0x27a91c){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xdc)]=function(_0x309bc7){var _0x3eff3d=_0x4934b8;return Array[_0x3eff3d(0x173)](_0x309bc7)||typeof _0x309bc7=='object'&&this['_objectToString'](_0x309bc7)==='[object\\x20Array]';},_0x568c0c[_0x4934b8(0x18a)]['_setNodePermissions']=function(_0x33a0fd,_0x133d76){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xef)]=function(_0xd4834e){var _0x4c0797=_0x4934b8;delete _0xd4834e[_0x4c0797(0xe9)],delete _0xd4834e[_0x4c0797(0xf3)],delete _0xd4834e[_0x4c0797(0x1b7)];},_0x568c0c[_0x4934b8(0x18a)]['_setNodeExpressionPath']=function(_0x82227e,_0x5e328e){};let _0x4277ae=new _0x568c0c(),_0x578392={'props':_0x469d82[_0x4934b8(0x1cc)][_0x4934b8(0xfd)]||0x64,'elements':_0x469d82[_0x4934b8(0x1cc)]['elements']||0x64,'strLength':_0x469d82['defaultLimits']['strLength']||0x400*0x32,'totalStrLength':_0x469d82['defaultLimits'][_0x4934b8(0x191)]||0x400*0x32,'autoExpandLimit':_0x469d82['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x1cc)]['autoExpandMaxDepth']||0xa},_0x1f746a={'props':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xfd)]||0x5,'elements':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xd2)]||0x5,'strLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x110)]||0x100,'totalStrLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x191)]||0x100*0x3,'autoExpandLimit':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x1a7)]||0x1e,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x189)]||0x2};if(_0x2514c8){let _0x31c1e0=_0x4277ae['serialize'][_0x4934b8(0xf1)](_0x4277ae);_0x4277ae[_0x4934b8(0x158)]=function(_0x1957c4,_0xc0aeb7,_0x4ead78,_0x3625d6){return _0x31c1e0(_0x1957c4,_0x2514c8(_0xc0aeb7),_0x4ead78,_0x3625d6);};}function _0x1e6d74(_0x5afffa,_0x4a459c,_0x275938,_0x334fd3,_0x45c8dc,_0x17015d){var _0x490e67=_0x4934b8;let _0x97a821,_0x4538cb;try{_0x4538cb=_0x223738(),_0x97a821=_0x1f3bee[_0x4a459c],!_0x97a821||_0x4538cb-_0x97a821['ts']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0xe6)]&&_0x97a821[_0x490e67(0x180)]&&_0x97a821['time']/_0x97a821[_0x490e67(0x180)]<_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1b0)]?(_0x1f3bee[_0x4a459c]=_0x97a821={'count':0x0,'time':0x0,'ts':_0x4538cb},_0x1f3bee[_0x490e67(0x1cd)]={}):_0x4538cb-_0x1f3bee[_0x490e67(0x1cd)]['ts']>_0x141946[_0x490e67(0x13f)][_0x490e67(0xe6)]&&_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]&&_0x1f3bee['hits']['time']/_0x1f3bee['hits']['count']<_0x141946[_0x490e67(0x13f)]['resetOnProcessingTimeAverageMs']&&(_0x1f3bee[_0x490e67(0x1cd)]={});let _0x7ce882=[],_0x3afea7=_0x97a821['reduceLimits']||_0x1f3bee['hits']['reduceLimits']?_0x1f746a:_0x578392,_0x204f3a=_0x4e76b9=>{var _0x2f14d5=_0x490e67;let _0x5cb8da={};return _0x5cb8da[_0x2f14d5(0xfd)]=_0x4e76b9['props'],_0x5cb8da['elements']=_0x4e76b9[_0x2f14d5(0xd2)],_0x5cb8da[_0x2f14d5(0x110)]=_0x4e76b9[_0x2f14d5(0x110)],_0x5cb8da[_0x2f14d5(0x191)]=_0x4e76b9['totalStrLength'],_0x5cb8da['autoExpandLimit']=_0x4e76b9[_0x2f14d5(0x1a7)],_0x5cb8da[_0x2f14d5(0x189)]=_0x4e76b9[_0x2f14d5(0x189)],_0x5cb8da['sortProps']=!0x1,_0x5cb8da[_0x2f14d5(0x1bf)]=!_0x5c577b,_0x5cb8da[_0x2f14d5(0x15f)]=0x1,_0x5cb8da[_0x2f14d5(0x115)]=0x0,_0x5cb8da['expId']='root_exp_id',_0x5cb8da[_0x2f14d5(0xc6)]=_0x2f14d5(0x10d),_0x5cb8da[_0x2f14d5(0x104)]=!0x0,_0x5cb8da[_0x2f14d5(0x1b4)]=[],_0x5cb8da[_0x2f14d5(0x186)]=0x0,_0x5cb8da['resolveGetters']=_0x469d82[_0x2f14d5(0xcb)],_0x5cb8da[_0x2f14d5(0xd4)]=0x0,_0x5cb8da[_0x2f14d5(0x128)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x5cb8da;};for(var _0x7432f7=0x0;_0x7432f7<_0x45c8dc['length'];_0x7432f7++)_0x7ce882[_0x490e67(0xff)](_0x4277ae[_0x490e67(0x158)]({'timeNode':_0x5afffa===_0x490e67(0x15e)||void 0x0},_0x45c8dc[_0x7432f7],_0x204f3a(_0x3afea7),{}));if(_0x5afffa===_0x490e67(0x17c)||_0x5afffa===_0x490e67(0x1bb)){let _0x5b3615=Error[_0x490e67(0x16f)];try{Error['stackTraceLimit']=0x1/0x0,_0x7ce882['push'](_0x4277ae[_0x490e67(0x158)]({'stackNode':!0x0},new Error()[_0x490e67(0x123)],_0x204f3a(_0x3afea7),{'strLength':0x1/0x0}));}finally{Error[_0x490e67(0x16f)]=_0x5b3615;}}return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':_0x7ce882,'id':_0x4a459c,'context':_0x17015d}]};}catch(_0x84cbeb){return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':[{'type':_0x490e67(0x16e),'error':_0x84cbeb&&_0x84cbeb[_0x490e67(0x188)]}],'id':_0x4a459c,'context':_0x17015d}]};}finally{try{if(_0x97a821&&_0x4538cb){let _0x432ee2=_0x223738();_0x97a821['count']++,_0x97a821['time']+=_0x42fb36(_0x4538cb,_0x432ee2),_0x97a821['ts']=_0x432ee2,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]++,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]+=_0x42fb36(_0x4538cb,_0x432ee2),_0x1f3bee[_0x490e67(0x1cd)]['ts']=_0x432ee2,(_0x97a821[_0x490e67(0x180)]>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x12d)]||_0x97a821['time']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1bc)])&&(_0x97a821[_0x490e67(0x171)]=!0x0),(_0x1f3bee['hits']['count']>_0x141946[_0x490e67(0x13f)][_0x490e67(0x12d)]||_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]>_0x141946[_0x490e67(0x13f)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x1f3bee[_0x490e67(0x1cd)]['reduceLimits']=!0x0);}}catch{}}}return _0x1e6d74;}function _0x2214(){var _0x14499a=['value','undefined','rootExpression','path','_treeNodePropertiesBeforeFullValue','origin','data','resolveGetters','_addProperty','expo','_blacklistedProperty','_getOwnPropertyDescriptor','timeStamp','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','elements','null','allStrLength','_regExpToString','react-native','Map','2eFQllr','ninjaSuppressConsole',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','coverage','_isArray','_connected','hrtime','toString','_setNodePermissions','bound\\x20Promise','reducePolicy','_reconnectTimeout','...','nan','resetWhenQuietMs','Number','_ninjaIgnoreNextError','_hasSymbolPropertyOnItsPath','current','Set','import(\\x27url\\x27)','bigint','sort','_cleanNode','_connectToHostNow','bind','catch','_hasSetOnItsPath','\\x20server','get','NEGATIVE_INFINITY','1.0.0','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','_addLoadNode','_consoleNinjaAllowedToStart','array','length','props','_p_name','push','performance','location','POSITIVE_INFINITY','date','autoExpand','10162370kgItlO','map','disabledTrace','10.0.2.2','_numberRegExp','env','symbol','resolve','root_exp','onmessage','test','strLength','port','concat','_WebSocket','then','level','log','_addObjectProperty','object','_isSet','getOwnPropertyDescriptor','Error','isExpressionToEvaluate','edge','charAt','match','parent','indexOf','valueOf','stack','warn','_connecting','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_setNodeId','node','next.js','versions','1668317DHAXqx','_property','reduceOnCount','_getOwnPropertySymbols','_undefined','positiveInfinity','_propertyName','_dateToString','_sendErrorMessage','gateway.docker.internal','remix','_treeNodePropertiesAfterFullValue','984054cwWOKG','reducedLimits','_capIfString','_keyStrRegExp','cappedProps','_attemptToReconnectShortly','_socket','reload','global','endsWith','args','RegExp','_extendedWarning','onerror','funcName','_isPrimitiveWrapperType','_disposeWebsocket','next.js','[object\\x20BigInt]','index','_maxConnectAttemptCount','[object\\x20Array]',\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",'getOwnPropertyNames','constructor','dockerizedApp','type','142700orZAYJ','includes','replace','51827','hasOwnProperty','boolean','serialize','_quotedRegExp','_setNodeExpressionPath','unref','join','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','time','depth','modules','_HTMLAllCollection','slice','method','nodeModules','_console_ninja','parse','415197WHEhXo','elapsed','process','eventReceivedCallback','getOwnPropertySymbols','_setNodeExpandableState','[object\\x20Map]','unknown','stackTraceLimit','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','reduceLimits','substr','isArray','_allowedToSend','stringify','console','disabledLog','_Symbol','_webSocketErrorDocsLink','_getOwnPropertyNames','getter','trace','send','_p_','[object\\x20Set]','count','','_allowedToConnectOnSend','hostname','negativeInfinity','set','autoExpandPropertyCount','_isNegativeZero','message','autoExpandMaxDepth','prototype','iterator','_addFunctionsNode','https://tinyurl.com/37x8b79t','angular','127.0.0.1','import(\\x27path\\x27)','totalStrLength','host','NEXT_RUNTIME','_ws','call','function','5lYlfxC','56GExRSR','Boolean','1563852BMXApG',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'_setNodeLabel','_isPrimitiveType','_isUndefined','Symbol','_processTreeNodeResult','_WebSocketClass','ExpoDevice','_isMap','default','_console_ninja_session','now','autoExpandLimit','android','string','11djOgAe','HTMLAllCollection','unshift','_type','capped','_sortProps','resetOnProcessingTimeAverageMs','_inBrowser','number','url','autoExpandPreviousObjects','WebSocket','toUpperCase','_hasMapOnItsPath','[object\\x20Date]','cappedElements','forEach','error','reduceOnAccumulatedProcessingTimeMs','toLowerCase','_connectAttemptCount','noFunctions','207488XhRovp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','split','name','logger\\x20websocket\\x20error','getWebSocketClass',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'_objectToString','String','_additionalMetadata','readyState','perLogpoint','defaultLimits','hits','expressionsToEvaluate','negativeZero'];_0x2214=function(){return _0x14499a;};return _0x2214();}function G(_0x3130d3){var _0x84a520=_0x54cc26;if(_0x3130d3&&typeof _0x3130d3==_0x84a520(0x118)&&_0x3130d3[_0x84a520(0x14f)])switch(_0x3130d3[_0x84a520(0x14f)][_0x84a520(0x1c3)]){case'Promise':return _0x3130d3[_0x84a520(0x156)](Symbol[_0x84a520(0x18b)])?Promise['resolve']():_0x3130d3;case _0x84a520(0xe1):return Promise[_0x84a520(0x10c)]();}return _0x3130d3;}function _0x4a90(_0xbf85a4,_0x245df9){var _0x2214cf=_0x2214();return _0x4a90=function(_0x4a90b3,_0x346472){_0x4a90b3=_0x4a90b3-0xc3;var _0x3eefbb=_0x2214cf[_0x4a90b3];return _0x3eefbb;},_0x4a90(_0xbf85a4,_0x245df9);}((_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x269295,_0x304d0c,_0x56b187,_0x5799d3,_0x19f830,_0x5a3a2e,_0x231e3c)=>{var _0x4818fc=_0x54cc26;if(_0x3cca3d[_0x4818fc(0x165)])return _0x3cca3d[_0x4818fc(0x165)];let _0x52e3da={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x3cca3d,_0x56b187,_0x38abea))return _0x3cca3d[_0x4818fc(0x165)]=_0x52e3da,_0x3cca3d['_console_ninja'];let _0x44b593=b(_0x3cca3d),_0x48380c=_0x44b593[_0x4818fc(0x168)],_0x1338d8=_0x44b593[_0x4818fc(0xd0)],_0x29d139=_0x44b593[_0x4818fc(0x1a6)],_0x1ed58e={'hits':{},'ts':{}},_0x19f55c=J(_0x3cca3d,_0x5799d3,_0x1ed58e,_0x269295,_0x231e3c,_0x38abea===_0x4818fc(0x129)?G:void 0x0),_0x59946f=(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0)=>{var _0x40d17e=_0x4818fc;let _0x218bcb=_0x3cca3d['_console_ninja'];try{return _0x3cca3d['_console_ninja']=_0x52e3da,_0x19f55c(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0);}finally{_0x3cca3d[_0x40d17e(0x165)]=_0x218bcb;}},_0x22921d=_0x423627=>{_0x1ed58e['ts'][_0x423627]=_0x1338d8();},_0x45102e=(_0x88203,_0x370b7a)=>{var _0x9ec8e9=_0x4818fc;let _0x3d041a=_0x1ed58e['ts'][_0x370b7a];if(delete _0x1ed58e['ts'][_0x370b7a],_0x3d041a){let _0x52a6eb=_0x48380c(_0x3d041a,_0x1338d8());_0x312a62(_0x59946f(_0x9ec8e9(0x15e),_0x88203,_0x29d139(),_0x9b859d,[_0x52a6eb],_0x370b7a));}},_0x2ee867=_0x41fceb=>{var _0x5bbca8=_0x4818fc,_0x5ba44d;return _0x38abea==='next.js'&&_0x3cca3d[_0x5bbca8(0xc9)]&&((_0x5ba44d=_0x41fceb==null?void 0x0:_0x41fceb[_0x5bbca8(0x141)])==null?void 0x0:_0x5ba44d[_0x5bbca8(0xfc)])&&(_0x41fceb['args'][0x0][_0x5bbca8(0xc9)]=_0x3cca3d[_0x5bbca8(0xc9)]),_0x41fceb;};_0x3cca3d[_0x4818fc(0x165)]={'consoleLog':(_0x1d0443,_0x2f73e4)=>{var _0x97f6bc=_0x4818fc;_0x3cca3d[_0x97f6bc(0x176)][_0x97f6bc(0x116)][_0x97f6bc(0x1c3)]!==_0x97f6bc(0x177)&&_0x312a62(_0x59946f(_0x97f6bc(0x116),_0x1d0443,_0x29d139(),_0x9b859d,_0x2f73e4));},'consoleTrace':(_0x4f29ba,_0x40e0fb)=>{var _0x5ea07f=_0x4818fc,_0xb083e5,_0x274db5;_0x3cca3d[_0x5ea07f(0x176)][_0x5ea07f(0x116)][_0x5ea07f(0x1c3)]!==_0x5ea07f(0x107)&&((_0x274db5=(_0xb083e5=_0x3cca3d['process'])==null?void 0x0:_0xb083e5[_0x5ea07f(0x12a)])!=null&&_0x274db5[_0x5ea07f(0x128)]&&(_0x3cca3d[_0x5ea07f(0xe8)]=!0x0),_0x312a62(_0x2ee867(_0x59946f(_0x5ea07f(0x17c),_0x4f29ba,_0x29d139(),_0x9b859d,_0x40e0fb))));},'consoleError':(_0x2bc0da,_0x1c2aec)=>{var _0x1781f6=_0x4818fc;_0x3cca3d[_0x1781f6(0xe8)]=!0x0,_0x312a62(_0x2ee867(_0x59946f(_0x1781f6(0x1bb),_0x2bc0da,_0x29d139(),_0x9b859d,_0x1c2aec)));},'consoleTime':_0x39580d=>{_0x22921d(_0x39580d);},'consoleTimeEnd':(_0x3bc815,_0x207b89)=>{_0x45102e(_0x207b89,_0x3bc815);},'autoLog':(_0x1feae7,_0x412215)=>{var _0x28d3ed=_0x4818fc;_0x312a62(_0x59946f(_0x28d3ed(0x116),_0x412215,_0x29d139(),_0x9b859d,[_0x1feae7]));},'autoLogMany':(_0x2ec4aa,_0x3ebbc7)=>{_0x312a62(_0x59946f('log',_0x2ec4aa,_0x29d139(),_0x9b859d,_0x3ebbc7));},'autoTrace':(_0x1181a3,_0x59d6b5)=>{_0x312a62(_0x2ee867(_0x59946f('trace',_0x59d6b5,_0x29d139(),_0x9b859d,[_0x1181a3])));},'autoTraceMany':(_0x5d59ec,_0x321085)=>{var _0x254ed6=_0x4818fc;_0x312a62(_0x2ee867(_0x59946f(_0x254ed6(0x17c),_0x5d59ec,_0x29d139(),_0x9b859d,_0x321085)));},'autoTime':(_0x221590,_0x1740ad,_0x144e01)=>{_0x22921d(_0x144e01);},'autoTimeEnd':(_0x37d7ca,_0x1b7b6f,_0x52089f)=>{_0x45102e(_0x1b7b6f,_0x52089f);},'coverage':_0x2fe387=>{var _0xeb334b=_0x4818fc;_0x312a62({'method':_0xeb334b(0xdb),'version':_0x269295,'args':[{'id':_0x2fe387}]});}};let _0x312a62=H(_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x19f830,_0x5a3a2e),_0x9b859d=_0x3cca3d[_0x4818fc(0x1a5)];return _0x3cca3d[_0x4818fc(0x165)];})(globalThis,_0x54cc26(0x18f),_0x54cc26(0x155),_0x54cc26(0x14d),_0x54cc26(0x148),_0x54cc26(0xf7),'1763946797424',_0x54cc26(0x1c6),_0x54cc26(0x181),'','1',_0x54cc26(0x19b));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "TabsMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ComboboxMolecule",
    ()=>ComboboxMolecule,
    "ComboboxPresets",
    ()=>ComboboxPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/popover.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/popover-local.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/command-local.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
function ComboboxMolecule({ options, value, onChange, placeholder = 'Seleccionar opción...', searchPlaceholder = 'Buscar...', variant = 'default', disabled = false, clearable = true, searchable = true, className = '', emptyMessage = 'No se encontraron opciones', maxSelections = 10, onSearch, loading = false }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    // Local state
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [searchValue, setSearchValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [selectedValues, setSelectedValues] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(Array.isArray(value) ? value : value ? [
        value
    ] : []);
    // Update selected values when external value changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ComboboxMolecule.useEffect": ()=>{
            setSelectedValues(Array.isArray(value) ? value : value ? [
                value
            ] : []);
        }
    }["ComboboxMolecule.useEffect"], [
        value
    ]);
    // Handle selection
    const handleSelect = (optionValue)=>{
        if (variant === 'multiple') {
            const isSelected = selectedValues.includes(optionValue);
            let newValues;
            if (isSelected) {
                newValues = selectedValues.filter((v)=>v !== optionValue);
            } else {
                if (selectedValues.length >= maxSelections) return;
                newValues = [
                    ...selectedValues,
                    optionValue
                ];
            }
            setSelectedValues(newValues);
            onChange?.(newValues);
        } else {
            setSelectedValues([
                optionValue
            ]);
            onChange?.(optionValue);
            setIsOpen(false);
        }
    };
    // Handle search
    const handleSearch = (query)=>{
        setSearchValue(query);
        onSearch?.(query);
    };
    // Clear selection
    const handleClear = ()=>{
        setSelectedValues([]);
        onChange?.(variant === 'multiple' ? [] : '');
    };
    // Get display value
    const getDisplayValue = ()=>{
        if (selectedValues.length === 0) return placeholder;
        if (variant === 'multiple') {
            return `${selectedValues.length} seleccionados`;
        }
        const selectedOption = options.find((opt)=>opt.value === selectedValues[0]);
        return selectedOption?.label || selectedValues[0];
    };
    // Filter options based on search
    const filteredOptions = searchable && searchValue ? options.filter((option)=>option.label.toLowerCase().includes(searchValue.toLowerCase()) || option.description?.toLowerCase().includes(searchValue.toLowerCase())) : options;
    // Enhanced styles with better visual feedback
    const getTriggerStyles = ()=>({
            width: '100%',
            justifyContent: 'space-between',
            fontWeight: selectedValues.length > 0 ? 500 : 400,
            color: selectedValues.length > 0 ? colors?.foreground?.value || 'var(--color-foreground)' : colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
            minHeight: '40px',
            padding: `8px ${smallSpacing}`,
            borderRadius: 'var(--radius, 8px)',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            border: isOpen ? `2px solid ${colors?.primary?.value || 'var(--color-primary)'}` : `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            boxShadow: isOpen ? `0 0 0 2px ${colors?.primary?.value || 'var(--color-primary)'}20` : 'none'
        });
    const getPopoverStyles = ()=>({
            background: colors?.popover?.value || 'var(--color-popover)',
            border: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            borderRadius: 'var(--radius-popover, 12px)',
            boxShadow: `${shadows?.shadowLg || 'var(--shadow-lg)'}, 0 0 0 1px ${colors?.border?.value || 'var(--color-border)'}20`,
            minWidth: 'min(320px, calc(100vw - 40px))',
            maxWidth: 'min(420px, calc(100vw - 20px))',
            backdropFilter: 'blur(8px)',
            background: `${colors?.popover?.value || 'var(--color-popover)'}f8`,
            animation: 'slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            transformOrigin: 'var(--radix-popover-content-transform-origin)'
        });
    const getSelectedBadgesStyles = ()=>({
            display: 'flex',
            flexWrap: 'wrap',
            gap: '6px',
            maxHeight: '80px',
            overflowY: 'auto',
            padding: '4px 0',
            alignItems: 'center'
        });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Popover"], {
            open: isOpen,
            onOpenChange: setIsOpen,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverTrigger"], {
                    asChild: true,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        variant: "outline",
                        disabled: disabled,
                        style: getTriggerStyles(),
                        className: `
              text-left group relative overflow-hidden
              ${!disabled ? 'hover:bg-accent/50 hover:scale-[0.99] active:scale-[0.98]' : ''}
              ${isOpen ? 'bg-accent/30' : ''}
              transition-all duration-300 ease-out
            `,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    flex: 1,
                                    minWidth: 0
                                },
                                children: variant === 'multiple' && selectedValues.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: getSelectedBadgesStyles(),
                                    children: [
                                        selectedValues.slice(0, 3).map((val)=>{
                                            const option = options.find((opt)=>opt.value === val);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                variant: "secondary",
                                                size: "sm",
                                                style: {
                                                    fontSize: '11px',
                                                    fontWeight: 500,
                                                    borderRadius: '6px',
                                                    background: `${colors?.primary?.value || 'var(--color-primary)'}15`,
                                                    color: colors?.primary?.value || 'var(--color-primary)',
                                                    border: `1px solid ${colors?.primary?.value || 'var(--color-primary)'}30`,
                                                    transition: 'all 0.2s ease'
                                                },
                                                className: "hover:scale-105",
                                                children: option?.label || val
                                            }, val, false, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                lineNumber: 221,
                                                columnNumber: 23
                                            }, this);
                                        }),
                                        selectedValues.length > 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                            variant: "outline",
                                            size: "sm",
                                            style: {
                                                fontSize: '10px',
                                                fontWeight: 600,
                                                borderRadius: '6px',
                                                background: colors?.mutedForeground?.value + '10' || 'var(--color-muted-foreground)10',
                                                color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                                transition: 'all 0.2s ease'
                                            },
                                            className: "hover:scale-105",
                                            children: [
                                                "+",
                                                selectedValues.length - 3,
                                                " más"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                            lineNumber: 241,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                    lineNumber: 217,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "truncate",
                                    children: getDisplayValue()
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                    lineNumber: 259,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                lineNumber: 215,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    flexShrink: 0
                                },
                                children: [
                                    clearable && selectedValues.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                        variant: "ghost",
                                        size: "sm",
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            handleClear();
                                        },
                                        style: {
                                            width: '20px',
                                            height: '20px',
                                            padding: '0',
                                            borderRadius: '4px',
                                            transition: 'all 0.2s ease',
                                            background: 'transparent'
                                        },
                                        className: "hover:bg-destructive/20 hover:scale-110 active:scale-95",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                            className: "h-3 w-3",
                                            style: {
                                                color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                                transition: 'color 0.2s ease'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                            lineNumber: 287,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                        lineNumber: 270,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                        className: "h-4 w-4",
                                        style: {
                                            color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                            transition: 'transform 0.3s ease, color 0.2s ease',
                                            transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                        lineNumber: 293,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                lineNumber: 263,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                        lineNumber: 204,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                    lineNumber: 203,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$popover$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopoverContent"], {
                    style: getPopoverStyles(),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Command"], {
                        children: [
                            searchable && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandInput"], {
                                placeholder: searchPlaceholder,
                                value: searchValue,
                                onValueChange: handleSearch
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                lineNumber: 308,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandList"], {
                                children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        padding: `${mediumSpacing} ${smallSpacing}`,
                                        textAlign: 'center',
                                        color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        gap: '8px',
                                        minHeight: '60px'
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: '16px',
                                                height: '16px',
                                                border: `2px solid ${colors?.border?.value || 'var(--color-border)'}`,
                                                borderTop: `2px solid ${colors?.primary?.value || 'var(--color-primary)'}`,
                                                borderRadius: '50%',
                                                animation: 'spin 1s linear infinite'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                            lineNumber: 327,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                fontSize: '14px',
                                                fontWeight: 500
                                            },
                                            children: "Cargando..."
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                            lineNumber: 335,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                    lineNumber: 317,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandEmpty"], {
                                            children: emptyMessage
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                            lineNumber: 342,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandGroup"], {
                                            children: filteredOptions.map((option)=>{
                                                const isSelected = selectedValues.includes(option.value);
                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$command$2d$local$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CommandItem"], {
                                                    value: option.value,
                                                    onSelect: ()=>handleSelect(option.value),
                                                    disabled: option.disabled,
                                                    style: {
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: '12px',
                                                        padding: `10px ${smallSpacing}`,
                                                        cursor: option.disabled ? 'not-allowed' : 'pointer',
                                                        fontFamily: 'var(--typography-paragraph-font-family)',
                                                        fontSize: '14px',
                                                        opacity: option.disabled ? 0.5 : 1,
                                                        borderRadius: '6px',
                                                        margin: '2px 4px',
                                                        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
                                                        position: 'relative',
                                                        minHeight: '44px',
                                                        background: isSelected ? `${colors?.primary?.value || 'var(--color-primary)'}10` : 'transparent'
                                                    },
                                                    className: `
                            ${!option.disabled ? 'hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1' : ''}
                            ${isSelected ? 'bg-primary/5' : ''}
                            group transition-all duration-300 ease-out
                          `,
                                                    children: [
                                                        variant === 'multiple' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            style: {
                                                                width: '18px',
                                                                height: '18px',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'center',
                                                                border: `2px solid ${isSelected ? colors?.primary?.value || 'var(--color-primary)' : colors?.border?.value || 'var(--color-border)'}`,
                                                                borderRadius: '4px',
                                                                background: isSelected ? colors?.primary?.value || 'var(--color-primary)' : 'transparent',
                                                                transition: 'all 0.3s ease',
                                                                flexShrink: 0
                                                            },
                                                            children: isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                                className: "h-3 w-3",
                                                                style: {
                                                                    color: colors?.primaryForeground?.value || 'var(--color-primary-foreground)',
                                                                    animation: 'fadeIn 0.2s ease-in-out'
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                                lineNumber: 390,
                                                                columnNumber: 33
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                            lineNumber: 377,
                                                            columnNumber: 29
                                                        }, this),
                                                        option.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            style: {
                                                                flexShrink: 0,
                                                                width: '20px',
                                                                height: '20px',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'center',
                                                                borderRadius: '4px',
                                                                background: isSelected ? `${colors?.primary?.value || 'var(--color-primary)'}20` : 'transparent',
                                                                transition: 'all 0.3s ease'
                                                            },
                                                            className: "group-hover:bg-primary/20",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                style: {
                                                                    color: isSelected ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                                                    width: '16px',
                                                                    height: '16px',
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    justifyContent: 'center',
                                                                    transition: 'color 0.3s ease'
                                                                },
                                                                children: option.icon
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                                lineNumber: 413,
                                                                columnNumber: 31
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                            lineNumber: 402,
                                                            columnNumber: 29
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            style: {
                                                                flex: 1,
                                                                minWidth: 0
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    style: {
                                                                        color: isSelected ? colors?.primary?.value || 'var(--color-primary)' : colors?.foreground?.value || 'var(--color-foreground)',
                                                                        fontWeight: isSelected ? 600 : 450,
                                                                        lineHeight: 1.4,
                                                                        transition: 'all 0.3s ease'
                                                                    },
                                                                    className: "group-hover:font-medium",
                                                                    children: option.label
                                                                }, void 0, false, {
                                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                                    lineNumber: 428,
                                                                    columnNumber: 29
                                                                }, this),
                                                                option.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    style: {
                                                                        fontSize: '12px',
                                                                        color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                                                        marginTop: '2px',
                                                                        lineHeight: 1.3,
                                                                        transition: 'color 0.3s ease'
                                                                    },
                                                                    className: "group-hover:opacity-80",
                                                                    children: option.description
                                                                }, void 0, false, {
                                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                                    lineNumber: 437,
                                                                    columnNumber: 31
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                            lineNumber: 427,
                                                            columnNumber: 27
                                                        }, this),
                                                        option.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                            variant: isSelected ? 'default' : option.badge.variant || 'outline',
                                                            size: "sm",
                                                            style: {
                                                                flexShrink: 0,
                                                                fontSize: '11px',
                                                                fontWeight: 500,
                                                                transition: 'all 0.3s ease',
                                                                transform: isSelected ? 'scale(0.95)' : 'scale(0.9)'
                                                            },
                                                            className: "group-hover:scale-100 group-hover:shadow-sm",
                                                            children: option.badge.text
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                            lineNumber: 450,
                                                            columnNumber: 29
                                                        }, this),
                                                        !variant.includes('multiple') && isSelected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            style: {
                                                                width: '20px',
                                                                height: '20px',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'center',
                                                                borderRadius: '50%',
                                                                background: `${colors?.primary?.value || 'var(--color-primary)'}20`,
                                                                flexShrink: 0
                                                            },
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                                className: "h-4 w-4",
                                                                style: {
                                                                    color: colors?.primary?.value || 'var(--color-primary)',
                                                                    animation: 'fadeIn 0.2s ease-in-out'
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                                lineNumber: 477,
                                                                columnNumber: 31
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                            lineNumber: 467,
                                                            columnNumber: 29
                                                        }, this)
                                                    ]
                                                }, option.id, true, {
                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                                    lineNumber: 349,
                                                    columnNumber: 25
                                                }, this);
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                            lineNumber: 344,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true)
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                                lineNumber: 315,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                        lineNumber: 306,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
                    lineNumber: 305,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
            lineNumber: 202,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/ComboboxMolecule.tsx",
        lineNumber: 201,
        columnNumber: 5
    }, this);
}
_s(ComboboxMolecule, "/SxZ5PopLpMaasva9i7jUwr9BSo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = ComboboxMolecule;
const ComboboxPresets = {
    basic: {
        variant: 'default',
        searchable: true,
        clearable: true
    },
    multiple: {
        variant: 'multiple',
        searchable: true,
        clearable: true,
        maxSelections: 5
    },
    async: {
        variant: 'async',
        searchable: true,
        clearable: true,
        loading: false
    }
};
var _c;
__turbopack_context__.k.register(_c, "ComboboxMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NavigationMenuMolecule",
    ()=>NavigationMenuMolecule,
    "NavigationMenuPresets",
    ()=>NavigationMenuPresets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-client] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/external-link.js [app-client] (ecmascript) <export default as ExternalLink>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/navigation-menu.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/navigation-menu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function NavigationMenuMolecule({ items, variant = 'default', orientation = 'horizontal', className = '' }) {
    _s();
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const largeSpacing = `var(--spacing-large, ${baseValue * 4}px)`;
    // Styles
    const getContainerStyles = ()=>({
            marginBottom: largeSpacing
        });
    const getTriggerStyles = ()=>({
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: '14px',
            fontWeight: 500,
            color: colors?.foreground?.value || 'var(--color-foreground)',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: `10px ${smallSpacing}`,
            borderRadius: 'var(--radius, 8px)',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            position: 'relative',
            overflow: 'hidden',
            minHeight: '40px'
        });
    const getContentStyles = ()=>({
            background: colors?.popover?.value || 'var(--color-popover)',
            borderTop: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            borderRight: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            borderLeft: `1px solid ${colors?.border?.value || 'var(--color-border)'}`,
            borderRadius: 'var(--radius-popover, 12px)',
            boxShadow: `${shadows?.shadowLg || 'var(--shadow-lg)'}, 0 0 0 1px ${colors?.border?.value || 'var(--color-border)'}20`,
            padding: `${mediumSpacing} ${smallSpacing}`,
            minWidth: variant === 'featured' ? 'min(640px, calc(100vw - 40px))' : 'min(420px, calc(100vw - 40px))',
            maxWidth: 'calc(100vw - 20px)',
            backdropFilter: 'blur(8px)',
            background: `${colors?.popover?.value || 'var(--color-popover)'}f8`,
            animation: 'slideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            transformOrigin: 'var(--radix-navigation-menu-content-transform-origin)'
        });
    const getLinkStyles = (item, isSubItem = false)=>({
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: isSubItem ? '8px 12px' : `12px ${smallSpacing}`,
            borderRadius: 'var(--radius, 8px)',
            textDecoration: 'none',
            color: colors?.foreground?.value || 'var(--color-foreground)',
            fontFamily: 'var(--typography-paragraph-font-family)',
            fontSize: isSubItem ? '13px' : '14px',
            fontWeight: item.featured ? 600 : 450,
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
            cursor: 'pointer',
            position: 'relative',
            overflow: 'hidden',
            margin: '2px 0',
            minHeight: isSubItem ? '36px' : '44px',
            background: item.featured ? `${colors?.primary?.value || 'var(--color-primary)'}08` : 'transparent'
        });
    const getDescriptionStyles = ()=>({
            fontSize: 'calc(var(--typography-paragraph-font-size) * 0.875)',
            color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
            marginTop: '4px',
            lineHeight: '1.4'
        });
    // Render navigation items
    const renderNavigationItem = (item)=>{
        const hasChildren = item.children && item.children.length > 0;
        if (!hasChildren) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenuItem"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenuLink"], {
                    className: `
              ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["navigationMenuTriggerStyle"])()}
              group relative overflow-hidden
              hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm
              focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2
              transition-all duration-300 ease-out
            `,
                    href: item.href,
                    target: item.external ? '_blank' : undefined,
                    rel: item.external ? 'noopener noreferrer' : undefined,
                    style: getTriggerStyles(),
                    children: [
                        item.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: '20px',
                                height: '20px',
                                borderRadius: '4px',
                                backgroundColor: 'transparent',
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:bg-primary/20 group-focus:bg-primary/30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    color: 'inherit',
                                    width: '16px',
                                    height: '16px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                },
                                children: item.icon
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                lineNumber: 164,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 153,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 177,
                            columnNumber: 13
                        }, this),
                        item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: item.badge.variant || 'outline',
                            size: "sm",
                            style: {
                                fontSize: '11px',
                                fontWeight: 500,
                                borderRadius: '6px',
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:scale-105 group-hover:shadow-sm",
                            children: item.badge.text
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 180,
                            columnNumber: 15
                        }, this),
                        item.external && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                            className: "h-3 w-3",
                            style: {
                                opacity: 0.6,
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:opacity-80 group-hover:scale-110"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 197,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                    lineNumber: 139,
                    columnNumber: 11
                }, this)
            }, item.id, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                lineNumber: 138,
                columnNumber: 9
            }, this);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenuItem"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenuTrigger"], {
                    style: getTriggerStyles(),
                    className: `
            group relative overflow-hidden
            hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm
            focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2
            data-[state=open]:bg-accent/30 data-[state=open]:shadow-md
            transition-all duration-300 ease-out
          `,
                    children: [
                        item.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                width: '20px',
                                height: '20px',
                                borderRadius: '4px',
                                backgroundColor: 'transparent',
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:bg-primary/20 group-focus:bg-primary/30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    color: 'inherit',
                                    width: '16px',
                                    height: '16px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                },
                                children: item.icon
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                lineNumber: 236,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 225,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 249,
                            columnNumber: 11
                        }, this),
                        item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                            variant: item.badge.variant || 'outline',
                            size: "sm",
                            style: {
                                fontSize: '11px',
                                fontWeight: 500,
                                borderRadius: '6px',
                                transition: 'all 0.3s ease',
                                flexShrink: 0
                            },
                            className: "group-hover:scale-105 group-hover:shadow-sm",
                            children: item.badge.text
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 252,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                            className: "h-3 w-3",
                            style: {
                                transition: 'transform 0.3s ease',
                                flexShrink: 0,
                                opacity: 0.7
                            },
                            className: "group-data-[state=open]:rotate-180 group-hover:opacity-90"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                            lineNumber: 268,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                    lineNumber: 214,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenuContent"], {
                    style: getContentStyles(),
                    children: variant === 'featured' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'grid',
                            gridTemplateColumns: 'repeat(2, 1fr)',
                            gap: mediumSpacing
                        },
                        className: "max-sm:grid-cols-1 max-sm:gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        style: {
                                            fontFamily: 'var(--typography-h4-font-family)',
                                            fontSize: '16px',
                                            fontWeight: 600,
                                            color: colors?.foreground?.value || 'var(--color-foreground)',
                                            marginBottom: '12px',
                                            paddingBottom: '8px',
                                            borderBottom: `2px solid ${colors?.primary?.value || 'var(--color-primary)'}`,
                                            position: 'relative'
                                        },
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            style: {
                                                background: `linear-gradient(90deg, ${colors?.primary?.value || 'var(--color-primary)'}, ${colors?.primary?.value || 'var(--color-primary)'}80)`,
                                                backgroundClip: 'text',
                                                WebkitBackgroundClip: 'text',
                                                color: 'transparent'
                                            },
                                            children: "Destacados"
                                        }, void 0, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                            lineNumber: 298,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                        lineNumber: 288,
                                        columnNumber: 17
                                    }, this),
                                    item.children?.filter((child)=>child.featured).map((child)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: child.href,
                                            target: child.external ? '_blank' : undefined,
                                            rel: child.external ? 'noopener noreferrer' : undefined,
                                            style: getLinkStyles(child),
                                            className: `
                      block mb-2 group
                      hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm
                      focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1
                      transition-all duration-300 ease-out
                    `,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    flex: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        style: {
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '12px'
                                                        },
                                                        children: [
                                                            child.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                style: {
                                                                    display: 'flex',
                                                                    alignItems: 'center',
                                                                    justifyContent: 'center',
                                                                    width: '20px',
                                                                    height: '20px',
                                                                    borderRadius: '4px',
                                                                    backgroundColor: child.featured ? `${colors?.primary?.value || 'var(--color-primary)'}20` : 'transparent',
                                                                    transition: 'all 0.3s ease',
                                                                    flexShrink: 0
                                                                },
                                                                className: "group-hover:bg-primary/30",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    style: {
                                                                        color: child.featured ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                                                        width: '16px',
                                                                        height: '16px',
                                                                        display: 'flex',
                                                                        alignItems: 'center',
                                                                        justifyContent: 'center'
                                                                    },
                                                                    children: child.icon
                                                                }, void 0, false, {
                                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                                    lineNumber: 333,
                                                                    columnNumber: 29
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                                lineNumber: 322,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                style: {
                                                                    fontWeight: child.featured ? 600 : 450,
                                                                    color: child.featured ? colors?.primary?.value || 'var(--color-primary)' : 'inherit',
                                                                    transition: 'all 0.3s ease',
                                                                    flex: 1
                                                                },
                                                                className: "group-hover:font-medium",
                                                                children: child.label
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                                lineNumber: 345,
                                                                columnNumber: 25
                                                            }, this),
                                                            child.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                                variant: child.featured ? 'default' : child.badge.variant || 'outline',
                                                                size: "sm",
                                                                style: {
                                                                    fontSize: '11px',
                                                                    fontWeight: 500,
                                                                    borderRadius: '6px',
                                                                    flexShrink: 0,
                                                                    transition: 'all 0.3s ease'
                                                                },
                                                                className: "group-hover:scale-105",
                                                                children: child.badge.text
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                                lineNumber: 354,
                                                                columnNumber: 27
                                                            }, this),
                                                            child.external && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                                className: "h-3 w-3",
                                                                style: {
                                                                    opacity: 0.6,
                                                                    transition: 'all 0.3s ease',
                                                                    flexShrink: 0
                                                                },
                                                                className: "group-hover:opacity-80 group-hover:scale-110"
                                                            }, void 0, false, {
                                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                                lineNumber: 370,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                        lineNumber: 320,
                                                        columnNumber: 23
                                                    }, this),
                                                    child.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        style: getDescriptionStyles(),
                                                        children: child.description
                                                    }, void 0, false, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                        lineNumber: 382,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                lineNumber: 319,
                                                columnNumber: 21
                                            }, this)
                                        }, child.id, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                            lineNumber: 306,
                                            columnNumber: 19
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                lineNumber: 287,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        style: {
                                            fontFamily: 'var(--typography-h4-font-family)',
                                            fontSize: '16px',
                                            fontWeight: 600,
                                            color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                            marginBottom: '12px',
                                            paddingBottom: '8px',
                                            borderBottom: `1px solid ${colors?.border?.value || 'var(--color-border)'}40`,
                                            textTransform: 'uppercase',
                                            letterSpacing: '0.5px',
                                            fontSize: '12px'
                                        },
                                        children: "Más opciones"
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                        lineNumber: 393,
                                        columnNumber: 17
                                    }, this),
                                    item.children?.filter((child)=>!child.featured).map((child)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: child.href,
                                            target: child.external ? '_blank' : undefined,
                                            rel: child.external ? 'noopener noreferrer' : undefined,
                                            style: getLinkStyles(child, true),
                                            className: `
                      block mb-1 group
                      hover:bg-accent/60 hover:scale-[0.98] hover:shadow-sm
                      focus:bg-accent/80 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-1
                      transition-all duration-300 ease-out
                    `,
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    gap: '10px'
                                                },
                                                children: [
                                                    child.icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        style: {
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            justifyContent: 'center',
                                                            width: '18px',
                                                            height: '18px',
                                                            borderRadius: '4px',
                                                            backgroundColor: 'transparent',
                                                            transition: 'all 0.3s ease',
                                                            flexShrink: 0
                                                        },
                                                        className: "group-hover:bg-primary/20",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            style: {
                                                                color: 'inherit',
                                                                width: '14px',
                                                                height: '14px',
                                                                display: 'flex',
                                                                alignItems: 'center',
                                                                justifyContent: 'center'
                                                            },
                                                            children: child.icon
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                            lineNumber: 434,
                                                            columnNumber: 27
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                        lineNumber: 423,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        style: {
                                                            fontWeight: 450,
                                                            transition: 'font-weight 0.3s ease',
                                                            flex: 1
                                                        },
                                                        className: "group-hover:font-medium",
                                                        children: child.label
                                                    }, void 0, false, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                        lineNumber: 446,
                                                        columnNumber: 23
                                                    }, this),
                                                    child.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                        variant: child.badge.variant || 'outline',
                                                        size: "sm",
                                                        style: {
                                                            fontSize: '10px',
                                                            fontWeight: 500,
                                                            borderRadius: '4px',
                                                            flexShrink: 0,
                                                            transition: 'all 0.3s ease'
                                                        },
                                                        className: "group-hover:scale-105",
                                                        children: child.badge.text
                                                    }, void 0, false, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                        lineNumber: 454,
                                                        columnNumber: 25
                                                    }, this),
                                                    child.external && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                        className: "h-3 w-3",
                                                        style: {
                                                            opacity: 0.5,
                                                            transition: 'all 0.3s ease',
                                                            flexShrink: 0
                                                        },
                                                        className: "group-hover:opacity-70 group-hover:scale-110"
                                                    }, void 0, false, {
                                                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                        lineNumber: 470,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                lineNumber: 421,
                                                columnNumber: 21
                                            }, this)
                                        }, child.id, false, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                            lineNumber: 408,
                                            columnNumber: 19
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                lineNumber: 392,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                        lineNumber: 281,
                        columnNumber: 13
                    }, this) : // Default and compact layouts
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: variant === 'compact' ? 'flex' : 'block',
                            flexWrap: 'wrap',
                            gap: variant === 'compact' ? '8px' : '0'
                        },
                        children: item.children?.map((child)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: child.href,
                                target: child.external ? '_blank' : undefined,
                                rel: child.external ? 'noopener noreferrer' : undefined,
                                style: getLinkStyles(child),
                                className: variant === 'compact' ? 'inline-block' : 'block mb-2',
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                    },
                                    children: [
                                        child.icon,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                flex: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    style: {
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: '8px'
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: child.label
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                            lineNumber: 505,
                                                            columnNumber: 25
                                                        }, this),
                                                        child.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Badge"], {
                                                            variant: child.badge.variant || 'outline',
                                                            size: "sm",
                                                            children: child.badge.text
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                            lineNumber: 507,
                                                            columnNumber: 27
                                                        }, this),
                                                        child.external && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$external$2d$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ExternalLink$3e$__["ExternalLink"], {
                                                            className: "h-3 w-3"
                                                        }, void 0, false, {
                                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                            lineNumber: 511,
                                                            columnNumber: 44
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                    lineNumber: 504,
                                                    columnNumber: 23
                                                }, this),
                                                child.description && variant !== 'compact' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    style: getDescriptionStyles(),
                                                    children: child.description
                                                }, void 0, false, {
                                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                                    lineNumber: 514,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                            lineNumber: 503,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                    lineNumber: 501,
                                    columnNumber: 19
                                }, this)
                            }, child.id, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                                lineNumber: 493,
                                columnNumber: 17
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                        lineNumber: 487,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                    lineNumber: 279,
                    columnNumber: 9
                }, this)
            ]
        }, item.id, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
            lineNumber: 213,
            columnNumber: 7
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        style: getContainerStyles(),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenu"], {
            orientation: orientation,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$navigation$2d$menu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NavigationMenuList"], {
                style: {
                    flexDirection: orientation === 'vertical' ? 'column' : 'row',
                    alignItems: orientation === 'vertical' ? 'flex-start' : 'center',
                    gap: orientation === 'vertical' ? '8px' : '16px'
                },
                className: "max-sm:flex-wrap max-sm:justify-center max-sm:gap-2",
                children: items.map(renderNavigationItem)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
                lineNumber: 532,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
            lineNumber: 531,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/NavigationMenuMolecule.tsx",
        lineNumber: 530,
        columnNumber: 5
    }, this);
}
_s(NavigationMenuMolecule, "mIRfWfYBCLkiT9fCCRUByvPsoVU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = NavigationMenuMolecule;
const NavigationMenuPresets = {
    basic: {
        variant: 'default',
        orientation: 'horizontal'
    },
    compact: {
        variant: 'compact',
        orientation: 'horizontal'
    },
    featured: {
        variant: 'featured',
        orientation: 'horizontal'
    },
    vertical: {
        variant: 'default',
        orientation: 'vertical'
    }
};
var _c;
__turbopack_context__.k.register(_c, "NavigationMenuMolecule");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SonnerMolecule",
    ()=>SonnerMolecule,
    "ToastProvider",
    ()=>ToastProvider,
    "toast",
    ()=>toast,
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/check.js [app-client] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-client] (ecmascript) <export default as AlertTriangle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/info.js [app-client] (ecmascript) <export default as Info>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-client] (ecmascript) <export default as AlertCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
const ToastContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const useToast = ()=>{
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
    if (!context) {
        throw new Error('useToast must be used within a ToastProvider');
    }
    return context;
};
_s(useToast, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function ToastProvider({ children, maxToasts = 5, defaultPosition = 'bottom-right', defaultDuration = 4000 }) {
    _s1();
    const [toasts, setToasts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    // Theme integration
    const colors = state.themeMode === 'dark' ? state.currentTheme?.darkColors : state.currentTheme?.lightColors;
    const shadows = state.currentTheme?.shadows;
    const spacing = state.currentTheme?.spacing;
    // Spacing system
    const baseSpacing = spacing?.spacing || '2.2rem';
    const baseValue = parseFloat(baseSpacing.replace('rem', '')) * 16;
    const smallSpacing = `var(--spacing-small, ${baseValue}px)`;
    const mediumSpacing = `var(--spacing-medium, ${baseValue * 2}px)`;
    const addToast = (toast)=>{
        const id = Math.random().toString(36).substr(2, 9);
        const newToast = {
            ...toast,
            id,
            position: toast.position || defaultPosition,
            duration: toast.duration ?? defaultDuration,
            dismissible: toast.dismissible ?? true
        };
        setToasts((prev)=>{
            const filtered = prev.slice(-(maxToasts - 1));
            return [
                ...filtered,
                newToast
            ];
        });
        // Auto dismiss
        if (newToast.duration && newToast.duration > 0) {
            setTimeout(()=>{
                removeToast(id);
            }, newToast.duration);
        }
        return id;
    };
    const removeToast = (id)=>{
        setToasts((prev)=>prev.filter((toast)=>toast.id !== id));
    };
    const clearAll = ()=>{
        setToasts([]);
    };
    // Group toasts by position
    const groupedToasts = toasts.reduce((acc, toast)=>{
        const position = toast.position || defaultPosition;
        if (!acc[position]) acc[position] = [];
        acc[position].push(toast);
        return acc;
    }, {});
    // Enhanced icons with styling
    const getToastIcon = (type)=>{
        const iconStyles = {
            width: '18px',
            height: '18px',
            flexShrink: 0,
            transition: 'all 0.3s ease'
        };
        switch(type){
            case 'success':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        background: `${colors?.success?.value || 'var(--color-success)'}20`,
                        borderRadius: '50%',
                        padding: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                        style: {
                            ...iconStyles,
                            color: colors?.success?.value || 'var(--color-success)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                        lineNumber: 139,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 131,
                    columnNumber: 11
                }, this);
            case 'error':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        background: `${colors?.destructive?.value || 'var(--color-destructive)'}20`,
                        borderRadius: '50%',
                        padding: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                        style: {
                            ...iconStyles,
                            color: colors?.destructive?.value || 'var(--color-destructive)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                        lineNumber: 155,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 147,
                    columnNumber: 11
                }, this);
            case 'warning':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        background: `${colors?.warning?.value || '#f59e0b'}20`,
                        borderRadius: '50%',
                        padding: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertTriangle$3e$__["AlertTriangle"], {
                        style: {
                            ...iconStyles,
                            color: colors?.warning?.value || '#f59e0b'
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                        lineNumber: 171,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, this);
            case 'info':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        background: `${colors?.primary?.value || 'var(--color-primary)'}20`,
                        borderRadius: '50%',
                        padding: '4px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center'
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$info$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Info$3e$__["Info"], {
                        style: {
                            ...iconStyles,
                            color: colors?.primary?.value || 'var(--color-primary)'
                        }
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                        lineNumber: 187,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 179,
                    columnNumber: 11
                }, this);
            default:
                return null;
        }
    };
    // Enhanced toast type styles with gradients and better theming
    const getToastTypeStyles = (type)=>{
        const baseStyles = {
            backdropFilter: 'blur(12px)',
            borderRadius: 'var(--radius-card, 12px)',
            transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        };
        switch(type){
            case 'success':
                return {
                    ...baseStyles,
                    background: `linear-gradient(135deg, ${colors?.success?.value || 'var(--color-success)'}15, ${colors?.success?.value || 'var(--color-success)'}08)`,
                    color: colors?.foreground?.value || 'var(--color-foreground)',
                    border: `1px solid ${colors?.success?.value || 'var(--color-success)'}40`,
                    boxShadow: `0 8px 32px ${colors?.success?.value || 'var(--color-success)'}20, inset 0 1px 0 ${colors?.success?.value || 'var(--color-success)'}20`
                };
            case 'error':
                return {
                    ...baseStyles,
                    background: `linear-gradient(135deg, ${colors?.destructive?.value || 'var(--color-destructive)'}15, ${colors?.destructive?.value || 'var(--color-destructive)'}08)`,
                    color: colors?.foreground?.value || 'var(--color-foreground)',
                    border: `1px solid ${colors?.destructive?.value || 'var(--color-destructive)'}40`,
                    boxShadow: `0 8px 32px ${colors?.destructive?.value || 'var(--color-destructive)'}20, inset 0 1px 0 ${colors?.destructive?.value || 'var(--color-destructive)'}20`
                };
            case 'warning':
                return {
                    ...baseStyles,
                    background: `linear-gradient(135deg, ${colors?.warning?.value || '#f59e0b'}15, ${colors?.warning?.value || '#f59e0b'}08)`,
                    color: colors?.foreground?.value || 'var(--color-foreground)',
                    border: `1px solid ${colors?.warning?.value || '#f59e0b'}40`,
                    boxShadow: `0 8px 32px ${colors?.warning?.value || '#f59e0b'}20, inset 0 1px 0 ${colors?.warning?.value || '#f59e0b'}20`
                };
            case 'info':
                return {
                    ...baseStyles,
                    background: `linear-gradient(135deg, ${colors?.primary?.value || 'var(--color-primary)'}15, ${colors?.primary?.value || 'var(--color-primary)'}08)`,
                    color: colors?.foreground?.value || 'var(--color-foreground)',
                    border: `1px solid ${colors?.primary?.value || 'var(--color-primary)'}40`,
                    boxShadow: `0 8px 32px ${colors?.primary?.value || 'var(--color-primary)'}20, inset 0 1px 0 ${colors?.primary?.value || 'var(--color-primary)'}20`
                };
            default:
                return {
                    ...baseStyles,
                    background: `linear-gradient(135deg, ${colors?.background?.value || 'var(--color-background)'}f8, ${colors?.accent?.value || 'var(--color-accent)'}20)`,
                    color: colors?.foreground?.value || 'var(--color-foreground)',
                    border: `1px solid ${colors?.border?.value || 'var(--color-border)'}60`,
                    boxShadow: `0 8px 32px ${colors?.accent?.value || 'var(--color-accent)'}10, inset 0 1px 0 ${colors?.accent?.value || 'var(--color-accent)'}20`
                };
        }
    };
    // Get container position styles
    const getPositionStyles = (position)=>{
        const baseStyles = {
            position: 'fixed',
            zIndex: 9999,
            display: 'flex',
            flexDirection: 'column',
            gap: '8px',
            maxWidth: 'min(400px, calc(100vw - 40px))',
            padding: mediumSpacing
        };
        switch(position){
            case 'top-left':
                return {
                    ...baseStyles,
                    top: 0,
                    left: 0
                };
            case 'top-right':
                return {
                    ...baseStyles,
                    top: 0,
                    right: 0
                };
            case 'bottom-left':
                return {
                    ...baseStyles,
                    bottom: 0,
                    left: 0
                };
            case 'bottom-right':
                return {
                    ...baseStyles,
                    bottom: 0,
                    right: 0
                };
            case 'top-center':
                return {
                    ...baseStyles,
                    top: 0,
                    left: '50%',
                    transform: 'translateX(-50%)'
                };
            case 'bottom-center':
                return {
                    ...baseStyles,
                    bottom: 0,
                    left: '50%',
                    transform: 'translateX(-50%)'
                };
            default:
                return {
                    ...baseStyles,
                    bottom: 0,
                    right: 0
                };
        }
    };
    // Toast component
    const ToastComponent = ({ toast })=>{
        const typeStyles = getToastTypeStyles(toast.type);
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                ...typeStyles,
                padding: `${smallSpacing} ${smallSpacing}`,
                minWidth: 'min(320px, calc(100vw - 40px))',
                maxWidth: 'min(420px, calc(100vw - 20px))',
                display: 'flex',
                alignItems: 'flex-start',
                gap: '14px',
                animation: 'toastSlideIn 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
                fontFamily: 'var(--typography-paragraph-font-family)',
                fontSize: '14px',
                position: 'relative',
                overflow: 'hidden'
            },
            className: "group hover:scale-[1.02] hover:shadow-2xl transition-all duration-300 ease-out",
            children: [
                (toast.icon || toast.type) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        flexShrink: 0,
                        marginTop: '2px',
                        transition: 'transform 0.3s ease'
                    },
                    className: "group-hover:scale-110",
                    children: toast.icon || getToastIcon(toast.type)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 304,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        flex: 1,
                        minWidth: 0
                    },
                    children: [
                        toast.title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                fontWeight: 600,
                                marginBottom: toast.description ? '6px' : '0',
                                lineHeight: 1.4,
                                fontSize: '15px',
                                transition: 'all 0.3s ease'
                            },
                            className: "group-hover:font-bold",
                            children: toast.title
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                            lineNumber: 316,
                            columnNumber: 13
                        }, this),
                        toast.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                opacity: 0.8,
                                lineHeight: 1.5,
                                fontSize: '13px',
                                color: colors?.mutedForeground?.value || 'var(--color-muted-foreground)',
                                transition: 'opacity 0.3s ease'
                            },
                            className: "group-hover:opacity-90",
                            children: toast.description
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                            lineNumber: 328,
                            columnNumber: 13
                        }, this),
                        toast.action && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                marginTop: '10px'
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                variant: "ghost",
                                size: "sm",
                                onClick: toast.action.onClick,
                                style: {
                                    color: 'inherit',
                                    padding: '6px 12px',
                                    height: '32px',
                                    fontSize: '13px',
                                    fontWeight: 500,
                                    borderRadius: 'var(--radius, 6px)',
                                    transition: 'all 0.3s ease',
                                    background: 'rgba(255,255,255,0.1)',
                                    border: `1px solid ${colors?.border?.value || 'var(--color-border)'}40`,
                                    backdropFilter: 'blur(4px)'
                                },
                                className: "hover:scale-105 hover:shadow-md hover:bg-accent/30 active:scale-95",
                                children: toast.action.label
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                                lineNumber: 342,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                            lineNumber: 341,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 314,
                    columnNumber: 9
                }, this),
                toast.dismissible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    size: "sm",
                    onClick: ()=>removeToast(toast.id),
                    style: {
                        color: 'inherit',
                        width: '24px',
                        height: '24px',
                        padding: '0',
                        flexShrink: 0,
                        borderRadius: '50%',
                        transition: 'all 0.3s ease',
                        background: 'rgba(255,255,255,0.1)',
                        border: `1px solid ${colors?.border?.value || 'var(--color-border)'}20`,
                        opacity: 0.7
                    },
                    className: "hover:scale-110 hover:bg-destructive/20 hover:opacity-100 hover:shadow-md active:scale-90",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                        className: "h-3 w-3",
                        style: {
                            transition: 'transform 0.3s ease'
                        },
                        className: "group-hover:rotate-90"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                        lineNumber: 386,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 368,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
            lineNumber: 285,
            columnNumber: 7
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ToastContext.Provider, {
        value: {
            toasts,
            addToast,
            removeToast,
            clearAll
        },
        children: [
            children,
            Object.entries(groupedToasts).map(([position, positionToasts])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: getPositionStyles(position),
                    className: "jsx-50ac055182ee42a2",
                    children: positionToasts.map((toast)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ToastComponent, {
                            toast: toast
                        }, toast.id, false, {
                            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                            lineNumber: 407,
                            columnNumber: 13
                        }, this))
                }, position, false, {
                    fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
                    lineNumber: 405,
                    columnNumber: 9
                }, this)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "50ac055182ee42a2",
                children: "@keyframes toastSlideIn{0%{opacity:0;filter:blur(4px);transform:translate(100%)scale(.95)}50%{opacity:.8;filter:blur(2px);transform:translate(-5px)scale(1.02)}to{opacity:1;filter:blur();transform:translate(0)scale(1)}}@keyframes toastSlideOut{0%{opacity:1;filter:blur();transform:translate(0)scale(1)}to{opacity:0;filter:blur(4px);transform:translate(100%)scale(.95)}}@keyframes toastBounce{0%,20%,50%,80%,to{transform:translateY(0)}40%{transform:translateY(-4px)}60%{transform:translateY(-2px)}}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/molecules/SonnerMolecule.tsx",
        lineNumber: 400,
        columnNumber: 5
    }, this);
}
_s1(ToastProvider, "v+p4f5/iD5azewcPVpbWM0IOnRM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
_c = ToastProvider;
const toast = {
    success: _s2((message, options)=>{
        _s2();
        const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
        return context?.addToast({
            title: message,
            type: 'success',
            ...options
        });
    }, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU="),
    error: _s3((message, options)=>{
        _s3();
        const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
        return context?.addToast({
            title: message,
            type: 'error',
            ...options
        });
    }, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU="),
    warning: _s4((message, options)=>{
        _s4();
        const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
        return context?.addToast({
            title: message,
            type: 'warning',
            ...options
        });
    }, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU="),
    info: _s5((message, options)=>{
        _s5();
        const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
        return context?.addToast({
            title: message,
            type: 'info',
            ...options
        });
    }, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU="),
    default: _s6((message, options)=>{
        _s6();
        const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ToastContext);
        return context?.addToast({
            title: message,
            type: 'default',
            ...options
        });
    }, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=")
};
const SonnerMolecule = ToastProvider;
var _c;
__turbopack_context__.k.register(_c, "ToastProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=730ea_web_src_components_features_theme-editor-3_0_design-system_molecules_5f89a090._.js.map