(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/packages_web_src_f26a32ce._.js",
  "static/chunks/_80ca4205._.js"
],
    source: "dynamic"
});
