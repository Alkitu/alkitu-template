(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/packages/web/src/lib/react-query.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/react-query.ts
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
;
const queryClient = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
    defaultOptions: {
        queries: {
            staleTime: 5 * 60 * 1000,
            gcTime: 10 * 60 * 1000
        }
    }
});
const __TURBOPACK__default__export__ = queryClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/context/providers/ReactQueryProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/components/providers/ReactQueryProvider.tsx
__turbopack_context__.s([
    "default",
    ()=>ReactQueryProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$react$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/react-query.ts [app-client] (ecmascript)");
"use client";
;
;
;
function ReactQueryProvider({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
        client: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$react$2d$query$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/context/providers/ReactQueryProvider.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = ReactQueryProvider;
var _c;
__turbopack_context__.k.register(_c, "ReactQueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/locales/es/common.json (json)", ((__turbopack_context__) => {

__turbopack_context__.v(JSON.parse("{\"NotFound\":{\"title\":\"Página No Encontrada\",\"description\":\"La página que buscas no existe.\"},\"index\":{\"title\":\"Inicio\"},\"homepage\":{\"hero\":{\"badge\":\"🚀 Next.js 14 + NextAuth v5 + Prisma + MongoDB\",\"title\":\"La plantilla perfecta para tu\",\"titleHighlight\":\" próximo proyecto\",\"subtitle\":\"Ahorra semanas de desarrollo con nuestra plantilla completa. Autenticación, base de datos, dashboard admin, y más. Todo listo para producción.\",\"getTemplate\":\"Obtener Template - $99\",\"viewDemo\":\"Ver Demo\",\"quickInstall\":\"Instalación en 5 minutos\",\"freeUpdates\":\"Actualizaciones gratuitas\",\"dashboardScreenshot\":\"[PLACEHOLDER: Imagen/Video del producto]\",\"productPlaceholder\":\"[PLACEHOLDER: Imagen/Video del producto]\"},\"features\":{\"title\":\"Todo lo que necesitas incluido\",\"subtitle\":\"No pierdas tiempo configurando. Nuestra plantilla incluye todas las funcionalidades esenciales para tu aplicación moderna.\",\"auth\":{\"title\":\"Autenticación Completa\",\"description\":\"NextAuth v5 con Google, GitHub, email y autenticación por credenciales. Verificación de email incluida.\"},\"admin\":{\"title\":\"Panel de Admin\",\"description\":\"Dashboard completo para administrar usuarios, roles y permisos. Tablas con filtros, paginación y exportación.\"},\"database\":{\"title\":\"Base de Datos\",\"description\":\"Prisma ORM configurado con MongoDB. Esquemas de usuario, sesiones y tokens ya definidos.\"},\"ui\":{\"title\":\"UI Components\",\"description\":\"Shadcn/ui + Tailwind CSS. Componentes modernos, accesibles y totalmente personalizables.\"},\"i18n\":{\"title\":\"Internacionalización\",\"description\":\"Soporte multi-idioma configurado. Español e inglés incluidos, fácil agregar más idiomas.\"},\"production\":{\"title\":\"Listo para Producción\",\"description\":\"Configuración de TypeScript, ESLint, Prettier. Optimizado para Vercel y otros providers.\"}},\"pricing\":{\"title\":\"Precio simple, valor infinito\",\"subtitle\":\"Una sola compra, uso ilimitado en todos tus proyectos\",\"badge\":\"🔥 Oferta de Lanzamiento\",\"planTitle\":\"Template Completo\",\"price\":\"$99\",\"originalPrice\":\"$199\",\"discount\":\"50% OFF\",\"description\":\"Pago único • Uso ilimitado • Actualizaciones incluidas\",\"features\":{\"sourceCode\":\"Código fuente completo\",\"nextjs\":\"Next.js 14 + App Router\",\"nextauth\":\"NextAuth v5\",\"database\":\"Prisma + MongoDB\",\"ui\":\"Shadcn/ui + Tailwind\",\"adminPanel\":\"Panel de administración\",\"userManagement\":\"Gestión de usuarios\",\"email\":\"Email con Resend\",\"i18n\":\"Soporte multi-idioma\",\"documentation\":\"Documentación completa\"},\"buyNow\":\"Comprar Ahora - $99\",\"guarantee\":\"Garantía de devolución de 30 días\"},\"footer\":{\"title\":\"Alkitu Template\",\"description\":\"La plantilla de Next.js más completa para desarrolladores modernos.\",\"product\":\"Producto\",\"features\":\"Características\",\"pricing\":\"Precios\",\"demo\":\"Demo\",\"support\":\"Soporte\",\"documentation\":\"Documentación\",\"contact\":\"Contacto\",\"faq\":\"FAQ\",\"legal\":\"Legal\",\"privacy\":\"Privacidad\",\"terms\":\"Términos\",\"license\":\"Licencia\",\"copyright\":\"© 2024 Alkitu Template. Todos los derechos reservados.\"}},\"navbar\":{\"title\":\"Alkitu Template\",\"language\":\"Idioma\",\"spanish\":\"Español\",\"english\":\"Inglés\",\"login\":\"Iniciar Sesión\",\"register\":\"Registrarse\",\"logout\":\"Cerrar Sesión\"},\"Metadata\":{\"title\":\"Alkitu Template - Plantilla Next.js Completa\",\"description\":\"La plantilla Next.js más completa con autenticación, base de datos, panel de administración y más.\",\"trainingIBMTitle\":\"Entrenamiento IBM\",\"trainingIBMDescription\":\"Capacitación profesional especializada\",\"contactTitle\":\"Contacto\",\"contactDescription\":\"Ponte en contacto con nosotros\"},\"auth\":{\"backToHome\":\"Volver al Inicio\",\"backToLogin\":\"Volver al Login\",\"socialDivider\":\"O continuar con\",\"socialPlaceholder\":\"Los proveedores OAuth serán configurados con el backend\",\"login\":{\"title\":\"Iniciar Sesión\",\"subtitle\":\"Ingresa los detalles de tu cuenta para continuar\",\"email\":\"Correo electrónico\",\"password\":\"Contraseña\",\"submit\":\"Iniciar sesión con correo\",\"newPassword\":\"Ingresa una nueva contraseña\",\"backToLogin\":\"Volver a la página de inicio de sesión\",\"success\":\"Inicio de sesión exitoso\",\"forgotPassword\":\"¿Olvidaste tu contraseña?\",\"emailLogin\":\"accede con código de email\",\"error\":\"Error al iniciar sesión\"},\"register\":{\"title\":\"Crear una cuenta\",\"subtitle\":\"Completa los siguientes campos para crear tu cuenta\",\"email\":\"Correo electrónico\",\"password\":\"Contraseña\",\"confirmPassword\":\"Confirmar contraseña\",\"name\":\"Nombre\",\"lastName\":\"Apellido\",\"phone\":\"Número de contacto\",\"submit\":\"Registrarse con correo\",\"terms\":\"Acepto los términos y condiciones\",\"termsRequired\":\"Debes aceptar los términos y condiciones\",\"success\":\"¡Registro exitoso!\",\"error\":\"Error al registrarse\"},\"verifyRequest\":{\"title\":\"Revisa tu correo\",\"message1\":\"Se ha enviado un enlace de inicio de sesión a\",\"message2\":\"tu dirección de correo electrónico\"},\"newVerification\":{\"title\":\"Verificar tu correo\",\"message\":\"Verificando tu correo electrónico...\",\"success\":\"¡Email verificado exitosamente!\",\"error\":\"Error verificando el email\",\"invalidToken\":\"Token inválido o faltante\",\"resendEmail\":\"Reenviar email de verificación\",\"redirecting\":\"Redirigiendo a la página de inicio de sesión...\"},\"forgotPassword\":{\"title\":\"¿Olvidaste tu contraseña?\",\"description\":\"Ingresa tu correo electrónico y te enviaremos un enlace para restablecer tu contraseña\",\"emailLabel\":\"Correo electrónico\",\"emailPlaceholder\":\"tu@email.com\",\"submit\":\"Enviar enlace de restablecimiento\",\"error\":\"Error enviando el email de restablecimiento\",\"success\":\"Se ha enviado un email con las instrucciones\"},\"newPassword\":{\"title\":\"Nueva Contraseña\",\"description\":\"Ingresa tu nueva contraseña\",\"submit\":\"Restablecer contraseña\",\"success\":\"¡Contraseña restablecida exitosamente!\",\"error\":\"Error al restablecer la contraseña\",\"invalidToken\":\"Token inválido o faltante\",\"passwordMismatch\":\"Las contraseñas no coinciden\"},\"resetPassword\":{\"title\":\"Restablecer Contraseña\",\"description\":\"Ingresa tu nueva contraseña\",\"invalidToken\":\"El enlace de restablecimiento es inválido o ha expirado\",\"tokenMissing\":\"Token de restablecimiento no encontrado\",\"loading\":\"Verificando enlace...\",\"newPassword\":\"Nueva contraseña\",\"confirmPassword\":\"Confirmar contraseña\",\"passwordPlaceholder\":\"Mínimo 6 caracteres\",\"confirmPasswordPlaceholder\":\"Repite tu nueva contraseña\",\"passwordMismatch\":\"Las contraseñas no coinciden\",\"passwordTooShort\":\"La contraseña debe tener al menos 6 caracteres\",\"submit\":\"Actualizar contraseña\",\"error\":\"Error actualizando la contraseña\",\"success\":\"Contraseña actualizada exitosamente\"},\"verifyLoginCode\":{\"title\":\"Verificar Código de Inicio de Sesión\",\"description\":\"Hemos enviado un código de 6 dígitos a:\",\"emailMissing\":\"Correo electrónico no encontrado\",\"loading\":\"Verificando correo...\",\"codeLabel\":\"Código de verificación\",\"submit\":\"Verificar código\",\"error\":\"Error verificando el código\",\"success\":\"¡Código verificado correctamente!\",\"resendCode\":\"Reenviar código\",\"resendIn\":\"Reenviar código en\",\"useOtherEmail\":\"Usar otro email\",\"invalidCode\":\"Código inválido o expirado\",\"codeRequired\":\"Por favor ingresa el código completo de 6 dígitos\"},\"emailLogin\":{\"title\":\"Iniciar Sesión con Correo\",\"description\":\"Ingresa tu correo electrónico para recibir un código de inicio de sesión\",\"emailLabel\":\"Correo electrónico\",\"emailPlaceholder\":\"tu@email.com\",\"submit\":\"Enviar código de acceso\",\"error\":\"Error enviando el código de acceso\",\"success\":\"Se ha enviado un código de acceso a tu email\",\"noAccount\":\"¿No tienes cuenta?\",\"registerHere\":\"Regístrate aquí\"},\"loading\":\"Cargando...\",\"error\":{\"title\":\"Error de Autenticación\",\"message\":\"Algo salió mal. Por favor, inténtalo de nuevo.\"},\"unauthorized\":{\"title\":\"Acceso Denegado\",\"description\":\"No tienes permisos para acceder a esta página\",\"message\":\"Por favor, contacta con el administrador si crees que esto es un error.\",\"goToDashboard\":\"Ir al Dashboard\",\"goToLogin\":\"Iniciar Sesión\"},\"routes\":{\"auth\":\"Autenticación\",\"login\":\"Iniciar Sesión\",\"register\":\"Registrarse\",\"resetPassword\":\"Restablecer Contraseña\",\"newPassword\":\"Nueva Contraseña\",\"newVerification\":\"Nueva Verificación\",\"verifyRequest\":\"Solicitud de Verificación\"},\"onboarding\":{\"title\":\"Completa tu perfil\",\"subtitle\":\"Ayúdanos a conocerte mejor para personalizar tu experiencia\",\"phone\":\"Teléfono (opcional)\",\"company\":\"Empresa (opcional)\",\"address\":\"Dirección (opcional)\",\"addContactPerson\":\"Agregar persona de contacto\",\"contactPersonInfo\":\"Información de contacto\",\"contactName\":\"Nombre\",\"contactLastname\":\"Apellido\",\"contactPhone\":\"Teléfono\",\"contactEmail\":\"Email\",\"skipButton\":\"Completar después\",\"submitButton\":\"Completar perfil\",\"contactPersonRequired\":\"Por favor complete todos los campos de la persona de contacto\",\"success\":\"¡Perfil completado exitosamente!\",\"error\":\"Error al completar perfil\"}},\"admin\":{\"dashboard\":{\"title\":\"Panel de Administración\",\"userManagement\":{\"title\":\"Gestión de Usuarios\",\"description\":\"Gestionar usuarios, roles y permisos\",\"viewUsers\":\"Ver Usuarios\"},\"settings\":{\"title\":\"Configuración\",\"description\":\"Configurar ajustes de la aplicación\"},\"analytics\":{\"title\":\"Analíticas\",\"description\":\"Ver analíticas e informes de la aplicación\"}},\"users\":{\"form\":{\"name\":\"Nombre\",\"lastName\":\"Apellido\",\"email\":\"Correo electrónico\",\"phone\":\"Teléfono\",\"userInfo\":\"Información del Usuario:\",\"accessLevel\":\"Nivel de Acceso:\",\"userId\":\"ID del Usuario:\",\"actions\":\"Acciones:\",\"twoFactor\":\"Autenticación de Dos Factores\",\"errors\":{\"somethingWrong\":\"Algo salió mal\",\"somethingWrongMessage\":\"Algo salió mal: {message}\"}}},\"routes\":{\"admin\":\"Administración\",\"users\":\"Usuarios\",\"dashboard\":\"Panel\"}},\"dashboard\":{\"nav\":{\"overview\":\"Dashboard\",\"users\":\"Usuarios\",\"userList\":\"Lista de Usuarios\",\"createUser\":\"Crear Usuario\",\"companies\":\"Empresas\",\"companiesList\":\"Todas las Empresas\",\"createCompany\":\"Nueva Empresa\",\"chat\":\"Chat\",\"conversations\":\"Conversaciones\",\"chatAnalytics\":\"Analíticas Chat\",\"notifications\":\"Notificaciones\",\"allNotifications\":\"Todas las Notificaciones\",\"notificationAnalytics\":\"Analíticas\",\"notificationPreferences\":\"Preferencias\",\"messaging\":\"Mensajería\",\"emailManagement\":\"Gestión de Email\",\"security\":\"Seguridad\",\"dataProtection\":\"Protección de Datos\",\"settings\":\"Configuración\",\"settingsGeneral\":\"General\",\"settingsChatbot\":\"Chatbot\",\"settingsThemes\":\"Temas\",\"billing\":\"Facturación\",\"analytics\":\"Analíticas\",\"reports\":\"Reportes\",\"insights\":\"Insights\",\"projects\":\"Proyectos\",\"activeProjects\":\"Proyectos Activos\",\"archived\":\"Archivados\",\"profile\":\"Mi Perfil\",\"account\":\"Cuenta\",\"privacy\":\"Privacidad\",\"docs\":\"Documentación\",\"help\":\"Ayuda\",\"dashboard\":\"Dashboard\",\"home\":\"Inicio\",\"preferences\":\"Preferencias\"},\"projects\":{\"alkitu\":\"Plataforma Alkitu\"},\"teams\":{\"development\":\"Equipo de Desarrollo\"}},\"navigation\":{\"platform\":\"Plataforma\",\"user\":{\"upgradeToPro\":\"Actualizar a Pro\",\"account\":\"Cuenta\",\"billing\":\"Facturación\",\"notifications\":\"Notificaciones\",\"logout\":\"Cerrar sesión\"}},\"notifications\":{\"title\":\"Notificaciones\",\"subtitle\":\"Administra tus notificaciones y mantente actualizado con las últimas actividades.\",\"fastMode\":\"Modo Rápido\",\"unread\":\"sin leer\",\"loaded\":\"cargadas\",\"onPage\":\"en página\",\"exportCsv\":\"Exportar CSV\",\"markAsRead\":\"Marcar como leída\",\"markPageAsRead\":\"Marcar página como leída\",\"markLoadedAsRead\":\"Marcar cargadas como leídas\",\"filteredResults\":\"Resultados filtrados\",\"allNotifications\":\"Todas las notificaciones\",\"moreAvailable\":\"más disponibles\",\"total\":\"total\",\"preferencesButton\":\"Preferencias\",\"noNotifications\":\"Sin notificaciones\",\"noNotificationsDescription\":\"¡Estás al día! Las nuevas notificaciones aparecerán aquí.\",\"noMatchingFilters\":\"Ninguna notificación coincide con tus filtros\",\"noMatchingFiltersDescription\":\"Intenta ajustar tus criterios de búsqueda o limpiar algunos filtros.\",\"buttomAnalytics\":\"Analíticas\",\"analytics\":{\"back\":\"Volver a Notificaciones\",\"title\":\"Analítica de Notificaciones\",\"description\":\"Estadísticas e información detallada sobre tu actividad de notificaciones.\"},\"filters\":{\"title\":\"Filtrar Notificaciones\",\"showing\":\"Mostrando\",\"showingAll\":\"Mostrando todas\",\"notifications\":\"notificaciones\",\"of\":\"de\",\"filter\":\"filtro\",\"active\":\"activos\",\"searchPlaceholder\":\"Buscar notificaciones... (prueba 'type:security' o 'urgent OR maintenance')\",\"advancedSearchTips\":\"Consejos de Búsqueda Avanzada:\",\"advancedTip1\":\"Usa comillas para frases exactas: \\\"actualización del sistema\\\"\",\"advancedTip2\":\"Usa OR para múltiples términos: seguridad OR urgente\",\"advancedTip3\":\"Usa - para excluir términos: notificación -spam\",\"advancedTip4\":\"Usa type: para filtrar por tipo: type:seguridad\",\"quickFilters\":\"Filtros rápidos:\",\"savedFilters\":\"Filtros Guardados:\",\"save\":\"Guardar\",\"clearAll\":\"Limpiar todo\",\"unread\":\"Sin leer\",\"read\":\"Leídas\",\"all\":\"Todas\",\"notificationTypes\":\"Tipos de Notificaciones\",\"dateRange\":\"Rango de Fechas\",\"pickDate\":\"Seleccionar rango de fechas\",\"clearDateRange\":\"Limpiar rango de fechas\",\"sortBy\":\"Ordenar por\",\"newest\":\"Más recientes\",\"oldest\":\"Más antiguas\",\"type\":\"Por tipo\",\"saved\":\"Guardado\",\"apply\":\"Aplicar\",\"saveCurrentFilters\":\"Guardar filtros actuales\",\"filterName\":\"Nombre del filtro\",\"activeFilters\":\"Filtros activos:\",\"today\":\"Hoy\",\"yesterday\":\"Ayer\",\"last7Days\":\"Últimos 7 días\",\"last30Days\":\"Últimos 30 días\",\"thisMonth\":\"Este mes\",\"lastMonth\":\"Mes pasado\",\"filters\":\"Filtros\",\"selectSorting\":\"Seleccionar ordenamiento\",\"search\":\"Búsqueda\",\"status\":\"Estado\",\"dateRangeSelected\":\"Rango de fechas seleccionado\",\"sort\":\"Ordenar\",\"cancel\":\"Cancelar\"},\"types\":{\"welcome\":\"Bienvenida\",\"security\":\"Seguridad\",\"system\":\"Sistema\",\"report\":\"Reportes\",\"feature\":\"Características\",\"maintenance\":\"Mantenimiento\",\"urgent\":\"Urgente\",\"info\":\"Información\",\"mentions\":\"Menciones\"},\"preferences\":{\"title\":\"Preferencias de Notificaciones\",\"subtitle\":\"Personaliza cómo y cuándo recibir notificaciones.\",\"resetToDefaults\":\"Restablecer a Valores Predeterminados\",\"resetting\":\"Restableciendo...\",\"savePreferences\":\"Guardar Preferencias\",\"saving\":\"Guardando...\",\"successUpdate\":\"¡Preferencias actualizadas exitosamente!\",\"errorUpdate\":\"Error al actualizar preferencias\",\"successReset\":\"¡Preferencias restablecidas a valores predeterminados!\",\"errorReset\":\"Error al restablecer preferencias\",\"email\":{\"title\":\"Notificaciones por Email\",\"description\":\"Configura los ajustes de notificaciones por email y frecuencia.\",\"enable\":\"Habilitar Notificaciones por Email\",\"enableDescription\":\"Recibir notificaciones vía email\",\"frequency\":\"Frecuencia de Email\",\"frequencyDescription\":\"Con qué frecuencia quieres recibir notificaciones por email\",\"selectFrequency\":\"Seleccionar frecuencia\",\"immediate\":\"Inmediato\",\"hourly\":\"Resumen por hora\",\"daily\":\"Resumen diario\",\"weekly\":\"Resumen semanal\",\"types\":\"Tipos de Notificaciones por Email\",\"typesDescription\":\"Selecciona qué tipos de notificaciones quieres recibir por email\"},\"push\":{\"title\":\"Preferencias de Notificaciones Push\",\"description\":\"Configura qué tipos de notificaciones push quieres recibir.\",\"enable\":\"Habilitar Notificaciones Push\",\"enableDescription\":\"Permitir notificaciones push para esta cuenta\",\"types\":\"Tipos de Notificaciones Push\",\"typesDescription\":\"Selecciona qué tipos de notificaciones quieres recibir como notificaciones push\",\"browserSettings\":\"Configuración de Notificaciones Push del Navegador\",\"browserDescription\":\"Administra los permisos de notificaciones push de tu navegador y prueba la funcionalidad.\",\"status\":\"Estado\",\"granted\":\"Permitido\",\"denied\":\"Denegado\",\"default\":\"Predeterminado\",\"subscribe\":\"Suscribirse\",\"unsubscribe\":\"Desuscribirse\",\"testNotification\":\"Notificación de Prueba\",\"subscription\":\"Suscripción\",\"active\":\"Activo\",\"inactive\":\"Inactivo\",\"subscribed\":\"¡Suscrito exitosamente!\",\"unsubscribed\":\"¡Desuscrito exitosamente!\",\"testSent\":\"¡Notificación de prueba enviada!\",\"errorSubscribe\":\"Error al suscribirse a notificaciones push\",\"errorUnsubscribe\":\"Error al desuscribirse de notificaciones push\",\"errorTest\":\"Error al enviar notificación de prueba\",\"blocked\":\"Las notificaciones push están bloqueadas. Para habilitarlas:\",\"blockedStep1\":\"1. Haz clic en el ícono de candado en la barra de direcciones de tu navegador\",\"blockedStep2\":\"2. Configura las notificaciones en \\\"Permitir\\\"\",\"blockedStep3\":\"3. Actualiza la página e inténtalo de nuevo\",\"disabledInfo\":\"Las notificaciones push están deshabilitadas en tus preferencias. Habilítalas arriba para administrar la configuración del navegador.\"},\"inApp\":{\"title\":\"Notificaciones en la Aplicación\",\"description\":\"Configura las notificaciones mostradas dentro de la aplicación.\",\"enable\":\"Habilitar Notificaciones en la Aplicación\",\"enableDescription\":\"Mostrar notificaciones dentro de la aplicación\"},\"quietHours\":{\"title\":\"Horas de Silencio\",\"description\":\"Configura horarios en los que no quieres recibir notificaciones.\",\"enable\":\"Habilitar Horas de Silencio\",\"enableDescription\":\"Deshabilitar notificaciones durante horas específicas\",\"start\":\"Hora de Inicio\",\"end\":\"Hora de Fin\",\"format\":\"La hora debe estar en formato HH:mm\"},\"marketing\":{\"title\":\"Marketing y Promocional\",\"description\":\"Administra las comunicaciones de marketing y promocionales.\",\"marketing\":\"Comunicaciones de Marketing\",\"marketingDescription\":\"Recibir emails de marketing y actualizaciones\",\"promotional\":\"Ofertas Promocionales\",\"promotionalDescription\":\"Recibir ofertas especiales y descuentos\"},\"notificationTypes\":{\"welcome\":{\"label\":\"Mensajes de bienvenida\",\"description\":\"Bienvenida de nuevos usuarios e incorporación\"},\"security\":{\"label\":\"Alertas de seguridad\",\"description\":\"Intentos de inicio de sesión y problemas de seguridad\"},\"system\":{\"label\":\"Actualizaciones del sistema\",\"description\":\"Mantenimiento y notificaciones del sistema\"},\"urgent\":{\"label\":\"Notificaciones urgentes\",\"description\":\"Alertas críticas y sensibles al tiempo\"},\"mentions\":{\"label\":\"Menciones\",\"description\":\"Cuando eres mencionado o etiquetado\"},\"reports\":{\"label\":\"Reportes\",\"description\":\"Reportes semanales y mensuales\"},\"features\":{\"label\":\"Nuevas características\",\"description\":\"Actualizaciones de producto y nuevas características\"}}}},\"Common\":{\"loading\":\"Cargando...\",\"save\":\"Guardar\",\"cancel\":\"Cancelar\",\"yes\":\"Sí\",\"no\":\"No\",\"openMenu\":\"Abrir menú\",\"pagination\":{\"previous\":\"Anterior\",\"next\":\"Siguiente\",\"morePages\":\"Más páginas\"},\"general\":{\"loading\":\"Cargando...\",\"pageNotFound\":\"Página no encontrada\",\"currentLanguage\":\"Idioma actual\",\"home\":\"Inicio\",\"contact\":\"Contacto\",\"about\":\"Acerca de\",\"services\":\"Servicios\",\"welcome\":\"Bienvenido\",\"logout\":\"Cerrar sesión\",\"loadingError\":\"Error de carga\"},\"errorMessages\":{\"loadingError\":\"Error de carga\"},\"columns\":{\"id\":\"ID\",\"data\":\"Datos\",\"select\":\"Seleccionar\",\"all\":\"Todos\",\"createdAt\":\"Creado en\",\"updatedAt\":\"Actualizado en\",\"contacts\":\"Contactos\",\"month\":\"Mes\",\"year\":\"Año\",\"actions\":\"Acciones\",\"originalType\":\"Tipo original\",\"dayOfMonth\":\"Día del mes\"},\"backups\":{\"current\":{\"title\":\"Actual\",\"description\":\"Backup actual\"},\"daily\":{\"title\":\"Diario\",\"description\":\"Backup diario\"},\"monthly\":{\"title\":\"Mensual\",\"description\":\"Backup mensual\"},\"favorite\":{\"title\":\"Favorito\",\"description\":\"Backup favorito\"},\"actions\":{\"createUpdateCurrent\":\"Crear/Actualizar actual\",\"createUpdateDaily\":\"Crear/Actualizar diario\",\"createUpdateMonthly\":\"Crear/Actualizar mensual\"},\"noBackupsFound\":\"No se encontraron backups\"},\"actions\":{\"delete\":\"Eliminar\",\"confirm\":\"Confirm\",\"cancel\":\"Cancelar\",\"viewDetails\":\"Ver detalles\",\"copy\":\"Copiar\",\"copied\":\"Copiado\",\"copySuccessTitle\":\"Copiado exitosamente\",\"copySuccessDescription\":\"El contenido ha sido copiado al portapapeles\",\"create\":\"Crear\",\"edit\":\"Editar\"},\"modals\":{\"confirmation\":{\"title\":\"Confirmación\",\"deleteDescription\":\"¿Estás seguro de que quieres eliminar este elemento?\",\"processingDescription\":\"Procesando...\"},\"deletion\":{\"title\":\"Eliminación\",\"description\":\"Eliminando elemento...\"},\"creatingUpdating\":{\"title\":\"Creando/Actualizando\",\"description\":\"Guardando cambios...\"},\"toggleFavorite\":{\"title\":\"Favorito\",\"adding\":\"Agregando a favoritos...\",\"removing\":\"Eliminando de favoritos...\"}},\"toasts\":{\"success\":{\"title\":\"Éxito\",\"description\":\"Operación completada exitosamente\"},\"error\":{\"title\":\"Error\",\"description\":\"Ocurrió un error\"}},\"currentBackupTab\":{\"title\":\"Backup Actual\",\"description\":\"Información del backup actual\",\"contacts\":\"Contactos\",\"createUpdateButton\":\"Crear/Actualizar\"},\"backupDetails\":{\"title\":\"Detalles del Backup\",\"itemsPerPage\":\"Elementos por página\",\"page\":\"Página\",\"of\":\"de\",\"data\":\"Datos\",\"select\":\"Seleccionar\",\"all\":\"Todos\",\"previous\":\"Anterior\",\"next\":\"Siguiente\"},\"backupActions\":{\"alreadyInFavorites\":\"Ya en favoritos\",\"addToFavorites\":\"Agregar a favoritos\",\"viewDetails\":\"Ver detalles\",\"deleteBackup\":\"Eliminar backup\"},\"dataTable\":{\"noFavoriteBackups\":\"No hay backups favoritos\"}},\"home\":{\"hero\":{\"title\":\"La plantilla perfecta para tu\",\"titleSpan\":\"próximo proyecto\",\"description\":\"Ahorra semanas de desarrollo con nuestra plantilla completa. Autenticación, base de datos, dashboard admin, y más. Todo listo para producción.\",\"ctaBuy\":\"Obtener Template - $99\",\"ctaDemo\":\"Ver Demo\",\"feature1\":\"Instalación en 5 minutos\",\"feature2\":\"Actualizaciones gratuitas\",\"dashboardScreenshot\":\"Captura de pantalla del dashboard\",\"placeholderImage\":\"[PLACEHOLDER: Imagen/Video del producto]\"},\"features\":{\"title\":\"Todo lo que necesitas incluido\",\"description\":\"No pierdas tiempo configurando. Nuestra plantilla incluye todas las funcionalidades esenciales para tu aplicación moderna.\",\"auth\":{\"title\":\"Autenticación Completa\",\"description\":\"NextAuth v5 con Google, GitHub, email y autenticación por credenciales. Verificación de email incluida.\"},\"adminPanel\":{\"title\":\"Panel de Admin\",\"description\":\"Dashboard completo para administrar usuarios, roles y permisos. Tablas con filtros, paginación y exportación.\"},\"database\":{\"title\":\"Base de Datos\",\"description\":\"Prisma ORM configurado con MongoDB. Esquemas de usuario, sesiones y tokens ya definidos.\"},\"uiComponents\":{\"title\":\"UI Components\",\"description\":\"Shadcn/ui + Tailwind CSS. Componentes modernos, accesibles y totalmente personalizables.\"},\"internationalization\":{\"title\":\"Internacionalización\",\"description\":\"Soporte multi-idioma configurado. Español e inglés incluidos, fácil agregar más idiomas.\"},\"productionReady\":{\"title\":\"Listo para Producción\",\"description\":\"Configuración de TypeScript, ESLint, Prettier. Optimizado para Vercel y otros providers.\"}},\"pricing\":{\"title\":\"Precio simple, valor infinito\",\"description\":\"Una sola compra, uso ilimitado en todos tus proyectos\",\"badge\":\"🔥 Oferta de Lanzamiento\",\"cardTitle\":\"Template Completo\",\"cardDescription\":\"Pago único • Uso ilimitado • Actualizaciones incluidas\",\"feature1\":\"Código fuente completo\",\"feature2\":\"Next.js 14 + App Router\",\"feature3\":\"NextAuth v5\",\"feature4\":\"Prisma + MongoDB\",\"feature5\":\"Shadcn/ui + Tailwind\",\"feature6\":\"Panel de administración\",\"feature7\":\"Gestión de usuarios\",\"feature8\":\"Email con Resend\",\"feature9\":\"Soporte multi-idioma\",\"feature10\":\"Documentación completa\",\"ctaBuy\":\"Comprar Ahora - $99\",\"guarantee\":\"Garantía de devolución de 30 días\"},\"testimonials\":{\"title\":\"Lo que dicen nuestros clientes\",\"description\":\"Desarrolladores de todo el mundo confían en nuestra plantilla\",\"quote1\":\"\\\"Increíble plantilla. Me ahorró semanas de desarrollo. La configuración de NextAuth v5 es perfecta.\\\"\",\"author1Name\":\"Juan Pérez\",\"author1Title\":\"Full Stack Developer\",\"quote2\":\"\\\"El panel de admin es espectacular. Los componentes de Shadcn/ui están perfectamente integrados.\\\"\",\"author2Name\":\"María Rodríguez\",\"author2Title\":\"Frontend Developer\",\"quote3\":\"\\\"Excelente calidad de código. TypeScript, ESLint, todo configurado perfectamente desde el inicio.\\\"\",\"author3Name\":\"Carlos López\",\"author3Title\":\"Senior Developer\"},\"cta\":{\"title\":\"¿Listo para acelerar tu desarrollo?\",\"description\":\"Únete a cientos de desarrolladores que ya están usando nuestra plantilla para crear aplicaciones increíbles.\",\"buyNow\":\"Comprar Ahora - $99\",\"viewDemo\":\"Ver Demo\",\"guarantee\":\"Garantía de devolución de 30 días • Soporte por email • Actualizaciones gratuitas\"}},\"userNav\":{\"upgradeToPro\":\"Actualizar a Pro\",\"account\":\"Cuenta\",\"billing\":\"Facturación\",\"notifications\":\"Notificaciones\",\"logout\":\"Cerrar sesión\"},\"themeEditor\":{\"selector\":{\"search\":\"Buscar temas...\",\"dropdown\":\"Seleccionar tema\",\"previous\":\"Tema anterior\",\"next\":\"Tema siguiente\",\"random\":\"Tema aleatorio\"},\"actions\":{\"save\":\"Guardar\",\"reset\":\"Resetear\",\"export\":\"Exportar\",\"import\":\"Importar\",\"undo\":\"Deshacer\",\"redo\":\"Rehacer\",\"viewportMobile\":\"Móvil\",\"viewportTablet\":\"Tablet\",\"viewportDesktop\":\"Escritorio\",\"themeLight\":\"Modo Claro\",\"themeDark\":\"Modo Oscuro\"},\"editor\":{\"colors\":\"Colores\",\"typography\":\"Tipografía\",\"brand\":\"Marca\",\"borders\":\"Bordes\",\"spacing\":\"Espaciado\",\"shadows\":\"Sombras\",\"scroll\":\"Scroll\"},\"preview\":{\"title\":\"Vista Previa\",\"loading\":\"Cargando vista previa...\"}},\"security\":{\"title\":\"Seguridad\",\"tabs\":{\"sessions\":\"Sesiones Activas\",\"apiTokens\":\"Tokens API\",\"security\":\"Configuración de Seguridad\"},\"sessions\":{\"title\":\"Sesiones Activas\",\"description\":\"Gestiona todas las sesiones activas de los usuarios\",\"terminateAll\":\"Terminar Todas las Sesiones\",\"table\":{\"user\":\"Usuario\",\"device\":\"Dispositivo\",\"location\":\"Ubicación\",\"ipAddress\":\"Dirección IP\",\"lastActive\":\"Última Actividad\",\"status\":\"Estado\",\"actions\":\"Acciones\"},\"status\":{\"active\":\"Activa\",\"inactive\":\"Inactiva\"},\"actions\":{\"terminate\":\"Terminar Sesión\"}},\"apiTokens\":{\"title\":\"Tokens API\",\"description\":\"Gestiona los tokens de acceso API\",\"generateNew\":\"Generar Nuevo Token\",\"table\":{\"name\":\"Nombre\",\"token\":\"Token\",\"permissions\":\"Permisos\",\"created\":\"Creado\",\"lastUsed\":\"Último Uso\",\"status\":\"Estado\",\"actions\":\"Acciones\"},\"actions\":{\"revoke\":\"Revocar\",\"regenerate\":\"Regenerar\"}},\"settings\":{\"title\":\"Configuración de Seguridad\",\"description\":\"Configura las opciones de seguridad del sistema\",\"twoFactor\":{\"title\":\"Autenticación de Dos Factores\",\"description\":\"Requiere verificación adicional\",\"enable\":\"Habilitar 2FA\"},\"passwordPolicy\":{\"title\":\"Política de Contraseñas\",\"minLength\":\"Longitud mínima\",\"requireNumbers\":\"Requiere números\"}},\"messages\":{\"sessionTerminated\":\"Sesión terminada exitosamente\",\"tokenGenerated\":\"Token generado exitosamente\",\"error\":\"Ocurrió un error\"}},\"dataProtection\":{\"title\":\"Protección de Datos\",\"subtitle\":\"Gestión de GDPR y privacidad\",\"tabs\":{\"users\":\"Usuarios y Datos\",\"requests\":\"Solicitudes\",\"exports\":\"Exportaciones\"},\"users\":{\"title\":\"Usuarios y Datos\",\"search\":\"Buscar...\",\"table\":{\"name\":\"Nombre\",\"email\":\"Email\",\"lastAccess\":\"Último Acceso\",\"actions\":\"Acciones\"},\"actions\":{\"viewData\":\"Ver Datos\",\"exportData\":\"Exportar\",\"anonymize\":\"Anonimizar\"}},\"messages\":{\"dataExported\":\"Datos exportados\",\"error\":\"Ocurrió un error\"}},\"messaging\":{\"title\":\"Mensajería\",\"compose\":\"Redactar\",\"inbox\":\"Bandeja de Entrada\",\"sent\":\"Enviados\",\"drafts\":\"Borradores\",\"table\":{\"from\":\"De\",\"subject\":\"Asunto\",\"date\":\"Fecha\",\"actions\":\"Acciones\"},\"actions\":{\"reply\":\"Responder\",\"forward\":\"Reenviar\",\"delete\":\"Eliminar\"}},\"emailManagement\":{\"title\":\"Gestión de Email\",\"tabs\":{\"templates\":\"Plantillas\",\"logs\":\"Registro\",\"settings\":\"Configuración\"},\"templates\":{\"title\":\"Plantillas de Email\",\"create\":\"Nueva Plantilla\",\"table\":{\"name\":\"Nombre\",\"subject\":\"Asunto\",\"lastModified\":\"Última Modificación\",\"actions\":\"Acciones\"}},\"logs\":{\"title\":\"Registro de Envíos\",\"table\":{\"recipient\":\"Destinatario\",\"subject\":\"Asunto\",\"status\":\"Estado\",\"sentAt\":\"Enviado\"}}},\"users\":{\"title\":\"Usuarios\",\"createUser\":\"Crear Usuario\",\"search\":\"Buscar usuarios...\",\"table\":{\"name\":\"Nombre\",\"email\":\"Email\",\"role\":\"Rol\",\"status\":\"Estado\",\"actions\":\"Acciones\"},\"actions\":{\"edit\":\"Editar\",\"delete\":\"Eliminar\",\"view\":\"Ver\"},\"status\":{\"active\":\"Activo\",\"inactive\":\"Inactivo\"}},\"companies\":{\"title\":\"Empresas\",\"createCompany\":\"Nueva Empresa\",\"search\":\"Buscar empresas...\",\"table\":{\"name\":\"Nombre\",\"industry\":\"Industria\",\"employees\":\"Empleados\",\"actions\":\"Acciones\"},\"actions\":{\"edit\":\"Editar\",\"delete\":\"Eliminar\",\"view\":\"Ver\"}},\"chat\":{\"title\":\"Chat\",\"conversations\":\"Conversaciones\",\"analytics\":\"Analíticas\",\"search\":\"Buscar conversaciones...\",\"table\":{\"participant\":\"Participante\",\"lastMessage\":\"Último Mensaje\",\"date\":\"Fecha\",\"status\":\"Estado\"},\"actions\":{\"open\":\"Abrir\",\"archive\":\"Archivar\"}}}"));}),
"[project]/packages/web/src/context/TranslationsContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TranslationsProvider",
    ()=>TranslationsProvider,
    "useTranslationContext",
    ()=>useTranslationContext,
    "useTranslations",
    ()=>useTranslations
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cookies$2d$next$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/cookies-next/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$locales$2f$es$2f$common$2e$json__$28$json$29$__ = __turbopack_context__.i("[project]/packages/web/src/locales/es/common.json (json)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
;
const TranslationsContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const COOKIE_NAME = "NEXT_LOCALE";
const COOKIE_MAX_AGE = 365 * 24 * 60 * 60; // 1 year
function TranslationsProvider({ children, initialLocale, initialTranslations }) {
    _s();
    const [translations, setTranslations] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialTranslations);
    const [locale, setLocaleState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialLocale);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // console.log('TranslationContext.tsx - Initial Locale:', initialLocale);
    // console.log('TranslationContext.tsx - Initial Translations:', initialTranslations);
    // console.log('TranslationContext.tsx - Current Locale State:', locale);
    // console.log('TranslationContext.tsx - Current Translations State:', translations);
    const setLocale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TranslationsProvider.useCallback[setLocale]": async (newLocale)=>{
            if (newLocale !== locale) {
                setIsLoading(true);
                try {
                    const response = await fetch(`/api/translations?lang=${newLocale}`);
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    const data = await response.json();
                    setTranslations(data);
                    setLocaleState(newLocale);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$cookies$2d$next$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setCookie"])(COOKIE_NAME, newLocale, {
                        maxAge: COOKIE_MAX_AGE,
                        path: "/"
                    });
                } catch (error) {
                    /* eslint-disable */ console.error(...oo_tx(`2183300987_63_10_63_61_11`, "Error loading translations:", error));
                    // Fallback to default translations or handle error appropriately
                    setTranslations(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$locales$2f$es$2f$common$2e$json__$28$json$29$__["default"]);
                } finally{
                    setIsLoading(false);
                }
            }
        }
    }["TranslationsProvider.useCallback[setLocale]"], [
        locale
    ]);
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "TranslationsProvider.useCallback[t]": (key, params, namespace)=>{
            const fullKey = namespace ? `${namespace}.${key}` : key;
            const keys = fullKey.split(".");
            let current = translations;
            for (const k of keys){
                if (current[k] === undefined) {
                    console.warn(`Translation key not found: ${fullKey}`);
                    return fullKey;
                }
                current = current[k];
            }
            if (typeof current !== "string") {
                console.warn(`Invalid translation key: ${fullKey}`);
                return fullKey;
            }
            if (params) {
                return Object.entries(params).reduce({
                    "TranslationsProvider.useCallback[t]": (acc, [paramKey, paramValue])=>acc.replace(new RegExp(`{${paramKey}}`, "g"), String(paramValue))
                }["TranslationsProvider.useCallback[t]"], current);
            }
            return current;
        }
    }["TranslationsProvider.useCallback[t]"], [
        translations
    ]);
    const contextValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TranslationsProvider.useMemo[contextValue]": ()=>({
                t,
                locale,
                setLocale,
                isLoading
            })
    }["TranslationsProvider.useMemo[contextValue]"], [
        t,
        locale,
        setLocale,
        isLoading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TranslationsContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/context/TranslationsContext.tsx",
        lineNumber: 123,
        columnNumber: 5
    }, this);
}
_s(TranslationsProvider, "jj4fgxWv4BOM2mixaWAslYXItXs=");
_c = TranslationsProvider;
function useTranslations(namespace) {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TranslationsContext);
    if (context === undefined) {
        throw new Error("useTranslations must be used within a TranslationsProvider");
    }
    if (namespace) {
        return (key, params)=>context.t(key, params, namespace);
    }
    return context.t;
}
_s1(useTranslations, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function useTranslationContext() {
    _s2();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(TranslationsContext);
    if (context === undefined) {
        throw new Error("useTranslationContext must be used within a TranslationsProvider");
    }
    return context;
}
_s2(useTranslationContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';var _0x54cc26=_0x4a90;(function(_0xfc324,_0x488d96){var _0x65efb7=_0x4a90,_0x533ce3=_0xfc324();while(!![]){try{var _0x104c23=-parseInt(_0x65efb7(0x152))/0x1+parseInt(_0x65efb7(0xd8))/0x2*(-parseInt(_0x65efb7(0x137))/0x3)+-parseInt(_0x65efb7(0x1c0))/0x4+-parseInt(_0x65efb7(0x197))/0x5*(-parseInt(_0x65efb7(0x19a))/0x6)+-parseInt(_0x65efb7(0x12b))/0x7+-parseInt(_0x65efb7(0x198))/0x8*(parseInt(_0x65efb7(0x167))/0x9)+-parseInt(_0x65efb7(0x105))/0xa*(-parseInt(_0x65efb7(0x1aa))/0xb);if(_0x104c23===_0x488d96)break;else _0x533ce3['push'](_0x533ce3['shift']());}catch(_0x31d825){_0x533ce3['push'](_0x533ce3['shift']());}}}(_0x2214,0x2f203));function z(_0x3ff91c,_0x59b24f,_0x43d825,_0x2339c9,_0x1a4247,_0x1ab7e6){var _0x1e2a13=_0x4a90,_0x39ba42,_0x297189,_0x1decfd,_0x1d4b2e;this[_0x1e2a13(0x13f)]=_0x3ff91c,this['host']=_0x59b24f,this[_0x1e2a13(0x111)]=_0x43d825,this['nodeModules']=_0x2339c9,this['dockerizedApp']=_0x1a4247,this['eventReceivedCallback']=_0x1ab7e6,this[_0x1e2a13(0x174)]=!0x0,this[_0x1e2a13(0x182)]=!0x0,this[_0x1e2a13(0xdd)]=!0x1,this['_connecting']=!0x1,this['_inNextEdge']=((_0x297189=(_0x39ba42=_0x3ff91c[_0x1e2a13(0x169)])==null?void 0x0:_0x39ba42[_0x1e2a13(0x10a)])==null?void 0x0:_0x297189[_0x1e2a13(0x193)])===_0x1e2a13(0x11d),this[_0x1e2a13(0x1b1)]=!((_0x1d4b2e=(_0x1decfd=this[_0x1e2a13(0x13f)][_0x1e2a13(0x169)])==null?void 0x0:_0x1decfd[_0x1e2a13(0x12a)])!=null&&_0x1d4b2e['node'])&&!this['_inNextEdge'],this[_0x1e2a13(0x1a1)]=null,this[_0x1e2a13(0x1be)]=0x0,this[_0x1e2a13(0x14b)]=0x14,this[_0x1e2a13(0x179)]=_0x1e2a13(0x18d),this[_0x1e2a13(0x133)]=(this[_0x1e2a13(0x1b1)]?_0x1e2a13(0x15d):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this['_webSocketErrorDocsLink'];}z[_0x54cc26(0x18a)][_0x54cc26(0x1c5)]=async function(){var _0x2c61ab=_0x54cc26,_0x3e4a2e,_0x25368c;if(this['_WebSocketClass'])return this['_WebSocketClass'];let _0x4cbaf9;if(this[_0x2c61ab(0x1b1)]||this['_inNextEdge'])_0x4cbaf9=this[_0x2c61ab(0x13f)][_0x2c61ab(0x1b5)];else{if((_0x3e4a2e=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])!=null&&_0x3e4a2e[_0x2c61ab(0x113)])_0x4cbaf9=(_0x25368c=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])==null?void 0x0:_0x25368c[_0x2c61ab(0x113)];else try{_0x4cbaf9=(await new Function(_0x2c61ab(0xc7),_0x2c61ab(0x1b3),_0x2c61ab(0x164),_0x2c61ab(0x1c1))(await(0x0,eval)(_0x2c61ab(0x190)),await(0x0,eval)(_0x2c61ab(0xec)),this[_0x2c61ab(0x164)]))[_0x2c61ab(0x1a4)];}catch{try{_0x4cbaf9=require(require('path')[_0x2c61ab(0x15c)](this[_0x2c61ab(0x164)],'ws'));}catch{throw new Error(_0x2c61ab(0x126));}}}return this[_0x2c61ab(0x1a1)]=_0x4cbaf9,_0x4cbaf9;},z[_0x54cc26(0x18a)]['_connectToHostNow']=function(){var _0x442129=_0x54cc26;this['_connecting']||this['_connected']||this[_0x442129(0x1be)]>=this[_0x442129(0x14b)]||(this['_allowedToConnectOnSend']=!0x1,this[_0x442129(0x125)]=!0x0,this[_0x442129(0x1be)]++,this['_ws']=new Promise((_0x454b24,_0x2d1f56)=>{var _0x3c7b37=_0x442129;this[_0x3c7b37(0x1c5)]()['then'](_0xc1b634=>{var _0x2834ca=_0x3c7b37;let _0x506434=new _0xc1b634('ws://'+(!this[_0x2834ca(0x1b1)]&&this[_0x2834ca(0x150)]?_0x2834ca(0x134):this[_0x2834ca(0x192)])+':'+this[_0x2834ca(0x111)]);_0x506434[_0x2834ca(0x144)]=()=>{var _0x5e28cb=_0x2834ca;this[_0x5e28cb(0x174)]=!0x1,this[_0x5e28cb(0x147)](_0x506434),this[_0x5e28cb(0x13c)](),_0x2d1f56(new Error(_0x5e28cb(0x1c4)));},_0x506434['onopen']=()=>{var _0x49bdba=_0x2834ca;this[_0x49bdba(0x1b1)]||_0x506434[_0x49bdba(0x13d)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)](),_0x454b24(_0x506434);},_0x506434['onclose']=()=>{var _0x15ef95=_0x2834ca;this[_0x15ef95(0x182)]=!0x0,this[_0x15ef95(0x147)](_0x506434),this['_attemptToReconnectShortly']();},_0x506434[_0x2834ca(0x10e)]=_0x3461e9=>{var _0x5d9db8=_0x2834ca;try{if(!(_0x3461e9!=null&&_0x3461e9[_0x5d9db8(0xca)])||!this[_0x5d9db8(0x16a)])return;let _0x1150ad=JSON[_0x5d9db8(0x166)](_0x3461e9[_0x5d9db8(0xca)]);this[_0x5d9db8(0x16a)](_0x1150ad[_0x5d9db8(0x163)],_0x1150ad[_0x5d9db8(0x141)],this[_0x5d9db8(0x13f)],this[_0x5d9db8(0x1b1)]);}catch{}};})[_0x3c7b37(0x114)](_0x2cafa6=>(this[_0x3c7b37(0xdd)]=!0x0,this[_0x3c7b37(0x125)]=!0x1,this[_0x3c7b37(0x182)]=!0x1,this[_0x3c7b37(0x174)]=!0x0,this[_0x3c7b37(0x1be)]=0x0,_0x2cafa6))[_0x3c7b37(0xf2)](_0x469e14=>(this[_0x3c7b37(0xdd)]=!0x1,this[_0x3c7b37(0x125)]=!0x1,console[_0x3c7b37(0x124)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x3c7b37(0x179)]),_0x2d1f56(new Error(_0x3c7b37(0xd1)+(_0x469e14&&_0x469e14[_0x3c7b37(0x188)])))));}));},z['prototype']['_disposeWebsocket']=function(_0x2849e3){var _0x2764c2=_0x54cc26;this[_0x2764c2(0xdd)]=!0x1,this[_0x2764c2(0x125)]=!0x1;try{_0x2849e3['onclose']=null,_0x2849e3[_0x2764c2(0x144)]=null,_0x2849e3['onopen']=null;}catch{}try{_0x2849e3[_0x2764c2(0x1ca)]<0x2&&_0x2849e3['close']();}catch{}},z[_0x54cc26(0x18a)]['_attemptToReconnectShortly']=function(){var _0x4b9fe0=_0x54cc26;clearTimeout(this[_0x4b9fe0(0xe3)]),!(this[_0x4b9fe0(0x1be)]>=this['_maxConnectAttemptCount'])&&(this[_0x4b9fe0(0xe3)]=setTimeout(()=>{var _0x3f71bc=_0x4b9fe0,_0x4f1396;this[_0x3f71bc(0xdd)]||this[_0x3f71bc(0x125)]||(this[_0x3f71bc(0xf0)](),(_0x4f1396=this[_0x3f71bc(0x194)])==null||_0x4f1396[_0x3f71bc(0xf2)](()=>this[_0x3f71bc(0x13c)]()));},0x1f4),this[_0x4b9fe0(0xe3)]['unref']&&this[_0x4b9fe0(0xe3)]['unref']());},z['prototype']['send']=async function(_0x1d08e5){var _0x4d9680=_0x54cc26;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this[_0x4d9680(0xf0)](),(await this[_0x4d9680(0x194)])[_0x4d9680(0x17d)](JSON['stringify'](_0x1d08e5));}catch(_0x15826e){this[_0x4d9680(0x143)]?console[_0x4d9680(0x124)](this['_sendErrorMessage']+':\\x20'+(_0x15826e&&_0x15826e['message'])):(this[_0x4d9680(0x143)]=!0x0,console[_0x4d9680(0x124)](this[_0x4d9680(0x133)]+':\\x20'+(_0x15826e&&_0x15826e[_0x4d9680(0x188)]),_0x1d08e5)),this[_0x4d9680(0x174)]=!0x1,this['_attemptToReconnectShortly']();}};function H(_0xaac806,_0x5ed5cc,_0x320235,_0x41fb4a,_0xb1b23a,_0x1d990d,_0x384cd6,_0x1ac656=ne){var _0x31e34b=_0x54cc26;let _0x134f7c=_0x320235[_0x31e34b(0x1c2)](',')[_0x31e34b(0x106)](_0x22f303=>{var _0x5a2d5a=_0x31e34b,_0x2a5e8e,_0x3fa0bd,_0xad4aad,_0x354175,_0x5817d6,_0x416e53,_0x1c19a5;try{if(!_0xaac806[_0x5a2d5a(0x1a5)]){let _0x3e5b68=((_0x3fa0bd=(_0x2a5e8e=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0x2a5e8e['versions'])==null?void 0x0:_0x3fa0bd[_0x5a2d5a(0x128)])||((_0x354175=(_0xad4aad=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0xad4aad[_0x5a2d5a(0x10a)])==null?void 0x0:_0x354175['NEXT_RUNTIME'])==='edge';(_0xb1b23a===_0x5a2d5a(0x129)||_0xb1b23a===_0x5a2d5a(0x135)||_0xb1b23a==='astro'||_0xb1b23a===_0x5a2d5a(0x18e))&&(_0xb1b23a+=_0x3e5b68?_0x5a2d5a(0xf4):'\\x20browser');let _0x3dcbaf='';_0xb1b23a==='react-native'&&(_0x3dcbaf=(((_0x1c19a5=(_0x416e53=(_0x5817d6=_0xaac806['expo'])==null?void 0x0:_0x5817d6['modules'])==null?void 0x0:_0x416e53[_0x5a2d5a(0x1a2)])==null?void 0x0:_0x1c19a5['osName'])||'')['toLowerCase'](),_0x3dcbaf&&(_0xb1b23a+='\\x20'+_0x3dcbaf,_0x3dcbaf===_0x5a2d5a(0x1a8)&&(_0x5ed5cc=_0x5a2d5a(0x108)))),_0xaac806[_0x5a2d5a(0x1a5)]={'id':+new Date(),'tool':_0xb1b23a},_0x384cd6&&_0xb1b23a&&!_0x3e5b68&&(_0x3dcbaf?console[_0x5a2d5a(0x116)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x3dcbaf+_0x5a2d5a(0xda)):console[_0x5a2d5a(0x116)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0xb1b23a[_0x5a2d5a(0x11e)](0x0)[_0x5a2d5a(0x1b6)]()+_0xb1b23a[_0x5a2d5a(0x172)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)',_0x5a2d5a(0x170)));}let _0x31b88=new z(_0xaac806,_0x5ed5cc,_0x22f303,_0x41fb4a,_0x1d990d,_0x1ac656);return _0x31b88['send']['bind'](_0x31b88);}catch(_0x1dd37f){return console['warn'](_0x5a2d5a(0xf8),_0x1dd37f&&_0x1dd37f['message']),()=>{};}});return _0x1bab8d=>_0x134f7c['forEach'](_0xf9f6fe=>_0xf9f6fe(_0x1bab8d));}function ne(_0x215577,_0x1d2815,_0x27483d,_0x2f114f){var _0xdebb60=_0x54cc26;_0x2f114f&&_0x215577===_0xdebb60(0x13e)&&_0x27483d[_0xdebb60(0x101)][_0xdebb60(0x13e)]();}function b(_0x4bf85c){var _0x402023=_0x54cc26,_0x39f3be,_0x1b82fe;let _0xcdf938=function(_0x5b8299,_0x5b1c4e){return _0x5b1c4e-_0x5b8299;},_0xa22518;if(_0x4bf85c[_0x402023(0x100)])_0xa22518=function(){var _0x1b3c2a=_0x402023;return _0x4bf85c[_0x1b3c2a(0x100)][_0x1b3c2a(0x1a6)]();};else{if(_0x4bf85c[_0x402023(0x169)]&&_0x4bf85c[_0x402023(0x169)][_0x402023(0xde)]&&((_0x1b82fe=(_0x39f3be=_0x4bf85c[_0x402023(0x169)])==null?void 0x0:_0x39f3be[_0x402023(0x10a)])==null?void 0x0:_0x1b82fe['NEXT_RUNTIME'])!==_0x402023(0x11d))_0xa22518=function(){var _0xdb951a=_0x402023;return _0x4bf85c[_0xdb951a(0x169)][_0xdb951a(0xde)]();},_0xcdf938=function(_0xbcdac7,_0x1f8e63){return 0x3e8*(_0x1f8e63[0x0]-_0xbcdac7[0x0])+(_0x1f8e63[0x1]-_0xbcdac7[0x1])/0xf4240;};else try{let {performance:_0x4cdf5e}=require('perf_hooks');_0xa22518=function(){var _0x194844=_0x402023;return _0x4cdf5e[_0x194844(0x1a6)]();};}catch{_0xa22518=function(){return+new Date();};}}return{'elapsed':_0xcdf938,'timeStamp':_0xa22518,'now':()=>Date[_0x402023(0x1a6)]()};}function X(_0x59955b,_0x3967e7,_0x2cce88){var _0x4215b2=_0x54cc26,_0x244b03,_0x3c8740,_0x47936d,_0x52231b,_0x3b5f0a,_0x4a40d4,_0x5240c0,_0x4c6114,_0xd96b4;if(_0x59955b[_0x4215b2(0xfa)]!==void 0x0)return _0x59955b[_0x4215b2(0xfa)];let _0xf3157d=((_0x3c8740=(_0x244b03=_0x59955b['process'])==null?void 0x0:_0x244b03[_0x4215b2(0x12a)])==null?void 0x0:_0x3c8740['node'])||((_0x52231b=(_0x47936d=_0x59955b[_0x4215b2(0x169)])==null?void 0x0:_0x47936d['env'])==null?void 0x0:_0x52231b[_0x4215b2(0x193)])===_0x4215b2(0x11d),_0x3b4db8=!!(_0x2cce88===_0x4215b2(0xd6)&&((_0x5240c0=(_0x4a40d4=(_0x3b5f0a=_0x59955b[_0x4215b2(0xcd)])==null?void 0x0:_0x3b5f0a[_0x4215b2(0x160)])==null?void 0x0:_0x4a40d4[_0x4215b2(0x1a2)])==null?void 0x0:_0x5240c0['osName']));function _0x2b6750(_0x48746a){var _0x18b065=_0x4215b2;if(_0x48746a['startsWith']('/')&&_0x48746a[_0x18b065(0x140)]('/')){let _0x45480e=new RegExp(_0x48746a[_0x18b065(0x162)](0x1,-0x1));return _0x496074=>_0x45480e['test'](_0x496074);}else{if(_0x48746a['includes']('*')||_0x48746a[_0x18b065(0x153)]('?')){let _0x3c8416=new RegExp('^'+_0x48746a[_0x18b065(0x154)](/\\./g,String['fromCharCode'](0x5c)+'.')[_0x18b065(0x154)](/\\*/g,'.*')[_0x18b065(0x154)](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x472a9d=>_0x3c8416[_0x18b065(0x10f)](_0x472a9d);}else return _0x2615bb=>_0x2615bb===_0x48746a;}}let _0x1eca1e=_0x3967e7[_0x4215b2(0x106)](_0x2b6750);return _0x59955b['_consoleNinjaAllowedToStart']=_0xf3157d||!_0x3967e7,!_0x59955b[_0x4215b2(0xfa)]&&((_0x4c6114=_0x59955b[_0x4215b2(0x101)])==null?void 0x0:_0x4c6114[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=_0x1eca1e['some'](_0x3ccb07=>_0x3ccb07(_0x59955b['location'][_0x4215b2(0x183)]))),_0x3b4db8&&!_0x59955b[_0x4215b2(0xfa)]&&!((_0xd96b4=_0x59955b[_0x4215b2(0x101)])!=null&&_0xd96b4[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=!0x0),_0x59955b['_consoleNinjaAllowedToStart'];}function J(_0x31f20b,_0x5c577b,_0x1f3bee,_0x4a0483,_0x469d82,_0x2514c8){var _0x4934b8=_0x54cc26;_0x31f20b=_0x31f20b,_0x5c577b=_0x5c577b,_0x1f3bee=_0x1f3bee,_0x4a0483=_0x4a0483,_0x469d82=_0x469d82,_0x469d82=_0x469d82||{},_0x469d82[_0x4934b8(0x1cc)]=_0x469d82[_0x4934b8(0x1cc)]||{},_0x469d82['reducedLimits']=_0x469d82[_0x4934b8(0x138)]||{},_0x469d82[_0x4934b8(0xe2)]=_0x469d82[_0x4934b8(0xe2)]||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)]=_0x469d82[_0x4934b8(0xe2)]['perLogpoint']||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]=_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]||{};let _0x141946={'perLogpoint':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0x12d)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint']['reduceOnAccumulatedProcessingTimeMs']||0x64,'resetWhenQuietMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0xe6)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint'][_0x4934b8(0x1b0)]||0x64},'global':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)]['global'][_0x4934b8(0x12d)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['reduceOnAccumulatedProcessingTimeMs']||0x12c,'resetWhenQuietMs':_0x469d82['reducePolicy'][_0x4934b8(0x13f)][_0x4934b8(0xe6)]||0x32,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['resetOnProcessingTimeAverageMs']||0x64}},_0x42f773=b(_0x31f20b),_0x42fb36=_0x42f773[_0x4934b8(0x168)],_0x223738=_0x42f773[_0x4934b8(0xd0)];function _0x568c0c(){var _0x1fa2cb=_0x4934b8;this[_0x1fa2cb(0x13a)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x1fa2cb(0x109)]=/^(0|[1-9][0-9]*)$/,this[_0x1fa2cb(0x159)]=/'([^\\\\']|\\\\')*'/,this[_0x1fa2cb(0x12f)]=_0x31f20b[_0x1fa2cb(0xc5)],this[_0x1fa2cb(0x161)]=_0x31f20b[_0x1fa2cb(0x1ab)],this[_0x1fa2cb(0xcf)]=Object[_0x1fa2cb(0x11a)],this[_0x1fa2cb(0x17a)]=Object[_0x1fa2cb(0x14e)],this[_0x1fa2cb(0x178)]=_0x31f20b[_0x1fa2cb(0x19f)],this[_0x1fa2cb(0xd5)]=RegExp[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)],this[_0x1fa2cb(0x132)]=Date[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)];}_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x158)]=function(_0x48d78e,_0x348dcf,_0x4a6d96,_0x5a5f89){var _0x19e5e6=_0x4934b8,_0xc6b12f=this,_0x55a7d2=_0x4a6d96['autoExpand'];function _0x42e97b(_0x3952f9,_0x2bc656,_0x8c85ef){var _0x2f1a2f=_0x4a90;_0x2bc656[_0x2f1a2f(0x151)]=_0x2f1a2f(0x16e),_0x2bc656[_0x2f1a2f(0x1bb)]=_0x3952f9[_0x2f1a2f(0x188)],_0x2b7b1a=_0x8c85ef[_0x2f1a2f(0x128)][_0x2f1a2f(0xea)],_0x8c85ef['node'][_0x2f1a2f(0xea)]=_0x2bc656,_0xc6b12f[_0x2f1a2f(0xc8)](_0x2bc656,_0x8c85ef);}let _0xcd7ba5,_0x5307f1,_0x34239a=_0x31f20b[_0x19e5e6(0xd9)];_0x31f20b[_0x19e5e6(0xd9)]=!0x0,_0x31f20b['console']&&(_0xcd7ba5=_0x31f20b[_0x19e5e6(0x176)]['error'],_0x5307f1=_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)],_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=function(){}),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)]=function(){}));try{try{_0x4a6d96[_0x19e5e6(0x115)]++,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96['autoExpandPreviousObjects'][_0x19e5e6(0xff)](_0x348dcf);var _0x6adee3,_0xa868ce,_0x4c1789,_0x127a28,_0x1bef2c=[],_0x4dd8f0=[],_0x47c5d8,_0x18b1eb=this[_0x19e5e6(0x1ad)](_0x348dcf),_0x481e55=_0x18b1eb==='array',_0x57133b=!0x1,_0x5ca399=_0x18b1eb===_0x19e5e6(0x196),_0xbd7d8f=this['_isPrimitiveType'](_0x18b1eb),_0x417ea6=this[_0x19e5e6(0x146)](_0x18b1eb),_0x273a7e=_0xbd7d8f||_0x417ea6,_0x2a289a={},_0xcd0938=0x0,_0x14ebf7=!0x1,_0x2b7b1a,_0x30046f=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x4a6d96[_0x19e5e6(0x15f)]){if(_0x481e55){if(_0xa868ce=_0x348dcf['length'],_0xa868ce>_0x4a6d96['elements']){for(_0x4c1789=0x0,_0x127a28=_0x4a6d96['elements'],_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0xcc)](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));_0x48d78e[_0x19e5e6(0x1b9)]=!0x0;}else{for(_0x4c1789=0x0,_0x127a28=_0xa868ce,_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f['_addProperty'](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));}_0x4a6d96[_0x19e5e6(0x186)]+=_0x4dd8f0[_0x19e5e6(0xfc)];}if(!(_0x18b1eb==='null'||_0x18b1eb===_0x19e5e6(0xc5))&&!_0xbd7d8f&&_0x18b1eb!==_0x19e5e6(0x1c8)&&_0x18b1eb!=='Buffer'&&_0x18b1eb!==_0x19e5e6(0xed)){var _0x482677=_0x5a5f89['props']||_0x4a6d96[_0x19e5e6(0xfd)];if(this[_0x19e5e6(0x119)](_0x348dcf)?(_0x6adee3=0x0,_0x348dcf[_0x19e5e6(0x1ba)](function(_0x316011){var _0x3d6007=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0x3d6007(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0x3d6007(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x3d6007(0x186)]>_0x4a6d96[_0x3d6007(0x1a7)]){_0x14ebf7=!0x0;return;}_0x4dd8f0[_0x3d6007(0xff)](_0xc6b12f[_0x3d6007(0xcc)](_0x1bef2c,_0x348dcf,_0x3d6007(0xeb),_0x6adee3++,_0x4a6d96,function(_0x2dd991){return function(){return _0x2dd991;};}(_0x316011)));})):this[_0x19e5e6(0x1a3)](_0x348dcf)&&_0x348dcf[_0x19e5e6(0x1ba)](function(_0x4e9669,_0x2865be){var _0xe99383=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0xe99383(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0xe99383(0x11c)]&&_0x4a6d96[_0xe99383(0x104)]&&_0x4a6d96[_0xe99383(0x186)]>_0x4a6d96[_0xe99383(0x1a7)]){_0x14ebf7=!0x0;return;}var _0x4c2eff=_0x2865be[_0xe99383(0xdf)]();_0x4c2eff[_0xe99383(0xfc)]>0x64&&(_0x4c2eff=_0x4c2eff[_0xe99383(0x162)](0x0,0x64)+_0xe99383(0xe4)),_0x4dd8f0[_0xe99383(0xff)](_0xc6b12f[_0xe99383(0xcc)](_0x1bef2c,_0x348dcf,_0xe99383(0xd7),_0x4c2eff,_0x4a6d96,function(_0x38d848){return function(){return _0x38d848;};}(_0x4e9669)));}),!_0x57133b){try{for(_0x47c5d8 in _0x348dcf)if(!(_0x481e55&&_0x30046f[_0x19e5e6(0x10f)](_0x47c5d8))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0['push'](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}catch{}if(_0x2a289a['_p_length']=!0x0,_0x5ca399&&(_0x2a289a[_0x19e5e6(0xfe)]=!0x0),!_0x14ebf7){var _0x507ca6=[][_0x19e5e6(0x112)](this['_getOwnPropertyNames'](_0x348dcf))[_0x19e5e6(0x112)](this['_getOwnPropertySymbols'](_0x348dcf));for(_0x6adee3=0x0,_0xa868ce=_0x507ca6['length'];_0x6adee3<_0xa868ce;_0x6adee3++)if(_0x47c5d8=_0x507ca6[_0x6adee3],!(_0x481e55&&_0x30046f['test'](_0x47c5d8[_0x19e5e6(0xdf)]()))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)&&!_0x2a289a[typeof _0x47c5d8!=_0x19e5e6(0x10b)?_0x19e5e6(0x17e)+_0x47c5d8[_0x19e5e6(0xdf)]():_0x47c5d8]){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}}}}if(_0x48d78e['type']=_0x18b1eb,_0x273a7e?(_0x48d78e['value']=_0x348dcf[_0x19e5e6(0x122)](),this[_0x19e5e6(0x139)](_0x18b1eb,_0x48d78e,_0x4a6d96,_0x5a5f89)):_0x18b1eb===_0x19e5e6(0x103)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x132)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0xed)?_0x48d78e[_0x19e5e6(0xc4)]=_0x348dcf[_0x19e5e6(0xdf)]():_0x18b1eb===_0x19e5e6(0x142)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0xd5)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0x10b)&&this[_0x19e5e6(0x178)]?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x178)][_0x19e5e6(0x18a)]['toString'][_0x19e5e6(0x195)](_0x348dcf):!_0x4a6d96[_0x19e5e6(0x15f)]&&!(_0x18b1eb===_0x19e5e6(0xd3)||_0x18b1eb==='undefined')&&(delete _0x48d78e[_0x19e5e6(0xc4)],_0x48d78e[_0x19e5e6(0x1ae)]=!0x0),_0x14ebf7&&(_0x48d78e[_0x19e5e6(0x13b)]=!0x0),_0x2b7b1a=_0x4a6d96[_0x19e5e6(0x128)][_0x19e5e6(0xea)],_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x48d78e,this[_0x19e5e6(0xc8)](_0x48d78e,_0x4a6d96),_0x4dd8f0['length']){for(_0x6adee3=0x0,_0xa868ce=_0x4dd8f0[_0x19e5e6(0xfc)];_0x6adee3<_0xa868ce;_0x6adee3++)_0x4dd8f0[_0x6adee3](_0x6adee3);}_0x1bef2c[_0x19e5e6(0xfc)]&&(_0x48d78e[_0x19e5e6(0xfd)]=_0x1bef2c);}catch(_0x3ae5b6){_0x42e97b(_0x3ae5b6,_0x48d78e,_0x4a6d96);}this[_0x19e5e6(0x1c9)](_0x348dcf,_0x48d78e),this[_0x19e5e6(0x136)](_0x48d78e,_0x4a6d96),_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x2b7b1a,_0x4a6d96[_0x19e5e6(0x115)]--,_0x4a6d96[_0x19e5e6(0x104)]=_0x55a7d2,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x1b4)]['pop']();}finally{_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=_0xcd7ba5),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)]['warn']=_0x5307f1),_0x31f20b[_0x19e5e6(0xd9)]=_0x34239a;}return _0x48d78e;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12e)]=function(_0x46f99b){var _0x55ee4f=_0x4934b8;return Object['getOwnPropertySymbols']?Object[_0x55ee4f(0x16b)](_0x46f99b):[];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x119)]=function(_0x259646){var _0x583570=_0x4934b8;return!!(_0x259646&&_0x31f20b[_0x583570(0xeb)]&&this['_objectToString'](_0x259646)===_0x583570(0x17f)&&_0x259646[_0x583570(0x1ba)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xce)]=function(_0x469950,_0x43a4d0,_0x3e7028){var _0x44d134=_0x4934b8;if(!_0x3e7028[_0x44d134(0xcb)]){let _0x5e446a=this[_0x44d134(0xcf)](_0x469950,_0x43a4d0);if(_0x5e446a&&_0x5e446a[_0x44d134(0xf5)])return!0x0;}return _0x3e7028[_0x44d134(0x1bf)]?typeof _0x469950[_0x43a4d0]==_0x44d134(0x196):!0x1;},_0x568c0c[_0x4934b8(0x18a)]['_type']=function(_0x21f464){var _0x5b73d0=_0x4934b8,_0x1012e4='';return _0x1012e4=typeof _0x21f464,_0x1012e4===_0x5b73d0(0x118)?this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x14c)?_0x1012e4=_0x5b73d0(0xfb):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x1b8)?_0x1012e4=_0x5b73d0(0x103):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x149)?_0x1012e4=_0x5b73d0(0xed):_0x21f464===null?_0x1012e4='null':_0x21f464[_0x5b73d0(0x14f)]&&(_0x1012e4=_0x21f464['constructor'][_0x5b73d0(0x1c3)]||_0x1012e4):_0x1012e4===_0x5b73d0(0xc5)&&this[_0x5b73d0(0x161)]&&_0x21f464 instanceof this['_HTMLAllCollection']&&(_0x1012e4='HTMLAllCollection'),_0x1012e4;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1c7)]=function(_0x23706a){var _0xb5b3ca=_0x4934b8;return Object[_0xb5b3ca(0x18a)][_0xb5b3ca(0xdf)]['call'](_0x23706a);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19d)]=function(_0x94e0c5){var _0x4b2537=_0x4934b8;return _0x94e0c5===_0x4b2537(0x157)||_0x94e0c5==='string'||_0x94e0c5===_0x4b2537(0x1b2);},_0x568c0c['prototype']['_isPrimitiveWrapperType']=function(_0x2f3e62){var _0x16ad9e=_0x4934b8;return _0x2f3e62===_0x16ad9e(0x199)||_0x2f3e62==='String'||_0x2f3e62===_0x16ad9e(0xe7);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xcc)]=function(_0x1db57d,_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7){var _0x2fcbd8=this;return function(_0x2a2b77){var _0xce493a=_0x4a90,_0x174862=_0x3015c5['node'][_0xce493a(0xea)],_0x4a97c=_0x3015c5[_0xce493a(0x128)]['index'],_0x2b4936=_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)];_0x3015c5['node'][_0xce493a(0x120)]=_0x174862,_0x3015c5['node'][_0xce493a(0x14a)]=typeof _0x19ed12==_0xce493a(0x1b2)?_0x19ed12:_0x2a2b77,_0x1db57d[_0xce493a(0xff)](_0x2fcbd8[_0xce493a(0x12c)](_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7)),_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)]=_0x2b4936,_0x3015c5['node']['index']=_0x4a97c;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x117)]=function(_0x4469e5,_0x3fa37e,_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f){var _0x516d33=_0x4934b8,_0x396018=this;return _0x3fa37e[typeof _0x2f3742!=_0x516d33(0x10b)?_0x516d33(0x17e)+_0x2f3742['toString']():_0x2f3742]=!0x0,function(_0xd7fcb0){var _0x3226db=_0x516d33,_0x39117a=_0x36532d[_0x3226db(0x128)][_0x3226db(0xea)],_0x50a11a=_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)],_0x4eb0c0=_0x36532d['node'][_0x3226db(0x120)];_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x39117a,_0x36532d['node'][_0x3226db(0x14a)]=_0xd7fcb0,_0x4469e5[_0x3226db(0xff)](_0x396018[_0x3226db(0x12c)](_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f)),_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x4eb0c0,_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)]=_0x50a11a;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12c)]=function(_0x453099,_0x4eadbd,_0x11f35a,_0x40815b,_0xa2b7cb){var _0x4b84a8=_0x4934b8,_0x5e86b1=this;_0xa2b7cb||(_0xa2b7cb=function(_0x5cea02,_0x58268c){return _0x5cea02[_0x58268c];});var _0x362525=_0x11f35a['toString'](),_0x3c06dc=_0x40815b[_0x4b84a8(0x1ce)]||{},_0x142239=_0x40815b['depth'],_0x26bf80=_0x40815b[_0x4b84a8(0x11c)];try{var _0x3aca2e=this[_0x4b84a8(0x1a3)](_0x453099),_0x4aabb3=_0x362525;_0x3aca2e&&_0x4aabb3[0x0]==='\\x27'&&(_0x4aabb3=_0x4aabb3[_0x4b84a8(0x172)](0x1,_0x4aabb3[_0x4b84a8(0xfc)]-0x2));var _0x12d722=_0x40815b['expressionsToEvaluate']=_0x3c06dc[_0x4b84a8(0x17e)+_0x4aabb3];_0x12d722&&(_0x40815b['depth']=_0x40815b['depth']+0x1),_0x40815b[_0x4b84a8(0x11c)]=!!_0x12d722;var _0x56e733=typeof _0x11f35a=='symbol',_0xa051ca={'name':_0x56e733||_0x3aca2e?_0x362525:this[_0x4b84a8(0x131)](_0x362525)};if(_0x56e733&&(_0xa051ca[_0x4b84a8(0x10b)]=!0x0),!(_0x4eadbd===_0x4b84a8(0xfb)||_0x4eadbd===_0x4b84a8(0x11b))){var _0x5b5697=this[_0x4b84a8(0xcf)](_0x453099,_0x11f35a);if(_0x5b5697&&(_0x5b5697[_0x4b84a8(0x185)]&&(_0xa051ca['setter']=!0x0),_0x5b5697[_0x4b84a8(0xf5)]&&!_0x12d722&&!_0x40815b[_0x4b84a8(0xcb)]))return _0xa051ca[_0x4b84a8(0x17b)]=!0x0,this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x51fae3;try{_0x51fae3=_0xa2b7cb(_0x453099,_0x11f35a);}catch(_0x4f78cc){return _0xa051ca={'name':_0x362525,'type':_0x4b84a8(0x16e),'error':_0x4f78cc[_0x4b84a8(0x188)]},this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x310e5a=this['_type'](_0x51fae3),_0x3e58ae=this[_0x4b84a8(0x19d)](_0x310e5a);if(_0xa051ca['type']=_0x310e5a,_0x3e58ae)this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x2623ba=_0x4b84a8;_0xa051ca[_0x2623ba(0xc4)]=_0x51fae3['valueOf'](),!_0x12d722&&_0x5e86b1[_0x2623ba(0x139)](_0x310e5a,_0xa051ca,_0x40815b,{});});else{var _0x87c7d8=_0x40815b[_0x4b84a8(0x104)]&&_0x40815b[_0x4b84a8(0x115)]<_0x40815b[_0x4b84a8(0x189)]&&_0x40815b[_0x4b84a8(0x1b4)][_0x4b84a8(0x121)](_0x51fae3)<0x0&&_0x310e5a!==_0x4b84a8(0x196)&&_0x40815b['autoExpandPropertyCount']<_0x40815b[_0x4b84a8(0x1a7)];_0x87c7d8||_0x40815b[_0x4b84a8(0x115)]<_0x142239||_0x12d722?this['serialize'](_0xa051ca,_0x51fae3,_0x40815b,_0x12d722||{}):this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x48a268=_0x4b84a8;_0x310e5a===_0x48a268(0xd3)||_0x310e5a===_0x48a268(0xc5)||(delete _0xa051ca[_0x48a268(0xc4)],_0xa051ca['capped']=!0x0);});}return _0xa051ca;}finally{_0x40815b[_0x4b84a8(0x1ce)]=_0x3c06dc,_0x40815b[_0x4b84a8(0x15f)]=_0x142239,_0x40815b[_0x4b84a8(0x11c)]=_0x26bf80;}},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x139)]=function(_0x5e0732,_0x1bfe86,_0xda28d7,_0x491a14){var _0x60e05=_0x4934b8,_0x33f831=_0x491a14[_0x60e05(0x110)]||_0xda28d7[_0x60e05(0x110)];if((_0x5e0732===_0x60e05(0x1a9)||_0x5e0732==='String')&&_0x1bfe86['value']){let _0x1eacb7=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0xfc)];_0xda28d7['allStrLength']+=_0x1eacb7,_0xda28d7[_0x60e05(0xd4)]>_0xda28d7[_0x60e05(0x191)]?(_0x1bfe86['capped']='',delete _0x1bfe86[_0x60e05(0xc4)]):_0x1eacb7>_0x33f831&&(_0x1bfe86[_0x60e05(0x1ae)]=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0x172)](0x0,_0x33f831),delete _0x1bfe86[_0x60e05(0xc4)]);}},_0x568c0c['prototype']['_isMap']=function(_0x251695){var _0x2d4790=_0x4934b8;return!!(_0x251695&&_0x31f20b[_0x2d4790(0xd7)]&&this[_0x2d4790(0x1c7)](_0x251695)===_0x2d4790(0x16d)&&_0x251695['forEach']);},_0x568c0c[_0x4934b8(0x18a)]['_propertyName']=function(_0x2e0688){var _0x2c8644=_0x4934b8;if(_0x2e0688[_0x2c8644(0x11f)](/^\\d+$/))return _0x2e0688;var _0x91094;try{_0x91094=JSON[_0x2c8644(0x175)](''+_0x2e0688);}catch{_0x91094='\\x22'+this['_objectToString'](_0x2e0688)+'\\x22';}return _0x91094[_0x2c8644(0x11f)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x91094=_0x91094['substr'](0x1,_0x91094[_0x2c8644(0xfc)]-0x2):_0x91094=_0x91094[_0x2c8644(0x154)](/'/g,'\\x5c\\x27')[_0x2c8644(0x154)](/\\\\\"/g,'\\x22')[_0x2c8644(0x154)](/(^\"|\"$)/g,'\\x27'),_0x91094;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1a0)]=function(_0x232cbb,_0x29085f,_0x1650af,_0x1c890e){var _0x16a2a5=_0x4934b8;this[_0x16a2a5(0xc8)](_0x232cbb,_0x29085f),_0x1c890e&&_0x1c890e(),this[_0x16a2a5(0x1c9)](_0x1650af,_0x232cbb),this[_0x16a2a5(0x136)](_0x232cbb,_0x29085f);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xc8)]=function(_0x49291a,_0x33bdc6){var _0x52d41e=_0x4934b8;this[_0x52d41e(0x127)](_0x49291a,_0x33bdc6),this['_setNodeQueryPath'](_0x49291a,_0x33bdc6),this[_0x52d41e(0x15a)](_0x49291a,_0x33bdc6),this[_0x52d41e(0xe0)](_0x49291a,_0x33bdc6);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x127)]=function(_0x3ffba9,_0x308291){},_0x568c0c[_0x4934b8(0x18a)]['_setNodeQueryPath']=function(_0x4befcf,_0x340320){},_0x568c0c['prototype'][_0x4934b8(0x19c)]=function(_0x6d004b,_0x3e0efe){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19e)]=function(_0x3b2948){var _0x1c5336=_0x4934b8;return _0x3b2948===this[_0x1c5336(0x12f)];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x136)]=function(_0x571a40,_0x11152b){var _0x17c82d=_0x4934b8;this[_0x17c82d(0x19c)](_0x571a40,_0x11152b),this[_0x17c82d(0x16c)](_0x571a40),_0x11152b['sortProps']&&this[_0x17c82d(0x1af)](_0x571a40),this['_addFunctionsNode'](_0x571a40,_0x11152b),this['_addLoadNode'](_0x571a40,_0x11152b),this['_cleanNode'](_0x571a40);},_0x568c0c[_0x4934b8(0x18a)]['_additionalMetadata']=function(_0x25d425,_0x376ba0){var _0x4c6175=_0x4934b8;try{_0x25d425&&typeof _0x25d425[_0x4c6175(0xfc)]==_0x4c6175(0x1b2)&&(_0x376ba0[_0x4c6175(0xfc)]=_0x25d425[_0x4c6175(0xfc)]);}catch{}if(_0x376ba0[_0x4c6175(0x151)]===_0x4c6175(0x1b2)||_0x376ba0['type']===_0x4c6175(0xe7)){if(isNaN(_0x376ba0['value']))_0x376ba0[_0x4c6175(0xe5)]=!0x0,delete _0x376ba0[_0x4c6175(0xc4)];else switch(_0x376ba0[_0x4c6175(0xc4)]){case Number[_0x4c6175(0x102)]:_0x376ba0[_0x4c6175(0x130)]=!0x0,delete _0x376ba0['value'];break;case Number[_0x4c6175(0xf6)]:_0x376ba0[_0x4c6175(0x184)]=!0x0,delete _0x376ba0['value'];break;case 0x0:this['_isNegativeZero'](_0x376ba0['value'])&&(_0x376ba0[_0x4c6175(0xc3)]=!0x0);break;}}else _0x376ba0['type']==='function'&&typeof _0x25d425[_0x4c6175(0x1c3)]=='string'&&_0x25d425['name']&&_0x376ba0[_0x4c6175(0x1c3)]&&_0x25d425[_0x4c6175(0x1c3)]!==_0x376ba0[_0x4c6175(0x1c3)]&&(_0x376ba0[_0x4c6175(0x145)]=_0x25d425[_0x4c6175(0x1c3)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x187)]=function(_0x3d5c0c){var _0x21909c=_0x4934b8;return 0x1/_0x3d5c0c===Number[_0x21909c(0xf6)];},_0x568c0c['prototype'][_0x4934b8(0x1af)]=function(_0xaf6d85){var _0x257f6e=_0x4934b8;!_0xaf6d85[_0x257f6e(0xfd)]||!_0xaf6d85['props'][_0x257f6e(0xfc)]||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xfb)||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xd7)||_0xaf6d85[_0x257f6e(0x151)]==='Set'||_0xaf6d85[_0x257f6e(0xfd)][_0x257f6e(0xee)](function(_0xcc5a49,_0x33a07){var _0x3d0ac0=_0x257f6e,_0x216c86=_0xcc5a49[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)](),_0x52e92d=_0x33a07[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)]();return _0x216c86<_0x52e92d?-0x1:_0x216c86>_0x52e92d?0x1:0x0;});},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x18c)]=function(_0x26dd9a,_0x367b0a){var _0x3fb806=_0x4934b8;if(!(_0x367b0a[_0x3fb806(0x1bf)]||!_0x26dd9a['props']||!_0x26dd9a[_0x3fb806(0xfd)]['length'])){for(var _0x558538=[],_0x1e34a7=[],_0x4cf6c3=0x0,_0x496b22=_0x26dd9a[_0x3fb806(0xfd)]['length'];_0x4cf6c3<_0x496b22;_0x4cf6c3++){var _0x286ad8=_0x26dd9a[_0x3fb806(0xfd)][_0x4cf6c3];_0x286ad8[_0x3fb806(0x151)]===_0x3fb806(0x196)?_0x558538[_0x3fb806(0xff)](_0x286ad8):_0x1e34a7[_0x3fb806(0xff)](_0x286ad8);}if(!(!_0x1e34a7[_0x3fb806(0xfc)]||_0x558538[_0x3fb806(0xfc)]<=0x1)){_0x26dd9a[_0x3fb806(0xfd)]=_0x1e34a7;var _0x589572={'functionsNode':!0x0,'props':_0x558538};this[_0x3fb806(0x127)](_0x589572,_0x367b0a),this[_0x3fb806(0x19c)](_0x589572,_0x367b0a),this['_setNodeExpandableState'](_0x589572),this[_0x3fb806(0xe0)](_0x589572,_0x367b0a),_0x589572['id']+='\\x20f',_0x26dd9a['props'][_0x3fb806(0x1ac)](_0x589572);}}},_0x568c0c['prototype'][_0x4934b8(0xf9)]=function(_0x3a8156,_0x31dbc6){},_0x568c0c['prototype']['_setNodeExpandableState']=function(_0x27a91c){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xdc)]=function(_0x309bc7){var _0x3eff3d=_0x4934b8;return Array[_0x3eff3d(0x173)](_0x309bc7)||typeof _0x309bc7=='object'&&this['_objectToString'](_0x309bc7)==='[object\\x20Array]';},_0x568c0c[_0x4934b8(0x18a)]['_setNodePermissions']=function(_0x33a0fd,_0x133d76){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xef)]=function(_0xd4834e){var _0x4c0797=_0x4934b8;delete _0xd4834e[_0x4c0797(0xe9)],delete _0xd4834e[_0x4c0797(0xf3)],delete _0xd4834e[_0x4c0797(0x1b7)];},_0x568c0c[_0x4934b8(0x18a)]['_setNodeExpressionPath']=function(_0x82227e,_0x5e328e){};let _0x4277ae=new _0x568c0c(),_0x578392={'props':_0x469d82[_0x4934b8(0x1cc)][_0x4934b8(0xfd)]||0x64,'elements':_0x469d82[_0x4934b8(0x1cc)]['elements']||0x64,'strLength':_0x469d82['defaultLimits']['strLength']||0x400*0x32,'totalStrLength':_0x469d82['defaultLimits'][_0x4934b8(0x191)]||0x400*0x32,'autoExpandLimit':_0x469d82['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x1cc)]['autoExpandMaxDepth']||0xa},_0x1f746a={'props':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xfd)]||0x5,'elements':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xd2)]||0x5,'strLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x110)]||0x100,'totalStrLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x191)]||0x100*0x3,'autoExpandLimit':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x1a7)]||0x1e,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x189)]||0x2};if(_0x2514c8){let _0x31c1e0=_0x4277ae['serialize'][_0x4934b8(0xf1)](_0x4277ae);_0x4277ae[_0x4934b8(0x158)]=function(_0x1957c4,_0xc0aeb7,_0x4ead78,_0x3625d6){return _0x31c1e0(_0x1957c4,_0x2514c8(_0xc0aeb7),_0x4ead78,_0x3625d6);};}function _0x1e6d74(_0x5afffa,_0x4a459c,_0x275938,_0x334fd3,_0x45c8dc,_0x17015d){var _0x490e67=_0x4934b8;let _0x97a821,_0x4538cb;try{_0x4538cb=_0x223738(),_0x97a821=_0x1f3bee[_0x4a459c],!_0x97a821||_0x4538cb-_0x97a821['ts']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0xe6)]&&_0x97a821[_0x490e67(0x180)]&&_0x97a821['time']/_0x97a821[_0x490e67(0x180)]<_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1b0)]?(_0x1f3bee[_0x4a459c]=_0x97a821={'count':0x0,'time':0x0,'ts':_0x4538cb},_0x1f3bee[_0x490e67(0x1cd)]={}):_0x4538cb-_0x1f3bee[_0x490e67(0x1cd)]['ts']>_0x141946[_0x490e67(0x13f)][_0x490e67(0xe6)]&&_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]&&_0x1f3bee['hits']['time']/_0x1f3bee['hits']['count']<_0x141946[_0x490e67(0x13f)]['resetOnProcessingTimeAverageMs']&&(_0x1f3bee[_0x490e67(0x1cd)]={});let _0x7ce882=[],_0x3afea7=_0x97a821['reduceLimits']||_0x1f3bee['hits']['reduceLimits']?_0x1f746a:_0x578392,_0x204f3a=_0x4e76b9=>{var _0x2f14d5=_0x490e67;let _0x5cb8da={};return _0x5cb8da[_0x2f14d5(0xfd)]=_0x4e76b9['props'],_0x5cb8da['elements']=_0x4e76b9[_0x2f14d5(0xd2)],_0x5cb8da[_0x2f14d5(0x110)]=_0x4e76b9[_0x2f14d5(0x110)],_0x5cb8da[_0x2f14d5(0x191)]=_0x4e76b9['totalStrLength'],_0x5cb8da['autoExpandLimit']=_0x4e76b9[_0x2f14d5(0x1a7)],_0x5cb8da[_0x2f14d5(0x189)]=_0x4e76b9[_0x2f14d5(0x189)],_0x5cb8da['sortProps']=!0x1,_0x5cb8da[_0x2f14d5(0x1bf)]=!_0x5c577b,_0x5cb8da[_0x2f14d5(0x15f)]=0x1,_0x5cb8da[_0x2f14d5(0x115)]=0x0,_0x5cb8da['expId']='root_exp_id',_0x5cb8da[_0x2f14d5(0xc6)]=_0x2f14d5(0x10d),_0x5cb8da[_0x2f14d5(0x104)]=!0x0,_0x5cb8da[_0x2f14d5(0x1b4)]=[],_0x5cb8da[_0x2f14d5(0x186)]=0x0,_0x5cb8da['resolveGetters']=_0x469d82[_0x2f14d5(0xcb)],_0x5cb8da[_0x2f14d5(0xd4)]=0x0,_0x5cb8da[_0x2f14d5(0x128)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x5cb8da;};for(var _0x7432f7=0x0;_0x7432f7<_0x45c8dc['length'];_0x7432f7++)_0x7ce882[_0x490e67(0xff)](_0x4277ae[_0x490e67(0x158)]({'timeNode':_0x5afffa===_0x490e67(0x15e)||void 0x0},_0x45c8dc[_0x7432f7],_0x204f3a(_0x3afea7),{}));if(_0x5afffa===_0x490e67(0x17c)||_0x5afffa===_0x490e67(0x1bb)){let _0x5b3615=Error[_0x490e67(0x16f)];try{Error['stackTraceLimit']=0x1/0x0,_0x7ce882['push'](_0x4277ae[_0x490e67(0x158)]({'stackNode':!0x0},new Error()[_0x490e67(0x123)],_0x204f3a(_0x3afea7),{'strLength':0x1/0x0}));}finally{Error[_0x490e67(0x16f)]=_0x5b3615;}}return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':_0x7ce882,'id':_0x4a459c,'context':_0x17015d}]};}catch(_0x84cbeb){return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':[{'type':_0x490e67(0x16e),'error':_0x84cbeb&&_0x84cbeb[_0x490e67(0x188)]}],'id':_0x4a459c,'context':_0x17015d}]};}finally{try{if(_0x97a821&&_0x4538cb){let _0x432ee2=_0x223738();_0x97a821['count']++,_0x97a821['time']+=_0x42fb36(_0x4538cb,_0x432ee2),_0x97a821['ts']=_0x432ee2,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]++,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]+=_0x42fb36(_0x4538cb,_0x432ee2),_0x1f3bee[_0x490e67(0x1cd)]['ts']=_0x432ee2,(_0x97a821[_0x490e67(0x180)]>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x12d)]||_0x97a821['time']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1bc)])&&(_0x97a821[_0x490e67(0x171)]=!0x0),(_0x1f3bee['hits']['count']>_0x141946[_0x490e67(0x13f)][_0x490e67(0x12d)]||_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]>_0x141946[_0x490e67(0x13f)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x1f3bee[_0x490e67(0x1cd)]['reduceLimits']=!0x0);}}catch{}}}return _0x1e6d74;}function _0x2214(){var _0x14499a=['value','undefined','rootExpression','path','_treeNodePropertiesBeforeFullValue','origin','data','resolveGetters','_addProperty','expo','_blacklistedProperty','_getOwnPropertyDescriptor','timeStamp','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','elements','null','allStrLength','_regExpToString','react-native','Map','2eFQllr','ninjaSuppressConsole',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','coverage','_isArray','_connected','hrtime','toString','_setNodePermissions','bound\\x20Promise','reducePolicy','_reconnectTimeout','...','nan','resetWhenQuietMs','Number','_ninjaIgnoreNextError','_hasSymbolPropertyOnItsPath','current','Set','import(\\x27url\\x27)','bigint','sort','_cleanNode','_connectToHostNow','bind','catch','_hasSetOnItsPath','\\x20server','get','NEGATIVE_INFINITY','1.0.0','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','_addLoadNode','_consoleNinjaAllowedToStart','array','length','props','_p_name','push','performance','location','POSITIVE_INFINITY','date','autoExpand','10162370kgItlO','map','disabledTrace','10.0.2.2','_numberRegExp','env','symbol','resolve','root_exp','onmessage','test','strLength','port','concat','_WebSocket','then','level','log','_addObjectProperty','object','_isSet','getOwnPropertyDescriptor','Error','isExpressionToEvaluate','edge','charAt','match','parent','indexOf','valueOf','stack','warn','_connecting','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_setNodeId','node','next.js','versions','1668317DHAXqx','_property','reduceOnCount','_getOwnPropertySymbols','_undefined','positiveInfinity','_propertyName','_dateToString','_sendErrorMessage','gateway.docker.internal','remix','_treeNodePropertiesAfterFullValue','984054cwWOKG','reducedLimits','_capIfString','_keyStrRegExp','cappedProps','_attemptToReconnectShortly','_socket','reload','global','endsWith','args','RegExp','_extendedWarning','onerror','funcName','_isPrimitiveWrapperType','_disposeWebsocket','next.js','[object\\x20BigInt]','index','_maxConnectAttemptCount','[object\\x20Array]',\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",'getOwnPropertyNames','constructor','dockerizedApp','type','142700orZAYJ','includes','replace','51827','hasOwnProperty','boolean','serialize','_quotedRegExp','_setNodeExpressionPath','unref','join','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','time','depth','modules','_HTMLAllCollection','slice','method','nodeModules','_console_ninja','parse','415197WHEhXo','elapsed','process','eventReceivedCallback','getOwnPropertySymbols','_setNodeExpandableState','[object\\x20Map]','unknown','stackTraceLimit','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','reduceLimits','substr','isArray','_allowedToSend','stringify','console','disabledLog','_Symbol','_webSocketErrorDocsLink','_getOwnPropertyNames','getter','trace','send','_p_','[object\\x20Set]','count','','_allowedToConnectOnSend','hostname','negativeInfinity','set','autoExpandPropertyCount','_isNegativeZero','message','autoExpandMaxDepth','prototype','iterator','_addFunctionsNode','https://tinyurl.com/37x8b79t','angular','127.0.0.1','import(\\x27path\\x27)','totalStrLength','host','NEXT_RUNTIME','_ws','call','function','5lYlfxC','56GExRSR','Boolean','1563852BMXApG',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'_setNodeLabel','_isPrimitiveType','_isUndefined','Symbol','_processTreeNodeResult','_WebSocketClass','ExpoDevice','_isMap','default','_console_ninja_session','now','autoExpandLimit','android','string','11djOgAe','HTMLAllCollection','unshift','_type','capped','_sortProps','resetOnProcessingTimeAverageMs','_inBrowser','number','url','autoExpandPreviousObjects','WebSocket','toUpperCase','_hasMapOnItsPath','[object\\x20Date]','cappedElements','forEach','error','reduceOnAccumulatedProcessingTimeMs','toLowerCase','_connectAttemptCount','noFunctions','207488XhRovp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','split','name','logger\\x20websocket\\x20error','getWebSocketClass',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'_objectToString','String','_additionalMetadata','readyState','perLogpoint','defaultLimits','hits','expressionsToEvaluate','negativeZero'];_0x2214=function(){return _0x14499a;};return _0x2214();}function G(_0x3130d3){var _0x84a520=_0x54cc26;if(_0x3130d3&&typeof _0x3130d3==_0x84a520(0x118)&&_0x3130d3[_0x84a520(0x14f)])switch(_0x3130d3[_0x84a520(0x14f)][_0x84a520(0x1c3)]){case'Promise':return _0x3130d3[_0x84a520(0x156)](Symbol[_0x84a520(0x18b)])?Promise['resolve']():_0x3130d3;case _0x84a520(0xe1):return Promise[_0x84a520(0x10c)]();}return _0x3130d3;}function _0x4a90(_0xbf85a4,_0x245df9){var _0x2214cf=_0x2214();return _0x4a90=function(_0x4a90b3,_0x346472){_0x4a90b3=_0x4a90b3-0xc3;var _0x3eefbb=_0x2214cf[_0x4a90b3];return _0x3eefbb;},_0x4a90(_0xbf85a4,_0x245df9);}((_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x269295,_0x304d0c,_0x56b187,_0x5799d3,_0x19f830,_0x5a3a2e,_0x231e3c)=>{var _0x4818fc=_0x54cc26;if(_0x3cca3d[_0x4818fc(0x165)])return _0x3cca3d[_0x4818fc(0x165)];let _0x52e3da={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x3cca3d,_0x56b187,_0x38abea))return _0x3cca3d[_0x4818fc(0x165)]=_0x52e3da,_0x3cca3d['_console_ninja'];let _0x44b593=b(_0x3cca3d),_0x48380c=_0x44b593[_0x4818fc(0x168)],_0x1338d8=_0x44b593[_0x4818fc(0xd0)],_0x29d139=_0x44b593[_0x4818fc(0x1a6)],_0x1ed58e={'hits':{},'ts':{}},_0x19f55c=J(_0x3cca3d,_0x5799d3,_0x1ed58e,_0x269295,_0x231e3c,_0x38abea===_0x4818fc(0x129)?G:void 0x0),_0x59946f=(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0)=>{var _0x40d17e=_0x4818fc;let _0x218bcb=_0x3cca3d['_console_ninja'];try{return _0x3cca3d['_console_ninja']=_0x52e3da,_0x19f55c(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0);}finally{_0x3cca3d[_0x40d17e(0x165)]=_0x218bcb;}},_0x22921d=_0x423627=>{_0x1ed58e['ts'][_0x423627]=_0x1338d8();},_0x45102e=(_0x88203,_0x370b7a)=>{var _0x9ec8e9=_0x4818fc;let _0x3d041a=_0x1ed58e['ts'][_0x370b7a];if(delete _0x1ed58e['ts'][_0x370b7a],_0x3d041a){let _0x52a6eb=_0x48380c(_0x3d041a,_0x1338d8());_0x312a62(_0x59946f(_0x9ec8e9(0x15e),_0x88203,_0x29d139(),_0x9b859d,[_0x52a6eb],_0x370b7a));}},_0x2ee867=_0x41fceb=>{var _0x5bbca8=_0x4818fc,_0x5ba44d;return _0x38abea==='next.js'&&_0x3cca3d[_0x5bbca8(0xc9)]&&((_0x5ba44d=_0x41fceb==null?void 0x0:_0x41fceb[_0x5bbca8(0x141)])==null?void 0x0:_0x5ba44d[_0x5bbca8(0xfc)])&&(_0x41fceb['args'][0x0][_0x5bbca8(0xc9)]=_0x3cca3d[_0x5bbca8(0xc9)]),_0x41fceb;};_0x3cca3d[_0x4818fc(0x165)]={'consoleLog':(_0x1d0443,_0x2f73e4)=>{var _0x97f6bc=_0x4818fc;_0x3cca3d[_0x97f6bc(0x176)][_0x97f6bc(0x116)][_0x97f6bc(0x1c3)]!==_0x97f6bc(0x177)&&_0x312a62(_0x59946f(_0x97f6bc(0x116),_0x1d0443,_0x29d139(),_0x9b859d,_0x2f73e4));},'consoleTrace':(_0x4f29ba,_0x40e0fb)=>{var _0x5ea07f=_0x4818fc,_0xb083e5,_0x274db5;_0x3cca3d[_0x5ea07f(0x176)][_0x5ea07f(0x116)][_0x5ea07f(0x1c3)]!==_0x5ea07f(0x107)&&((_0x274db5=(_0xb083e5=_0x3cca3d['process'])==null?void 0x0:_0xb083e5[_0x5ea07f(0x12a)])!=null&&_0x274db5[_0x5ea07f(0x128)]&&(_0x3cca3d[_0x5ea07f(0xe8)]=!0x0),_0x312a62(_0x2ee867(_0x59946f(_0x5ea07f(0x17c),_0x4f29ba,_0x29d139(),_0x9b859d,_0x40e0fb))));},'consoleError':(_0x2bc0da,_0x1c2aec)=>{var _0x1781f6=_0x4818fc;_0x3cca3d[_0x1781f6(0xe8)]=!0x0,_0x312a62(_0x2ee867(_0x59946f(_0x1781f6(0x1bb),_0x2bc0da,_0x29d139(),_0x9b859d,_0x1c2aec)));},'consoleTime':_0x39580d=>{_0x22921d(_0x39580d);},'consoleTimeEnd':(_0x3bc815,_0x207b89)=>{_0x45102e(_0x207b89,_0x3bc815);},'autoLog':(_0x1feae7,_0x412215)=>{var _0x28d3ed=_0x4818fc;_0x312a62(_0x59946f(_0x28d3ed(0x116),_0x412215,_0x29d139(),_0x9b859d,[_0x1feae7]));},'autoLogMany':(_0x2ec4aa,_0x3ebbc7)=>{_0x312a62(_0x59946f('log',_0x2ec4aa,_0x29d139(),_0x9b859d,_0x3ebbc7));},'autoTrace':(_0x1181a3,_0x59d6b5)=>{_0x312a62(_0x2ee867(_0x59946f('trace',_0x59d6b5,_0x29d139(),_0x9b859d,[_0x1181a3])));},'autoTraceMany':(_0x5d59ec,_0x321085)=>{var _0x254ed6=_0x4818fc;_0x312a62(_0x2ee867(_0x59946f(_0x254ed6(0x17c),_0x5d59ec,_0x29d139(),_0x9b859d,_0x321085)));},'autoTime':(_0x221590,_0x1740ad,_0x144e01)=>{_0x22921d(_0x144e01);},'autoTimeEnd':(_0x37d7ca,_0x1b7b6f,_0x52089f)=>{_0x45102e(_0x1b7b6f,_0x52089f);},'coverage':_0x2fe387=>{var _0xeb334b=_0x4818fc;_0x312a62({'method':_0xeb334b(0xdb),'version':_0x269295,'args':[{'id':_0x2fe387}]});}};let _0x312a62=H(_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x19f830,_0x5a3a2e),_0x9b859d=_0x3cca3d[_0x4818fc(0x1a5)];return _0x3cca3d[_0x4818fc(0x165)];})(globalThis,_0x54cc26(0x18f),_0x54cc26(0x155),_0x54cc26(0x14d),_0x54cc26(0x148),_0x54cc26(0xf7),'1763946797424',_0x54cc26(0x1c6),_0x54cc26(0x181),'','1',_0x54cc26(0x19b));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "TranslationsProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/lib/trpc.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "trpc",
    ()=>trpc
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$trpc$2f$react$2d$query$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@trpc/react-query/dist/index.mjs [app-client] (ecmascript) <locals>");
;
const trpc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$trpc$2f$react$2d$query$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createTRPCReact"])();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/context/providers/TrpcProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TrpcProvider",
    ()=>TrpcProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@trpc/client/dist/index.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$httpBatchLink$2d$CA96$2d$gnJ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@trpc/client/dist/httpBatchLink-CA96-gnJ.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/trpc.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function TrpcProvider({ children }) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [trpcClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "TrpcProvider.useState": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].createClient({
                links: [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$trpc$2f$client$2f$dist$2f$httpBatchLink$2d$CA96$2d$gnJ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["httpBatchLink"])({
                        url: ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'http://localhost:3001/trpc',
                        fetch (url, options) {
                            return fetch(url, {
                                ...options,
                                credentials: 'include'
                            });
                        }
                    })
                ]
            })
    }["TrpcProvider.useState"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].Provider, {
        client: trpcClient,
        queryClient: queryClient,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/context/providers/TrpcProvider.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
}
_s(TrpcProvider, "XBUy/0jnJUOMQGz2hxdybUIceNs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"]
    ];
});
_c = TrpcProvider;
var _c;
__turbopack_context__.k.register(_c, "TrpcProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/lib/utils/color/color-conversions-v2.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Color Conversions V2 - Precise conversions using Culori
 * Provides scientifically accurate bidirectional color conversions
 */ __turbopack_context__.s([
    "createPreciseColorToken",
    ()=>createPreciseColorToken,
    "formatHexDisplay",
    ()=>formatHexDisplay,
    "formatHsvDisplay",
    ()=>formatHsvDisplay,
    "formatOklchDisplay",
    ()=>formatOklchDisplay,
    "formatRgbDisplay",
    ()=>formatRgbDisplay,
    "hexToOklch",
    ()=>hexToOklch,
    "hexToRgb",
    ()=>hexToRgb,
    "hsvToHex",
    ()=>hsvToHex,
    "hsvToRgb",
    ()=>hsvToRgb,
    "isValidHex",
    ()=>isValidHex,
    "isValidHsv",
    ()=>isValidHsv,
    "isValidOklch",
    ()=>isValidOklch,
    "isValidRgb",
    ()=>isValidRgb,
    "oklchToHex",
    ()=>oklchToHex,
    "oklchToRgb",
    ()=>oklchToRgb,
    "rgbToHex",
    ()=>rgbToHex,
    "rgbToHsv",
    ()=>rgbToHsv,
    "rgbToOklch",
    ()=>rgbToOklch,
    "updateColorTokenFromHex",
    ()=>updateColorTokenFromHex,
    "updateColorTokenFromHsv",
    ()=>updateColorTokenFromHsv,
    "updateColorTokenFromOklch",
    ()=>updateColorTokenFromOklch,
    "updateColorTokenFromRgb",
    ()=>updateColorTokenFromRgb
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/culori/src/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$formatter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/culori/src/formatter.js [app-client] (ecmascript)");
;
function createPreciseColorToken(name, inputColor, description) {
    // Convert input to Culori OKLCH
    const oklchColor = typeof inputColor === 'string' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["oklch"])(inputColor) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["oklch"])({
        mode: 'oklch',
        ...inputColor
    });
    // Convert to other color spaces using Culori
    const rgbColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["rgb"])(oklchColor);
    const hsvColor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hsv"])(oklchColor);
    const oklchString = `oklch(${(oklchColor.l || 0).toFixed(4)} ${(oklchColor.c || 0).toFixed(4)} ${(oklchColor.h || 0).toFixed(2)})`;
    return {
        name,
        hex: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$formatter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatHex"])(oklchColor),
        oklch: {
            l: Math.min(1, Math.max(0, oklchColor.l || 0)),
            c: Math.max(0, oklchColor.c || 0),
            h: oklchColor.h || 0
        },
        oklchString,
        rgb: {
            r: Math.round((rgbColor.r || 0) * 255),
            g: Math.round((rgbColor.g || 0) * 255),
            b: Math.round((rgbColor.b || 0) * 255)
        },
        hsv: {
            h: hsvColor.h || 0,
            s: (hsvColor.s || 0) * 100,
            v: (hsvColor.v || 0) * 100
        },
        description,
        value: oklchString // Legacy compatibility
    };
}
function updateColorTokenFromHex(existingToken, hexValue) {
    const newToken = createPreciseColorToken(existingToken.name, hexValue, existingToken.description);
    // Preserve linking properties
    return {
        ...newToken,
        linkedTo: existingToken.linkedTo,
        linkedColors: existingToken.linkedColors
    };
}
function updateColorTokenFromRgb(existingToken, rgbValue) {
    const hexValue = `#${rgbValue.r.toString(16).padStart(2, '0')}${rgbValue.g.toString(16).padStart(2, '0')}${rgbValue.b.toString(16).padStart(2, '0')}`;
    const newToken = createPreciseColorToken(existingToken.name, hexValue, existingToken.description);
    // Preserve linking properties
    return {
        ...newToken,
        linkedTo: existingToken.linkedTo,
        linkedColors: existingToken.linkedColors
    };
}
function updateColorTokenFromHsv(existingToken, hsvValue) {
    // Convert HSV to Culori format
    const culoriHsv = {
        mode: 'hsv',
        h: hsvValue.h,
        s: hsvValue.s / 100,
        v: hsvValue.v / 100
    };
    const hexValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$culori$2f$src$2f$formatter$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatHex"])(culoriHsv);
    const newToken = createPreciseColorToken(existingToken.name, hexValue, existingToken.description);
    // Preserve linking properties
    return {
        ...newToken,
        linkedTo: existingToken.linkedTo,
        linkedColors: existingToken.linkedColors
    };
}
function updateColorTokenFromOklch(existingToken, oklchValue) {
    const newToken = createPreciseColorToken(existingToken.name, oklchValue, existingToken.description);
    // Preserve linking properties
    return {
        ...newToken,
        linkedTo: existingToken.linkedTo,
        linkedColors: existingToken.linkedColors
    };
}
function isValidHex(hex) {
    const cleanHex = hex.replace('#', '');
    return /^[0-9A-Fa-f]{3}$|^[0-9A-Fa-f]{6}$/.test(cleanHex);
}
function isValidRgb(rgb) {
    return rgb.r >= 0 && rgb.r <= 255 && rgb.g >= 0 && rgb.g <= 255 && rgb.b >= 0 && rgb.b <= 255;
}
function isValidHsv(hsv) {
    return hsv.h >= 0 && hsv.h <= 360 && hsv.s >= 0 && hsv.s <= 100 && hsv.v >= 0 && hsv.v <= 100;
}
function isValidOklch(oklch) {
    return oklch.l >= 0 && oklch.l <= 1 && oklch.c >= 0 && oklch.c <= 0.5 && // More generous chroma limit
    oklch.h >= 0 && oklch.h <= 360;
}
function formatHexDisplay(hex) {
    return hex.toUpperCase();
}
function formatRgbDisplay(rgb) {
    return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
}
function formatHsvDisplay(hsv) {
    return `hsv(${hsv.h.toFixed(1)}°, ${hsv.s.toFixed(1)}%, ${hsv.v.toFixed(1)}%)`;
}
function formatOklchDisplay(oklch) {
    return `oklch(${oklch.l.toFixed(4)} ${oklch.c.toFixed(4)} ${oklch.h.toFixed(2)})`;
}
const hexToRgb = (hex)=>{
    try {
        const token = createPreciseColorToken('temp', hex);
        return token.rgb;
    } catch  {
        return null;
    }
};
const rgbToHex = (rgb)=>{
    const token = updateColorTokenFromRgb({
        name: 'temp',
        hex: '#000000',
        oklch: {
            l: 0,
            c: 0,
            h: 0
        },
        oklchString: '',
        rgb: {
            r: 0,
            g: 0,
            b: 0
        },
        hsv: {
            h: 0,
            s: 0,
            v: 0
        }
    }, rgb);
    return token.hex;
};
const hsvToRgb = (hsv)=>{
    const token = updateColorTokenFromHsv({
        name: 'temp',
        hex: '#000000',
        oklch: {
            l: 0,
            c: 0,
            h: 0
        },
        oklchString: '',
        rgb: {
            r: 0,
            g: 0,
            b: 0
        },
        hsv: {
            h: 0,
            s: 0,
            v: 0
        }
    }, hsv);
    return token.rgb;
};
const rgbToHsv = (rgb)=>{
    const token = updateColorTokenFromRgb({
        name: 'temp',
        hex: '#000000',
        oklch: {
            l: 0,
            c: 0,
            h: 0
        },
        oklchString: '',
        rgb: {
            r: 0,
            g: 0,
            b: 0
        },
        hsv: {
            h: 0,
            s: 0,
            v: 0
        }
    }, rgb);
    return token.hsv;
};
const hsvToHex = (hsv)=>{
    const token = updateColorTokenFromHsv({
        name: 'temp',
        hex: '#000000',
        oklch: {
            l: 0,
            c: 0,
            h: 0
        },
        oklchString: '',
        rgb: {
            r: 0,
            g: 0,
            b: 0
        },
        hsv: {
            h: 0,
            s: 0,
            v: 0
        }
    }, hsv);
    return token.hex;
};
const oklchToHex = (oklch)=>{
    const token = createPreciseColorToken('temp', oklch);
    return token.hex;
};
const hexToOklch = (hex)=>{
    try {
        const token = createPreciseColorToken('temp', hex);
        return token.oklch;
    } catch  {
        return null;
    }
};
const oklchToRgb = (oklch)=>{
    const token = createPreciseColorToken('temp', oklch);
    return token.rgb;
};
const rgbToOklch = (rgb)=>{
    const token = updateColorTokenFromRgb({
        name: 'temp',
        hex: '#000000',
        oklch: {
            l: 0,
            c: 0,
            h: 0
        },
        oklchString: '',
        rgb: {
            r: 0,
            g: 0,
            b: 0
        },
        hsv: {
            h: 0,
            s: 0,
            v: 0
        }
    }, rgb);
    return token.oklch;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/theme-editor/editor/brand/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDefaultModeConfig",
    ()=>createDefaultModeConfig,
    "detectColorsFromSVG",
    ()=>detectColorsFromSVG,
    "extractSVGMetadata",
    ()=>extractSVGMetadata,
    "generateColorVariants",
    ()=>generateColorVariants,
    "getCurrentModeIsLinked",
    ()=>getCurrentModeIsLinked,
    "getCurrentModeMonoColor",
    ()=>getCurrentModeMonoColor,
    "getCurrentModeVariants",
    ()=>getCurrentModeVariants,
    "normalizeSVGForContainer",
    ()=>normalizeSVGForContainer,
    "readSVGContent",
    ()=>readSVGContent,
    "replaceColorInSVG",
    ()=>replaceColorInSVG,
    "validateAspectRatio",
    ()=>validateAspectRatio
]);
const detectColorsFromSVG = (svgContent)=>{
    const colors = new Set();
    // Expresiones regulares mejoradas para detectar diferentes formatos de colores
    const hexColorRegex = /#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})\b/g;
    const rgbColorRegex = /rgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)/g;
    const rgbaColorRegex = /rgba\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([0-9.]+)\s*\)/g;
    const hslColorRegex = /hsl\s*\(\s*(\d+)\s*,\s*(\d+)%\s*,\s*(\d+)%\s*\)/g;
    const namedColorRegex = /\b(red|blue|green|yellow|orange|purple|pink|brown|gray|grey|black|white|cyan|magenta|lime|navy|olive|teal|silver|maroon|aqua|fuchsia|darkred|darkblue|darkgreen|lightblue|lightgreen|lightgray|lightgrey|darkgray|darkgrey)\b/gi;
    // También buscar en atributos específicos
    const fillRegex = /fill\s*=\s*["']([^"']+)["']/g;
    const strokeRegex = /stroke\s*=\s*["']([^"']+)["']/g;
    const stopColorRegex = /stop-color\s*=\s*["']([^"']+)["']/g;
    const colorPropertyRegex = /color\s*:\s*([^;]+);/g;
    const fillPropertyRegex = /fill\s*:\s*([^;]+);/g;
    const strokePropertyRegex = /stroke\s*:\s*([^;]+);/g;
    // Función helper para convertir RGB a HEX
    const rgbToHex = (r, g, b)=>{
        return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).padStart(6, '0')}`;
    };
    // Función helper para convertir HSL a HEX
    const hslToHex = (h, s, l)=>{
        l /= 100;
        const a = s * Math.min(l, 1 - l) / 100;
        const f = (n)=>{
            const k = (n + h / 30) % 12;
            const color = l - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
            return Math.round(255 * color).toString(16).padStart(2, '0');
        };
        return `#${f(0)}${f(8)}${f(4)}`;
    };
    // Detectar colores hexadecimales
    let match;
    while((match = hexColorRegex.exec(svgContent)) !== null){
        let hex = match[0].toLowerCase();
        // Convertir hex de 3 caracteres a 6
        if (hex.length === 4) {
            hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
        }
        colors.add(hex);
    }
    // Detectar colores RGB
    while((match = rgbColorRegex.exec(svgContent)) !== null){
        const r = parseInt(match[1]);
        const g = parseInt(match[2]);
        const b = parseInt(match[3]);
        const hex = rgbToHex(r, g, b);
        colors.add(hex);
    }
    // Detectar colores RGBA (ignorar alpha por ahora)
    while((match = rgbaColorRegex.exec(svgContent)) !== null){
        const r = parseInt(match[1]);
        const g = parseInt(match[2]);
        const b = parseInt(match[3]);
        const hex = rgbToHex(r, g, b);
        colors.add(hex);
    }
    // Detectar colores HSL
    while((match = hslColorRegex.exec(svgContent)) !== null){
        const h = parseInt(match[1]);
        const s = parseInt(match[2]);
        const l = parseInt(match[3]);
        const hex = hslToHex(h, s, l);
        colors.add(hex);
    }
    // Detectar colores en atributos fill
    while((match = fillRegex.exec(svgContent)) !== null){
        const colorValue = match[1];
        if (colorValue !== 'none' && colorValue !== 'transparent' && !colorValue.startsWith('url(')) {
            if (colorValue.startsWith('#')) {
                let hex = colorValue.toLowerCase();
                if (hex.length === 4) {
                    hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
                }
                colors.add(hex);
            }
        }
    }
    // Detectar colores en atributos stroke
    while((match = strokeRegex.exec(svgContent)) !== null){
        const colorValue = match[1];
        if (colorValue !== 'none' && colorValue !== 'transparent' && !colorValue.startsWith('url(')) {
            if (colorValue.startsWith('#')) {
                let hex = colorValue.toLowerCase();
                if (hex.length === 4) {
                    hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
                }
                colors.add(hex);
            }
        }
    }
    // Detectar colores en stop-color (gradientes)
    while((match = stopColorRegex.exec(svgContent)) !== null){
        const colorValue = match[1];
        if (colorValue.startsWith('#')) {
            let hex = colorValue.toLowerCase();
            if (hex.length === 4) {
                hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
            }
            colors.add(hex);
        }
    }
    // Detectar colores con nombres en atributos
    const namedColors = {
        'red': '#ff0000',
        'blue': '#0000ff',
        'green': '#008000',
        'yellow': '#ffff00',
        'orange': '#ffa500',
        'purple': '#800080',
        'pink': '#ffc0cb',
        'brown': '#a52a2a',
        'gray': '#808080',
        'grey': '#808080',
        'black': '#000000',
        'white': '#ffffff',
        'cyan': '#00ffff',
        'magenta': '#ff00ff',
        'lime': '#00ff00',
        'navy': '#000080',
        'olive': '#808000',
        'teal': '#008080',
        'silver': '#c0c0c0',
        'maroon': '#800000',
        'aqua': '#00ffff',
        'fuchsia': '#ff00ff',
        'darkred': '#8b0000',
        'darkblue': '#00008b',
        'darkgreen': '#006400',
        'lightblue': '#add8e6',
        'lightgreen': '#90ee90',
        'lightgray': '#d3d3d3',
        'lightgrey': '#d3d3d3',
        'darkgray': '#a9a9a9',
        'darkgrey': '#a9a9a9'
    };
    // Buscar colores nombrados en atributos específicos
    Object.entries(namedColors).forEach(([name, hex])=>{
        const namedInAttrRegex = new RegExp(`(fill|stroke|stop-color|flood-color|color)\\s*=\\s*["']${name}["']`, 'gi');
        const namedInStyleRegex = new RegExp(`(fill|stroke|stop-color|flood-color|color)\\s*:\\s*${name}`, 'gi');
        if (namedInAttrRegex.test(svgContent) || namedInStyleRegex.test(svgContent)) {
            colors.add(hex);
        }
    });
    // Detectar colores en elementos <text> y <tspan>
    const textColorRegex = /<(text|tspan)[^>]*(?:fill|stroke|color)\s*=\s*["']([^"']+)["'][^>]*>/gi;
    while((match = textColorRegex.exec(svgContent)) !== null){
        const colorValue = match[2];
        if (colorValue.startsWith('#')) {
            let hex = colorValue.toLowerCase();
            if (hex.length === 4) {
                hex = `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
            }
            colors.add(hex);
        } else if (namedColors[colorValue.toLowerCase()]) {
            colors.add(namedColors[colorValue.toLowerCase()]);
        }
    }
    // NO filtrar ningún color - devolver TODOS los detectados incluyendo negro y blanco
    const allColors = Array.from(colors);
    // Ordenar por frecuencia de aparición (colores más usados primero)
    const colorFrequency = new Map();
    allColors.forEach((color)=>{
        const frequency = (svgContent.match(new RegExp(color.replace('#', '#?'), 'gi')) || []).length;
        colorFrequency.set(color, frequency);
    });
    return allColors.sort((a, b)=>(colorFrequency.get(b) || 0) - (colorFrequency.get(a) || 0));
};
// Función para reemplazar TODOS los colores del SVG con un solo color
const replaceAllColorsInSVG = (svgContent, newColor)=>{
    let result = svgContent;
    // Diccionario de colores nombrados comunes
    const colorNames = [
        'black',
        'white',
        'red',
        'blue',
        'green',
        'yellow',
        'orange',
        'purple',
        'pink',
        'brown',
        'gray',
        'grey',
        'cyan',
        'magenta',
        'lime',
        'navy',
        'olive',
        'teal',
        'silver',
        'maroon',
        'aqua',
        'fuchsia'
    ];
    // Atributos que pueden contener colores
    const colorAttributes = [
        'fill',
        'stroke',
        'stop-color',
        'flood-color',
        'color'
    ];
    // 1. Reemplazar colores hex (#123456, #123, etc.)
    const hexRegex = /#[0-9a-fA-F]{6}|#[0-9a-fA-F]{3}/g;
    result = result.replace(hexRegex, newColor);
    // 2. Reemplazar colores nombrados
    colorNames.forEach((colorName)=>{
        colorAttributes.forEach((attr)=>{
            // En atributos: fill="black" -> fill="#000000"
            const attrRegex = new RegExp(`(${attr})\\s*=\\s*["']${colorName}["']`, 'gi');
            result = result.replace(attrRegex, `$1="${newColor}"`);
            // En estilos: fill:black -> fill:#000000
            const styleRegex = new RegExp(`(${attr})\\s*:\\s*${colorName}`, 'gi');
            result = result.replace(styleRegex, `$1:${newColor}`);
        });
    });
    // 3. Reemplazar colores rgb/rgba
    const rgbRegex = /rgba?\([^)]+\)/g;
    result = result.replace(rgbRegex, newColor);
    return result;
};
const generateColorVariants = (svgContent, detectedColors, monoColor = '#000000', isDarkMode = false)=>{
    // Normalizar el SVG original primero
    const normalizedOriginal = normalizeSVGForContainer(svgContent);
    const variants = {
        original: normalizedOriginal,
        white: '',
        black: '',
        gray: ''
    };
    // Generar versión "Negativo" - SIEMPRE contrastante 
    // Para light mode: blanco (se muestra en fondos oscuros en la preview)
    // Para dark mode: negro (se muestra en fondos claros en la preview)
    const negativeColor = isDarkMode ? '#000000' : '#ffffff';
    variants.white = replaceAllColorsInSVG(normalizedOriginal, negativeColor);
    // Generar versión mono-color (usa el color primary del tema actual)
    variants.black = replaceColorsInSVG(normalizedOriginal, detectedColors, monoColor);
    // Generar versión en gris (color fijo pero apropiado para cada modo)
    const grayColor = isDarkMode ? '#9ca3af' : '#6b7280';
    variants.gray = replaceColorsInSVG(normalizedOriginal, detectedColors, grayColor);
    return variants;
};
const replaceColorsInSVG = (svgContent, originalColors, newColor)=>{
    let result = svgContent;
    // Si estamos reemplazando con blanco, negro o gris, asegurarnos de reemplazar TODOS los colores
    const isMonochrome = newColor === '#ffffff' || newColor === '#000000' || newColor === '#808080';
    originalColors.forEach((color)=>{
        // Preparar el color para búsqueda (escapar caracteres especiales)
        const escapeRegex = (str)=>str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        // Normalizar el color a minúsculas para comparación
        const colorLower = color.toLowerCase();
        const newColorFormatted = newColor.toLowerCase();
        // 1. Reemplazar en TODOS los atributos posibles (no solo fill/stroke)
        // Buscar el color en cualquier atributo que pueda contener colores
        const attributeNames = [
            'fill',
            'stroke',
            'stop-color',
            'flood-color',
            'lighting-color',
            'color',
            'background-color',
            'border-color',
            'outline-color',
            'text-decoration-color',
            'column-rule-color'
        ];
        // Reemplazar el color hex completo (#ffffff)
        const hexRegex = new RegExp(escapeRegex(colorLower), 'gi');
        result = result.replace(hexRegex, newColor);
        // También buscar variaciones de caso
        const hexRegexCase = new RegExp(escapeRegex(color), 'g');
        result = result.replace(hexRegexCase, newColor);
        // 2. Reemplazar en atributos sin #
        if (color.startsWith('#')) {
            const colorWithoutHash = color.substring(1);
            const colorWithoutHashLower = colorWithoutHash.toLowerCase();
            // En cualquier atributo
            attributeNames.forEach((attr)=>{
                // Formato: fill="#ffffff" o fill="#FFFFFF"
                const attrWithHashRegex = new RegExp(`(${attr})\\s*=\\s*["']${escapeRegex(color)}["']`, 'gi');
                result = result.replace(attrWithHashRegex, `$1="${newColor}"`);
                // Formato: fill="ffffff" o fill="FFFFFF"
                const attrNoHashRegex = new RegExp(`(${attr})\\s*=\\s*["']${escapeRegex(colorWithoutHash)}["']`, 'gi');
                result = result.replace(attrNoHashRegex, `$1="${newColor.substring(1)}"`);
                // En estilos inline: style="fill:#ffffff" o style="fill:ffffff"
                const styleWithHashRegex = new RegExp(`(${attr})\\s*:\\s*${escapeRegex(color)}`, 'gi');
                result = result.replace(styleWithHashRegex, `$1:${newColor}`);
                const styleNoHashRegex = new RegExp(`(${attr})\\s*:\\s*${escapeRegex(colorWithoutHash)}`, 'gi');
                result = result.replace(styleNoHashRegex, `$1:${newColor.substring(1)}`);
            });
        }
        // 3. Reemplazar colores nombrados (black, white, etc.)
        // Convertir colores comunes a sus nombres si coinciden
        const colorNames = {
            '#000000': [
                'black',
                '#000'
            ],
            '#ffffff': [
                'white',
                '#fff'
            ],
            '#ff0000': [
                'red',
                '#f00'
            ],
            '#00ff00': [
                'lime',
                '#0f0'
            ],
            '#0000ff': [
                'blue',
                '#00f'
            ],
            '#808080': [
                'gray',
                'grey'
            ]
        };
        // Si el color coincide con un color nombrado, reemplazar también el nombre
        Object.entries(colorNames).forEach(([hex, names])=>{
            if (colorLower === hex || names.some((n)=>`#${n}` === colorLower)) {
                names.forEach((name)=>{
                    // Reemplazar en atributos
                    attributeNames.forEach((attr)=>{
                        const namedAttrRegex = new RegExp(`(${attr})\\s*=\\s*["']${name}["']`, 'gi');
                        result = result.replace(namedAttrRegex, `$1="${newColor}"`);
                        const namedStyleRegex = new RegExp(`(${attr})\\s*:\\s*${name}`, 'gi');
                        result = result.replace(namedStyleRegex, `$1:${newColor}`);
                    });
                });
            }
        });
        // 4. Reemplazar en elementos <text> y <tspan> que pueden tener color directo
        // Buscar en style attributes dentro de text elements
        const textStyleRegex = new RegExp(`(<text[^>]*style="[^"]*)(fill|stroke|color)\\s*:\\s*${escapeRegex(color)}([^"]*")`, 'gi');
        result = result.replace(textStyleRegex, `$1$2:${newColor}$3`);
        // 5. Reemplazar formato corto de 3 caracteres
        if (color.length === 7) {
            // Verificar si se puede acortar a 3 caracteres
            if (color[1] === color[2] && color[3] === color[4] && color[5] === color[6]) {
                const shortHex = `#${color[1]}${color[3]}${color[5]}`.toLowerCase();
                const shortRegex = new RegExp(escapeRegex(shortHex), 'gi');
                result = result.replace(shortRegex, newColor);
            }
        }
    });
    return result;
};
const replaceColorInSVG = (svgContent, oldColor, newColor)=>{
    // Solo reemplazar el color, no re-normalizar si ya está normalizado
    let result = svgContent;
    // Hacer el reemplazo más agresivo para asegurar que funcione
    const escapeRegex = (str)=>str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Lista de todas las posibles formas en que puede aparecer el color
    const variations = [];
    // Agregar el color original
    variations.push(oldColor);
    variations.push(oldColor.toLowerCase());
    variations.push(oldColor.toUpperCase());
    // Si es hex, agregar variaciones sin #
    if (oldColor.startsWith('#')) {
        const withoutHash = oldColor.substring(1);
        variations.push(withoutHash);
        variations.push(withoutHash.toLowerCase());
        variations.push(withoutHash.toUpperCase());
        // Si es formato largo, agregar formato corto
        if (oldColor.length === 7 && oldColor[1] === oldColor[2] && oldColor[3] === oldColor[4] && oldColor[5] === oldColor[6]) {
            const shortForm = `#${oldColor[1]}${oldColor[3]}${oldColor[5]}`;
            variations.push(shortForm);
            variations.push(shortForm.toLowerCase());
            variations.push(shortForm.toUpperCase());
        }
    }
    // Mapeo de colores especiales
    const specialColors = {
        '#000000': [
            'black',
            '#000',
            '000000',
            '000'
        ],
        '#ffffff': [
            'white',
            '#fff',
            'ffffff',
            'fff'
        ],
        '#ff0000': [
            'red',
            '#f00',
            'ff0000',
            'f00'
        ],
        '#00ff00': [
            'lime',
            '#0f0',
            '00ff00',
            '0f0'
        ],
        '#0000ff': [
            'blue',
            '#00f',
            '0000ff',
            '00f'
        ]
    };
    // Agregar nombres de colores si aplica
    const oldColorLower = oldColor.toLowerCase();
    if (specialColors[oldColorLower]) {
        variations.push(...specialColors[oldColorLower]);
    }
    // Reemplazar todas las variaciones
    variations.forEach((variant)=>{
        // Reemplazo global sin importar el contexto
        const regex = new RegExp(escapeRegex(variant), 'gi');
        result = result.replace(regex, (match)=>{
            // Preservar el formato (si venía sin #, devolver sin #)
            if (!variant.includes('#') && newColor.startsWith('#')) {
                return newColor.substring(1);
            }
            return newColor;
        });
    });
    // Si el SVG no tiene width="100%" entonces normalizarlo
    if (!result.includes('width="100%"')) {
        return normalizeSVGForContainer(result);
    }
    return result;
};
const extractSVGMetadata = (svgContent, fileName)=>{
    // Calcular tamaño aproximado del archivo
    const fileSize = `${(new Blob([
        svgContent
    ]).size / 1024).toFixed(1)} KB`;
    // Extraer dimensiones
    const svgMatch = svgContent.match(/<svg[^>]*>/i);
    let dimensions = 'Auto';
    if (svgMatch) {
        const widthMatch = svgMatch[0].match(/width\s*=\s*["']([^"']*)["']/i);
        const heightMatch = svgMatch[0].match(/height\s*=\s*["']([^"']*)["']/i);
        if (widthMatch && heightMatch) {
            dimensions = `${widthMatch[1]} × ${heightMatch[1]}`;
        }
    }
    // Extraer viewBox
    let viewBox = 'None';
    if (svgMatch) {
        const viewBoxMatch = svgMatch[0].match(/viewBox\s*=\s*["']([^"']*)["']/i);
        if (viewBoxMatch) {
            viewBox = viewBoxMatch[1];
        }
    }
    // Contar colores
    const detectedColors = detectColorsFromSVG(svgContent);
    const colorCount = detectedColors.length;
    // Detectar gradientes
    const hasGradients = svgContent.includes('<gradient') || svgContent.includes('<linearGradient') || svgContent.includes('<radialGradient');
    return {
        fileName,
        fileSize,
        dimensions,
        viewBox,
        colorCount,
        hasGradients
    };
};
const validateAspectRatio = (file, expectedRatio)=>{
    return new Promise((resolve)=>{
        const img = new Image();
        img.onload = ()=>{
            const actualRatio = img.width / img.height;
            const [expectedW, expectedH] = expectedRatio.split(':').map(Number);
            const expectedRatioValue = expectedW / expectedH;
            // Permitir una tolerancia del 10%
            const tolerance = 0.1;
            const isValid = Math.abs(actualRatio - expectedRatioValue) <= tolerance;
            resolve(isValid);
        };
        img.onerror = ()=>resolve(false);
        // Convertir SVG a data URL para poder cargar en Image
        const reader = new FileReader();
        reader.onload = (e)=>{
            img.src = e.target?.result;
        };
        reader.readAsDataURL(file);
    });
};
const readSVGContent = (file)=>{
    return new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.onload = (e)=>{
            const content = e.target?.result;
            const normalizedContent = normalizeSVGForContainer(content);
            resolve(normalizedContent);
        };
        reader.onerror = ()=>reject(new Error('Error reading file'));
        reader.readAsText(file);
    });
};
const normalizeSVGForContainer = (svgContent)=>{
    // Normalizar el SVG para que se ajuste al contenedor
    let normalizedSVG = svgContent;
    // Buscar el tag svg y sus atributos
    const svgTagRegex = /<svg([^>]*)>/i;
    const match = normalizedSVG.match(svgTagRegex);
    if (match) {
        let svgAttributes = match[1];
        // Eliminar atributos de width y height fijos
        svgAttributes = svgAttributes.replace(/\s*width\s*=\s*["'][^"']*["']/gi, '');
        svgAttributes = svgAttributes.replace(/\s*height\s*=\s*["'][^"']*["']/gi, '');
        // Asegurar que tenga viewBox si no lo tiene
        if (!svgAttributes.includes('viewBox')) {
            // Si no tiene viewBox, intentar extraerlo de width/height originales
            const originalSvg = svgContent.match(/<svg([^>]*)>/i)?.[1] || '';
            const widthMatch = originalSvg.match(/width\s*=\s*["']([^"']*)["']/i);
            const heightMatch = originalSvg.match(/height\s*=\s*["']([^"']*)["']/i);
            if (widthMatch && heightMatch) {
                const width = parseFloat(widthMatch[1]);
                const height = parseFloat(heightMatch[1]);
                if (!isNaN(width) && !isNaN(height)) {
                    svgAttributes += ` viewBox="0 0 ${width} ${height}"`;
                }
            } else {
                // ViewBox por defecto si no se puede determinar
                svgAttributes += ` viewBox="0 0 100 100"`;
            }
        }
        // Añadir atributos para que se ajuste al contenedor
        svgAttributes += ` width="100%" height="100%" preserveAspectRatio="xMidYMid meet"`;
        // Reemplazar el tag svg original
        normalizedSVG = normalizedSVG.replace(svgTagRegex, `<svg${svgAttributes}>`);
    }
    return normalizedSVG;
};
const createDefaultModeConfig = (svgContent, detectedColors, monoColor, isDarkMode)=>{
    return {
        variants: generateColorVariants(svgContent, detectedColors, monoColor, isDarkMode),
        monoColor,
        isLinkedToPrimary: true
    };
};
const getCurrentModeVariants = (logo, isDarkMode)=>{
    // Si está en modo oscuro y existe una versión específica, usarla
    if (isDarkMode && logo.darkModeVersion?.variants) {
        return logo.darkModeVersion.variants;
    }
    // Usar ÚNICAMENTE la configuración específica del modo (estructura antigua como fallback)
    if (logo.darkMode && logo.lightMode) {
        return isDarkMode ? logo.darkMode.variants : logo.lightMode.variants;
    }
    // Fallback a la estructura original si no hay configuraciones específicas
    return logo.variants || {
        original: logo.svgContent || '',
        white: '',
        black: '',
        gray: ''
    };
};
const getCurrentModeMonoColor = (logo, isDarkMode)=>{
    return isDarkMode ? logo.darkMode.monoColor : logo.lightMode.monoColor;
};
const getCurrentModeIsLinked = (logo, isDarkMode)=>{
    return isDarkMode ? logo.darkMode.isLinkedToPrimary : logo.lightMode.isLinkedToPrimary;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/theme-editor/editor/brand/default-logos.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDefaultAlkituHorizontalLogo",
    ()=>createDefaultAlkituHorizontalLogo,
    "createDefaultAlkituIconLogo",
    ()=>createDefaultAlkituIconLogo,
    "createDefaultAlkituVerticalLogo",
    ()=>createDefaultAlkituVerticalLogo,
    "getDefaultBrandAssets",
    ()=>getDefaultBrandAssets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/theme-editor/editor/brand/utils.ts [app-client] (ecmascript)");
;
// SVG content for the default Alkitu logos
const ALKITU_ICON_SVG = `<svg width="54" height="51" viewBox="0 0 54 51" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M22.9481 31.4206H33.5498L26.4672 9.8328L13.1597 50.5391H0L19.222 0H33.8603L49.4006 41.0021H19.8283L22.9481 31.4206Z" fill="black"/>
<path d="M50.6723 44.3584L53.0233 50.539H39.8784L37.8379 44.3584H50.6723Z" fill="#2AB34B"/>
</svg>`;
const ALKITU_HORIZONTAL_SVG = `<svg width="204" height="57" viewBox="0 0 204 57" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M69.9692 6.31396V56.8087H57.0312V6.31396H69.9692Z" fill="black"/>
<path d="M127.932 16.1914V56.809H115.098V16.1914H127.932Z" fill="black"/>
<path d="M158.228 47.0942V56.8087H152.181C147.439 56.7496 143.758 55.5371 141.136 53.1713C138.504 50.7908 137.232 48.1884 137.276 42.821L137.439 26.0387H131.924V16.1911H137.528L137.631 6.31396H150.066L149.978 16.1763H158.228V25.8761H149.889L149.712 42.6584C149.577 43.8578 149.917 45.0622 150.658 46.0148C151.595 46.7435 152.772 47.0919 153.955 46.9907L158.228 47.0942Z" fill="black"/>
<path d="M203.415 16.2206L203.015 56.853H190.595V49.2086C189.42 51.5508 187.592 53.5024 185.331 54.8273C182.891 56.2374 180.105 56.9389 177.288 56.853C175.211 56.9235 173.145 56.533 171.238 55.7098C169.331 54.8866 167.63 53.651 166.257 52.0919C163.536 48.9572 162.22 44.6988 162.265 39.2427V16.1911H174.877L174.656 37.8084C174.49 40.1507 175.237 42.4661 176.74 44.27C178.332 45.7954 180.451 46.6471 182.655 46.6471C184.859 46.6471 186.978 45.7954 188.569 44.27C190.148 42.3608 190.95 39.9273 190.817 37.4536L191.024 16.1763L203.415 16.2206Z" fill="black"/>
<path d="M121.515 12.8344C125.059 12.8344 127.932 9.96132 127.932 6.4172C127.932 2.87308 125.059 0 121.515 0C117.971 0 115.098 2.87308 115.098 6.4172C115.098 9.96132 117.971 12.8344 121.515 12.8344Z" fill="black"/>
<path d="M97.0424 56.8235L85.6127 40.6474V56.8235H73.9316V6.31396H85.6127V34.0232L97.1903 16.1911H111.075L95.4012 37.7789L111.104 56.8235H97.0424Z" fill="#2AB34B"/>
<path d="M22.9481 37.7346H33.5498L26.4672 16.1468L13.1597 56.8531H0L19.222 6.31396H33.8603L49.4006 47.316H19.8283L22.9481 37.7346Z" fill="black"/>
<path d="M50.6723 50.6724L53.0233 56.853H39.8784L37.8379 50.6724H50.6723Z" fill="#2AB34B"/>
</svg>`;
const ALKITU_VERTICAL_SVG = `<svg width="57" height="204" viewBox="0 0 57 204" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6.3125 133.445L56.8073 133.445L56.8073 146.383L6.3125 146.383L6.3125 133.445Z" fill="black"/>
<path d="M16.1914 75.4825L56.809 75.4825L56.809 88.3169L16.1914 88.3169L16.1914 75.4825Z" fill="black"/>
<path d="M47.0928 45.1861L56.8073 45.1861L56.8073 51.2337C56.7481 55.9751 55.5357 59.6569 53.1699 62.2789C50.7893 64.9109 48.1869 66.1825 42.8196 66.1381L26.0373 65.9755L26.0373 71.4907L16.1897 71.4907L16.1897 65.8868L6.3125 65.7833L6.3125 53.3481L16.1749 53.4368L16.1749 45.1861L25.8746 45.1861L25.8746 53.5255L42.6569 53.703C43.8563 53.8372 45.0607 53.4977 46.0134 52.7566C46.742 51.8195 47.0905 50.6421 46.9893 49.4593L47.0928 45.1861Z" fill="black"/>
<path d="M16.2201 -0.000126029L56.8525 0.399105L56.8525 12.8195L49.2081 12.8195C51.5503 13.9943 53.5019 15.8227 54.8268 18.0834C56.2369 20.524 56.9384 23.3096 56.8525 26.127C56.923 28.2032 56.5325 30.2691 55.7093 32.1764C54.8861 34.0836 53.6505 35.7848 52.0914 37.1575C48.9567 39.8782 44.6983 41.1942 39.2422 41.1498L16.1906 41.1498L16.1906 28.5372L37.8079 28.759C40.1502 28.9243 42.4656 28.1772 44.2695 26.6741C45.7949 25.0829 46.6466 22.9639 46.6466 20.7596C46.6466 18.5554 45.7949 16.4363 44.2695 14.8452C42.3603 13.2665 39.9269 12.4641 37.4531 12.5977L16.1758 12.3907L16.2201 -0.000126029Z" fill="black"/>
<path d="M12.8344 81.8997C12.8344 78.3556 9.96132 75.4825 6.4172 75.4825C2.87308 75.4825 -4.35423e-07 78.3556 -2.80504e-07 81.8997C-1.25586e-07 85.4438 2.87308 88.3169 6.4172 88.3169C9.96132 88.3169 12.8344 85.4438 12.8344 81.8997Z" fill="black"/>
<path d="M56.8221 106.372L40.646 117.802L56.8221 117.802L56.8221 129.483L6.3125 129.483L6.3125 117.802L34.0218 117.802L16.1897 106.224L16.1897 92.34L37.7775 108.013L56.8221 92.3105L56.8221 106.372Z" fill="#2AB34B"/>
<path d="M37.7331 180.466L37.7331 169.865L16.1453 176.947L56.8516 190.255L56.8516 203.415L6.3125 184.193L6.3125 169.554L47.3146 154.014L47.3146 183.586L37.7331 180.466Z" fill="black"/>
<path d="M50.6719 152.742L56.8525 150.391L56.8525 163.536L50.6719 165.577L50.6719 152.742Z" fill="#2AB34B"/>
</svg>`;
function createDefaultAlkituIconLogo(primaryColor = '#2AB34B') {
    const svgContent = ALKITU_ICON_SVG;
    const detectedColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectColorsFromSVG"])(svgContent);
    // Create light and dark mode configurations with proper theme-aware colors
    const lightModeConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultModeConfig"])(svgContent, detectedColors, primaryColor, false);
    const darkModeConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultModeConfig"])(svgContent, detectedColors, primaryColor, true);
    // Extract metadata
    const metadata = {
        fileName: 'alkitu-icon.svg',
        fileSize: '0.9 KB',
        dimensions: '54 × 51',
        viewBox: '0 0 54 51',
        colorCount: detectedColors.length,
        hasGradients: false
    };
    const logoVariant = {
        id: `alkitu_icon_${Date.now()}`,
        name: 'alkitu-icon.svg',
        type: 'icon',
        aspectRatio: '1:1',
        svgContent,
        detectedColors,
        lightMode: lightModeConfig,
        darkMode: darkModeConfig,
        metadata
    };
    return logoVariant;
}
function createDefaultAlkituHorizontalLogo(primaryColor = '#2AB34B') {
    const svgContent = ALKITU_HORIZONTAL_SVG;
    const detectedColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectColorsFromSVG"])(svgContent);
    // Create light and dark mode configurations with proper theme-aware colors
    const lightModeConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultModeConfig"])(svgContent, detectedColors, primaryColor, false);
    const darkModeConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultModeConfig"])(svgContent, detectedColors, primaryColor, true);
    // Extract metadata
    const metadata = {
        fileName: 'alkitu-horizontal.svg',
        fileSize: '2.1 KB',
        dimensions: '204 × 57',
        viewBox: '0 0 204 57',
        colorCount: detectedColors.length,
        hasGradients: false
    };
    const logoVariant = {
        id: `alkitu_horizontal_${Date.now()}`,
        name: 'alkitu-horizontal.svg',
        type: 'horizontal',
        aspectRatio: '3:1',
        svgContent,
        detectedColors,
        lightMode: lightModeConfig,
        darkMode: darkModeConfig,
        metadata
    };
    return logoVariant;
}
function createDefaultAlkituVerticalLogo(primaryColor = '#2AB34B') {
    const svgContent = ALKITU_VERTICAL_SVG;
    const detectedColors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["detectColorsFromSVG"])(svgContent);
    // Create light and dark mode configurations with proper theme-aware colors
    const lightModeConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultModeConfig"])(svgContent, detectedColors, primaryColor, false);
    const darkModeConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDefaultModeConfig"])(svgContent, detectedColors, primaryColor, true);
    // Extract metadata
    const metadata = {
        fileName: 'alkitu-vertical.svg',
        fileSize: '2.3 KB',
        dimensions: '57 × 204',
        viewBox: '0 0 57 204',
        colorCount: detectedColors.length,
        hasGradients: false
    };
    const logoVariant = {
        id: `alkitu_vertical_${Date.now()}`,
        name: 'alkitu-vertical.svg',
        type: 'vertical',
        aspectRatio: '1:3',
        svgContent,
        detectedColors,
        lightMode: lightModeConfig,
        darkMode: darkModeConfig,
        metadata
    };
    return logoVariant;
}
function getDefaultBrandAssets(primaryColor = '#2AB34B') {
    return {
        icon: createDefaultAlkituIconLogo(primaryColor),
        horizontal: createDefaultAlkituHorizontalLogo(primaryColor),
        vertical: createDefaultAlkituVerticalLogo(primaryColor)
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/core/constants/default-themes.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Theme Editor 3.0 - Default Themes V2 with Precise Colors
__turbopack_context__.s([
    "AMBER_MINIMAL_THEME",
    ()=>AMBER_MINIMAL_THEME,
    "AMETHYST_HAZE_THEME",
    ()=>AMETHYST_HAZE_THEME,
    "BOLD_TECH_THEME",
    ()=>BOLD_TECH_THEME,
    "BUBBLEGUM_THEME",
    ()=>BUBBLEGUM_THEME,
    "CAFFEINE_THEME",
    ()=>CAFFEINE_THEME,
    "CANDYLAND_THEME",
    ()=>CANDYLAND_THEME,
    "DEFAULT_THEME",
    ()=>DEFAULT_THEME,
    "DEFAULT_THEMES",
    ()=>DEFAULT_THEMES,
    "THEMES_BY_ID",
    ()=>THEMES_BY_ID
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/lib/utils/color/color-conversions-v2.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$default$2d$logos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/theme-editor/editor/brand/default-logos.ts [app-client] (ecmascript)");
;
;
// Legacy helper function (deprecated - use createPreciseColorToken instead)
function createColorToken(name, value, l, c, h, description) {
    // Convert to precise token for backward compatibility
    const preciseToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])(name, {
        l,
        c,
        h
    }, description);
    return {
        ...preciseToken,
        value
    };
}
// Light mode colors (original default theme)
const DEFAULT_LIGHT_COLORS = {
    // Base colors
    background: createColorToken('background', 'oklch(1 0 0)', 1, 0, 0),
    foreground: createColorToken('foreground', 'oklch(0.1450 0 0)', 0.1450, 0, 0),
    // UI container colors
    card: createColorToken('card', 'oklch(1 0 0)', 1, 0, 0),
    cardForeground: createColorToken('card-foreground', 'oklch(0.1450 0 0)', 0.1450, 0, 0),
    popover: createColorToken('popover', 'oklch(1 0 0)', 1, 0, 0),
    popoverForeground: createColorToken('popover-foreground', 'oklch(0.1450 0 0)', 0.1450, 0, 0),
    // Primary colors
    primary: createColorToken('primary', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    primaryForeground: createColorToken('primary-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    // Secondary colors
    secondary: createColorToken('secondary', 'oklch(0.9700 0 0)', 0.9700, 0, 0),
    secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    // Accent colors
    accent: createColorToken('accent', 'oklch(0.9700 0 0)', 0.9700, 0, 0),
    accentForeground: createColorToken('accent-foreground', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    // Muted colors
    muted: createColorToken('muted', 'oklch(0.9700 0 0)', 0.9700, 0, 0),
    mutedForeground: createColorToken('muted-foreground', 'oklch(0.5560 0 0)', 0.5560, 0, 0),
    // Alert colors (destructive, warning, success)
    destructive: createColorToken('destructive', 'oklch(0.5770 0.2450 27.3250)', 0.5770, 0.2450, 27.3250),
    destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
    warning: createColorToken('warning', 'oklch(0.6800 0.2200 65.00)', 0.6800, 0.2200, 65.00),
    warningForeground: createColorToken('warning-foreground', 'oklch(1 0 0)', 1, 0, 0),
    success: createColorToken('success', 'oklch(0.5600 0.2000 142.50)', 0.5600, 0.2000, 142.50),
    successForeground: createColorToken('success-foreground', 'oklch(1 0 0)', 1, 0, 0),
    // Border & Input colors
    border: createColorToken('border', 'oklch(0.9220 0 0)', 0.9220, 0, 0),
    input: createColorToken('input', 'oklch(0.9220 0 0)', 0.9220, 0, 0),
    ring: createColorToken('ring', 'oklch(0.7080 0 0)', 0.7080, 0, 0),
    // Chart colors
    chart1: createColorToken('chart-1', 'oklch(0.8100 0.1000 252)', 0.8100, 0.1000, 252),
    chart2: createColorToken('chart-2', 'oklch(0.6200 0.1900 260)', 0.6200, 0.1900, 260),
    chart3: createColorToken('chart-3', 'oklch(0.5500 0.2200 263)', 0.5500, 0.2200, 263),
    chart4: createColorToken('chart-4', 'oklch(0.4900 0.2200 264)', 0.4900, 0.2200, 264),
    chart5: createColorToken('chart-5', 'oklch(0.4200 0.1800 266)', 0.4200, 0.1800, 266),
    // Sidebar colors
    sidebar: createColorToken('sidebar', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.1450 0 0)', 0.1450, 0, 0),
    sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.9700 0 0)', 0.9700, 0, 0),
    sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    sidebarBorder: createColorToken('sidebar-border', 'oklch(0.9220 0 0)', 0.9220, 0, 0),
    sidebarRing: createColorToken('sidebar-ring', 'oklch(0.7080 0 0)', 0.7080, 0, 0),
    // Scrollbar colors - Using precise conversions
    scrollbarTrack: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('Scrollbar Track', '#ffffff', 'Light mode scrollbar track background'),
    scrollbarThumb: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('Scrollbar Thumb', '#cdcdcd', 'Light mode scrollbar thumb color')
};
// Dark mode colors (original default theme)
const DEFAULT_DARK_COLORS = {
    // Base colors
    background: createColorToken('background', 'oklch(0.1450 0 0)', 0.1450, 0, 0),
    foreground: createColorToken('foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    // UI container colors
    card: createColorToken('card', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    cardForeground: createColorToken('card-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    popover: createColorToken('popover', 'oklch(0.2690 0 0)', 0.2690, 0, 0),
    popoverForeground: createColorToken('popover-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    // Primary colors
    primary: createColorToken('primary', 'oklch(0.9220 0 0)', 0.9220, 0, 0),
    primaryForeground: createColorToken('primary-foreground', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    // Secondary colors
    secondary: createColorToken('secondary', 'oklch(0.2690 0 0)', 0.2690, 0, 0),
    secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    // Accent colors
    accent: createColorToken('accent', 'oklch(0.3710 0 0)', 0.3710, 0, 0),
    accentForeground: createColorToken('accent-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    // Muted colors
    muted: createColorToken('muted', 'oklch(0.2690 0 0)', 0.2690, 0, 0),
    mutedForeground: createColorToken('muted-foreground', 'oklch(0.7080 0 0)', 0.7080, 0, 0),
    // Alert colors (destructive, warning, success) 
    destructive: createColorToken('destructive', 'oklch(0.7040 0.1910 22.2160)', 0.7040, 0.1910, 22.2160),
    destructiveForeground: createColorToken('destructive-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    warning: createColorToken('warning', 'oklch(0.7500 0.2000 65.00)', 0.7500, 0.2000, 65.00),
    warningForeground: createColorToken('warning-foreground', 'oklch(1 0 0)', 1, 0, 0),
    success: createColorToken('success', 'oklch(0.6800 0.1800 142.50)', 0.6800, 0.1800, 142.50),
    successForeground: createColorToken('success-foreground', 'oklch(1 0 0)', 1, 0, 0),
    // Border & Input colors
    border: createColorToken('border', 'oklch(0.2750 0 0)', 0.2750, 0, 0),
    input: createColorToken('input', 'oklch(0.3250 0 0)', 0.3250, 0, 0),
    ring: createColorToken('ring', 'oklch(0.5560 0 0)', 0.5560, 0, 0),
    // Chart colors (same as light for consistency)
    chart1: createColorToken('chart-1', 'oklch(0.8100 0.1000 252)', 0.8100, 0.1000, 252),
    chart2: createColorToken('chart-2', 'oklch(0.6200 0.1900 260)', 0.6200, 0.1900, 260),
    chart3: createColorToken('chart-3', 'oklch(0.5500 0.2200 263)', 0.5500, 0.2200, 263),
    chart4: createColorToken('chart-4', 'oklch(0.4900 0.2200 264)', 0.4900, 0.2200, 264),
    chart5: createColorToken('chart-5', 'oklch(0.4200 0.1800 266)', 0.4200, 0.1800, 266),
    // Sidebar colors
    sidebar: createColorToken('sidebar', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
    sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.4880 0.2430 264.3760)', 0.4880, 0.2430, 264.3760),
    sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.2690 0 0)', 0.2690, 0, 0),
    sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.9850 0 0)', 0.9850, 0, 0),
    sidebarBorder: createColorToken('sidebar-border', 'oklch(0.2750 0 0)', 0.2750, 0, 0),
    sidebarRing: createColorToken('sidebar-ring', 'oklch(0.4390 0 0)', 0.4390, 0, 0),
    // Scrollbar colors - Using precise conversions  
    scrollbarTrack: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('Scrollbar Track', '#0A0A0A', 'Dark mode scrollbar track background'),
    scrollbarThumb: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('Scrollbar Thumb', '#2E2929', 'Dark mode scrollbar thumb color')
};
const DEFAULT_THEME = {
    id: 'default',
    name: 'Default',
    description: '',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    // Dual color configurations
    lightColors: DEFAULT_LIGHT_COLORS,
    darkColors: DEFAULT_DARK_COLORS,
    typography: {
        fontFamilies: {
            sans: 'Poppins, ui-sans-serif, system-ui, sans-serif',
            serif: 'ui-serif, Georgia, serif',
            mono: 'ui-monospace, SFMono-Regular, monospace'
        },
        trackingNormal: '0em'
    },
    brand: {
        name: 'Alkitu Brand',
        tagline: 'Empowering innovation through technology',
        description: 'Modern, versatile, and professional brand identity for the Alkitu platform',
        voice: 'Professional and approachable',
        tone: 'Confident yet friendly',
        colorGuidelines: 'Green (#2AB34B) represents growth and innovation, used as accent color throughout the design system',
        logos: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$brand$2f$default$2d$logos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDefaultBrandAssets"])('#2AB34B'),
        primaryColor: createColorToken('primary', 'oklch(0.2050 0 0)', 0.2050, 0, 0),
        secondaryColor: createColorToken('secondary', 'oklch(0.9700 0 0)', 0.9700, 0, 0) // Migrated from brand-secondary
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.625rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '0 1px 3px 0px hsl(0 0% 0% / 0.05)',
        shadowXs: '0 1px 3px 0px hsl(0 0% 0% / 0.05)',
        shadowSm: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 1px 2px -1px hsl(0 0% 0% / 0.10)',
        shadow: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 1px 2px -1px hsl(0 0% 0% / 0.10)',
        shadowMd: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 2px 4px -1px hsl(0 0% 0% / 0.10)',
        shadowLg: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 4px 6px -1px hsl(0 0% 0% / 0.10)',
        shadowXl: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 8px 10px -1px hsl(0 0% 0% / 0.10)',
        shadow2xl: '0 1px 3px 0px hsl(0 0% 0% / 0.25)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'default',
        'clean',
        'modern'
    ],
    isPublic: true,
    isFavorite: false
};
// Helper function to create themed variants
function createThemedVariants(baseColors, darkColors, accentColors) {
    return {
        lightColors: {
            ...baseColors,
            ...accentColors
        },
        darkColors: {
            ...darkColors,
            ...accentColors
        }
    };
}
const AMBER_MINIMAL_THEME = {
    id: 'amber-minimal',
    name: 'Amber Minimal',
    description: 'Warm amber theme',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    // Light mode colors
    lightColors: {
        background: createColorToken('background', 'oklch(1 0 0)', 1, 0, 0),
        foreground: createColorToken('foreground', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        card: createColorToken('card', 'oklch(1 0 0)', 1, 0, 0),
        cardForeground: createColorToken('card-foreground', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        popover: createColorToken('popover', 'oklch(1 0 0)', 1, 0, 0),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        primary: createColorToken('primary', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.9558 0.0044 106.78)', 0.9558, 0.0044, 106.78),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.2950 0.0044 272.31)', 0.2950, 0.0044, 272.31),
        muted: createColorToken('muted', 'oklch(0.9853 0.0029 120.00)', 0.9853, 0.0029, 120.00),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.4242 0.0044 272.31)', 0.4242, 0.0044, 272.31),
        accent: createColorToken('accent', 'oklch(0.9938 0.0362 79.65)', 0.9938, 0.0362, 79.65),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        destructive: createColorToken('destructive', 'oklch(0.6279 0.2574 27.33)', 0.6279, 0.2574, 27.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        warning: createColorToken('warning', 'oklch(0.6800 0.2200 65.00)', 0.6800, 0.2200, 65.00),
        warningForeground: createColorToken('warning-foreground', 'oklch(1 0 0)', 1, 0, 0),
        success: createColorToken('success', 'oklch(0.5600 0.2000 142.50)', 0.5600, 0.2000, 142.50),
        successForeground: createColorToken('success-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.8985 0.0044 272.31)', 0.8985, 0.0044, 272.31),
        input: createColorToken('input', 'oklch(0.8985 0.0044 272.31)', 0.8985, 0.0044, 272.31),
        ring: createColorToken('ring', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        chart1: createColorToken('chart-1', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        chart2: createColorToken('chart-2', 'oklch(0.6144 0.1468 43.09)', 0.6144, 0.1468, 43.09),
        chart3: createColorToken('chart-3', 'oklch(0.5460 0.1468 30.78)', 0.5460, 0.1468, 30.78),
        chart4: createColorToken('chart-4', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        chart5: createColorToken('chart-5', 'oklch(0.3900 0.0840 22.09)', 0.3900, 0.0840, 22.09),
        sidebar: createColorToken('sidebar', 'oklch(0.9853 0.0029 120.00)', 0.9853, 0.0029, 120.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.9938 0.0362 79.65)', 0.9938, 0.0362, 79.65),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.8985 0.0044 272.31)', 0.8985, 0.0044, 272.31),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(1 0 0)', 1, 0, 0),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.8985 0.0044 272.31)', 0.8985, 0.0044, 272.31)
    },
    // Dark mode colors
    darkColors: {
        background: createColorToken('background', 'oklch(0.0900 0 0)', 0.0900, 0, 0),
        foreground: createColorToken('foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        card: createColorToken('card', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        cardForeground: createColorToken('card-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        popover: createColorToken('popover', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        primary: createColorToken('primary', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        muted: createColorToken('muted', 'oklch(0.1490 0 0)', 0.1490, 0, 0),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.6391 0 0)', 0.6391, 0, 0),
        accent: createColorToken('accent', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.9445 0.0516 81.85)', 0.9445, 0.0516, 81.85),
        destructive: createColorToken('destructive', 'oklch(0.6279 0.2574 27.33)', 0.6279, 0.2574, 27.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        warning: createColorToken('warning', 'oklch(0.7500 0.2000 65.00)', 0.7500, 0.2000, 65.00),
        warningForeground: createColorToken('warning-foreground', 'oklch(1 0 0)', 1, 0, 0),
        success: createColorToken('success', 'oklch(0.6800 0.1800 142.50)', 0.6800, 0.1800, 142.50),
        successForeground: createColorToken('success-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.2518 0 0)', 0.2518, 0, 0),
        input: createColorToken('input', 'oklch(0.2518 0 0)', 0.2518, 0, 0),
        ring: createColorToken('ring', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        chart1: createColorToken('chart-1', 'oklch(0.7450 0.1468 55.4)', 0.7450, 0.1468, 55.4),
        chart2: createColorToken('chart-2', 'oklch(0.6144 0.1468 43.09)', 0.6144, 0.1468, 43.09),
        chart3: createColorToken('chart-3', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        chart4: createColorToken('chart-4', 'oklch(0.5460 0.1468 30.78)', 0.5460, 0.1468, 30.78),
        chart5: createColorToken('chart-5', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        sidebar: createColorToken('sidebar', 'oklch(0.0588 0 0)', 0.0588, 0, 0),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.4640 0.1050 28.62)', 0.4640, 0.1050, 28.62),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.9445 0.0516 81.85)', 0.9445, 0.0516, 81.85),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.2518 0 0)', 0.2518, 0, 0),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.0900 0 0)', 0.0900, 0, 0),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.2518 0 0)', 0.2518, 0, 0)
    },
    typography: {
        fontFamilies: {
            sans: 'var(--font-sans)',
            serif: 'var(--font-serif)',
            mono: 'var(--font-mono)'
        },
        trackingNormal: 'var(--tracking-normal)'
    },
    brand: {
        name: 'Amber Minimal Brand',
        tagline: '',
        description: '',
        voice: '',
        tone: '',
        colorGuidelines: '',
        logos: {
            icon: null,
            horizontal: null,
            vertical: null
        },
        primaryColor: createColorToken('primary', 'oklch(0.6830 0.1468 55.4)', 0.6830, 0.1468, 55.4),
        secondaryColor: createColorToken('secondary', 'oklch(0.9558 0.0044 106.78)', 0.9558, 0.0044, 106.78) // Migrated from brand-secondary
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.375rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '0px 4px 8px -1px hsl(var(--foreground) / 0.05)',
        shadowXs: '0px 4px 8px -1px hsl(var(--foreground) / 0.05)',
        shadowSm: '0px 4px 8px -1px hsl(var(--foreground) / 0.10), 0px 1px 2px -2px hsl(var(--foreground) / 0.10)',
        shadow: '0px 4px 8px -1px hsl(var(--foreground) / 0.10), 0px 1px 2px -2px hsl(var(--foreground) / 0.10)',
        shadowMd: '0px 4px 8px -1px hsl(var(--foreground) / 0.10), 0px 2px 4px -2px hsl(var(--foreground) / 0.10)',
        shadowLg: '0px 4px 8px -1px hsl(var(--foreground) / 0.10), 0px 4px 6px -2px hsl(var(--foreground) / 0.10)',
        shadowXl: '0px 4px 8px -1px hsl(var(--foreground) / 0.10), 0px 8px 10px -2px hsl(var(--foreground) / 0.10)',
        shadow2xl: '0px 4px 8px -1px hsl(var(--foreground) / 0.25)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'amber',
        'warm',
        'minimal'
    ],
    isPublic: true,
    isFavorite: false
};
const AMETHYST_HAZE_THEME = {
    id: 'amethyst-haze',
    name: 'Amethyst Haze',
    description: 'Purple mystical theme',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    // Light mode colors
    lightColors: {
        background: createColorToken('background', 'oklch(0.9780 0.0070 300.00)', 0.9780, 0.0070, 300.00),
        foreground: createColorToken('foreground', 'oklch(0.2550 0.0250 260.00)', 0.2550, 0.0250, 260.00),
        card: createColorToken('card', 'oklch(1 0 0)', 1, 0, 0),
        cardForeground: createColorToken('card-foreground', 'oklch(0.2550 0.0250 260.00)', 0.2550, 0.0250, 260.00),
        popover: createColorToken('popover', 'oklch(1 0 0)', 1, 0, 0),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.2550 0.0250 260.00)', 0.2550, 0.0250, 260.00),
        primary: createColorToken('primary', 'oklch(0.6370 0.0850 280.00)', 0.6370, 0.0850, 280.00),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0.9780 0.0070 300.00)', 0.9780, 0.0070, 300.00),
        secondary: createColorToken('secondary', 'oklch(0.8970 0.0380 270.00)', 0.8970, 0.0380, 270.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.2550 0.0250 260.00)', 0.2550, 0.0250, 260.00),
        muted: createColorToken('muted', 'oklch(0.8840 0.0210 260.00)', 0.8840, 0.0210, 260.00),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.4210 0.0150 260.00)', 0.4210, 0.0150, 260.00),
        accent: createColorToken('accent', 'oklch(0.7610 0.0750 340.00)', 0.7610, 0.0750, 340.00),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.2980 0.0450 20.00)', 0.2980, 0.0450, 20.00),
        destructive: createColorToken('destructive', 'oklch(0.6420 0.1350 15.00)', 0.6420, 0.1350, 15.00),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(0.9780 0.0070 300.00)', 0.9780, 0.0070, 300.00),
        border: createColorToken('border', 'oklch(0.8320 0.0320 270.00)', 0.8320, 0.0320, 270.00),
        input: createColorToken('input', 'oklch(0.9240 0.0180 280.00)', 0.9240, 0.0180, 280.00),
        ring: createColorToken('ring', 'oklch(0.6370 0.0850 280.00)', 0.6370, 0.0850, 280.00),
        chart1: createColorToken('chart-1', 'oklch(0.6370 0.0850 280.00)', 0.6370, 0.0850, 280.00),
        chart2: createColorToken('chart-2', 'oklch(0.7610 0.0750 340.00)', 0.7610, 0.0750, 340.00),
        chart3: createColorToken('chart-3', 'oklch(0.6820 0.0980 165.00)', 0.6820, 0.0980, 165.00),
        chart4: createColorToken('chart-4', 'oklch(0.8370 0.0620 60.00)', 0.8370, 0.0620, 60.00),
        chart5: createColorToken('chart-5', 'oklch(0.7190 0.0750 230.00)', 0.7190, 0.0750, 230.00),
        sidebar: createColorToken('sidebar', 'oklch(0.9540 0.0150 280.00)', 0.9540, 0.0150, 280.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.2550 0.0250 260.00)', 0.2550, 0.0250, 260.00),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.6370 0.0850 280.00)', 0.6370, 0.0850, 280.00),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0.9780 0.0070 300.00)', 0.9780, 0.0070, 300.00),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.7610 0.0750 340.00)', 0.7610, 0.0750, 340.00),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.2980 0.0450 20.00)', 0.2980, 0.0450, 20.00),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.8650 0.0250 280.00)', 0.8650, 0.0250, 280.00),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.6370 0.0850 280.00)', 0.6370, 0.0850, 280.00),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.9780 0.0070 300.00)', 0.9780, 0.0070, 300.00),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.8320 0.0320 270.00)', 0.8320, 0.0320, 270.00)
    },
    // Dark mode colors
    darkColors: {
        background: createColorToken('background', 'oklch(0.1060 0.0130 260.00)', 0.1060, 0.0130, 260.00),
        foreground: createColorToken('foreground', 'oklch(0.8930 0.0180 280.00)', 0.8930, 0.0180, 280.00),
        card: createColorToken('card', 'oklch(0.1420 0.0180 260.00)', 0.1420, 0.0180, 260.00),
        cardForeground: createColorToken('card-foreground', 'oklch(0.8930 0.0180 280.00)', 0.8930, 0.0180, 280.00),
        popover: createColorToken('popover', 'oklch(0.1420 0.0180 260.00)', 0.1420, 0.0180, 260.00),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.8930 0.0180 280.00)', 0.8930, 0.0180, 280.00),
        primary: createColorToken('primary', 'oklch(0.7120 0.0950 280.00)', 0.7120, 0.0950, 280.00),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0.1060 0.0130 260.00)', 0.1060, 0.0130, 260.00),
        secondary: createColorToken('secondary', 'oklch(0.3490 0.0520 270.00)', 0.3490, 0.0520, 270.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.8930 0.0180 280.00)', 0.8930, 0.0180, 280.00),
        muted: createColorToken('muted', 'oklch(0.1450 0.0200 260.00)', 0.1450, 0.0200, 260.00),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.6290 0.0380 280.00)', 0.6290, 0.0380, 280.00),
        accent: createColorToken('accent', 'oklch(0.2190 0.0280 260.00)', 0.2190, 0.0280, 260.00),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.8350 0.0650 340.00)', 0.8350, 0.0650, 340.00),
        destructive: createColorToken('destructive', 'oklch(0.7020 0.1480 15.00)', 0.7020, 0.1480, 15.00),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(0.1060 0.0130 260.00)', 0.1060, 0.0130, 260.00),
        border: createColorToken('border', 'oklch(0.1980 0.0250 260.00)', 0.1980, 0.0250, 260.00),
        input: createColorToken('input', 'oklch(0.1730 0.0220 260.00)', 0.1730, 0.0220, 260.00),
        ring: createColorToken('ring', 'oklch(0.7120 0.0950 280.00)', 0.7120, 0.0950, 280.00),
        chart1: createColorToken('chart-1', 'oklch(0.7120 0.0950 280.00)', 0.7120, 0.0950, 280.00),
        chart2: createColorToken('chart-2', 'oklch(0.8350 0.0650 340.00)', 0.8350, 0.0650, 340.00),
        chart3: createColorToken('chart-3', 'oklch(0.6820 0.0980 165.00)', 0.6820, 0.0980, 165.00),
        chart4: createColorToken('chart-4', 'oklch(0.8370 0.0620 60.00)', 0.8370, 0.0620, 60.00),
        chart5: createColorToken('chart-5', 'oklch(0.7190 0.0750 230.00)', 0.7190, 0.0750, 230.00),
        sidebar: createColorToken('sidebar', 'oklch(0.0890 0.0110 260.00)', 0.0890, 0.0110, 260.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.8930 0.0180 280.00)', 0.8930, 0.0180, 280.00),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.7120 0.0950 280.00)', 0.7120, 0.0950, 280.00),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0.1060 0.0130 260.00)', 0.1060, 0.0130, 260.00),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.2190 0.0280 260.00)', 0.2190, 0.0280, 260.00),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.8350 0.0650 340.00)', 0.8350, 0.0650, 340.00),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.1730 0.0220 260.00)', 0.1730, 0.0220, 260.00),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.7120 0.0950 280.00)', 0.7120, 0.0950, 280.00),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.1060 0.0130 260.00)', 0.1060, 0.0130, 260.00),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.1980 0.0250 260.00)', 0.1980, 0.0250, 260.00)
    },
    typography: {
        fontFamilies: {
            sans: 'Geist, sans-serif',
            serif: 'Lora, Georgia, serif',
            mono: 'Fira Code, Courier New, monospace'
        },
        trackingNormal: '0em'
    },
    brand: {
        name: 'Amethyst Haze Brand',
        tagline: '',
        description: '',
        voice: '',
        tone: '',
        colorGuidelines: '',
        logos: {
            icon: null,
            horizontal: null,
            vertical: null
        },
        primaryColor: createColorToken('primary', 'oklch(0.6370 0.0850 280.00)', 0.6370, 0.0850, 280.00),
        secondaryColor: createColorToken('secondary', 'oklch(0.7610 0.0750 340.00)', 0.7610, 0.0750, 340.00) // Migrated from brand-secondary
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.5rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '1px 2px 5px 1px hsl(0 0% 0% / 0.03)',
        shadowXs: '1px 2px 5px 1px hsl(0 0% 0% / 0.03)',
        shadowSm: '1px 2px 5px 1px hsl(0 0% 0% / 0.06), 1px 1px 2px 0px hsl(0 0% 0% / 0.06)',
        shadow: '1px 2px 5px 1px hsl(0 0% 0% / 0.06), 1px 1px 2px 0px hsl(0 0% 0% / 0.06)',
        shadowMd: '1px 2px 5px 1px hsl(0 0% 0% / 0.06), 1px 2px 4px 0px hsl(0 0% 0% / 0.06)',
        shadowLg: '1px 2px 5px 1px hsl(0 0% 0% / 0.06), 1px 4px 6px 0px hsl(0 0% 0% / 0.06)',
        shadowXl: '1px 2px 5px 1px hsl(0 0% 0% / 0.06), 1px 8px 10px 0px hsl(0 0% 0% / 0.06)',
        shadow2xl: '1px 2px 5px 1px hsl(0 0% 0% / 0.15)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'purple',
        'elegant',
        'mystical'
    ],
    isPublic: true,
    isFavorite: false
};
const BOLD_TECH_THEME = {
    id: 'bold-tech',
    name: 'Bold Tech',
    description: 'Bold blue tech theme',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lightColors: {
        background: createColorToken('background', 'oklch(1 0 0)', 1, 0, 0),
        foreground: createColorToken('foreground', 'oklch(0.1960 0.0690 264.52)', 0.1960, 0.0690, 264.52),
        card: createColorToken('card', 'oklch(1 0 0)', 1, 0, 0),
        cardForeground: createColorToken('card-foreground', 'oklch(0.1960 0.0690 264.52)', 0.1960, 0.0690, 264.52),
        popover: createColorToken('popover', 'oklch(1 0 0)', 1, 0, 0),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.1960 0.0690 264.52)', 0.1960, 0.0690, 264.52),
        primary: createColorToken('primary', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        primaryForeground: createColorToken('primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.9680 0.0090 285.00)', 0.9680, 0.0090, 285.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.2830 0.0820 264.52)', 0.2830, 0.0820, 264.52),
        muted: createColorToken('muted', 'oklch(0.9740 0.0110 285.00)', 0.9740, 0.0110, 285.00),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.4900 0.1480 280.50)', 0.4900, 0.1480, 280.50),
        accent: createColorToken('accent', 'oklch(0.8730 0.0750 210.00)', 0.8730, 0.0750, 210.00),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.1250 0.0650 220.00)', 0.1250, 0.0650, 220.00),
        destructive: createColorToken('destructive', 'oklch(0.6279 0.2574 27.33)', 0.6279, 0.2574, 27.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        input: createColorToken('input', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        ring: createColorToken('ring', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        chart1: createColorToken('chart-1', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        chart2: createColorToken('chart-2', 'oklch(0.4900 0.1480 280.50)', 0.4900, 0.1480, 280.50),
        chart3: createColorToken('chart-3', 'oklch(0.4320 0.1750 284.60)', 0.4320, 0.1750, 284.60),
        chart4: createColorToken('chart-4', 'oklch(0.3630 0.1750 289.70)', 0.3630, 0.1750, 289.70),
        chart5: createColorToken('chart-5', 'oklch(0.3050 0.1480 294.80)', 0.3050, 0.1480, 294.80),
        sidebar: createColorToken('sidebar', 'oklch(0.9740 0.0110 285.00)', 0.9740, 0.0110, 285.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.1960 0.0690 264.52)', 0.1960, 0.0690, 264.52),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.8730 0.0750 210.00)', 0.8730, 0.0750, 210.00),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.1250 0.0650 220.00)', 0.1250, 0.0650, 220.00),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(1 0 0)', 1, 0, 0),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50)
    },
    darkColors: {
        background: createColorToken('background', 'oklch(0.0950 0 0)', 0.0950, 0, 0),
        foreground: createColorToken('foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        card: createColorToken('card', 'oklch(0.1160 0.0690 264.52)', 0.1160, 0.0690, 264.52),
        cardForeground: createColorToken('card-foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        popover: createColorToken('popover', 'oklch(0.1160 0.0690 264.52)', 0.1160, 0.0690, 264.52),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        primary: createColorToken('primary', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        primaryForeground: createColorToken('primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.1160 0.0690 264.52)', 0.1160, 0.0690, 264.52),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        muted: createColorToken('muted', 'oklch(0.1160 0.0690 264.52)', 0.1160, 0.0690, 264.52),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.7780 0.0810 280.50)', 0.7780, 0.0810, 280.50),
        accent: createColorToken('accent', 'oklch(0.2830 0.0820 264.52)', 0.2830, 0.0820, 264.52),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        destructive: createColorToken('destructive', 'oklch(0.6279 0.2574 27.33)', 0.6279, 0.2574, 27.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.1880 0.0830 289.70)', 0.1880, 0.0830, 289.70),
        input: createColorToken('input', 'oklch(0.1880 0.0830 289.70)', 0.1880, 0.0830, 289.70),
        ring: createColorToken('ring', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        chart1: createColorToken('chart-1', 'oklch(0.6870 0.1480 280.50)', 0.6870, 0.1480, 280.50),
        chart2: createColorToken('chart-2', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        chart3: createColorToken('chart-3', 'oklch(0.4900 0.1480 280.50)', 0.4900, 0.1480, 280.50),
        chart4: createColorToken('chart-4', 'oklch(0.4320 0.1750 284.60)', 0.4320, 0.1750, 284.60),
        chart5: createColorToken('chart-5', 'oklch(0.3630 0.1750 289.70)', 0.3630, 0.1750, 289.70),
        sidebar: createColorToken('sidebar', 'oklch(0.0950 0 0)', 0.0950, 0, 0),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.2830 0.0820 264.52)', 0.2830, 0.0820, 264.52),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.8920 0.0350 280.50)', 0.8920, 0.0350, 280.50),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.1880 0.0830 289.70)', 0.1880, 0.0830, 289.70),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.0950 0 0)', 0.0950, 0, 0),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.1880 0.0830 289.70)', 0.1880, 0.0830, 289.70)
    },
    typography: {
        fontFamilies: {
            sans: 'Roboto, sans-serif',
            serif: 'Playfair Display, serif',
            mono: 'Fira Code, monospace'
        },
        trackingNormal: '0em'
    },
    brand: {
        name: 'Bold Tech Brand',
        tagline: '',
        description: '',
        voice: '',
        tone: '',
        colorGuidelines: '',
        logos: {
            icon: null,
            horizontal: null,
            vertical: null
        },
        primaryColor: createColorToken('primary', 'oklch(0.6330 0.1950 280.50)', 0.6330, 0.1950, 280.50),
        secondaryColor: createColorToken('secondary', 'oklch(0.8730 0.0750 210.00)', 0.8730, 0.0750, 210.00) // Migrated from brand-secondary
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.625rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '2px 2px 4px 0px hsl(255 86% 66% / 0.10)',
        shadowXs: '2px 2px 4px 0px hsl(255 86% 66% / 0.10)',
        shadowSm: '2px 2px 4px 0px hsl(255 86% 66% / 0.20), 2px 1px 2px -1px hsl(255 86% 66% / 0.20)',
        shadow: '2px 2px 4px 0px hsl(255 86% 66% / 0.20), 2px 1px 2px -1px hsl(255 86% 66% / 0.20)',
        shadowMd: '2px 2px 4px 0px hsl(255 86% 66% / 0.20), 2px 2px 4px -1px hsl(255 86% 66% / 0.20)',
        shadowLg: '2px 2px 4px 0px hsl(255 86% 66% / 0.20), 2px 4px 6px -1px hsl(255 86% 66% / 0.20)',
        shadowXl: '2px 2px 4px 0px hsl(255 86% 66% / 0.20), 2px 8px 10px -1px hsl(255 86% 66% / 0.20)',
        shadow2xl: '2px 2px 4px 0px hsl(255 86% 66% / 0.50)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'blue',
        'tech',
        'bold'
    ],
    isPublic: true,
    isFavorite: false
};
const BUBBLEGUM_THEME = {
    id: 'bubblegum',
    name: 'Bubblegum',
    description: 'A vibrant, candy-colored theme with pink and cyan accents',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lightColors: {
        background: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('background', '#f6e6ee'),
        foreground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('foreground', '#737373'),
        card: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('card', '#fdedc9'),
        cardForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('card-foreground', '#737373'),
        popover: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('popover', '#ffffff'),
        popoverForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('popover-foreground', '#737373'),
        primary: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('primary', '#d04f99'),
        primaryForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('primary-foreground', '#ffffff'),
        secondary: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('secondary', '#8acfd1'),
        secondaryForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('secondary-foreground', '#525252'),
        accent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('accent', '#fbe2a7'),
        accentForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('accent-foreground', '#525252'),
        muted: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('muted', '#b2e1eb'),
        mutedForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('muted-foreground', '#898989'),
        destructive: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('destructive', '#f96f70'),
        destructiveForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('destructive-foreground', '#ffffff'),
        border: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('border', '#f4cee4'),
        input: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('input', '#f4cee4'),
        ring: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('ring', '#d04f99'),
        chart1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-1', '#d04f99'),
        chart2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-2', '#8acfd1'),
        chart3: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-3', '#fbe2a7'),
        chart4: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-4', '#f96f70'),
        chart5: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-5', '#7dd3c2'),
        sidebar: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar', '#f8f0f4'),
        sidebarForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-foreground', '#737373'),
        sidebarPrimary: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-primary', '#d04f99'),
        sidebarPrimaryForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-primary-foreground', '#ffffff'),
        sidebarAccent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-accent', '#fbe2a7'),
        sidebarAccentForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-accent-foreground', '#525252'),
        sidebarBorder: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-border', '#f4cee4'),
        sidebarRing: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-ring', '#d04f99'),
        scrollbarTrack: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('scrollbar-track', '#f6e6ee'),
        scrollbarThumb: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('scrollbar-thumb', '#f4cee4')
    },
    darkColors: {
        background: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('background', '#2d1b26'),
        foreground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('foreground', '#f0d5e5'),
        card: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('card', '#3d2832'),
        cardForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('card-foreground', '#f0d5e5'),
        popover: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('popover', '#3d2832'),
        popoverForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('popover-foreground', '#f0d5e5'),
        primary: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('primary', '#e85da8'),
        primaryForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('primary-foreground', '#2d1b26'),
        secondary: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('secondary', '#5a9fa3'),
        secondaryForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('secondary-foreground', '#f0d5e5'),
        accent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('accent', '#4a3d2f'),
        accentForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('accent-foreground', '#d4b88a'),
        muted: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('muted', '#3d2832'),
        mutedForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('muted-foreground', '#c7a5bb'),
        destructive: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('destructive', '#f96f70'),
        destructiveForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('destructive-foreground', '#2d1b26'),
        border: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('border', '#4d3140'),
        input: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('input', '#4d3140'),
        ring: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('ring', '#e85da8'),
        chart1: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-1', '#e85da8'),
        chart2: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-2', '#5a9fa3'),
        chart3: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-3', '#d4b88a'),
        chart4: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-4', '#f96f70'),
        chart5: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('chart-5', '#4dbfa8'),
        sidebar: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar', '#251520'),
        sidebarForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-foreground', '#f0d5e5'),
        sidebarPrimary: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-primary', '#e85da8'),
        sidebarPrimaryForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-primary-foreground', '#2d1b26'),
        sidebarAccent: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-accent', '#4a3d2f'),
        sidebarAccentForeground: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-accent-foreground', '#d4b88a'),
        sidebarBorder: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-border', '#4d3140'),
        sidebarRing: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('sidebar-ring', '#e85da8'),
        scrollbarTrack: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('scrollbar-track', '#2d1b26'),
        scrollbarThumb: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('scrollbar-thumb', '#4d3140')
    },
    typography: {
        fontFamilies: {
            sans: 'Inter, sans-serif',
            serif: 'Georgia, serif',
            mono: 'Fira Code, monospace'
        },
        trackingNormal: '0em'
    },
    brand: {
        name: 'Bubblegum Brand',
        tagline: '',
        description: '',
        voice: '',
        tone: '',
        colorGuidelines: '',
        logos: {
            icon: null,
            horizontal: null,
            vertical: null
        },
        primaryColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('primary', '#d04f99'),
        secondaryColor: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2d$v2$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPreciseColorToken"])('secondary', '#8acfd1') // Migrated from brand-secondary
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.5rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '0 1px 3px 0px hsl(340 50% 70% / 0.05)',
        shadowXs: '0 1px 3px 0px hsl(340 50% 70% / 0.05)',
        shadowSm: '0 1px 3px 0px hsl(340 50% 70% / 0.10), 0 1px 2px -1px hsl(340 50% 70% / 0.10)',
        shadow: '0 1px 3px 0px hsl(340 50% 70% / 0.10), 0 1px 2px -1px hsl(340 50% 70% / 0.10)',
        shadowMd: '0 1px 3px 0px hsl(340 50% 70% / 0.10), 0 2px 4px -1px hsl(340 50% 70% / 0.10)',
        shadowLg: '0 1px 3px 0px hsl(340 50% 70% / 0.10), 0 4px 6px -1px hsl(340 50% 70% / 0.10)',
        shadowXl: '0 1px 3px 0px hsl(340 50% 70% / 0.10), 0 8px 10px -1px hsl(340 50% 70% / 0.10)',
        shadow2xl: '0 1px 3px 0px hsl(340 50% 70% / 0.25)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'pink',
        'playful',
        'fun',
        'vibrant',
        'candy'
    ],
    isPublic: true,
    isFavorite: false
};
const CAFFEINE_THEME = {
    id: 'caffeine',
    name: 'Caffeine',
    description: 'Energetic cyan theme',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lightColors: {
        background: createColorToken('background', 'oklch(0.9850 0.0020 120.00)', 0.9850, 0.0020, 120.00),
        foreground: createColorToken('foreground', 'oklch(0.1255 0 0)', 0.1255, 0, 0),
        card: createColorToken('card', 'oklch(0.9930 0.0010 120.00)', 0.9930, 0.0010, 120.00),
        cardForeground: createColorToken('card-foreground', 'oklch(0.1255 0 0)', 0.1255, 0, 0),
        popover: createColorToken('popover', 'oklch(0.9930 0.0010 120.00)', 0.9930, 0.0010, 120.00),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.1255 0 0)', 0.1255, 0, 0),
        primary: createColorToken('primary', 'oklch(0.2980 0.0430 40.00)', 0.2980, 0.0430, 40.00),
        primaryForeground: createColorToken('primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.9130 0.0890 50.00)', 0.9130, 0.0890, 50.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.1950 0.0650 30.00)', 0.1950, 0.0650, 30.00),
        muted: createColorToken('muted', 'oklch(0.9370 0 0)', 0.9370, 0, 0),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.3920 0 0)', 0.3920, 0, 0),
        accent: createColorToken('accent', 'oklch(0.9100 0 0)', 0.9100, 0, 0),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.1255 0 0)', 0.1255, 0, 0),
        destructive: createColorToken('destructive', 'oklch(0.5590 0.2070 25.33)', 0.5590, 0.2070, 25.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.8470 0 0)', 0.8470, 0, 0),
        input: createColorToken('input', 'oklch(0.8470 0 0)', 0.8470, 0, 0),
        ring: createColorToken('ring', 'oklch(0.2980 0.0430 40.00)', 0.2980, 0.0430, 40.00),
        chart1: createColorToken('chart-1', 'oklch(0.2980 0.0430 40.00)', 0.2980, 0.0430, 40.00),
        chart2: createColorToken('chart-2', 'oklch(0.9130 0.0890 50.00)', 0.9130, 0.0890, 50.00),
        chart3: createColorToken('chart-3', 'oklch(0.9100 0 0)', 0.9100, 0, 0),
        chart4: createColorToken('chart-4', 'oklch(0.9200 0.0490 60.00)', 0.9200, 0.0490, 60.00),
        chart5: createColorToken('chart-5', 'oklch(0.3130 0.0450 35.00)', 0.3130, 0.0450, 35.00),
        sidebar: createColorToken('sidebar', 'oklch(0.9820 0.0015 120.00)', 0.9820, 0.0015, 120.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.1450 0 0)', 0.1450, 0, 0),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.2040 0 0)', 0.2040, 0, 0),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0.9820 0.0015 120.00)', 0.9820, 0.0015, 120.00),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.9680 0 0)', 0.9680, 0, 0),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.2040 0 0)', 0.2040, 0, 0),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.9220 0 0)', 0.9220, 0, 0),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.7080 0 0)', 0.7080, 0, 0),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.9850 0.0020 120.00)', 0.9850, 0.0020, 120.00),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.8470 0 0)', 0.8470, 0, 0)
    },
    darkColors: {
        background: createColorToken('background', 'oklch(0.0670 0 0)', 0.0670, 0, 0),
        foreground: createColorToken('foreground', 'oklch(0.9340 0 0)', 0.9340, 0, 0),
        card: createColorToken('card', 'oklch(0.0980 0 0)', 0.0980, 0, 0),
        cardForeground: createColorToken('card-foreground', 'oklch(0.9340 0 0)', 0.9340, 0, 0),
        popover: createColorToken('popover', 'oklch(0.0980 0 0)', 0.0980, 0, 0),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.9340 0 0)', 0.9340, 0, 0),
        primary: createColorToken('primary', 'oklch(0.8960 0.0890 50.00)', 0.8960, 0.0890, 50.00),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0.0530 0.0110 191.81)', 0.0530, 0.0110, 191.81),
        secondary: createColorToken('secondary', 'oklch(0.2200 0.0430 40.00)', 0.2200, 0.0430, 40.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0.8960 0.0890 50.00)', 0.8960, 0.0890, 50.00),
        muted: createColorToken('muted', 'oklch(0.1330 0 0)', 0.1330, 0, 0),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.7060 0 0)', 0.7060, 0, 0),
        accent: createColorToken('accent', 'oklch(0.1670 0 0)', 0.1670, 0, 0),
        accentForeground: createColorToken('accent-foreground', 'oklch(0.9340 0 0)', 0.9340, 0, 0),
        destructive: createColorToken('destructive', 'oklch(0.5590 0.2070 25.33)', 0.5590, 0.2070, 25.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.1270 0.0180 10.00)', 0.1270, 0.0180, 10.00),
        input: createColorToken('input', 'oklch(0.2840 0 0)', 0.2840, 0, 0),
        ring: createColorToken('ring', 'oklch(0.8960 0.0890 50.00)', 0.8960, 0.0890, 50.00),
        chart1: createColorToken('chart-1', 'oklch(0.8960 0.0890 50.00)', 0.8960, 0.0890, 50.00),
        chart2: createColorToken('chart-2', 'oklch(0.2200 0.0430 40.00)', 0.2200, 0.0430, 40.00),
        chart3: createColorToken('chart-3', 'oklch(0.1670 0 0)', 0.1670, 0, 0),
        chart4: createColorToken('chart-4', 'oklch(0.2620 0.0490 35.00)', 0.2620, 0.0490, 35.00),
        chart5: createColorToken('chart-5', 'oklch(0.8820 0.0890 52.00)', 0.8820, 0.0890, 52.00),
        sidebar: createColorToken('sidebar', 'oklch(0.0940 0 0)', 0.0940, 0, 0),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.9570 0 0)', 0.9570, 0, 0),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.1250 0.0650 220.00)', 0.1250, 0.0650, 220.00),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(1 0 0)', 1, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.1540 0 0)', 0.1540, 0, 0),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0.9570 0 0)', 0.9570, 0, 0),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.1540 0 0)', 0.1540, 0, 0),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.8300 0 0)', 0.8300, 0, 0),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.0670 0 0)', 0.0670, 0, 0),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.1270 0.0180 10.00)', 0.1270, 0.0180, 10.00)
    },
    typography: {
        fontFamilies: {
            sans: 'ui-sans-serif, system-ui, sans-serif',
            serif: 'ui-serif, Georgia, serif',
            mono: 'ui-monospace, SFMono-Regular, monospace'
        },
        trackingNormal: '0em'
    },
    brand: {
        name: 'Caffeine Brand',
        tagline: '',
        description: '',
        voice: '',
        tone: '',
        colorGuidelines: '',
        logos: {
            icon: null,
            horizontal: null,
            vertical: null
        },
        primaryColor: createColorToken('primary', 'oklch(0.2980 0.0430 40.00)', 0.2980, 0.0430, 40.00),
        secondaryColor: createColorToken('secondary', 'oklch(0.9130 0.0890 50.00)', 0.9130, 0.0890, 50.00)
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.5rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '0 1px 3px 0px hsl(0 0% 0% / 0.05)',
        shadowXs: '0 1px 3px 0px hsl(0 0% 0% / 0.05)',
        shadowSm: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 1px 2px -1px hsl(0 0% 0% / 0.10)',
        shadow: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 1px 2px -1px hsl(0 0% 0% / 0.10)',
        shadowMd: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 2px 4px -1px hsl(0 0% 0% / 0.10)',
        shadowLg: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 4px 6px -1px hsl(0 0% 0% / 0.10)',
        shadowXl: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 8px 10px -1px hsl(0 0% 0% / 0.10)',
        shadow2xl: '0 1px 3px 0px hsl(0 0% 0% / 0.25)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'cyan',
        'energetic',
        'productivity'
    ],
    isPublic: true,
    isFavorite: false
};
const CANDYLAND_THEME = {
    id: 'candyland',
    name: 'Candyland',
    description: 'Sweet orange theme',
    version: '1.0.0',
    author: 'Theme Editor 3.0',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    lightColors: {
        background: createColorToken('background', 'oklch(0.9830 0.0050 120.00)', 0.9830, 0.0050, 120.00),
        foreground: createColorToken('foreground', 'oklch(0.2000 0 0)', 0.2000, 0, 0),
        card: createColorToken('card', 'oklch(1 0 0)', 1, 0, 0),
        cardForeground: createColorToken('card-foreground', 'oklch(0.2000 0 0)', 0.2000, 0, 0),
        popover: createColorToken('popover', 'oklch(1 0 0)', 1, 0, 0),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.2000 0 0)', 0.2000, 0, 0),
        primary: createColorToken('primary', 'oklch(0.8200 0.1110 350.00)', 0.8200, 0.1110, 350.00),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.7780 0.1050 205.00)', 0.7780, 0.1050, 205.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        muted: createColorToken('muted', 'oklch(0.8670 0.0390 75.00)', 0.8670, 0.0390, 75.00),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.4310 0 0)', 0.4310, 0, 0),
        accent: createColorToken('accent', 'oklch(1 0.1800 90.00)', 1, 0.1800, 90.00),
        accentForeground: createColorToken('accent-foreground', 'oklch(0 0 0)', 0, 0, 0),
        destructive: createColorToken('destructive', 'oklch(0.6279 0.2574 27.33)', 0.6279, 0.2574, 27.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.8310 0 0)', 0.8310, 0, 0),
        input: createColorToken('input', 'oklch(0.8310 0 0)', 0.8310, 0, 0),
        ring: createColorToken('ring', 'oklch(0.8200 0.1110 350.00)', 0.8200, 0.1110, 350.00),
        chart1: createColorToken('chart-1', 'oklch(0.8200 0.1110 350.00)', 0.8200, 0.1110, 350.00),
        chart2: createColorToken('chart-2', 'oklch(0.7780 0.1050 205.00)', 0.7780, 0.1050, 205.00),
        chart3: createColorToken('chart-3', 'oklch(1 0.1800 90.00)', 1, 0.1800, 90.00),
        chart4: createColorToken('chart-4', 'oklch(0.8760 0.1080 325.00)', 0.8760, 0.1080, 325.00),
        chart5: createColorToken('chart-5', 'oklch(0.5980 0.1980 145.00)', 0.5980, 0.1980, 145.00),
        sidebar: createColorToken('sidebar', 'oklch(0.9830 0.0050 120.00)', 0.9830, 0.0050, 120.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.2000 0 0)', 0.2000, 0, 0),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.8200 0.1110 350.00)', 0.8200, 0.1110, 350.00),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(1 0.1800 90.00)', 1, 0.1800, 90.00),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0 0 0)', 0, 0, 0),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.8310 0 0)', 0.8310, 0, 0),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.8200 0.1110 350.00)', 0.8200, 0.1110, 350.00),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.9830 0.0050 120.00)', 0.9830, 0.0050, 120.00),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.8310 0 0)', 0.8310, 0, 0)
    },
    darkColors: {
        background: createColorToken('background', 'oklch(0.1040 0.0150 230.00)', 0.1040, 0.0150, 230.00),
        foreground: createColorToken('foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        card: createColorToken('card', 'oklch(0.1860 0.0190 220.00)', 0.1860, 0.0190, 220.00),
        cardForeground: createColorToken('card-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        popover: createColorToken('popover', 'oklch(0.1860 0.0190 220.00)', 0.1860, 0.0190, 220.00),
        popoverForeground: createColorToken('popover-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        primary: createColorToken('primary', 'oklch(0.8760 0.1080 325.00)', 0.8760, 0.1080, 325.00),
        primaryForeground: createColorToken('primary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        secondary: createColorToken('secondary', 'oklch(0.5980 0.1980 145.00)', 0.5980, 0.1980, 145.00),
        secondaryForeground: createColorToken('secondary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        muted: createColorToken('muted', 'oklch(0.2750 0 0)', 0.2750, 0, 0),
        mutedForeground: createColorToken('muted-foreground', 'oklch(0.6391 0 0)', 0.6391, 0, 0),
        accent: createColorToken('accent', 'oklch(0.7780 0.1050 205.00)', 0.7780, 0.1050, 205.00),
        accentForeground: createColorToken('accent-foreground', 'oklch(0 0 0)', 0, 0, 0),
        destructive: createColorToken('destructive', 'oklch(0.6279 0.2574 27.33)', 0.6279, 0.2574, 27.33),
        destructiveForeground: createColorToken('destructive-foreground', 'oklch(1 0 0)', 1, 0, 0),
        border: createColorToken('border', 'oklch(0.2750 0 0)', 0.2750, 0, 0),
        input: createColorToken('input', 'oklch(0.2750 0 0)', 0.2750, 0, 0),
        ring: createColorToken('ring', 'oklch(0.8760 0.1080 325.00)', 0.8760, 0.1080, 325.00),
        chart1: createColorToken('chart-1', 'oklch(0.8760 0.1080 325.00)', 0.8760, 0.1080, 325.00),
        chart2: createColorToken('chart-2', 'oklch(0.5980 0.1980 145.00)', 0.5980, 0.1980, 145.00),
        chart3: createColorToken('chart-3', 'oklch(0.7780 0.1050 205.00)', 0.7780, 0.1050, 205.00),
        chart4: createColorToken('chart-4', 'oklch(1 0.1800 90.00)', 1, 0.1800, 90.00),
        chart5: createColorToken('chart-5', 'oklch(0.9200 0.1350 65.00)', 0.9200, 0.1350, 65.00),
        sidebar: createColorToken('sidebar', 'oklch(0.1040 0.0150 230.00)', 0.1040, 0.0150, 230.00),
        sidebarForeground: createColorToken('sidebar-foreground', 'oklch(0.8970 0 0)', 0.8970, 0, 0),
        sidebarPrimary: createColorToken('sidebar-primary', 'oklch(0.8760 0.1080 325.00)', 0.8760, 0.1080, 325.00),
        sidebarPrimaryForeground: createColorToken('sidebar-primary-foreground', 'oklch(0 0 0)', 0, 0, 0),
        sidebarAccent: createColorToken('sidebar-accent', 'oklch(0.7780 0.1050 205.00)', 0.7780, 0.1050, 205.00),
        sidebarAccentForeground: createColorToken('sidebar-accent-foreground', 'oklch(0 0 0)', 0, 0, 0),
        sidebarBorder: createColorToken('sidebar-border', 'oklch(0.2750 0 0)', 0.2750, 0, 0),
        sidebarRing: createColorToken('sidebar-ring', 'oklch(0.8760 0.1080 325.00)', 0.8760, 0.1080, 325.00),
        scrollbarTrack: createColorToken('scrollbar-track', 'oklch(0.1040 0.0150 230.00)', 0.1040, 0.0150, 230.00),
        scrollbarThumb: createColorToken('scrollbar-thumb', 'oklch(0.2750 0 0)', 0.2750, 0, 0)
    },
    typography: {
        fontFamilies: {
            sans: 'Poppins, sans-serif',
            serif: 'ui-serif, Georgia, serif',
            mono: 'Roboto Mono, monospace'
        },
        trackingNormal: '0em'
    },
    brand: {
        name: 'Candyland Brand',
        tagline: '',
        description: '',
        voice: '',
        tone: '',
        colorGuidelines: '',
        logos: {
            icon: null,
            horizontal: null,
            vertical: null
        },
        primaryColor: createColorToken('primary', 'oklch(0.8200 0.1110 350.00)', 0.8200, 0.1110, 350.00),
        secondaryColor: createColorToken('secondary', 'oklch(0.7780 0.1050 205.00)', 0.7780, 0.1050, 205.00)
    },
    spacing: {
        spacing: '2.2rem',
        scale: {
            'small': '1rem',
            'medium': '1.3rem',
            'large': '2rem' // 32px
        }
    },
    borders: {
        radius: '0.5rem',
        radiusSm: 'calc(var(--radius) - 4px)',
        radiusMd: 'calc(var(--radius) - 2px)',
        radiusLg: 'var(--radius)',
        radiusXl: 'calc(var(--radius) + 4px)'
    },
    shadows: {
        shadow2xs: '0 1px 3px 0px hsl(0 0% 0% / 0.05)',
        shadowXs: '0 1px 3px 0px hsl(0 0% 0% / 0.05)',
        shadowSm: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 1px 2px -1px hsl(0 0% 0% / 0.10)',
        shadow: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 1px 2px -1px hsl(0 0% 0% / 0.10)',
        shadowMd: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 2px 4px -1px hsl(0 0% 0% / 0.10)',
        shadowLg: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 4px 6px -1px hsl(0 0% 0% / 0.10)',
        shadowXl: '0 1px 3px 0px hsl(0 0% 0% / 0.10), 0 8px 10px -1px hsl(0 0% 0% / 0.10)',
        shadow2xl: '0 1px 3px 0px hsl(0 0% 0% / 0.25)'
    },
    scroll: {
        width: '8px',
        behavior: 'smooth',
        smooth: true,
        hide: false,
        trackRadius: '0px',
        thumbRadius: '4px'
    },
    tags: [
        'orange',
        'sweet',
        'candy'
    ],
    isPublic: true,
    isFavorite: false
};
const DEFAULT_THEMES = [
    DEFAULT_THEME,
    AMBER_MINIMAL_THEME,
    AMETHYST_HAZE_THEME,
    BOLD_TECH_THEME,
    BUBBLEGUM_THEME,
    CAFFEINE_THEME,
    CANDYLAND_THEME
];
const THEMES_BY_ID = DEFAULT_THEMES.reduce(_c = (acc, theme)=>{
    acc[theme.id] = theme;
    return acc;
}, {});
_c1 = THEMES_BY_ID;
var _c, _c1;
__turbopack_context__.k.register(_c, "THEMES_BY_ID$DEFAULT_THEMES.reduce");
__turbopack_context__.k.register(_c1, "THEMES_BY_ID");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/core/types/color-sections.types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Theme Editor 3.0 - Color Sections Organization
__turbopack_context__.s([
    "COLOR_LABELS",
    ()=>COLOR_LABELS,
    "COLOR_SECTIONS",
    ()=>COLOR_SECTIONS,
    "CSS_VARIABLE_MAP",
    ()=>CSS_VARIABLE_MAP
]);
const COLOR_SECTIONS = [
    {
        id: 'primary',
        title: 'Primary Colors',
        description: 'Main brand colors used for primary actions and emphasis',
        colorKeys: [
            'primary',
            'primaryForeground'
        ],
        defaultExpanded: true
    },
    {
        id: 'secondary',
        title: 'Secondary Colors',
        description: 'Secondary brand colors for supporting elements',
        colorKeys: [
            'secondary',
            'secondaryForeground'
        ]
    },
    {
        id: 'accent',
        title: 'Accent Colors',
        description: 'Accent colors for highlights and special elements',
        colorKeys: [
            'accent',
            'accentForeground'
        ]
    },
    {
        id: 'base',
        title: 'Base Colors',
        description: 'Foundation colors for backgrounds and text',
        colorKeys: [
            'background',
            'foreground'
        ]
    },
    {
        id: 'card',
        title: 'Card Colors',
        description: 'Colors for card containers and their content',
        colorKeys: [
            'card',
            'cardForeground'
        ]
    },
    {
        id: 'popover',
        title: 'Popover Colors',
        description: 'Colors for popovers, dropdowns, and floating elements',
        colorKeys: [
            'popover',
            'popoverForeground'
        ]
    },
    {
        id: 'muted',
        title: 'Muted Colors',
        description: 'Subdued colors for less prominent content',
        colorKeys: [
            'muted',
            'mutedForeground'
        ]
    },
    {
        id: 'alert',
        title: 'Alert Colors',
        description: 'Colors for alerts, errors, warnings, and success states',
        colorKeys: [
            'destructive',
            'destructiveForeground',
            'warning',
            'warningForeground',
            'success',
            'successForeground'
        ]
    },
    {
        id: 'border-input',
        title: 'Border & Input Colors',
        description: 'Colors for borders, inputs, and focus rings',
        colorKeys: [
            'border',
            'input',
            'ring'
        ]
    },
    {
        id: 'chart',
        title: 'Chart Colors',
        description: 'Color palette for data visualization and charts',
        colorKeys: [
            'chart1',
            'chart2',
            'chart3',
            'chart4',
            'chart5'
        ]
    },
    {
        id: 'sidebar',
        title: 'Sidebar Colors',
        description: 'Colors specifically for sidebar navigation',
        colorKeys: [
            'sidebar',
            'sidebarForeground',
            'sidebarPrimary',
            'sidebarPrimaryForeground',
            'sidebarAccent',
            'sidebarAccentForeground',
            'sidebarBorder',
            'sidebarRing'
        ]
    },
    {
        id: 'scrollbar',
        title: 'Scrollbar Colors',
        description: 'Colors for scrollbar track and thumb elements',
        colorKeys: [
            'scrollbarTrack',
            'scrollbarThumb'
        ]
    }
];
const CSS_VARIABLE_MAP = {
    background: '--background',
    foreground: '--foreground',
    card: '--card',
    cardForeground: '--card-foreground',
    popover: '--popover',
    popoverForeground: '--popover-foreground',
    primary: '--primary',
    primaryForeground: '--primary-foreground',
    secondary: '--secondary',
    secondaryForeground: '--secondary-foreground',
    accent: '--accent',
    accentForeground: '--accent-foreground',
    muted: '--muted',
    mutedForeground: '--muted-foreground',
    destructive: '--destructive',
    destructiveForeground: '--destructive-foreground',
    warning: '--warning',
    warningForeground: '--warning-foreground',
    success: '--success',
    successForeground: '--success-foreground',
    border: '--border',
    input: '--input',
    ring: '--ring',
    chart1: '--chart-1',
    chart2: '--chart-2',
    chart3: '--chart-3',
    chart4: '--chart-4',
    chart5: '--chart-5',
    sidebar: '--sidebar',
    sidebarForeground: '--sidebar-foreground',
    sidebarPrimary: '--sidebar-primary',
    sidebarPrimaryForeground: '--sidebar-primary-foreground',
    sidebarAccent: '--sidebar-accent',
    sidebarAccentForeground: '--sidebar-accent-foreground',
    sidebarBorder: '--sidebar-border',
    sidebarRing: '--sidebar-ring',
    scrollbarTrack: '--scrollbar-track',
    scrollbarThumb: '--scrollbar-thumb'
};
const COLOR_LABELS = {
    background: 'Background',
    foreground: 'Foreground',
    card: 'Card Background',
    cardForeground: 'Card Foreground',
    popover: 'Popover Background',
    popoverForeground: 'Popover Foreground',
    primary: 'Primary',
    primaryForeground: 'Primary Foreground',
    secondary: 'Secondary',
    secondaryForeground: 'Secondary Foreground',
    accent: 'Accent',
    accentForeground: 'Accent Foreground',
    muted: 'Muted',
    mutedForeground: 'Muted Foreground',
    destructive: 'Destructive',
    destructiveForeground: 'Destructive Foreground',
    warning: 'Warning',
    warningForeground: 'Warning Foreground',
    success: 'Success',
    successForeground: 'Success Foreground',
    border: 'Border',
    input: 'Input',
    ring: 'Ring',
    chart1: 'Chart 1',
    chart2: 'Chart 2',
    chart3: 'Chart 3',
    chart4: 'Chart 4',
    chart5: 'Chart 5',
    sidebar: 'Sidebar Background',
    sidebarForeground: 'Sidebar Foreground',
    sidebarPrimary: 'Sidebar Primary',
    sidebarPrimaryForeground: 'Sidebar Primary Foreground',
    sidebarAccent: 'Sidebar Accent',
    sidebarAccentForeground: 'Sidebar Accent Foreground',
    sidebarBorder: 'Sidebar Border',
    sidebarRing: 'Sidebar Ring',
    scrollbarTrack: 'Scrollbar Track',
    scrollbarThumb: 'Scrollbar Thumb'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/lib/utils/color/color-conversions.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Color Conversion Utilities
 * Handles conversions between HEX, RGB, HSV, and OKLCH color spaces
 */ __turbopack_context__.s([
    "formatHex",
    ()=>formatHex,
    "formatHsv",
    ()=>formatHsv,
    "formatRgb",
    ()=>formatRgb,
    "hexToHsv",
    ()=>hexToHsv,
    "hexToOklch",
    ()=>hexToOklch,
    "hexToRgb",
    ()=>hexToRgb,
    "hsvToHex",
    ()=>hsvToHex,
    "hsvToRgb",
    ()=>hsvToRgb,
    "isValidHex",
    ()=>isValidHex,
    "isValidHsv",
    ()=>isValidHsv,
    "isValidRgb",
    ()=>isValidRgb,
    "oklchToHex",
    ()=>oklchToHex,
    "oklchToRgb",
    ()=>oklchToRgb,
    "rgbToHex",
    ()=>rgbToHex,
    "rgbToHsv",
    ()=>rgbToHsv,
    "rgbToOklch",
    ()=>rgbToOklch
]);
function hexToRgb(hex) {
    const cleanHex = hex.replace('#', '');
    if (cleanHex.length === 3) {
        const r = parseInt(cleanHex[0] + cleanHex[0], 16);
        const g = parseInt(cleanHex[1] + cleanHex[1], 16);
        const b = parseInt(cleanHex[2] + cleanHex[2], 16);
        return {
            r,
            g,
            b
        };
    }
    if (cleanHex.length === 6) {
        const r = parseInt(cleanHex.substring(0, 2), 16);
        const g = parseInt(cleanHex.substring(2, 4), 16);
        const b = parseInt(cleanHex.substring(4, 6), 16);
        return {
            r,
            g,
            b
        };
    }
    return null;
}
function rgbToHex(rgb) {
    const toHex = (n)=>{
        const hex = Math.round(Math.max(0, Math.min(255, n))).toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    };
    return `#${toHex(rgb.r)}${toHex(rgb.g)}${toHex(rgb.b)}`;
}
function rgbToHsv(rgb) {
    const r = rgb.r / 255;
    const g = rgb.g / 255;
    const b = rgb.b / 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    const delta = max - min;
    let h = 0;
    let s = 0;
    const v = max;
    if (delta !== 0) {
        s = delta / max;
        switch(max){
            case r:
                h = (g - b) / delta % 6;
                break;
            case g:
                h = (b - r) / delta + 2;
                break;
            case b:
                h = (r - g) / delta + 4;
                break;
        }
        h *= 60;
        if (h < 0) h += 360;
    }
    return {
        h: parseFloat(h.toFixed(1)),
        s: parseFloat((s * 100).toFixed(1)),
        v: parseFloat((v * 100).toFixed(1)) // Mayor precisión en valor
    };
}
function hsvToRgb(hsv) {
    const h = hsv.h / 360;
    const s = hsv.s / 100;
    const v = hsv.v / 100;
    const i = Math.floor(h * 6);
    const f = h * 6 - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    let r, g, b;
    switch(i % 6){
        case 0:
            r = v;
            g = t;
            b = p;
            break;
        case 1:
            r = q;
            g = v;
            b = p;
            break;
        case 2:
            r = p;
            g = v;
            b = t;
            break;
        case 3:
            r = p;
            g = q;
            b = v;
            break;
        case 4:
            r = t;
            g = p;
            b = v;
            break;
        case 5:
            r = v;
            g = p;
            b = q;
            break;
        default:
            r = g = b = 0;
    }
    return {
        r: Math.round(r * 255),
        g: Math.round(g * 255),
        b: Math.round(b * 255)
    };
}
function rgbToOklch(rgb) {
    // Convert RGB to linear RGB
    const toLinear = (c)=>{
        c = c / 255;
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    };
    const r = toLinear(rgb.r);
    const g = toLinear(rgb.g);
    const b = toLinear(rgb.b);
    // Convert to XYZ (simplified D65)
    const x = 0.4124564 * r + 0.3575761 * g + 0.1804375 * b;
    const y = 0.2126729 * r + 0.7151522 * g + 0.0721750 * b;
    const z = 0.0193339 * r + 0.1191920 * g + 0.9503041 * b;
    // Convert to OKLCH (simplified approximation)
    const l = Math.cbrt(y); // Lightness approximation
    // Chroma and hue calculations (simplified)
    const a = Math.cbrt(x) - l;
    const bComponent = l - Math.cbrt(z);
    const c = Math.sqrt(a * a + bComponent * bComponent);
    let h = Math.atan2(bComponent, a) * 180 / Math.PI;
    if (h < 0) h += 360;
    return {
        l: Math.max(0, Math.min(1, l)),
        c: Math.max(0, Math.min(0.4, c)),
        h: h
    };
}
function oklchToRgb(oklch) {
    const { l, c, h } = oklch;
    // Convert to XYZ (simplified approximation)
    const hRad = h * Math.PI / 180;
    const a = c * Math.cos(hRad);
    const bComponent = c * Math.sin(hRad);
    const x = Math.pow(l + a, 3);
    const y = Math.pow(l, 3);
    const z = Math.pow(l - bComponent, 3);
    // Convert XYZ to linear RGB
    let r = 3.2404542 * x - 1.5371385 * y - 0.4985314 * z;
    let g = -0.9692660 * x + 1.8760108 * y + 0.0415560 * z;
    let b = 0.0556434 * x - 0.2040259 * y + 1.0572252 * z;
    // Convert linear RGB to sRGB
    const fromLinear = (c)=>{
        c = Math.max(0, Math.min(1, c));
        return c <= 0.0031308 ? c * 12.92 : 1.055 * Math.pow(c, 1 / 2.4) - 0.055;
    };
    r = fromLinear(r);
    g = fromLinear(g);
    b = fromLinear(b);
    return {
        r: Math.round(Math.max(0, Math.min(255, r * 255))),
        g: Math.round(Math.max(0, Math.min(255, g * 255))),
        b: Math.round(Math.max(0, Math.min(255, b * 255)))
    };
}
function hexToHsv(hex) {
    const rgb = hexToRgb(hex);
    return rgb ? rgbToHsv(rgb) : null;
}
function hsvToHex(hsv) {
    const rgb = hsvToRgb(hsv);
    return rgbToHex(rgb);
}
function hexToOklch(hex) {
    const rgb = hexToRgb(hex);
    return rgb ? rgbToOklch(rgb) : null;
}
function oklchToHex(oklch) {
    const rgb = oklchToRgb(oklch);
    return rgbToHex(rgb);
}
function isValidHex(hex) {
    const cleanHex = hex.replace('#', '');
    return /^[0-9A-Fa-f]{3}$|^[0-9A-Fa-f]{6}$/.test(cleanHex);
}
function isValidRgb(rgb) {
    return rgb.r >= 0 && rgb.r <= 255 && rgb.g >= 0 && rgb.g <= 255 && rgb.b >= 0 && rgb.b <= 255;
}
function isValidHsv(hsv) {
    return hsv.h >= 0 && hsv.h <= 360 && hsv.s >= 0 && hsv.s <= 100 && hsv.v >= 0 && hsv.v <= 100;
}
function formatHex(hex) {
    const cleanHex = hex.replace('#', '').toUpperCase();
    return cleanHex.length === 3 || cleanHex.length === 6 ? `#${cleanHex}` : hex;
}
function formatRgb(rgb) {
    return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
}
function formatHsv(hsv) {
    return `hsv(${hsv.h}°, ${hsv.s}%, ${hsv.v}%)`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/lib/utils/css/css-variables.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Theme Editor 3.0 - CSS Variables Management
__turbopack_context__.s([
    "applyBorderElements",
    ()=>applyBorderElements,
    "applyModeSpecificColors",
    ()=>applyModeSpecificColors,
    "applyScrollElements",
    ()=>applyScrollElements,
    "applyScrollbarColors",
    ()=>applyScrollbarColors,
    "applyScrollbarUtilityClass",
    ()=>applyScrollbarUtilityClass,
    "applyShadowElements",
    ()=>applyShadowElements,
    "applySpacingElements",
    ()=>applySpacingElements,
    "applyThemeColorsToRoot",
    ()=>applyThemeColorsToRoot,
    "applyThemeMode",
    ()=>applyThemeMode,
    "applyThemeToRoot",
    ()=>applyThemeToRoot,
    "applyTypographyElements",
    ()=>applyTypographyElements,
    "generateThemeCSS",
    ()=>generateThemeCSS,
    "getCSSVariableValue",
    ()=>getCSSVariableValue,
    "oklchToString",
    ()=>oklchToString,
    "parseOklchString",
    ()=>parseOklchString,
    "resetThemeVariables",
    ()=>resetThemeVariables,
    "updateCSSVariable",
    ()=>updateCSSVariable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$types$2f$color$2d$sections$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/types/color-sections.types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/lib/utils/color/color-conversions.ts [app-client] (ecmascript)");
;
;
function oklchToString(oklch) {
    const { l, c, h } = oklch;
    return `oklch(${l.toFixed(4)} ${c.toFixed(4)} ${h.toFixed(4)})`;
}
function parseOklchString(value) {
    // Match oklch(l c h) - no alpha support
    const match = value.match(/oklch\(([^)]+)\)/);
    if (!match) return null;
    const parts = match[1].split(/\s+/);
    if (parts.length < 3) return null;
    const l = parseFloat(parts[0]);
    const c = parseFloat(parts[1]);
    const h = parseFloat(parts[2]);
    if (isNaN(l) || isNaN(c) || isNaN(h)) return null;
    return {
        l,
        c,
        h
    };
}
function applyThemeColorsToRoot(colors) {
    applyModeSpecificColors(colors);
}
function applyModeSpecificColors(colors) {
    const root = document.documentElement;
    Object.entries(colors).forEach(([colorKey, colorToken])=>{
        const cssVariable = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$types$2f$color$2d$sections$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS_VARIABLE_MAP"][colorKey];
        if (cssVariable) {
            // Prefer oklchString for precise colors, fallback to legacy value
            const colorValue = colorToken.oklchString || colorToken.value;
            if (colorValue) {
                root.style.setProperty(cssVariable, colorValue);
            }
        }
    });
}
function applyThemeToRoot(theme, mode = 'light') {
    const root = document.documentElement;
    // Apply mode-specific colors
    const colors = mode === 'dark' ? theme.darkColors : theme.lightColors;
    applyModeSpecificColors(colors);
    // Apply typography
    root.style.setProperty('--font-sans', theme.typography.fontFamilies.sans);
    root.style.setProperty('--font-serif', theme.typography.fontFamilies.serif);
    root.style.setProperty('--font-mono', theme.typography.fontFamilies.mono);
    root.style.setProperty('--tracking-normal', theme.typography.trackingNormal);
    // Apply borders
    root.style.setProperty('--radius', theme.borders.radius);
    // Apply specific border radius variables if available
    if (theme.borders.radiusButton) {
        root.style.setProperty('--radius-button', theme.borders.radiusButton);
    }
    if (theme.borders.radiusCard) {
        root.style.setProperty('--radius-card', theme.borders.radiusCard);
    }
    if (theme.borders.radiusCheckbox) {
        root.style.setProperty('--radius-checkbox', theme.borders.radiusCheckbox);
    }
    if (theme.borders.radiusButtonInner) {
        root.style.setProperty('--radius-button-inner', theme.borders.radiusButtonInner);
    }
    if (theme.borders.radiusCardInner) {
        root.style.setProperty('--radius-card-inner', theme.borders.radiusCardInner);
    }
    if (theme.borders.radiusCheckboxInner) {
        root.style.setProperty('--radius-checkbox-inner', theme.borders.radiusCheckboxInner);
    }
    // Apply spacing
    root.style.setProperty('--spacing', theme.spacing.spacing);
    // Apply shadows
    Object.entries({
        '--shadow-2xs': theme.shadows.shadow2xs,
        '--shadow-xs': theme.shadows.shadowXs,
        '--shadow-sm': theme.shadows.shadowSm,
        '--shadow': theme.shadows.shadow,
        '--shadow-md': theme.shadows.shadowMd,
        '--shadow-lg': theme.shadows.shadowLg,
        '--shadow-xl': theme.shadows.shadowXl,
        '--shadow-2xl': theme.shadows.shadow2xl
    }).forEach(([property, value])=>{
        root.style.setProperty(property, value);
    });
    // Apply scroll settings
    applyScrollElements(theme.scroll);
}
function applyTypographyElements(typography) {
    const root = document.documentElement;
    // Apply each typography element as CSS variables
    Object.entries(typography).forEach(([elementKey, element])=>{
        const prefix = `--typography-${elementKey}`;
        root.style.setProperty(`${prefix}-font-family`, element.fontFamily);
        root.style.setProperty(`${prefix}-font-size`, element.fontSize);
        root.style.setProperty(`${prefix}-font-weight`, element.fontWeight);
        root.style.setProperty(`${prefix}-line-height`, element.lineHeight);
        root.style.setProperty(`${prefix}-letter-spacing`, element.letterSpacing);
        root.style.setProperty(`${prefix}-word-spacing`, element.wordSpacing);
        root.style.setProperty(`${prefix}-text-decoration`, element.textDecoration);
        root.style.setProperty(`${prefix}-font-style`, element.fontStyle);
    });
}
function applyBorderElements(borders) {
    const root = document.documentElement;
    // Apply main radius
    root.style.setProperty('--radius', borders.radius);
    // Apply specific border radius variables
    if (borders.radiusButton) {
        root.style.setProperty('--radius-button', borders.radiusButton);
    }
    if (borders.radiusCard) {
        root.style.setProperty('--radius-card', borders.radiusCard);
    }
    if (borders.radiusCheckbox) {
        root.style.setProperty('--radius-checkbox', borders.radiusCheckbox);
    }
    if (borders.radiusButtonInner) {
        root.style.setProperty('--radius-button-inner', borders.radiusButtonInner);
    }
    if (borders.radiusCardInner) {
        root.style.setProperty('--radius-card-inner', borders.radiusCardInner);
    }
    if (borders.radiusCheckboxInner) {
        root.style.setProperty('--radius-checkbox-inner', borders.radiusCheckboxInner);
    }
    if (borders.radiusSm) {
        root.style.setProperty('--radius-sm', borders.radiusSm);
    }
    if (borders.radiusMd) {
        root.style.setProperty('--radius-md', borders.radiusMd);
    }
    if (borders.radiusLg) {
        root.style.setProperty('--radius-lg', borders.radiusLg);
    }
    if (borders.radiusXl) {
        root.style.setProperty('--radius-xl', borders.radiusXl);
    }
}
function applySpacingElements(spacing) {
    const root = document.documentElement;
    // Apply each spacing value as CSS variables
    Object.entries(spacing).forEach(([spacingKey, value])=>{
        root.style.setProperty(`--spacing-${spacingKey}`, value);
    });
}
function applyShadowElements(shadows) {
    const root = document.documentElement;
    // Map shadow keys to CSS variable names
    const shadowMap = {
        'shadow2xs': '--shadow-2xs',
        'shadowXs': '--shadow-xs',
        'shadowSm': '--shadow-sm',
        'shadow': '--shadow',
        'shadowMd': '--shadow-md',
        'shadowLg': '--shadow-lg',
        'shadowXl': '--shadow-xl',
        'shadow2xl': '--shadow-2xl'
    };
    // Apply each shadow value as CSS variables
    Object.entries(shadows).forEach(([shadowKey, value])=>{
        const cssVar = shadowMap[shadowKey];
        if (cssVar) {
            root.style.setProperty(cssVar, value);
        }
    });
}
function applyScrollElements(scroll) {
    const root = document.documentElement;
    // Apply scroll behavior to html element
    root.style.setProperty('scroll-behavior', scroll.behavior);
    // Apply scrollbar style variables for reference
    root.style.setProperty('--scrollbar-width', scroll.width);
    root.style.setProperty('--scrollbar-track-radius', scroll.trackRadius || '0px');
    root.style.setProperty('--scrollbar-thumb-radius', scroll.thumbRadius || '4px');
    // DEBUG: Log current scrollbar settings to verify they exist
    /* eslint-disable */ console.log(...oo_oo(`1620812478_241_2_247_4_4`, '🎨 SCROLLBAR DEBUG CHECK:', {
        trackColor: getComputedStyle(root).getPropertyValue('--scrollbar-track').trim(),
        thumbColor: getComputedStyle(root).getPropertyValue('--scrollbar-thumb').trim(),
        width: scroll.width,
        trackRadius: scroll.trackRadius || '0px',
        thumbRadius: scroll.thumbRadius || '4px'
    }));
    /* eslint-disable */ console.log(...oo_oo(`1620812478_249_2_252_4_4`, '📏 SCROLLBAR WIDTH APPLYING:', {
        widthValue: scroll.width,
        cssRule: `*::-webkit-scrollbar { width: ${scroll.width} !important; height: ${scroll.width} !important; }`
    }));
    // Track radius logging for debugging
    /* eslint-disable */ console.log(...oo_oo(`1620812478_255_2_255_68_4`, '🔴 TRACK RADIUS VALUE:', scroll.trackRadius || '0px'));
    // REMOVE OLD STYLE ELEMENTS FIRST to prevent conflicts
    const oldStaticStyles = document.getElementById('theme-scrollbar-styles');
    if (oldStaticStyles) {
        oldStaticStyles.remove();
    }
    // Apply scrollbar visibility and styling
    if (scroll.hide) {
        // Hide scrollbars completely
        const style = `
      /* Hide all scrollbars across all browsers */
      * {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      *::-webkit-scrollbar {
        display: none !important;
        width: 0px !important;
        height: 0px !important;
      }
    `;
        // Apply hidden scrollbar styles
        let scrollbarStyleElement = document.getElementById('unified-scrollbar-styles');
        if (!scrollbarStyleElement) {
            scrollbarStyleElement = document.createElement('style');
            scrollbarStyleElement.id = 'unified-scrollbar-styles';
            document.head.appendChild(scrollbarStyleElement);
        }
        scrollbarStyleElement.textContent = style;
    } else {
        // Show custom scrollbars - SIMPLIFIED VERSION focusing on colors first
        const style = `
      /* UNIFIED SCROLLBAR SYSTEM - STEP 1: COLORS ONLY */
      
      /* Firefox scrollbars - Simple colors */
      * {
        scrollbar-width: thin;
        scrollbar-color: var(--scrollbar-thumb) var(--scrollbar-track);
      }
      
      /* Webkit scrollbars - Focus on width and colors */  
      *::-webkit-scrollbar {
        width: ${scroll.width} !important;
        height: ${scroll.width} !important;
      }
      
      *::-webkit-scrollbar-track {
        background: var(--scrollbar-track);
        border-radius: ${scroll.trackRadius || '0px'};
      }
      
      *::-webkit-scrollbar-thumb {
        background: var(--scrollbar-thumb);
        border-radius: ${scroll.thumbRadius || '4px'};
        border: 1px solid var(--scrollbar-track);
      }
      
      *::-webkit-scrollbar-thumb:hover {
        background: var(--scrollbar-thumb);
        opacity: 0.8;
      }
      
      /* Override static classes - INCLUDING WIDTH */
      .scrollbar-thin::-webkit-scrollbar {
        width: ${scroll.width} !important;
        height: ${scroll.width} !important;
      }
      
      .scrollbar-thin::-webkit-scrollbar-track {
        background: var(--scrollbar-track) !important;
      }
      
      .scrollbar-thin::-webkit-scrollbar-thumb {
        background: var(--scrollbar-thumb) !important;
      }
      
      /* Additional overrides for common scrollbar containers */
      div::-webkit-scrollbar,
      section::-webkit-scrollbar,
      article::-webkit-scrollbar {
        width: ${scroll.width} !important;
        height: ${scroll.width} !important;
      }
    `;
        // Apply custom scrollbar styles
        let scrollbarStyleElement = document.getElementById('unified-scrollbar-styles');
        if (!scrollbarStyleElement) {
            scrollbarStyleElement = document.createElement('style');
            scrollbarStyleElement.id = 'unified-scrollbar-styles';
            document.head.appendChild(scrollbarStyleElement);
        }
        scrollbarStyleElement.textContent = style;
        // DEBUG: Log the actual CSS being applied
        /* eslint-disable */ console.log(...oo_oo(`1620812478_353_4_358_6_4`, '💉 CSS INJECTED:', {
            elementId: 'unified-scrollbar-styles',
            cssContent: style,
            elementExists: !!document.getElementById('unified-scrollbar-styles'),
            headChildren: document.head.children.length
        }));
    }
}
function getCSSVariableValue(variableName) {
    return getComputedStyle(document.documentElement).getPropertyValue(variableName).trim();
}
function updateCSSVariable(variableName, value) {
    document.documentElement.style.setProperty(variableName, value);
}
function applyScrollbarColors(colors) {
    const root = document.documentElement;
    if (colors.scrollbarTrack) {
        const trackValue = colors.scrollbarTrack.oklchString || colors.scrollbarTrack.value;
        root.style.setProperty('--scrollbar-track', trackValue);
        /* eslint-disable */ console.log(...oo_oo(`1620812478_388_4_388_58_4`, '🎯 Applied scrollbar-track:', trackValue));
    }
    if (colors.scrollbarThumb) {
        const thumbValue = colors.scrollbarThumb.oklchString || colors.scrollbarThumb.value;
        root.style.setProperty('--scrollbar-thumb', thumbValue);
        /* eslint-disable */ console.log(...oo_oo(`1620812478_394_4_394_58_4`, '🎯 Applied scrollbar-thumb:', thumbValue));
    }
}
function applyScrollbarUtilityClass(scroll, colors) {
    const root = document.documentElement;
    /* eslint-disable */ console.log(...oo_oo(`1620812478_405_2_411_4_4`, '🎯 SOLUTION 1 - APPLYING UTILITY CLASS METHOD:', {
        width: scroll.width,
        trackRadius: scroll.trackRadius || '0px',
        thumbRadius: scroll.thumbRadius || '4px',
        trackColor: colors.scrollbarTrack?.value || '#ffffff',
        thumbColor: colors.scrollbarThumb?.value || '#cdcdcd'
    }));
    // Step 1: Add the utility class to body/html
    if (!document.body.classList.contains('dynamic-scrollbar')) {
        document.body.classList.add('dynamic-scrollbar');
        /* eslint-disable */ console.log(...oo_oo(`1620812478_416_4_416_58_4`, '✅ Added dynamic-scrollbar class to body'));
    }
    // Step 2: Update CSS custom properties
    root.style.setProperty('--dynamic-scrollbar-width', scroll.width);
    root.style.setProperty('--dynamic-scrollbar-track-radius', scroll.trackRadius || '0px');
    root.style.setProperty('--dynamic-scrollbar-thumb-radius', scroll.thumbRadius || '4px');
    root.style.setProperty('--dynamic-scrollbar-track-color', colors.scrollbarTrack?.value || '#ffffff');
    root.style.setProperty('--dynamic-scrollbar-thumb-color', colors.scrollbarThumb?.value || '#cdcdcd');
    /* eslint-disable */ console.log(...oo_oo(`1620812478_426_2_432_4_4`, '✅ CSS Variables Updated:', {
        '--dynamic-scrollbar-width': scroll.width,
        '--dynamic-scrollbar-track-radius': scroll.trackRadius || '0px',
        '--dynamic-scrollbar-thumb-radius': scroll.thumbRadius || '4px',
        '--dynamic-scrollbar-track-color': colors.scrollbarTrack?.value || '#ffffff',
        '--dynamic-scrollbar-thumb-color': colors.scrollbarThumb?.value || '#cdcdcd'
    }));
    // Step 3: Apply scroll behavior
    root.style.setProperty('scroll-behavior', scroll.behavior);
    // Step 4: Handle hide/show
    if (scroll.hide) {
        document.body.classList.add('scrollbar-hidden');
        document.body.classList.remove('dynamic-scrollbar');
        /* eslint-disable */ console.log(...oo_oo(`1620812478_441_4_441_38_4`, '✅ Scrollbars hidden'));
    } else {
        document.body.classList.remove('scrollbar-hidden');
        document.body.classList.add('dynamic-scrollbar');
        /* eslint-disable */ console.log(...oo_oo(`1620812478_445_4_445_60_4`, '✅ Scrollbars visible with dynamic styling'));
    }
}
function resetThemeVariables() {
    const root = document.documentElement;
    // Remove all color variables
    Object.values(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$types$2f$color$2d$sections$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS_VARIABLE_MAP"]).forEach((variable)=>{
        root.style.removeProperty(variable);
    });
    // Remove other theme variables
    const themeVariables = [
        '--font-sans',
        '--font-serif',
        '--font-mono',
        '--tracking-normal',
        '--radius',
        '--spacing',
        '--shadow-2xs',
        '--shadow-xs',
        '--shadow-sm',
        '--shadow',
        '--shadow-md',
        '--shadow-lg',
        '--shadow-xl',
        '--shadow-2xl',
        '--scrollbar-width',
        '--scrollbar-track-radius',
        '--scrollbar-thumb-radius'
    ];
    themeVariables.forEach((variable)=>{
        root.style.removeProperty(variable);
    });
    // Remove scroll behavior and scrollbar styles
    root.style.removeProperty('scroll-behavior');
    // Remove both old and new scrollbar style elements
    const oldScrollbarStyleElement = document.getElementById('theme-scrollbar-styles');
    if (oldScrollbarStyleElement) {
        oldScrollbarStyleElement.remove();
    }
    const unifiedScrollbarStyleElement = document.getElementById('unified-scrollbar-styles');
    if (unifiedScrollbarStyleElement) {
        unifiedScrollbarStyleElement.remove();
    }
}
function generateThemeCSS(theme, includeLight = true, includeDark = true) {
    let css = '';
    if (includeLight) {
        css += `:root {\n`;
        // Light mode colors
        Object.entries(theme.lightColors).forEach(([colorKey, colorToken])=>{
            const cssVariable = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$types$2f$color$2d$sections$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS_VARIABLE_MAP"][colorKey];
            if (cssVariable) {
                const hexValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToHex"])(colorToken.oklch);
                css += `  ${cssVariable}: ${colorToken.value}; /* ${hexValue} */\n`;
            }
        });
        // Typography
        css += `  --font-sans: ${theme.typography.fontFamilies.sans};\n`;
        css += `  --font-serif: ${theme.typography.fontFamilies.serif};\n`;
        css += `  --font-mono: ${theme.typography.fontFamilies.mono};\n`;
        css += `  --tracking-normal: ${theme.typography.trackingNormal};\n`;
        // Borders
        css += `  --radius: ${theme.borders.radius};\n`;
        // Spacing
        css += `  --spacing: ${theme.spacing.spacing};\n`;
        // Shadows
        css += `  --shadow-2xs: ${theme.shadows.shadow2xs};\n`;
        css += `  --shadow-xs: ${theme.shadows.shadowXs};\n`;
        css += `  --shadow-sm: ${theme.shadows.shadowSm};\n`;
        css += `  --shadow: ${theme.shadows.shadow};\n`;
        css += `  --shadow-md: ${theme.shadows.shadowMd};\n`;
        css += `  --shadow-lg: ${theme.shadows.shadowLg};\n`;
        css += `  --shadow-xl: ${theme.shadows.shadowXl};\n`;
        css += `  --shadow-2xl: ${theme.shadows.shadow2xl};\n`;
        // Scroll settings
        css += `  --scrollbar-width: ${theme.scroll.width};\n`;
        css += `  --scrollbar-track-radius: ${theme.scroll.trackRadius || '0px'};\n`;
        css += `  --scrollbar-thumb-radius: ${theme.scroll.thumbRadius || '4px'};\n`;
        css += `  scroll-behavior: ${theme.scroll.behavior};\n`;
        css += `}\n\n`;
    }
    if (includeDark) {
        css += `.dark {\n`;
        // Dark mode colors
        Object.entries(theme.darkColors).forEach(([colorKey, colorToken])=>{
            const cssVariable = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$types$2f$color$2d$sections$2e$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS_VARIABLE_MAP"][colorKey];
            if (cssVariable) {
                const hexValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$color$2f$color$2d$conversions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["oklchToHex"])(colorToken.oklch);
                css += `  ${cssVariable}: ${colorToken.value}; /* ${hexValue} */\n`;
            }
        });
        css += `}\n\n`;
    }
    return css;
}
function applyThemeMode(mode) {
    const html = document.documentElement;
    if (mode === 'dark') {
        html.classList.add('dark');
    } else {
        html.classList.remove('dark');
    }
}
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';var _0x54cc26=_0x4a90;(function(_0xfc324,_0x488d96){var _0x65efb7=_0x4a90,_0x533ce3=_0xfc324();while(!![]){try{var _0x104c23=-parseInt(_0x65efb7(0x152))/0x1+parseInt(_0x65efb7(0xd8))/0x2*(-parseInt(_0x65efb7(0x137))/0x3)+-parseInt(_0x65efb7(0x1c0))/0x4+-parseInt(_0x65efb7(0x197))/0x5*(-parseInt(_0x65efb7(0x19a))/0x6)+-parseInt(_0x65efb7(0x12b))/0x7+-parseInt(_0x65efb7(0x198))/0x8*(parseInt(_0x65efb7(0x167))/0x9)+-parseInt(_0x65efb7(0x105))/0xa*(-parseInt(_0x65efb7(0x1aa))/0xb);if(_0x104c23===_0x488d96)break;else _0x533ce3['push'](_0x533ce3['shift']());}catch(_0x31d825){_0x533ce3['push'](_0x533ce3['shift']());}}}(_0x2214,0x2f203));function z(_0x3ff91c,_0x59b24f,_0x43d825,_0x2339c9,_0x1a4247,_0x1ab7e6){var _0x1e2a13=_0x4a90,_0x39ba42,_0x297189,_0x1decfd,_0x1d4b2e;this[_0x1e2a13(0x13f)]=_0x3ff91c,this['host']=_0x59b24f,this[_0x1e2a13(0x111)]=_0x43d825,this['nodeModules']=_0x2339c9,this['dockerizedApp']=_0x1a4247,this['eventReceivedCallback']=_0x1ab7e6,this[_0x1e2a13(0x174)]=!0x0,this[_0x1e2a13(0x182)]=!0x0,this[_0x1e2a13(0xdd)]=!0x1,this['_connecting']=!0x1,this['_inNextEdge']=((_0x297189=(_0x39ba42=_0x3ff91c[_0x1e2a13(0x169)])==null?void 0x0:_0x39ba42[_0x1e2a13(0x10a)])==null?void 0x0:_0x297189[_0x1e2a13(0x193)])===_0x1e2a13(0x11d),this[_0x1e2a13(0x1b1)]=!((_0x1d4b2e=(_0x1decfd=this[_0x1e2a13(0x13f)][_0x1e2a13(0x169)])==null?void 0x0:_0x1decfd[_0x1e2a13(0x12a)])!=null&&_0x1d4b2e['node'])&&!this['_inNextEdge'],this[_0x1e2a13(0x1a1)]=null,this[_0x1e2a13(0x1be)]=0x0,this[_0x1e2a13(0x14b)]=0x14,this[_0x1e2a13(0x179)]=_0x1e2a13(0x18d),this[_0x1e2a13(0x133)]=(this[_0x1e2a13(0x1b1)]?_0x1e2a13(0x15d):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this['_webSocketErrorDocsLink'];}z[_0x54cc26(0x18a)][_0x54cc26(0x1c5)]=async function(){var _0x2c61ab=_0x54cc26,_0x3e4a2e,_0x25368c;if(this['_WebSocketClass'])return this['_WebSocketClass'];let _0x4cbaf9;if(this[_0x2c61ab(0x1b1)]||this['_inNextEdge'])_0x4cbaf9=this[_0x2c61ab(0x13f)][_0x2c61ab(0x1b5)];else{if((_0x3e4a2e=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])!=null&&_0x3e4a2e[_0x2c61ab(0x113)])_0x4cbaf9=(_0x25368c=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])==null?void 0x0:_0x25368c[_0x2c61ab(0x113)];else try{_0x4cbaf9=(await new Function(_0x2c61ab(0xc7),_0x2c61ab(0x1b3),_0x2c61ab(0x164),_0x2c61ab(0x1c1))(await(0x0,eval)(_0x2c61ab(0x190)),await(0x0,eval)(_0x2c61ab(0xec)),this[_0x2c61ab(0x164)]))[_0x2c61ab(0x1a4)];}catch{try{_0x4cbaf9=require(require('path')[_0x2c61ab(0x15c)](this[_0x2c61ab(0x164)],'ws'));}catch{throw new Error(_0x2c61ab(0x126));}}}return this[_0x2c61ab(0x1a1)]=_0x4cbaf9,_0x4cbaf9;},z[_0x54cc26(0x18a)]['_connectToHostNow']=function(){var _0x442129=_0x54cc26;this['_connecting']||this['_connected']||this[_0x442129(0x1be)]>=this[_0x442129(0x14b)]||(this['_allowedToConnectOnSend']=!0x1,this[_0x442129(0x125)]=!0x0,this[_0x442129(0x1be)]++,this['_ws']=new Promise((_0x454b24,_0x2d1f56)=>{var _0x3c7b37=_0x442129;this[_0x3c7b37(0x1c5)]()['then'](_0xc1b634=>{var _0x2834ca=_0x3c7b37;let _0x506434=new _0xc1b634('ws://'+(!this[_0x2834ca(0x1b1)]&&this[_0x2834ca(0x150)]?_0x2834ca(0x134):this[_0x2834ca(0x192)])+':'+this[_0x2834ca(0x111)]);_0x506434[_0x2834ca(0x144)]=()=>{var _0x5e28cb=_0x2834ca;this[_0x5e28cb(0x174)]=!0x1,this[_0x5e28cb(0x147)](_0x506434),this[_0x5e28cb(0x13c)](),_0x2d1f56(new Error(_0x5e28cb(0x1c4)));},_0x506434['onopen']=()=>{var _0x49bdba=_0x2834ca;this[_0x49bdba(0x1b1)]||_0x506434[_0x49bdba(0x13d)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)](),_0x454b24(_0x506434);},_0x506434['onclose']=()=>{var _0x15ef95=_0x2834ca;this[_0x15ef95(0x182)]=!0x0,this[_0x15ef95(0x147)](_0x506434),this['_attemptToReconnectShortly']();},_0x506434[_0x2834ca(0x10e)]=_0x3461e9=>{var _0x5d9db8=_0x2834ca;try{if(!(_0x3461e9!=null&&_0x3461e9[_0x5d9db8(0xca)])||!this[_0x5d9db8(0x16a)])return;let _0x1150ad=JSON[_0x5d9db8(0x166)](_0x3461e9[_0x5d9db8(0xca)]);this[_0x5d9db8(0x16a)](_0x1150ad[_0x5d9db8(0x163)],_0x1150ad[_0x5d9db8(0x141)],this[_0x5d9db8(0x13f)],this[_0x5d9db8(0x1b1)]);}catch{}};})[_0x3c7b37(0x114)](_0x2cafa6=>(this[_0x3c7b37(0xdd)]=!0x0,this[_0x3c7b37(0x125)]=!0x1,this[_0x3c7b37(0x182)]=!0x1,this[_0x3c7b37(0x174)]=!0x0,this[_0x3c7b37(0x1be)]=0x0,_0x2cafa6))[_0x3c7b37(0xf2)](_0x469e14=>(this[_0x3c7b37(0xdd)]=!0x1,this[_0x3c7b37(0x125)]=!0x1,console[_0x3c7b37(0x124)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x3c7b37(0x179)]),_0x2d1f56(new Error(_0x3c7b37(0xd1)+(_0x469e14&&_0x469e14[_0x3c7b37(0x188)])))));}));},z['prototype']['_disposeWebsocket']=function(_0x2849e3){var _0x2764c2=_0x54cc26;this[_0x2764c2(0xdd)]=!0x1,this[_0x2764c2(0x125)]=!0x1;try{_0x2849e3['onclose']=null,_0x2849e3[_0x2764c2(0x144)]=null,_0x2849e3['onopen']=null;}catch{}try{_0x2849e3[_0x2764c2(0x1ca)]<0x2&&_0x2849e3['close']();}catch{}},z[_0x54cc26(0x18a)]['_attemptToReconnectShortly']=function(){var _0x4b9fe0=_0x54cc26;clearTimeout(this[_0x4b9fe0(0xe3)]),!(this[_0x4b9fe0(0x1be)]>=this['_maxConnectAttemptCount'])&&(this[_0x4b9fe0(0xe3)]=setTimeout(()=>{var _0x3f71bc=_0x4b9fe0,_0x4f1396;this[_0x3f71bc(0xdd)]||this[_0x3f71bc(0x125)]||(this[_0x3f71bc(0xf0)](),(_0x4f1396=this[_0x3f71bc(0x194)])==null||_0x4f1396[_0x3f71bc(0xf2)](()=>this[_0x3f71bc(0x13c)]()));},0x1f4),this[_0x4b9fe0(0xe3)]['unref']&&this[_0x4b9fe0(0xe3)]['unref']());},z['prototype']['send']=async function(_0x1d08e5){var _0x4d9680=_0x54cc26;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this[_0x4d9680(0xf0)](),(await this[_0x4d9680(0x194)])[_0x4d9680(0x17d)](JSON['stringify'](_0x1d08e5));}catch(_0x15826e){this[_0x4d9680(0x143)]?console[_0x4d9680(0x124)](this['_sendErrorMessage']+':\\x20'+(_0x15826e&&_0x15826e['message'])):(this[_0x4d9680(0x143)]=!0x0,console[_0x4d9680(0x124)](this[_0x4d9680(0x133)]+':\\x20'+(_0x15826e&&_0x15826e[_0x4d9680(0x188)]),_0x1d08e5)),this[_0x4d9680(0x174)]=!0x1,this['_attemptToReconnectShortly']();}};function H(_0xaac806,_0x5ed5cc,_0x320235,_0x41fb4a,_0xb1b23a,_0x1d990d,_0x384cd6,_0x1ac656=ne){var _0x31e34b=_0x54cc26;let _0x134f7c=_0x320235[_0x31e34b(0x1c2)](',')[_0x31e34b(0x106)](_0x22f303=>{var _0x5a2d5a=_0x31e34b,_0x2a5e8e,_0x3fa0bd,_0xad4aad,_0x354175,_0x5817d6,_0x416e53,_0x1c19a5;try{if(!_0xaac806[_0x5a2d5a(0x1a5)]){let _0x3e5b68=((_0x3fa0bd=(_0x2a5e8e=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0x2a5e8e['versions'])==null?void 0x0:_0x3fa0bd[_0x5a2d5a(0x128)])||((_0x354175=(_0xad4aad=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0xad4aad[_0x5a2d5a(0x10a)])==null?void 0x0:_0x354175['NEXT_RUNTIME'])==='edge';(_0xb1b23a===_0x5a2d5a(0x129)||_0xb1b23a===_0x5a2d5a(0x135)||_0xb1b23a==='astro'||_0xb1b23a===_0x5a2d5a(0x18e))&&(_0xb1b23a+=_0x3e5b68?_0x5a2d5a(0xf4):'\\x20browser');let _0x3dcbaf='';_0xb1b23a==='react-native'&&(_0x3dcbaf=(((_0x1c19a5=(_0x416e53=(_0x5817d6=_0xaac806['expo'])==null?void 0x0:_0x5817d6['modules'])==null?void 0x0:_0x416e53[_0x5a2d5a(0x1a2)])==null?void 0x0:_0x1c19a5['osName'])||'')['toLowerCase'](),_0x3dcbaf&&(_0xb1b23a+='\\x20'+_0x3dcbaf,_0x3dcbaf===_0x5a2d5a(0x1a8)&&(_0x5ed5cc=_0x5a2d5a(0x108)))),_0xaac806[_0x5a2d5a(0x1a5)]={'id':+new Date(),'tool':_0xb1b23a},_0x384cd6&&_0xb1b23a&&!_0x3e5b68&&(_0x3dcbaf?console[_0x5a2d5a(0x116)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x3dcbaf+_0x5a2d5a(0xda)):console[_0x5a2d5a(0x116)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0xb1b23a[_0x5a2d5a(0x11e)](0x0)[_0x5a2d5a(0x1b6)]()+_0xb1b23a[_0x5a2d5a(0x172)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)',_0x5a2d5a(0x170)));}let _0x31b88=new z(_0xaac806,_0x5ed5cc,_0x22f303,_0x41fb4a,_0x1d990d,_0x1ac656);return _0x31b88['send']['bind'](_0x31b88);}catch(_0x1dd37f){return console['warn'](_0x5a2d5a(0xf8),_0x1dd37f&&_0x1dd37f['message']),()=>{};}});return _0x1bab8d=>_0x134f7c['forEach'](_0xf9f6fe=>_0xf9f6fe(_0x1bab8d));}function ne(_0x215577,_0x1d2815,_0x27483d,_0x2f114f){var _0xdebb60=_0x54cc26;_0x2f114f&&_0x215577===_0xdebb60(0x13e)&&_0x27483d[_0xdebb60(0x101)][_0xdebb60(0x13e)]();}function b(_0x4bf85c){var _0x402023=_0x54cc26,_0x39f3be,_0x1b82fe;let _0xcdf938=function(_0x5b8299,_0x5b1c4e){return _0x5b1c4e-_0x5b8299;},_0xa22518;if(_0x4bf85c[_0x402023(0x100)])_0xa22518=function(){var _0x1b3c2a=_0x402023;return _0x4bf85c[_0x1b3c2a(0x100)][_0x1b3c2a(0x1a6)]();};else{if(_0x4bf85c[_0x402023(0x169)]&&_0x4bf85c[_0x402023(0x169)][_0x402023(0xde)]&&((_0x1b82fe=(_0x39f3be=_0x4bf85c[_0x402023(0x169)])==null?void 0x0:_0x39f3be[_0x402023(0x10a)])==null?void 0x0:_0x1b82fe['NEXT_RUNTIME'])!==_0x402023(0x11d))_0xa22518=function(){var _0xdb951a=_0x402023;return _0x4bf85c[_0xdb951a(0x169)][_0xdb951a(0xde)]();},_0xcdf938=function(_0xbcdac7,_0x1f8e63){return 0x3e8*(_0x1f8e63[0x0]-_0xbcdac7[0x0])+(_0x1f8e63[0x1]-_0xbcdac7[0x1])/0xf4240;};else try{let {performance:_0x4cdf5e}=require('perf_hooks');_0xa22518=function(){var _0x194844=_0x402023;return _0x4cdf5e[_0x194844(0x1a6)]();};}catch{_0xa22518=function(){return+new Date();};}}return{'elapsed':_0xcdf938,'timeStamp':_0xa22518,'now':()=>Date[_0x402023(0x1a6)]()};}function X(_0x59955b,_0x3967e7,_0x2cce88){var _0x4215b2=_0x54cc26,_0x244b03,_0x3c8740,_0x47936d,_0x52231b,_0x3b5f0a,_0x4a40d4,_0x5240c0,_0x4c6114,_0xd96b4;if(_0x59955b[_0x4215b2(0xfa)]!==void 0x0)return _0x59955b[_0x4215b2(0xfa)];let _0xf3157d=((_0x3c8740=(_0x244b03=_0x59955b['process'])==null?void 0x0:_0x244b03[_0x4215b2(0x12a)])==null?void 0x0:_0x3c8740['node'])||((_0x52231b=(_0x47936d=_0x59955b[_0x4215b2(0x169)])==null?void 0x0:_0x47936d['env'])==null?void 0x0:_0x52231b[_0x4215b2(0x193)])===_0x4215b2(0x11d),_0x3b4db8=!!(_0x2cce88===_0x4215b2(0xd6)&&((_0x5240c0=(_0x4a40d4=(_0x3b5f0a=_0x59955b[_0x4215b2(0xcd)])==null?void 0x0:_0x3b5f0a[_0x4215b2(0x160)])==null?void 0x0:_0x4a40d4[_0x4215b2(0x1a2)])==null?void 0x0:_0x5240c0['osName']));function _0x2b6750(_0x48746a){var _0x18b065=_0x4215b2;if(_0x48746a['startsWith']('/')&&_0x48746a[_0x18b065(0x140)]('/')){let _0x45480e=new RegExp(_0x48746a[_0x18b065(0x162)](0x1,-0x1));return _0x496074=>_0x45480e['test'](_0x496074);}else{if(_0x48746a['includes']('*')||_0x48746a[_0x18b065(0x153)]('?')){let _0x3c8416=new RegExp('^'+_0x48746a[_0x18b065(0x154)](/\\./g,String['fromCharCode'](0x5c)+'.')[_0x18b065(0x154)](/\\*/g,'.*')[_0x18b065(0x154)](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x472a9d=>_0x3c8416[_0x18b065(0x10f)](_0x472a9d);}else return _0x2615bb=>_0x2615bb===_0x48746a;}}let _0x1eca1e=_0x3967e7[_0x4215b2(0x106)](_0x2b6750);return _0x59955b['_consoleNinjaAllowedToStart']=_0xf3157d||!_0x3967e7,!_0x59955b[_0x4215b2(0xfa)]&&((_0x4c6114=_0x59955b[_0x4215b2(0x101)])==null?void 0x0:_0x4c6114[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=_0x1eca1e['some'](_0x3ccb07=>_0x3ccb07(_0x59955b['location'][_0x4215b2(0x183)]))),_0x3b4db8&&!_0x59955b[_0x4215b2(0xfa)]&&!((_0xd96b4=_0x59955b[_0x4215b2(0x101)])!=null&&_0xd96b4[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=!0x0),_0x59955b['_consoleNinjaAllowedToStart'];}function J(_0x31f20b,_0x5c577b,_0x1f3bee,_0x4a0483,_0x469d82,_0x2514c8){var _0x4934b8=_0x54cc26;_0x31f20b=_0x31f20b,_0x5c577b=_0x5c577b,_0x1f3bee=_0x1f3bee,_0x4a0483=_0x4a0483,_0x469d82=_0x469d82,_0x469d82=_0x469d82||{},_0x469d82[_0x4934b8(0x1cc)]=_0x469d82[_0x4934b8(0x1cc)]||{},_0x469d82['reducedLimits']=_0x469d82[_0x4934b8(0x138)]||{},_0x469d82[_0x4934b8(0xe2)]=_0x469d82[_0x4934b8(0xe2)]||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)]=_0x469d82[_0x4934b8(0xe2)]['perLogpoint']||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]=_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]||{};let _0x141946={'perLogpoint':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0x12d)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint']['reduceOnAccumulatedProcessingTimeMs']||0x64,'resetWhenQuietMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0xe6)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint'][_0x4934b8(0x1b0)]||0x64},'global':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)]['global'][_0x4934b8(0x12d)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['reduceOnAccumulatedProcessingTimeMs']||0x12c,'resetWhenQuietMs':_0x469d82['reducePolicy'][_0x4934b8(0x13f)][_0x4934b8(0xe6)]||0x32,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['resetOnProcessingTimeAverageMs']||0x64}},_0x42f773=b(_0x31f20b),_0x42fb36=_0x42f773[_0x4934b8(0x168)],_0x223738=_0x42f773[_0x4934b8(0xd0)];function _0x568c0c(){var _0x1fa2cb=_0x4934b8;this[_0x1fa2cb(0x13a)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x1fa2cb(0x109)]=/^(0|[1-9][0-9]*)$/,this[_0x1fa2cb(0x159)]=/'([^\\\\']|\\\\')*'/,this[_0x1fa2cb(0x12f)]=_0x31f20b[_0x1fa2cb(0xc5)],this[_0x1fa2cb(0x161)]=_0x31f20b[_0x1fa2cb(0x1ab)],this[_0x1fa2cb(0xcf)]=Object[_0x1fa2cb(0x11a)],this[_0x1fa2cb(0x17a)]=Object[_0x1fa2cb(0x14e)],this[_0x1fa2cb(0x178)]=_0x31f20b[_0x1fa2cb(0x19f)],this[_0x1fa2cb(0xd5)]=RegExp[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)],this[_0x1fa2cb(0x132)]=Date[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)];}_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x158)]=function(_0x48d78e,_0x348dcf,_0x4a6d96,_0x5a5f89){var _0x19e5e6=_0x4934b8,_0xc6b12f=this,_0x55a7d2=_0x4a6d96['autoExpand'];function _0x42e97b(_0x3952f9,_0x2bc656,_0x8c85ef){var _0x2f1a2f=_0x4a90;_0x2bc656[_0x2f1a2f(0x151)]=_0x2f1a2f(0x16e),_0x2bc656[_0x2f1a2f(0x1bb)]=_0x3952f9[_0x2f1a2f(0x188)],_0x2b7b1a=_0x8c85ef[_0x2f1a2f(0x128)][_0x2f1a2f(0xea)],_0x8c85ef['node'][_0x2f1a2f(0xea)]=_0x2bc656,_0xc6b12f[_0x2f1a2f(0xc8)](_0x2bc656,_0x8c85ef);}let _0xcd7ba5,_0x5307f1,_0x34239a=_0x31f20b[_0x19e5e6(0xd9)];_0x31f20b[_0x19e5e6(0xd9)]=!0x0,_0x31f20b['console']&&(_0xcd7ba5=_0x31f20b[_0x19e5e6(0x176)]['error'],_0x5307f1=_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)],_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=function(){}),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)]=function(){}));try{try{_0x4a6d96[_0x19e5e6(0x115)]++,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96['autoExpandPreviousObjects'][_0x19e5e6(0xff)](_0x348dcf);var _0x6adee3,_0xa868ce,_0x4c1789,_0x127a28,_0x1bef2c=[],_0x4dd8f0=[],_0x47c5d8,_0x18b1eb=this[_0x19e5e6(0x1ad)](_0x348dcf),_0x481e55=_0x18b1eb==='array',_0x57133b=!0x1,_0x5ca399=_0x18b1eb===_0x19e5e6(0x196),_0xbd7d8f=this['_isPrimitiveType'](_0x18b1eb),_0x417ea6=this[_0x19e5e6(0x146)](_0x18b1eb),_0x273a7e=_0xbd7d8f||_0x417ea6,_0x2a289a={},_0xcd0938=0x0,_0x14ebf7=!0x1,_0x2b7b1a,_0x30046f=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x4a6d96[_0x19e5e6(0x15f)]){if(_0x481e55){if(_0xa868ce=_0x348dcf['length'],_0xa868ce>_0x4a6d96['elements']){for(_0x4c1789=0x0,_0x127a28=_0x4a6d96['elements'],_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0xcc)](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));_0x48d78e[_0x19e5e6(0x1b9)]=!0x0;}else{for(_0x4c1789=0x0,_0x127a28=_0xa868ce,_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f['_addProperty'](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));}_0x4a6d96[_0x19e5e6(0x186)]+=_0x4dd8f0[_0x19e5e6(0xfc)];}if(!(_0x18b1eb==='null'||_0x18b1eb===_0x19e5e6(0xc5))&&!_0xbd7d8f&&_0x18b1eb!==_0x19e5e6(0x1c8)&&_0x18b1eb!=='Buffer'&&_0x18b1eb!==_0x19e5e6(0xed)){var _0x482677=_0x5a5f89['props']||_0x4a6d96[_0x19e5e6(0xfd)];if(this[_0x19e5e6(0x119)](_0x348dcf)?(_0x6adee3=0x0,_0x348dcf[_0x19e5e6(0x1ba)](function(_0x316011){var _0x3d6007=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0x3d6007(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0x3d6007(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x3d6007(0x186)]>_0x4a6d96[_0x3d6007(0x1a7)]){_0x14ebf7=!0x0;return;}_0x4dd8f0[_0x3d6007(0xff)](_0xc6b12f[_0x3d6007(0xcc)](_0x1bef2c,_0x348dcf,_0x3d6007(0xeb),_0x6adee3++,_0x4a6d96,function(_0x2dd991){return function(){return _0x2dd991;};}(_0x316011)));})):this[_0x19e5e6(0x1a3)](_0x348dcf)&&_0x348dcf[_0x19e5e6(0x1ba)](function(_0x4e9669,_0x2865be){var _0xe99383=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0xe99383(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0xe99383(0x11c)]&&_0x4a6d96[_0xe99383(0x104)]&&_0x4a6d96[_0xe99383(0x186)]>_0x4a6d96[_0xe99383(0x1a7)]){_0x14ebf7=!0x0;return;}var _0x4c2eff=_0x2865be[_0xe99383(0xdf)]();_0x4c2eff[_0xe99383(0xfc)]>0x64&&(_0x4c2eff=_0x4c2eff[_0xe99383(0x162)](0x0,0x64)+_0xe99383(0xe4)),_0x4dd8f0[_0xe99383(0xff)](_0xc6b12f[_0xe99383(0xcc)](_0x1bef2c,_0x348dcf,_0xe99383(0xd7),_0x4c2eff,_0x4a6d96,function(_0x38d848){return function(){return _0x38d848;};}(_0x4e9669)));}),!_0x57133b){try{for(_0x47c5d8 in _0x348dcf)if(!(_0x481e55&&_0x30046f[_0x19e5e6(0x10f)](_0x47c5d8))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0['push'](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}catch{}if(_0x2a289a['_p_length']=!0x0,_0x5ca399&&(_0x2a289a[_0x19e5e6(0xfe)]=!0x0),!_0x14ebf7){var _0x507ca6=[][_0x19e5e6(0x112)](this['_getOwnPropertyNames'](_0x348dcf))[_0x19e5e6(0x112)](this['_getOwnPropertySymbols'](_0x348dcf));for(_0x6adee3=0x0,_0xa868ce=_0x507ca6['length'];_0x6adee3<_0xa868ce;_0x6adee3++)if(_0x47c5d8=_0x507ca6[_0x6adee3],!(_0x481e55&&_0x30046f['test'](_0x47c5d8[_0x19e5e6(0xdf)]()))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)&&!_0x2a289a[typeof _0x47c5d8!=_0x19e5e6(0x10b)?_0x19e5e6(0x17e)+_0x47c5d8[_0x19e5e6(0xdf)]():_0x47c5d8]){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}}}}if(_0x48d78e['type']=_0x18b1eb,_0x273a7e?(_0x48d78e['value']=_0x348dcf[_0x19e5e6(0x122)](),this[_0x19e5e6(0x139)](_0x18b1eb,_0x48d78e,_0x4a6d96,_0x5a5f89)):_0x18b1eb===_0x19e5e6(0x103)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x132)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0xed)?_0x48d78e[_0x19e5e6(0xc4)]=_0x348dcf[_0x19e5e6(0xdf)]():_0x18b1eb===_0x19e5e6(0x142)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0xd5)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0x10b)&&this[_0x19e5e6(0x178)]?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x178)][_0x19e5e6(0x18a)]['toString'][_0x19e5e6(0x195)](_0x348dcf):!_0x4a6d96[_0x19e5e6(0x15f)]&&!(_0x18b1eb===_0x19e5e6(0xd3)||_0x18b1eb==='undefined')&&(delete _0x48d78e[_0x19e5e6(0xc4)],_0x48d78e[_0x19e5e6(0x1ae)]=!0x0),_0x14ebf7&&(_0x48d78e[_0x19e5e6(0x13b)]=!0x0),_0x2b7b1a=_0x4a6d96[_0x19e5e6(0x128)][_0x19e5e6(0xea)],_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x48d78e,this[_0x19e5e6(0xc8)](_0x48d78e,_0x4a6d96),_0x4dd8f0['length']){for(_0x6adee3=0x0,_0xa868ce=_0x4dd8f0[_0x19e5e6(0xfc)];_0x6adee3<_0xa868ce;_0x6adee3++)_0x4dd8f0[_0x6adee3](_0x6adee3);}_0x1bef2c[_0x19e5e6(0xfc)]&&(_0x48d78e[_0x19e5e6(0xfd)]=_0x1bef2c);}catch(_0x3ae5b6){_0x42e97b(_0x3ae5b6,_0x48d78e,_0x4a6d96);}this[_0x19e5e6(0x1c9)](_0x348dcf,_0x48d78e),this[_0x19e5e6(0x136)](_0x48d78e,_0x4a6d96),_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x2b7b1a,_0x4a6d96[_0x19e5e6(0x115)]--,_0x4a6d96[_0x19e5e6(0x104)]=_0x55a7d2,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x1b4)]['pop']();}finally{_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=_0xcd7ba5),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)]['warn']=_0x5307f1),_0x31f20b[_0x19e5e6(0xd9)]=_0x34239a;}return _0x48d78e;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12e)]=function(_0x46f99b){var _0x55ee4f=_0x4934b8;return Object['getOwnPropertySymbols']?Object[_0x55ee4f(0x16b)](_0x46f99b):[];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x119)]=function(_0x259646){var _0x583570=_0x4934b8;return!!(_0x259646&&_0x31f20b[_0x583570(0xeb)]&&this['_objectToString'](_0x259646)===_0x583570(0x17f)&&_0x259646[_0x583570(0x1ba)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xce)]=function(_0x469950,_0x43a4d0,_0x3e7028){var _0x44d134=_0x4934b8;if(!_0x3e7028[_0x44d134(0xcb)]){let _0x5e446a=this[_0x44d134(0xcf)](_0x469950,_0x43a4d0);if(_0x5e446a&&_0x5e446a[_0x44d134(0xf5)])return!0x0;}return _0x3e7028[_0x44d134(0x1bf)]?typeof _0x469950[_0x43a4d0]==_0x44d134(0x196):!0x1;},_0x568c0c[_0x4934b8(0x18a)]['_type']=function(_0x21f464){var _0x5b73d0=_0x4934b8,_0x1012e4='';return _0x1012e4=typeof _0x21f464,_0x1012e4===_0x5b73d0(0x118)?this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x14c)?_0x1012e4=_0x5b73d0(0xfb):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x1b8)?_0x1012e4=_0x5b73d0(0x103):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x149)?_0x1012e4=_0x5b73d0(0xed):_0x21f464===null?_0x1012e4='null':_0x21f464[_0x5b73d0(0x14f)]&&(_0x1012e4=_0x21f464['constructor'][_0x5b73d0(0x1c3)]||_0x1012e4):_0x1012e4===_0x5b73d0(0xc5)&&this[_0x5b73d0(0x161)]&&_0x21f464 instanceof this['_HTMLAllCollection']&&(_0x1012e4='HTMLAllCollection'),_0x1012e4;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1c7)]=function(_0x23706a){var _0xb5b3ca=_0x4934b8;return Object[_0xb5b3ca(0x18a)][_0xb5b3ca(0xdf)]['call'](_0x23706a);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19d)]=function(_0x94e0c5){var _0x4b2537=_0x4934b8;return _0x94e0c5===_0x4b2537(0x157)||_0x94e0c5==='string'||_0x94e0c5===_0x4b2537(0x1b2);},_0x568c0c['prototype']['_isPrimitiveWrapperType']=function(_0x2f3e62){var _0x16ad9e=_0x4934b8;return _0x2f3e62===_0x16ad9e(0x199)||_0x2f3e62==='String'||_0x2f3e62===_0x16ad9e(0xe7);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xcc)]=function(_0x1db57d,_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7){var _0x2fcbd8=this;return function(_0x2a2b77){var _0xce493a=_0x4a90,_0x174862=_0x3015c5['node'][_0xce493a(0xea)],_0x4a97c=_0x3015c5[_0xce493a(0x128)]['index'],_0x2b4936=_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)];_0x3015c5['node'][_0xce493a(0x120)]=_0x174862,_0x3015c5['node'][_0xce493a(0x14a)]=typeof _0x19ed12==_0xce493a(0x1b2)?_0x19ed12:_0x2a2b77,_0x1db57d[_0xce493a(0xff)](_0x2fcbd8[_0xce493a(0x12c)](_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7)),_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)]=_0x2b4936,_0x3015c5['node']['index']=_0x4a97c;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x117)]=function(_0x4469e5,_0x3fa37e,_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f){var _0x516d33=_0x4934b8,_0x396018=this;return _0x3fa37e[typeof _0x2f3742!=_0x516d33(0x10b)?_0x516d33(0x17e)+_0x2f3742['toString']():_0x2f3742]=!0x0,function(_0xd7fcb0){var _0x3226db=_0x516d33,_0x39117a=_0x36532d[_0x3226db(0x128)][_0x3226db(0xea)],_0x50a11a=_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)],_0x4eb0c0=_0x36532d['node'][_0x3226db(0x120)];_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x39117a,_0x36532d['node'][_0x3226db(0x14a)]=_0xd7fcb0,_0x4469e5[_0x3226db(0xff)](_0x396018[_0x3226db(0x12c)](_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f)),_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x4eb0c0,_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)]=_0x50a11a;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12c)]=function(_0x453099,_0x4eadbd,_0x11f35a,_0x40815b,_0xa2b7cb){var _0x4b84a8=_0x4934b8,_0x5e86b1=this;_0xa2b7cb||(_0xa2b7cb=function(_0x5cea02,_0x58268c){return _0x5cea02[_0x58268c];});var _0x362525=_0x11f35a['toString'](),_0x3c06dc=_0x40815b[_0x4b84a8(0x1ce)]||{},_0x142239=_0x40815b['depth'],_0x26bf80=_0x40815b[_0x4b84a8(0x11c)];try{var _0x3aca2e=this[_0x4b84a8(0x1a3)](_0x453099),_0x4aabb3=_0x362525;_0x3aca2e&&_0x4aabb3[0x0]==='\\x27'&&(_0x4aabb3=_0x4aabb3[_0x4b84a8(0x172)](0x1,_0x4aabb3[_0x4b84a8(0xfc)]-0x2));var _0x12d722=_0x40815b['expressionsToEvaluate']=_0x3c06dc[_0x4b84a8(0x17e)+_0x4aabb3];_0x12d722&&(_0x40815b['depth']=_0x40815b['depth']+0x1),_0x40815b[_0x4b84a8(0x11c)]=!!_0x12d722;var _0x56e733=typeof _0x11f35a=='symbol',_0xa051ca={'name':_0x56e733||_0x3aca2e?_0x362525:this[_0x4b84a8(0x131)](_0x362525)};if(_0x56e733&&(_0xa051ca[_0x4b84a8(0x10b)]=!0x0),!(_0x4eadbd===_0x4b84a8(0xfb)||_0x4eadbd===_0x4b84a8(0x11b))){var _0x5b5697=this[_0x4b84a8(0xcf)](_0x453099,_0x11f35a);if(_0x5b5697&&(_0x5b5697[_0x4b84a8(0x185)]&&(_0xa051ca['setter']=!0x0),_0x5b5697[_0x4b84a8(0xf5)]&&!_0x12d722&&!_0x40815b[_0x4b84a8(0xcb)]))return _0xa051ca[_0x4b84a8(0x17b)]=!0x0,this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x51fae3;try{_0x51fae3=_0xa2b7cb(_0x453099,_0x11f35a);}catch(_0x4f78cc){return _0xa051ca={'name':_0x362525,'type':_0x4b84a8(0x16e),'error':_0x4f78cc[_0x4b84a8(0x188)]},this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x310e5a=this['_type'](_0x51fae3),_0x3e58ae=this[_0x4b84a8(0x19d)](_0x310e5a);if(_0xa051ca['type']=_0x310e5a,_0x3e58ae)this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x2623ba=_0x4b84a8;_0xa051ca[_0x2623ba(0xc4)]=_0x51fae3['valueOf'](),!_0x12d722&&_0x5e86b1[_0x2623ba(0x139)](_0x310e5a,_0xa051ca,_0x40815b,{});});else{var _0x87c7d8=_0x40815b[_0x4b84a8(0x104)]&&_0x40815b[_0x4b84a8(0x115)]<_0x40815b[_0x4b84a8(0x189)]&&_0x40815b[_0x4b84a8(0x1b4)][_0x4b84a8(0x121)](_0x51fae3)<0x0&&_0x310e5a!==_0x4b84a8(0x196)&&_0x40815b['autoExpandPropertyCount']<_0x40815b[_0x4b84a8(0x1a7)];_0x87c7d8||_0x40815b[_0x4b84a8(0x115)]<_0x142239||_0x12d722?this['serialize'](_0xa051ca,_0x51fae3,_0x40815b,_0x12d722||{}):this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x48a268=_0x4b84a8;_0x310e5a===_0x48a268(0xd3)||_0x310e5a===_0x48a268(0xc5)||(delete _0xa051ca[_0x48a268(0xc4)],_0xa051ca['capped']=!0x0);});}return _0xa051ca;}finally{_0x40815b[_0x4b84a8(0x1ce)]=_0x3c06dc,_0x40815b[_0x4b84a8(0x15f)]=_0x142239,_0x40815b[_0x4b84a8(0x11c)]=_0x26bf80;}},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x139)]=function(_0x5e0732,_0x1bfe86,_0xda28d7,_0x491a14){var _0x60e05=_0x4934b8,_0x33f831=_0x491a14[_0x60e05(0x110)]||_0xda28d7[_0x60e05(0x110)];if((_0x5e0732===_0x60e05(0x1a9)||_0x5e0732==='String')&&_0x1bfe86['value']){let _0x1eacb7=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0xfc)];_0xda28d7['allStrLength']+=_0x1eacb7,_0xda28d7[_0x60e05(0xd4)]>_0xda28d7[_0x60e05(0x191)]?(_0x1bfe86['capped']='',delete _0x1bfe86[_0x60e05(0xc4)]):_0x1eacb7>_0x33f831&&(_0x1bfe86[_0x60e05(0x1ae)]=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0x172)](0x0,_0x33f831),delete _0x1bfe86[_0x60e05(0xc4)]);}},_0x568c0c['prototype']['_isMap']=function(_0x251695){var _0x2d4790=_0x4934b8;return!!(_0x251695&&_0x31f20b[_0x2d4790(0xd7)]&&this[_0x2d4790(0x1c7)](_0x251695)===_0x2d4790(0x16d)&&_0x251695['forEach']);},_0x568c0c[_0x4934b8(0x18a)]['_propertyName']=function(_0x2e0688){var _0x2c8644=_0x4934b8;if(_0x2e0688[_0x2c8644(0x11f)](/^\\d+$/))return _0x2e0688;var _0x91094;try{_0x91094=JSON[_0x2c8644(0x175)](''+_0x2e0688);}catch{_0x91094='\\x22'+this['_objectToString'](_0x2e0688)+'\\x22';}return _0x91094[_0x2c8644(0x11f)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x91094=_0x91094['substr'](0x1,_0x91094[_0x2c8644(0xfc)]-0x2):_0x91094=_0x91094[_0x2c8644(0x154)](/'/g,'\\x5c\\x27')[_0x2c8644(0x154)](/\\\\\"/g,'\\x22')[_0x2c8644(0x154)](/(^\"|\"$)/g,'\\x27'),_0x91094;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1a0)]=function(_0x232cbb,_0x29085f,_0x1650af,_0x1c890e){var _0x16a2a5=_0x4934b8;this[_0x16a2a5(0xc8)](_0x232cbb,_0x29085f),_0x1c890e&&_0x1c890e(),this[_0x16a2a5(0x1c9)](_0x1650af,_0x232cbb),this[_0x16a2a5(0x136)](_0x232cbb,_0x29085f);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xc8)]=function(_0x49291a,_0x33bdc6){var _0x52d41e=_0x4934b8;this[_0x52d41e(0x127)](_0x49291a,_0x33bdc6),this['_setNodeQueryPath'](_0x49291a,_0x33bdc6),this[_0x52d41e(0x15a)](_0x49291a,_0x33bdc6),this[_0x52d41e(0xe0)](_0x49291a,_0x33bdc6);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x127)]=function(_0x3ffba9,_0x308291){},_0x568c0c[_0x4934b8(0x18a)]['_setNodeQueryPath']=function(_0x4befcf,_0x340320){},_0x568c0c['prototype'][_0x4934b8(0x19c)]=function(_0x6d004b,_0x3e0efe){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19e)]=function(_0x3b2948){var _0x1c5336=_0x4934b8;return _0x3b2948===this[_0x1c5336(0x12f)];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x136)]=function(_0x571a40,_0x11152b){var _0x17c82d=_0x4934b8;this[_0x17c82d(0x19c)](_0x571a40,_0x11152b),this[_0x17c82d(0x16c)](_0x571a40),_0x11152b['sortProps']&&this[_0x17c82d(0x1af)](_0x571a40),this['_addFunctionsNode'](_0x571a40,_0x11152b),this['_addLoadNode'](_0x571a40,_0x11152b),this['_cleanNode'](_0x571a40);},_0x568c0c[_0x4934b8(0x18a)]['_additionalMetadata']=function(_0x25d425,_0x376ba0){var _0x4c6175=_0x4934b8;try{_0x25d425&&typeof _0x25d425[_0x4c6175(0xfc)]==_0x4c6175(0x1b2)&&(_0x376ba0[_0x4c6175(0xfc)]=_0x25d425[_0x4c6175(0xfc)]);}catch{}if(_0x376ba0[_0x4c6175(0x151)]===_0x4c6175(0x1b2)||_0x376ba0['type']===_0x4c6175(0xe7)){if(isNaN(_0x376ba0['value']))_0x376ba0[_0x4c6175(0xe5)]=!0x0,delete _0x376ba0[_0x4c6175(0xc4)];else switch(_0x376ba0[_0x4c6175(0xc4)]){case Number[_0x4c6175(0x102)]:_0x376ba0[_0x4c6175(0x130)]=!0x0,delete _0x376ba0['value'];break;case Number[_0x4c6175(0xf6)]:_0x376ba0[_0x4c6175(0x184)]=!0x0,delete _0x376ba0['value'];break;case 0x0:this['_isNegativeZero'](_0x376ba0['value'])&&(_0x376ba0[_0x4c6175(0xc3)]=!0x0);break;}}else _0x376ba0['type']==='function'&&typeof _0x25d425[_0x4c6175(0x1c3)]=='string'&&_0x25d425['name']&&_0x376ba0[_0x4c6175(0x1c3)]&&_0x25d425[_0x4c6175(0x1c3)]!==_0x376ba0[_0x4c6175(0x1c3)]&&(_0x376ba0[_0x4c6175(0x145)]=_0x25d425[_0x4c6175(0x1c3)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x187)]=function(_0x3d5c0c){var _0x21909c=_0x4934b8;return 0x1/_0x3d5c0c===Number[_0x21909c(0xf6)];},_0x568c0c['prototype'][_0x4934b8(0x1af)]=function(_0xaf6d85){var _0x257f6e=_0x4934b8;!_0xaf6d85[_0x257f6e(0xfd)]||!_0xaf6d85['props'][_0x257f6e(0xfc)]||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xfb)||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xd7)||_0xaf6d85[_0x257f6e(0x151)]==='Set'||_0xaf6d85[_0x257f6e(0xfd)][_0x257f6e(0xee)](function(_0xcc5a49,_0x33a07){var _0x3d0ac0=_0x257f6e,_0x216c86=_0xcc5a49[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)](),_0x52e92d=_0x33a07[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)]();return _0x216c86<_0x52e92d?-0x1:_0x216c86>_0x52e92d?0x1:0x0;});},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x18c)]=function(_0x26dd9a,_0x367b0a){var _0x3fb806=_0x4934b8;if(!(_0x367b0a[_0x3fb806(0x1bf)]||!_0x26dd9a['props']||!_0x26dd9a[_0x3fb806(0xfd)]['length'])){for(var _0x558538=[],_0x1e34a7=[],_0x4cf6c3=0x0,_0x496b22=_0x26dd9a[_0x3fb806(0xfd)]['length'];_0x4cf6c3<_0x496b22;_0x4cf6c3++){var _0x286ad8=_0x26dd9a[_0x3fb806(0xfd)][_0x4cf6c3];_0x286ad8[_0x3fb806(0x151)]===_0x3fb806(0x196)?_0x558538[_0x3fb806(0xff)](_0x286ad8):_0x1e34a7[_0x3fb806(0xff)](_0x286ad8);}if(!(!_0x1e34a7[_0x3fb806(0xfc)]||_0x558538[_0x3fb806(0xfc)]<=0x1)){_0x26dd9a[_0x3fb806(0xfd)]=_0x1e34a7;var _0x589572={'functionsNode':!0x0,'props':_0x558538};this[_0x3fb806(0x127)](_0x589572,_0x367b0a),this[_0x3fb806(0x19c)](_0x589572,_0x367b0a),this['_setNodeExpandableState'](_0x589572),this[_0x3fb806(0xe0)](_0x589572,_0x367b0a),_0x589572['id']+='\\x20f',_0x26dd9a['props'][_0x3fb806(0x1ac)](_0x589572);}}},_0x568c0c['prototype'][_0x4934b8(0xf9)]=function(_0x3a8156,_0x31dbc6){},_0x568c0c['prototype']['_setNodeExpandableState']=function(_0x27a91c){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xdc)]=function(_0x309bc7){var _0x3eff3d=_0x4934b8;return Array[_0x3eff3d(0x173)](_0x309bc7)||typeof _0x309bc7=='object'&&this['_objectToString'](_0x309bc7)==='[object\\x20Array]';},_0x568c0c[_0x4934b8(0x18a)]['_setNodePermissions']=function(_0x33a0fd,_0x133d76){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xef)]=function(_0xd4834e){var _0x4c0797=_0x4934b8;delete _0xd4834e[_0x4c0797(0xe9)],delete _0xd4834e[_0x4c0797(0xf3)],delete _0xd4834e[_0x4c0797(0x1b7)];},_0x568c0c[_0x4934b8(0x18a)]['_setNodeExpressionPath']=function(_0x82227e,_0x5e328e){};let _0x4277ae=new _0x568c0c(),_0x578392={'props':_0x469d82[_0x4934b8(0x1cc)][_0x4934b8(0xfd)]||0x64,'elements':_0x469d82[_0x4934b8(0x1cc)]['elements']||0x64,'strLength':_0x469d82['defaultLimits']['strLength']||0x400*0x32,'totalStrLength':_0x469d82['defaultLimits'][_0x4934b8(0x191)]||0x400*0x32,'autoExpandLimit':_0x469d82['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x1cc)]['autoExpandMaxDepth']||0xa},_0x1f746a={'props':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xfd)]||0x5,'elements':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xd2)]||0x5,'strLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x110)]||0x100,'totalStrLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x191)]||0x100*0x3,'autoExpandLimit':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x1a7)]||0x1e,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x189)]||0x2};if(_0x2514c8){let _0x31c1e0=_0x4277ae['serialize'][_0x4934b8(0xf1)](_0x4277ae);_0x4277ae[_0x4934b8(0x158)]=function(_0x1957c4,_0xc0aeb7,_0x4ead78,_0x3625d6){return _0x31c1e0(_0x1957c4,_0x2514c8(_0xc0aeb7),_0x4ead78,_0x3625d6);};}function _0x1e6d74(_0x5afffa,_0x4a459c,_0x275938,_0x334fd3,_0x45c8dc,_0x17015d){var _0x490e67=_0x4934b8;let _0x97a821,_0x4538cb;try{_0x4538cb=_0x223738(),_0x97a821=_0x1f3bee[_0x4a459c],!_0x97a821||_0x4538cb-_0x97a821['ts']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0xe6)]&&_0x97a821[_0x490e67(0x180)]&&_0x97a821['time']/_0x97a821[_0x490e67(0x180)]<_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1b0)]?(_0x1f3bee[_0x4a459c]=_0x97a821={'count':0x0,'time':0x0,'ts':_0x4538cb},_0x1f3bee[_0x490e67(0x1cd)]={}):_0x4538cb-_0x1f3bee[_0x490e67(0x1cd)]['ts']>_0x141946[_0x490e67(0x13f)][_0x490e67(0xe6)]&&_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]&&_0x1f3bee['hits']['time']/_0x1f3bee['hits']['count']<_0x141946[_0x490e67(0x13f)]['resetOnProcessingTimeAverageMs']&&(_0x1f3bee[_0x490e67(0x1cd)]={});let _0x7ce882=[],_0x3afea7=_0x97a821['reduceLimits']||_0x1f3bee['hits']['reduceLimits']?_0x1f746a:_0x578392,_0x204f3a=_0x4e76b9=>{var _0x2f14d5=_0x490e67;let _0x5cb8da={};return _0x5cb8da[_0x2f14d5(0xfd)]=_0x4e76b9['props'],_0x5cb8da['elements']=_0x4e76b9[_0x2f14d5(0xd2)],_0x5cb8da[_0x2f14d5(0x110)]=_0x4e76b9[_0x2f14d5(0x110)],_0x5cb8da[_0x2f14d5(0x191)]=_0x4e76b9['totalStrLength'],_0x5cb8da['autoExpandLimit']=_0x4e76b9[_0x2f14d5(0x1a7)],_0x5cb8da[_0x2f14d5(0x189)]=_0x4e76b9[_0x2f14d5(0x189)],_0x5cb8da['sortProps']=!0x1,_0x5cb8da[_0x2f14d5(0x1bf)]=!_0x5c577b,_0x5cb8da[_0x2f14d5(0x15f)]=0x1,_0x5cb8da[_0x2f14d5(0x115)]=0x0,_0x5cb8da['expId']='root_exp_id',_0x5cb8da[_0x2f14d5(0xc6)]=_0x2f14d5(0x10d),_0x5cb8da[_0x2f14d5(0x104)]=!0x0,_0x5cb8da[_0x2f14d5(0x1b4)]=[],_0x5cb8da[_0x2f14d5(0x186)]=0x0,_0x5cb8da['resolveGetters']=_0x469d82[_0x2f14d5(0xcb)],_0x5cb8da[_0x2f14d5(0xd4)]=0x0,_0x5cb8da[_0x2f14d5(0x128)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x5cb8da;};for(var _0x7432f7=0x0;_0x7432f7<_0x45c8dc['length'];_0x7432f7++)_0x7ce882[_0x490e67(0xff)](_0x4277ae[_0x490e67(0x158)]({'timeNode':_0x5afffa===_0x490e67(0x15e)||void 0x0},_0x45c8dc[_0x7432f7],_0x204f3a(_0x3afea7),{}));if(_0x5afffa===_0x490e67(0x17c)||_0x5afffa===_0x490e67(0x1bb)){let _0x5b3615=Error[_0x490e67(0x16f)];try{Error['stackTraceLimit']=0x1/0x0,_0x7ce882['push'](_0x4277ae[_0x490e67(0x158)]({'stackNode':!0x0},new Error()[_0x490e67(0x123)],_0x204f3a(_0x3afea7),{'strLength':0x1/0x0}));}finally{Error[_0x490e67(0x16f)]=_0x5b3615;}}return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':_0x7ce882,'id':_0x4a459c,'context':_0x17015d}]};}catch(_0x84cbeb){return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':[{'type':_0x490e67(0x16e),'error':_0x84cbeb&&_0x84cbeb[_0x490e67(0x188)]}],'id':_0x4a459c,'context':_0x17015d}]};}finally{try{if(_0x97a821&&_0x4538cb){let _0x432ee2=_0x223738();_0x97a821['count']++,_0x97a821['time']+=_0x42fb36(_0x4538cb,_0x432ee2),_0x97a821['ts']=_0x432ee2,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]++,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]+=_0x42fb36(_0x4538cb,_0x432ee2),_0x1f3bee[_0x490e67(0x1cd)]['ts']=_0x432ee2,(_0x97a821[_0x490e67(0x180)]>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x12d)]||_0x97a821['time']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1bc)])&&(_0x97a821[_0x490e67(0x171)]=!0x0),(_0x1f3bee['hits']['count']>_0x141946[_0x490e67(0x13f)][_0x490e67(0x12d)]||_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]>_0x141946[_0x490e67(0x13f)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x1f3bee[_0x490e67(0x1cd)]['reduceLimits']=!0x0);}}catch{}}}return _0x1e6d74;}function _0x2214(){var _0x14499a=['value','undefined','rootExpression','path','_treeNodePropertiesBeforeFullValue','origin','data','resolveGetters','_addProperty','expo','_blacklistedProperty','_getOwnPropertyDescriptor','timeStamp','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','elements','null','allStrLength','_regExpToString','react-native','Map','2eFQllr','ninjaSuppressConsole',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','coverage','_isArray','_connected','hrtime','toString','_setNodePermissions','bound\\x20Promise','reducePolicy','_reconnectTimeout','...','nan','resetWhenQuietMs','Number','_ninjaIgnoreNextError','_hasSymbolPropertyOnItsPath','current','Set','import(\\x27url\\x27)','bigint','sort','_cleanNode','_connectToHostNow','bind','catch','_hasSetOnItsPath','\\x20server','get','NEGATIVE_INFINITY','1.0.0','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','_addLoadNode','_consoleNinjaAllowedToStart','array','length','props','_p_name','push','performance','location','POSITIVE_INFINITY','date','autoExpand','10162370kgItlO','map','disabledTrace','10.0.2.2','_numberRegExp','env','symbol','resolve','root_exp','onmessage','test','strLength','port','concat','_WebSocket','then','level','log','_addObjectProperty','object','_isSet','getOwnPropertyDescriptor','Error','isExpressionToEvaluate','edge','charAt','match','parent','indexOf','valueOf','stack','warn','_connecting','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_setNodeId','node','next.js','versions','1668317DHAXqx','_property','reduceOnCount','_getOwnPropertySymbols','_undefined','positiveInfinity','_propertyName','_dateToString','_sendErrorMessage','gateway.docker.internal','remix','_treeNodePropertiesAfterFullValue','984054cwWOKG','reducedLimits','_capIfString','_keyStrRegExp','cappedProps','_attemptToReconnectShortly','_socket','reload','global','endsWith','args','RegExp','_extendedWarning','onerror','funcName','_isPrimitiveWrapperType','_disposeWebsocket','next.js','[object\\x20BigInt]','index','_maxConnectAttemptCount','[object\\x20Array]',\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",'getOwnPropertyNames','constructor','dockerizedApp','type','142700orZAYJ','includes','replace','51827','hasOwnProperty','boolean','serialize','_quotedRegExp','_setNodeExpressionPath','unref','join','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','time','depth','modules','_HTMLAllCollection','slice','method','nodeModules','_console_ninja','parse','415197WHEhXo','elapsed','process','eventReceivedCallback','getOwnPropertySymbols','_setNodeExpandableState','[object\\x20Map]','unknown','stackTraceLimit','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','reduceLimits','substr','isArray','_allowedToSend','stringify','console','disabledLog','_Symbol','_webSocketErrorDocsLink','_getOwnPropertyNames','getter','trace','send','_p_','[object\\x20Set]','count','','_allowedToConnectOnSend','hostname','negativeInfinity','set','autoExpandPropertyCount','_isNegativeZero','message','autoExpandMaxDepth','prototype','iterator','_addFunctionsNode','https://tinyurl.com/37x8b79t','angular','127.0.0.1','import(\\x27path\\x27)','totalStrLength','host','NEXT_RUNTIME','_ws','call','function','5lYlfxC','56GExRSR','Boolean','1563852BMXApG',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'_setNodeLabel','_isPrimitiveType','_isUndefined','Symbol','_processTreeNodeResult','_WebSocketClass','ExpoDevice','_isMap','default','_console_ninja_session','now','autoExpandLimit','android','string','11djOgAe','HTMLAllCollection','unshift','_type','capped','_sortProps','resetOnProcessingTimeAverageMs','_inBrowser','number','url','autoExpandPreviousObjects','WebSocket','toUpperCase','_hasMapOnItsPath','[object\\x20Date]','cappedElements','forEach','error','reduceOnAccumulatedProcessingTimeMs','toLowerCase','_connectAttemptCount','noFunctions','207488XhRovp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','split','name','logger\\x20websocket\\x20error','getWebSocketClass',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'_objectToString','String','_additionalMetadata','readyState','perLogpoint','defaultLimits','hits','expressionsToEvaluate','negativeZero'];_0x2214=function(){return _0x14499a;};return _0x2214();}function G(_0x3130d3){var _0x84a520=_0x54cc26;if(_0x3130d3&&typeof _0x3130d3==_0x84a520(0x118)&&_0x3130d3[_0x84a520(0x14f)])switch(_0x3130d3[_0x84a520(0x14f)][_0x84a520(0x1c3)]){case'Promise':return _0x3130d3[_0x84a520(0x156)](Symbol[_0x84a520(0x18b)])?Promise['resolve']():_0x3130d3;case _0x84a520(0xe1):return Promise[_0x84a520(0x10c)]();}return _0x3130d3;}function _0x4a90(_0xbf85a4,_0x245df9){var _0x2214cf=_0x2214();return _0x4a90=function(_0x4a90b3,_0x346472){_0x4a90b3=_0x4a90b3-0xc3;var _0x3eefbb=_0x2214cf[_0x4a90b3];return _0x3eefbb;},_0x4a90(_0xbf85a4,_0x245df9);}((_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x269295,_0x304d0c,_0x56b187,_0x5799d3,_0x19f830,_0x5a3a2e,_0x231e3c)=>{var _0x4818fc=_0x54cc26;if(_0x3cca3d[_0x4818fc(0x165)])return _0x3cca3d[_0x4818fc(0x165)];let _0x52e3da={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x3cca3d,_0x56b187,_0x38abea))return _0x3cca3d[_0x4818fc(0x165)]=_0x52e3da,_0x3cca3d['_console_ninja'];let _0x44b593=b(_0x3cca3d),_0x48380c=_0x44b593[_0x4818fc(0x168)],_0x1338d8=_0x44b593[_0x4818fc(0xd0)],_0x29d139=_0x44b593[_0x4818fc(0x1a6)],_0x1ed58e={'hits':{},'ts':{}},_0x19f55c=J(_0x3cca3d,_0x5799d3,_0x1ed58e,_0x269295,_0x231e3c,_0x38abea===_0x4818fc(0x129)?G:void 0x0),_0x59946f=(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0)=>{var _0x40d17e=_0x4818fc;let _0x218bcb=_0x3cca3d['_console_ninja'];try{return _0x3cca3d['_console_ninja']=_0x52e3da,_0x19f55c(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0);}finally{_0x3cca3d[_0x40d17e(0x165)]=_0x218bcb;}},_0x22921d=_0x423627=>{_0x1ed58e['ts'][_0x423627]=_0x1338d8();},_0x45102e=(_0x88203,_0x370b7a)=>{var _0x9ec8e9=_0x4818fc;let _0x3d041a=_0x1ed58e['ts'][_0x370b7a];if(delete _0x1ed58e['ts'][_0x370b7a],_0x3d041a){let _0x52a6eb=_0x48380c(_0x3d041a,_0x1338d8());_0x312a62(_0x59946f(_0x9ec8e9(0x15e),_0x88203,_0x29d139(),_0x9b859d,[_0x52a6eb],_0x370b7a));}},_0x2ee867=_0x41fceb=>{var _0x5bbca8=_0x4818fc,_0x5ba44d;return _0x38abea==='next.js'&&_0x3cca3d[_0x5bbca8(0xc9)]&&((_0x5ba44d=_0x41fceb==null?void 0x0:_0x41fceb[_0x5bbca8(0x141)])==null?void 0x0:_0x5ba44d[_0x5bbca8(0xfc)])&&(_0x41fceb['args'][0x0][_0x5bbca8(0xc9)]=_0x3cca3d[_0x5bbca8(0xc9)]),_0x41fceb;};_0x3cca3d[_0x4818fc(0x165)]={'consoleLog':(_0x1d0443,_0x2f73e4)=>{var _0x97f6bc=_0x4818fc;_0x3cca3d[_0x97f6bc(0x176)][_0x97f6bc(0x116)][_0x97f6bc(0x1c3)]!==_0x97f6bc(0x177)&&_0x312a62(_0x59946f(_0x97f6bc(0x116),_0x1d0443,_0x29d139(),_0x9b859d,_0x2f73e4));},'consoleTrace':(_0x4f29ba,_0x40e0fb)=>{var _0x5ea07f=_0x4818fc,_0xb083e5,_0x274db5;_0x3cca3d[_0x5ea07f(0x176)][_0x5ea07f(0x116)][_0x5ea07f(0x1c3)]!==_0x5ea07f(0x107)&&((_0x274db5=(_0xb083e5=_0x3cca3d['process'])==null?void 0x0:_0xb083e5[_0x5ea07f(0x12a)])!=null&&_0x274db5[_0x5ea07f(0x128)]&&(_0x3cca3d[_0x5ea07f(0xe8)]=!0x0),_0x312a62(_0x2ee867(_0x59946f(_0x5ea07f(0x17c),_0x4f29ba,_0x29d139(),_0x9b859d,_0x40e0fb))));},'consoleError':(_0x2bc0da,_0x1c2aec)=>{var _0x1781f6=_0x4818fc;_0x3cca3d[_0x1781f6(0xe8)]=!0x0,_0x312a62(_0x2ee867(_0x59946f(_0x1781f6(0x1bb),_0x2bc0da,_0x29d139(),_0x9b859d,_0x1c2aec)));},'consoleTime':_0x39580d=>{_0x22921d(_0x39580d);},'consoleTimeEnd':(_0x3bc815,_0x207b89)=>{_0x45102e(_0x207b89,_0x3bc815);},'autoLog':(_0x1feae7,_0x412215)=>{var _0x28d3ed=_0x4818fc;_0x312a62(_0x59946f(_0x28d3ed(0x116),_0x412215,_0x29d139(),_0x9b859d,[_0x1feae7]));},'autoLogMany':(_0x2ec4aa,_0x3ebbc7)=>{_0x312a62(_0x59946f('log',_0x2ec4aa,_0x29d139(),_0x9b859d,_0x3ebbc7));},'autoTrace':(_0x1181a3,_0x59d6b5)=>{_0x312a62(_0x2ee867(_0x59946f('trace',_0x59d6b5,_0x29d139(),_0x9b859d,[_0x1181a3])));},'autoTraceMany':(_0x5d59ec,_0x321085)=>{var _0x254ed6=_0x4818fc;_0x312a62(_0x2ee867(_0x59946f(_0x254ed6(0x17c),_0x5d59ec,_0x29d139(),_0x9b859d,_0x321085)));},'autoTime':(_0x221590,_0x1740ad,_0x144e01)=>{_0x22921d(_0x144e01);},'autoTimeEnd':(_0x37d7ca,_0x1b7b6f,_0x52089f)=>{_0x45102e(_0x1b7b6f,_0x52089f);},'coverage':_0x2fe387=>{var _0xeb334b=_0x4818fc;_0x312a62({'method':_0xeb334b(0xdb),'version':_0x269295,'args':[{'id':_0x2fe387}]});}};let _0x312a62=H(_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x19f830,_0x5a3a2e),_0x9b859d=_0x3cca3d[_0x4818fc(0x1a5)];return _0x3cca3d[_0x4818fc(0x165)];})(globalThis,_0x54cc26(0x18f),_0x54cc26(0x155),_0x54cc26(0x14d),_0x54cc26(0x148),_0x54cc26(0xf7),'1763946797424',_0x54cc26(0x1c6),_0x54cc26(0x181),'','1',_0x54cc26(0x19b));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/theme-editor/editor/typography/types.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Typography element type definition
__turbopack_context__.s([
    "DEFAULT_TYPOGRAPHY",
    ()=>DEFAULT_TYPOGRAPHY
]);
const DEFAULT_TYPOGRAPHY = {
    h1: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '2.5rem',
        fontWeight: '700',
        lineHeight: '1.2',
        letterSpacing: '-0.02em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    },
    h2: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '2rem',
        fontWeight: '600',
        lineHeight: '1.3',
        letterSpacing: '-0.01em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    },
    h3: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '1.5rem',
        fontWeight: '600',
        lineHeight: '1.4',
        letterSpacing: '0em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    },
    h4: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '1.25rem',
        fontWeight: '500',
        lineHeight: '1.4',
        letterSpacing: '0em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    },
    h5: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '1.03rem',
        fontWeight: '500',
        lineHeight: '1.5',
        letterSpacing: '0em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    },
    paragraph: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '1rem',
        fontWeight: '400',
        lineHeight: '1.6',
        letterSpacing: '0em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    },
    quote: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '1.125rem',
        fontWeight: '400',
        lineHeight: '1.7',
        letterSpacing: '0.01em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'italic'
    },
    emphasis: {
        fontFamily: 'Poppins, ui-sans-serif, system-ui, sans-serif',
        fontSize: '0.875rem',
        fontWeight: '500',
        lineHeight: '1.5',
        letterSpacing: '0.02em',
        wordSpacing: '0px',
        textDecoration: 'none',
        fontStyle: 'normal'
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeEditorProvider",
    ()=>ThemeEditorProvider,
    "useThemeEditor",
    ()=>useThemeEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/constants/default-themes.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/lib/utils/css/css-variables.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$typography$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/theme-editor/editor/typography/types.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/trpc.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
// Helper function to compute current theme with mode-specific colors
function computeCurrentTheme(baseTheme, mode) {
    const colors = mode === 'dark' ? baseTheme.darkColors : baseTheme.lightColors;
    return {
        ...baseTheme,
        colors,
        lightColors: baseTheme.lightColors,
        darkColors: baseTheme.darkColors
    };
}
// Helper function to create initial history state
function createInitialHistoryState(theme, mode) {
    const initialEntry = {
        baseTheme: theme,
        themeMode: mode,
        timestamp: Date.now()
    };
    return {
        past: [],
        present: initialEntry,
        future: [],
        maxHistory: 30
    };
}
// Helper functions for history management
function addToHistory(history, newEntry) {
    const newPast = [
        ...history.past,
        history.present
    ];
    // Limit history to maxHistory entries
    if (newPast.length > history.maxHistory) {
        newPast.shift(); // Remove oldest entry
    }
    return {
        ...history,
        past: newPast,
        present: newEntry,
        future: [] // Clear future when new action is performed
    };
}
function canUndo(history) {
    return history.past.length > 0;
}
function canRedo(history) {
    return history.future.length > 0;
}
function performUndo(history) {
    if (!canUndo(history)) return null;
    const previous = history.past[history.past.length - 1];
    const newPast = history.past.slice(0, -1);
    const newFuture = [
        history.present,
        ...history.future
    ];
    return {
        history: {
            ...history,
            past: newPast,
            present: previous,
            future: newFuture
        },
        entry: previous
    };
}
function performRedo(history) {
    if (!canRedo(history)) return null;
    const next = history.future[0];
    const newFuture = history.future.slice(1);
    const newPast = [
        ...history.past,
        history.present
    ];
    return {
        history: {
            ...history,
            past: newPast,
            present: next,
            future: newFuture
        },
        entry: next
    };
}
// Helper function to get persisted active section (client-side only)
function getPersistedActiveSection() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const stored = localStorage.getItem('theme-editor-active-section');
        if (stored && [
            'colors',
            'typography',
            'brand',
            'borders',
            'spacing',
            'shadows',
            'scroll'
        ].includes(stored)) {
            return stored;
        }
    } catch (error) {
        console.warn('Failed to read active section from localStorage:', error);
    }
    return null;
}
// Helper function to persist active section
function persistActiveSection(section) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.setItem('theme-editor-active-section', section);
    } catch (error) {
        console.warn('Failed to save active section to localStorage:', error);
    }
}
/**
 * Get initial theme mode from localStorage (client-side only)
 * This prevents FOUC by ensuring React hydrates with the same mode as the blocking script
 */ function getInitialThemeMode() {
    // Only read from localStorage on the client
    if ("TURBOPACK compile-time truthy", 1) {
        try {
            const savedMode = localStorage.getItem('theme-mode');
            if (savedMode === 'dark' || savedMode === 'light' || savedMode === 'system') {
                return savedMode;
            }
        } catch (error) {
            console.warn('Failed to read theme-mode from localStorage:', error);
        }
    }
    // Default to 'light' for SSR or if localStorage is not available
    return 'light';
}
/**
 * Create initial state - reads theme mode from localStorage to prevent FOUC
 * This function is called during component initialization to ensure
 * the initial state matches the blocking script's applied mode
 */ function createInitialState() {
    const initialThemeMode = getInitialThemeMode();
    return {
        baseTheme: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_THEME"],
        currentTheme: computeCurrentTheme(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_THEME"], initialThemeMode),
        availableThemes: __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_THEMES"],
        themeMode: initialThemeMode,
        history: createInitialHistoryState(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_THEME"], initialThemeMode),
        editor: {
            activeSection: 'colors',
            isEditing: false,
            hasUnsavedChanges: false
        },
        viewport: {
            current: 'desktop',
            isResponsive: true
        },
        preview: {
            activeSection: 'colors',
            isFullscreen: false,
            showGrid: false,
            showRuler: false
        },
        isLoading: false,
        error: null
    };
}
// Reducer
function themeEditorReducer(state, action) {
    switch(action.type){
        case 'SET_THEME':
            const newCurrentTheme = computeCurrentTheme(action.payload, state.themeMode);
            return {
                ...state,
                baseTheme: action.payload,
                currentTheme: newCurrentTheme,
                editor: {
                    ...state.editor,
                    hasUnsavedChanges: false
                }
            };
        case 'SET_THEME_MODE':
            const updatedCurrentTheme = computeCurrentTheme(state.baseTheme, action.payload);
            return {
                ...state,
                themeMode: action.payload,
                currentTheme: updatedCurrentTheme
            };
        case 'UPDATE_CURRENT_COLORS':
            // Add current state to history BEFORE making changes
            const { mode, colors } = action.payload;
            const previousHistoryEntry = {
                baseTheme: state.baseTheme,
                themeMode: state.themeMode,
                timestamp: Date.now()
            };
            const updatedHistory = addToHistory(state.history, previousHistoryEntry);
            // Update colors for the current mode in the base theme
            const updatedBaseTheme = {
                ...state.baseTheme,
                [mode === 'dark' ? 'darkColors' : 'lightColors']: colors
            };
            // Recompute current theme if we're updating colors for the active mode
            const shouldUpdateCurrent = mode === state.themeMode;
            const newCurrentForColorUpdate = shouldUpdateCurrent ? {
                ...state.currentTheme,
                colors,
                [mode === 'dark' ? 'darkColors' : 'lightColors']: colors
            } : {
                ...state.currentTheme,
                [mode === 'dark' ? 'darkColors' : 'lightColors']: colors
            };
            return {
                ...state,
                baseTheme: updatedBaseTheme,
                currentTheme: newCurrentForColorUpdate,
                history: updatedHistory,
                editor: {
                    ...state.editor,
                    hasUnsavedChanges: true
                }
            };
        case 'SET_EDITOR_SECTION':
            // Persist the active section to localStorage
            persistActiveSection(action.payload);
            return {
                ...state,
                editor: {
                    ...state.editor,
                    activeSection: action.payload
                }
            };
        case 'SET_VIEWPORT':
            return {
                ...state,
                viewport: {
                    ...state.viewport,
                    current: action.payload
                }
            };
        case 'SET_PREVIEW_SECTION':
            return {
                ...state,
                preview: {
                    ...state.preview,
                    activeSection: action.payload
                }
            };
        case 'SET_LOADING':
            return {
                ...state,
                isLoading: action.payload
            };
        case 'SET_ERROR':
            return {
                ...state,
                error: action.payload,
                isLoading: false
            };
        case 'TOGGLE_UNSAVED_CHANGES':
            return {
                ...state,
                editor: {
                    ...state.editor,
                    hasUnsavedChanges: action.payload
                }
            };
        case 'ADD_THEME':
            return {
                ...state,
                availableThemes: [
                    ...state.availableThemes,
                    action.payload
                ],
                currentTheme: computeCurrentTheme(action.payload, state.themeMode),
                baseTheme: action.payload,
                editor: {
                    ...state.editor,
                    hasUnsavedChanges: false
                }
            };
        case 'UNDO':
            const undoResult = performUndo(state.history);
            if (!undoResult) return state;
            const undoCurrentTheme = computeCurrentTheme(undoResult.entry.baseTheme, undoResult.entry.themeMode);
            return {
                ...state,
                baseTheme: undoResult.entry.baseTheme,
                themeMode: undoResult.entry.themeMode,
                currentTheme: undoCurrentTheme,
                history: undoResult.history,
                editor: {
                    ...state.editor,
                    hasUnsavedChanges: true
                }
            };
        case 'REDO':
            const redoResult = performRedo(state.history);
            if (!redoResult) return state;
            const redoCurrentTheme = computeCurrentTheme(redoResult.entry.baseTheme, redoResult.entry.themeMode);
            return {
                ...state,
                baseTheme: redoResult.entry.baseTheme,
                themeMode: redoResult.entry.themeMode,
                currentTheme: redoCurrentTheme,
                history: redoResult.history,
                editor: {
                    ...state.editor,
                    hasUnsavedChanges: true
                }
            };
        default:
            return state;
    }
}
const ThemeEditorContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function ThemeEditorProvider({ children, companyId: propCompanyId, initialTheme, isEditorMode = false }) {
    _s();
    // Initialize state with localStorage theme mode to prevent FOUC
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(themeEditorReducer, undefined, createInitialState);
    // Load themes from database
    // Use prop if provided, otherwise fallback to hardcoded (TODO: Get from auth context)
    const companyId = propCompanyId || '6733c2fd80b7b58d4c36d966';
    // Always fetch from database to detect theme updates (favorite/default changes)
    const { data: dbThemes, refetch: refetchThemes } = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].theme.getCompanyThemes.useQuery({
        companyId,
        activeOnly: false
    }, {
        refetchOnMount: true,
        refetchOnWindowFocus: false,
        staleTime: 1000 * 60 * 5
    });
    // Load theme with priority: DB themes (isDefault/isFavorite) → Server initialTheme → Hardcoded
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeEditorProvider.useEffect": ()=>{
            let themeToLoad = null;
            // Priority 1 (HIGHEST): Database themes - check for isDefault or isFavorite
            if (dbThemes && dbThemes.length > 0) {
                // Find default theme (starred theme)
                themeToLoad = dbThemes.find({
                    "ThemeEditorProvider.useEffect": (t)=>t.isDefault
                }["ThemeEditorProvider.useEffect"]);
                // If no default, find favorite theme
                if (!themeToLoad) {
                    themeToLoad = dbThemes.find({
                        "ThemeEditorProvider.useEffect": (t)=>t.isFavorite
                    }["ThemeEditorProvider.useEffect"]);
                }
                // If no default or favorite, use the most recently updated theme
                if (!themeToLoad) {
                    themeToLoad = dbThemes[0]; // Already sorted by updatedAt desc from backend
                }
            } else if (initialTheme) {
                themeToLoad = initialTheme;
            } else {
                const initialColors = state.themeMode === 'dark' ? __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_THEME"].darkColors : __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$constants$2f$default$2d$themes$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_THEME"].lightColors;
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyModeSpecificColors"])(initialColors);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyThemeMode"])(state.themeMode);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollElements"])(state.baseTheme.scroll);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyTypographyElements"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$typography$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TYPOGRAPHY"]);
                return;
            }
            // Convert theme to ThemeData format (works for both DB themes and initialTheme)
            const loadedTheme = {
                id: themeToLoad.id,
                name: themeToLoad.name,
                description: themeToLoad.description || '',
                lightColors: themeToLoad.lightModeConfig,
                darkColors: themeToLoad.darkModeConfig,
                typography: themeToLoad.typography,
                brand: {},
                spacing: {},
                borders: {},
                shadows: {},
                scroll: {},
                isDefault: themeToLoad.isDefault,
                isFavorite: themeToLoad.isFavorite
            };
            // Apply the loaded theme
            dispatch({
                type: 'SET_THEME',
                payload: loadedTheme
            });
            const colors = state.themeMode === 'dark' ? loadedTheme.darkColors : loadedTheme.lightColors;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyModeSpecificColors"])(colors);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyThemeMode"])(state.themeMode);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollElements"])(loadedTheme.scroll || {});
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyTypographyElements"])(loadedTheme.typography || __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$theme$2d$editor$2f$editor$2f$typography$2f$types$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TYPOGRAPHY"]);
        }
    }["ThemeEditorProvider.useEffect"], [
        dbThemes,
        state.themeMode
    ]); // Removed initialTheme from deps - only load it once on mount
    // Hydrate persisted active section after initial render to prevent hydration mismatch
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeEditorProvider.useEffect": ()=>{
            const persistedSection = getPersistedActiveSection();
            if (persistedSection && persistedSection !== state.editor.activeSection) {
                dispatch({
                    type: 'SET_EDITOR_SECTION',
                    payload: persistedSection
                });
            }
        }
    }["ThemeEditorProvider.useEffect"], []);
    // Apply colors and mode when theme mode changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeEditorProvider.useEffect": ()=>{
            const currentColors = state.themeMode === 'dark' ? state.baseTheme.darkColors : state.baseTheme.lightColors;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyModeSpecificColors"])(currentColors);
            // IMPORTANT: Apply scrollbar colors specifically to ensure they work
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollbarColors"])(currentColors);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyThemeMode"])(state.themeMode);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollElements"])(state.baseTheme.scroll);
        }
    }["ThemeEditorProvider.useEffect"], [
        state.themeMode,
        state.baseTheme
    ]);
    // Apply borders when they change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeEditorProvider.useEffect": ()=>{
            if (state.baseTheme.borders) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyBorderElements"])(state.baseTheme.borders);
            }
        }
    }["ThemeEditorProvider.useEffect"], [
        state.baseTheme.borders
    ]);
    // Apply scroll settings when they change - SOLUTION 1
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeEditorProvider.useEffect": ()=>{
            if (state.baseTheme.scroll) {
                const currentColors = state.themeMode === 'dark' ? state.baseTheme.darkColors : state.baseTheme.lightColors;
                // Use SOLUTION 1: Utility Classes + CSS Variables
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollbarUtilityClass"])(state.baseTheme.scroll, {
                    scrollbarTrack: currentColors.scrollbarTrack,
                    scrollbarThumb: currentColors.scrollbarThumb
                });
            }
        }
    }["ThemeEditorProvider.useEffect"], [
        state.baseTheme.scroll,
        state.themeMode
    ]);
    // Apply CSS changes when undo/redo affects the base theme (for immediate visual feedback)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ThemeEditorProvider.useEffect": ()=>{
            const currentColors = state.themeMode === 'dark' ? state.baseTheme.darkColors : state.baseTheme.lightColors;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyModeSpecificColors"])(currentColors);
            // IMPORTANT: Apply scrollbar colors specifically to ensure they work
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollbarColors"])(currentColors);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollElements"])(state.baseTheme.scroll);
        }
    }["ThemeEditorProvider.useEffect"], [
        state.baseTheme.lightColors,
        state.baseTheme.darkColors,
        state.themeMode
    ]);
    // Helper actions
    const setTheme = (theme)=>{
        dispatch({
            type: 'SET_THEME',
            payload: theme
        });
    };
    const setThemeMode = (mode)=>{
        dispatch({
            type: 'SET_THEME_MODE',
            payload: mode
        });
    };
    const updateCurrentModeColors = (colors)=>{
        dispatch({
            type: 'UPDATE_CURRENT_COLORS',
            payload: {
                mode: state.themeMode,
                colors
            }
        });
        // Apply colors immediately for live preview
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyModeSpecificColors"])(colors);
        // SOLUTION 1: Apply scrollbar styling with new colors
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$lib$2f$utils$2f$css$2f$css$2d$variables$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["applyScrollbarUtilityClass"])(state.baseTheme.scroll, {
            scrollbarTrack: colors.scrollbarTrack,
            scrollbarThumb: colors.scrollbarThumb
        });
    };
    const setEditorSection = (section)=>dispatch({
            type: 'SET_EDITOR_SECTION',
            payload: section
        });
    const setViewport = (viewport)=>dispatch({
            type: 'SET_VIEWPORT',
            payload: viewport
        });
    const setPreviewSection = (section)=>dispatch({
            type: 'SET_PREVIEW_SECTION',
            payload: section
        });
    const setLoading = (loading)=>dispatch({
            type: 'SET_LOADING',
            payload: loading
        });
    const setError = (error)=>dispatch({
            type: 'SET_ERROR',
            payload: error
        });
    const markUnsaved = ()=>dispatch({
            type: 'TOGGLE_UNSAVED_CHANGES',
            payload: true
        });
    const markSaved = ()=>dispatch({
            type: 'TOGGLE_UNSAVED_CHANGES',
            payload: false
        });
    const updateTheme = (theme)=>{
        dispatch({
            type: 'SET_THEME',
            payload: theme
        });
        markUnsaved();
    };
    const addTheme = (theme)=>{
        dispatch({
            type: 'ADD_THEME',
            payload: theme
        });
    };
    // History functions
    const undo = ()=>{
        dispatch({
            type: 'UNDO'
        });
    };
    const redo = ()=>{
        dispatch({
            type: 'REDO'
        });
    };
    // History state computed from current state
    const canUndoValue = canUndo(state.history);
    const canRedoValue = canRedo(state.history);
    const undoCount = state.history.past.length;
    const redoCount = state.history.future.length;
    const value = {
        state,
        dispatch,
        setTheme,
        updateTheme,
        setThemeMode,
        updateCurrentModeColors,
        setEditorSection,
        setViewport,
        setPreviewSection,
        setLoading,
        setError,
        markUnsaved,
        markSaved,
        addTheme,
        undo,
        redo,
        canUndo: canUndoValue,
        canRedo: canRedoValue,
        undoCount,
        redoCount
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ThemeEditorContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx",
        lineNumber: 618,
        columnNumber: 5
    }, this);
}
_s(ThemeEditorProvider, "RSmGuko7r+8sOqKO/7iNtenIc4Q=");
_c = ThemeEditorProvider;
function useThemeEditor() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ThemeEditorContext);
    if (context === undefined) {
        throw new Error('useThemeEditor must be used within a ThemeEditorProvider');
    }
    return context;
}
_s1(useThemeEditor, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';var _0x54cc26=_0x4a90;(function(_0xfc324,_0x488d96){var _0x65efb7=_0x4a90,_0x533ce3=_0xfc324();while(!![]){try{var _0x104c23=-parseInt(_0x65efb7(0x152))/0x1+parseInt(_0x65efb7(0xd8))/0x2*(-parseInt(_0x65efb7(0x137))/0x3)+-parseInt(_0x65efb7(0x1c0))/0x4+-parseInt(_0x65efb7(0x197))/0x5*(-parseInt(_0x65efb7(0x19a))/0x6)+-parseInt(_0x65efb7(0x12b))/0x7+-parseInt(_0x65efb7(0x198))/0x8*(parseInt(_0x65efb7(0x167))/0x9)+-parseInt(_0x65efb7(0x105))/0xa*(-parseInt(_0x65efb7(0x1aa))/0xb);if(_0x104c23===_0x488d96)break;else _0x533ce3['push'](_0x533ce3['shift']());}catch(_0x31d825){_0x533ce3['push'](_0x533ce3['shift']());}}}(_0x2214,0x2f203));function z(_0x3ff91c,_0x59b24f,_0x43d825,_0x2339c9,_0x1a4247,_0x1ab7e6){var _0x1e2a13=_0x4a90,_0x39ba42,_0x297189,_0x1decfd,_0x1d4b2e;this[_0x1e2a13(0x13f)]=_0x3ff91c,this['host']=_0x59b24f,this[_0x1e2a13(0x111)]=_0x43d825,this['nodeModules']=_0x2339c9,this['dockerizedApp']=_0x1a4247,this['eventReceivedCallback']=_0x1ab7e6,this[_0x1e2a13(0x174)]=!0x0,this[_0x1e2a13(0x182)]=!0x0,this[_0x1e2a13(0xdd)]=!0x1,this['_connecting']=!0x1,this['_inNextEdge']=((_0x297189=(_0x39ba42=_0x3ff91c[_0x1e2a13(0x169)])==null?void 0x0:_0x39ba42[_0x1e2a13(0x10a)])==null?void 0x0:_0x297189[_0x1e2a13(0x193)])===_0x1e2a13(0x11d),this[_0x1e2a13(0x1b1)]=!((_0x1d4b2e=(_0x1decfd=this[_0x1e2a13(0x13f)][_0x1e2a13(0x169)])==null?void 0x0:_0x1decfd[_0x1e2a13(0x12a)])!=null&&_0x1d4b2e['node'])&&!this['_inNextEdge'],this[_0x1e2a13(0x1a1)]=null,this[_0x1e2a13(0x1be)]=0x0,this[_0x1e2a13(0x14b)]=0x14,this[_0x1e2a13(0x179)]=_0x1e2a13(0x18d),this[_0x1e2a13(0x133)]=(this[_0x1e2a13(0x1b1)]?_0x1e2a13(0x15d):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this['_webSocketErrorDocsLink'];}z[_0x54cc26(0x18a)][_0x54cc26(0x1c5)]=async function(){var _0x2c61ab=_0x54cc26,_0x3e4a2e,_0x25368c;if(this['_WebSocketClass'])return this['_WebSocketClass'];let _0x4cbaf9;if(this[_0x2c61ab(0x1b1)]||this['_inNextEdge'])_0x4cbaf9=this[_0x2c61ab(0x13f)][_0x2c61ab(0x1b5)];else{if((_0x3e4a2e=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])!=null&&_0x3e4a2e[_0x2c61ab(0x113)])_0x4cbaf9=(_0x25368c=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])==null?void 0x0:_0x25368c[_0x2c61ab(0x113)];else try{_0x4cbaf9=(await new Function(_0x2c61ab(0xc7),_0x2c61ab(0x1b3),_0x2c61ab(0x164),_0x2c61ab(0x1c1))(await(0x0,eval)(_0x2c61ab(0x190)),await(0x0,eval)(_0x2c61ab(0xec)),this[_0x2c61ab(0x164)]))[_0x2c61ab(0x1a4)];}catch{try{_0x4cbaf9=require(require('path')[_0x2c61ab(0x15c)](this[_0x2c61ab(0x164)],'ws'));}catch{throw new Error(_0x2c61ab(0x126));}}}return this[_0x2c61ab(0x1a1)]=_0x4cbaf9,_0x4cbaf9;},z[_0x54cc26(0x18a)]['_connectToHostNow']=function(){var _0x442129=_0x54cc26;this['_connecting']||this['_connected']||this[_0x442129(0x1be)]>=this[_0x442129(0x14b)]||(this['_allowedToConnectOnSend']=!0x1,this[_0x442129(0x125)]=!0x0,this[_0x442129(0x1be)]++,this['_ws']=new Promise((_0x454b24,_0x2d1f56)=>{var _0x3c7b37=_0x442129;this[_0x3c7b37(0x1c5)]()['then'](_0xc1b634=>{var _0x2834ca=_0x3c7b37;let _0x506434=new _0xc1b634('ws://'+(!this[_0x2834ca(0x1b1)]&&this[_0x2834ca(0x150)]?_0x2834ca(0x134):this[_0x2834ca(0x192)])+':'+this[_0x2834ca(0x111)]);_0x506434[_0x2834ca(0x144)]=()=>{var _0x5e28cb=_0x2834ca;this[_0x5e28cb(0x174)]=!0x1,this[_0x5e28cb(0x147)](_0x506434),this[_0x5e28cb(0x13c)](),_0x2d1f56(new Error(_0x5e28cb(0x1c4)));},_0x506434['onopen']=()=>{var _0x49bdba=_0x2834ca;this[_0x49bdba(0x1b1)]||_0x506434[_0x49bdba(0x13d)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)](),_0x454b24(_0x506434);},_0x506434['onclose']=()=>{var _0x15ef95=_0x2834ca;this[_0x15ef95(0x182)]=!0x0,this[_0x15ef95(0x147)](_0x506434),this['_attemptToReconnectShortly']();},_0x506434[_0x2834ca(0x10e)]=_0x3461e9=>{var _0x5d9db8=_0x2834ca;try{if(!(_0x3461e9!=null&&_0x3461e9[_0x5d9db8(0xca)])||!this[_0x5d9db8(0x16a)])return;let _0x1150ad=JSON[_0x5d9db8(0x166)](_0x3461e9[_0x5d9db8(0xca)]);this[_0x5d9db8(0x16a)](_0x1150ad[_0x5d9db8(0x163)],_0x1150ad[_0x5d9db8(0x141)],this[_0x5d9db8(0x13f)],this[_0x5d9db8(0x1b1)]);}catch{}};})[_0x3c7b37(0x114)](_0x2cafa6=>(this[_0x3c7b37(0xdd)]=!0x0,this[_0x3c7b37(0x125)]=!0x1,this[_0x3c7b37(0x182)]=!0x1,this[_0x3c7b37(0x174)]=!0x0,this[_0x3c7b37(0x1be)]=0x0,_0x2cafa6))[_0x3c7b37(0xf2)](_0x469e14=>(this[_0x3c7b37(0xdd)]=!0x1,this[_0x3c7b37(0x125)]=!0x1,console[_0x3c7b37(0x124)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x3c7b37(0x179)]),_0x2d1f56(new Error(_0x3c7b37(0xd1)+(_0x469e14&&_0x469e14[_0x3c7b37(0x188)])))));}));},z['prototype']['_disposeWebsocket']=function(_0x2849e3){var _0x2764c2=_0x54cc26;this[_0x2764c2(0xdd)]=!0x1,this[_0x2764c2(0x125)]=!0x1;try{_0x2849e3['onclose']=null,_0x2849e3[_0x2764c2(0x144)]=null,_0x2849e3['onopen']=null;}catch{}try{_0x2849e3[_0x2764c2(0x1ca)]<0x2&&_0x2849e3['close']();}catch{}},z[_0x54cc26(0x18a)]['_attemptToReconnectShortly']=function(){var _0x4b9fe0=_0x54cc26;clearTimeout(this[_0x4b9fe0(0xe3)]),!(this[_0x4b9fe0(0x1be)]>=this['_maxConnectAttemptCount'])&&(this[_0x4b9fe0(0xe3)]=setTimeout(()=>{var _0x3f71bc=_0x4b9fe0,_0x4f1396;this[_0x3f71bc(0xdd)]||this[_0x3f71bc(0x125)]||(this[_0x3f71bc(0xf0)](),(_0x4f1396=this[_0x3f71bc(0x194)])==null||_0x4f1396[_0x3f71bc(0xf2)](()=>this[_0x3f71bc(0x13c)]()));},0x1f4),this[_0x4b9fe0(0xe3)]['unref']&&this[_0x4b9fe0(0xe3)]['unref']());},z['prototype']['send']=async function(_0x1d08e5){var _0x4d9680=_0x54cc26;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this[_0x4d9680(0xf0)](),(await this[_0x4d9680(0x194)])[_0x4d9680(0x17d)](JSON['stringify'](_0x1d08e5));}catch(_0x15826e){this[_0x4d9680(0x143)]?console[_0x4d9680(0x124)](this['_sendErrorMessage']+':\\x20'+(_0x15826e&&_0x15826e['message'])):(this[_0x4d9680(0x143)]=!0x0,console[_0x4d9680(0x124)](this[_0x4d9680(0x133)]+':\\x20'+(_0x15826e&&_0x15826e[_0x4d9680(0x188)]),_0x1d08e5)),this[_0x4d9680(0x174)]=!0x1,this['_attemptToReconnectShortly']();}};function H(_0xaac806,_0x5ed5cc,_0x320235,_0x41fb4a,_0xb1b23a,_0x1d990d,_0x384cd6,_0x1ac656=ne){var _0x31e34b=_0x54cc26;let _0x134f7c=_0x320235[_0x31e34b(0x1c2)](',')[_0x31e34b(0x106)](_0x22f303=>{var _0x5a2d5a=_0x31e34b,_0x2a5e8e,_0x3fa0bd,_0xad4aad,_0x354175,_0x5817d6,_0x416e53,_0x1c19a5;try{if(!_0xaac806[_0x5a2d5a(0x1a5)]){let _0x3e5b68=((_0x3fa0bd=(_0x2a5e8e=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0x2a5e8e['versions'])==null?void 0x0:_0x3fa0bd[_0x5a2d5a(0x128)])||((_0x354175=(_0xad4aad=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0xad4aad[_0x5a2d5a(0x10a)])==null?void 0x0:_0x354175['NEXT_RUNTIME'])==='edge';(_0xb1b23a===_0x5a2d5a(0x129)||_0xb1b23a===_0x5a2d5a(0x135)||_0xb1b23a==='astro'||_0xb1b23a===_0x5a2d5a(0x18e))&&(_0xb1b23a+=_0x3e5b68?_0x5a2d5a(0xf4):'\\x20browser');let _0x3dcbaf='';_0xb1b23a==='react-native'&&(_0x3dcbaf=(((_0x1c19a5=(_0x416e53=(_0x5817d6=_0xaac806['expo'])==null?void 0x0:_0x5817d6['modules'])==null?void 0x0:_0x416e53[_0x5a2d5a(0x1a2)])==null?void 0x0:_0x1c19a5['osName'])||'')['toLowerCase'](),_0x3dcbaf&&(_0xb1b23a+='\\x20'+_0x3dcbaf,_0x3dcbaf===_0x5a2d5a(0x1a8)&&(_0x5ed5cc=_0x5a2d5a(0x108)))),_0xaac806[_0x5a2d5a(0x1a5)]={'id':+new Date(),'tool':_0xb1b23a},_0x384cd6&&_0xb1b23a&&!_0x3e5b68&&(_0x3dcbaf?console[_0x5a2d5a(0x116)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x3dcbaf+_0x5a2d5a(0xda)):console[_0x5a2d5a(0x116)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0xb1b23a[_0x5a2d5a(0x11e)](0x0)[_0x5a2d5a(0x1b6)]()+_0xb1b23a[_0x5a2d5a(0x172)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)',_0x5a2d5a(0x170)));}let _0x31b88=new z(_0xaac806,_0x5ed5cc,_0x22f303,_0x41fb4a,_0x1d990d,_0x1ac656);return _0x31b88['send']['bind'](_0x31b88);}catch(_0x1dd37f){return console['warn'](_0x5a2d5a(0xf8),_0x1dd37f&&_0x1dd37f['message']),()=>{};}});return _0x1bab8d=>_0x134f7c['forEach'](_0xf9f6fe=>_0xf9f6fe(_0x1bab8d));}function ne(_0x215577,_0x1d2815,_0x27483d,_0x2f114f){var _0xdebb60=_0x54cc26;_0x2f114f&&_0x215577===_0xdebb60(0x13e)&&_0x27483d[_0xdebb60(0x101)][_0xdebb60(0x13e)]();}function b(_0x4bf85c){var _0x402023=_0x54cc26,_0x39f3be,_0x1b82fe;let _0xcdf938=function(_0x5b8299,_0x5b1c4e){return _0x5b1c4e-_0x5b8299;},_0xa22518;if(_0x4bf85c[_0x402023(0x100)])_0xa22518=function(){var _0x1b3c2a=_0x402023;return _0x4bf85c[_0x1b3c2a(0x100)][_0x1b3c2a(0x1a6)]();};else{if(_0x4bf85c[_0x402023(0x169)]&&_0x4bf85c[_0x402023(0x169)][_0x402023(0xde)]&&((_0x1b82fe=(_0x39f3be=_0x4bf85c[_0x402023(0x169)])==null?void 0x0:_0x39f3be[_0x402023(0x10a)])==null?void 0x0:_0x1b82fe['NEXT_RUNTIME'])!==_0x402023(0x11d))_0xa22518=function(){var _0xdb951a=_0x402023;return _0x4bf85c[_0xdb951a(0x169)][_0xdb951a(0xde)]();},_0xcdf938=function(_0xbcdac7,_0x1f8e63){return 0x3e8*(_0x1f8e63[0x0]-_0xbcdac7[0x0])+(_0x1f8e63[0x1]-_0xbcdac7[0x1])/0xf4240;};else try{let {performance:_0x4cdf5e}=require('perf_hooks');_0xa22518=function(){var _0x194844=_0x402023;return _0x4cdf5e[_0x194844(0x1a6)]();};}catch{_0xa22518=function(){return+new Date();};}}return{'elapsed':_0xcdf938,'timeStamp':_0xa22518,'now':()=>Date[_0x402023(0x1a6)]()};}function X(_0x59955b,_0x3967e7,_0x2cce88){var _0x4215b2=_0x54cc26,_0x244b03,_0x3c8740,_0x47936d,_0x52231b,_0x3b5f0a,_0x4a40d4,_0x5240c0,_0x4c6114,_0xd96b4;if(_0x59955b[_0x4215b2(0xfa)]!==void 0x0)return _0x59955b[_0x4215b2(0xfa)];let _0xf3157d=((_0x3c8740=(_0x244b03=_0x59955b['process'])==null?void 0x0:_0x244b03[_0x4215b2(0x12a)])==null?void 0x0:_0x3c8740['node'])||((_0x52231b=(_0x47936d=_0x59955b[_0x4215b2(0x169)])==null?void 0x0:_0x47936d['env'])==null?void 0x0:_0x52231b[_0x4215b2(0x193)])===_0x4215b2(0x11d),_0x3b4db8=!!(_0x2cce88===_0x4215b2(0xd6)&&((_0x5240c0=(_0x4a40d4=(_0x3b5f0a=_0x59955b[_0x4215b2(0xcd)])==null?void 0x0:_0x3b5f0a[_0x4215b2(0x160)])==null?void 0x0:_0x4a40d4[_0x4215b2(0x1a2)])==null?void 0x0:_0x5240c0['osName']));function _0x2b6750(_0x48746a){var _0x18b065=_0x4215b2;if(_0x48746a['startsWith']('/')&&_0x48746a[_0x18b065(0x140)]('/')){let _0x45480e=new RegExp(_0x48746a[_0x18b065(0x162)](0x1,-0x1));return _0x496074=>_0x45480e['test'](_0x496074);}else{if(_0x48746a['includes']('*')||_0x48746a[_0x18b065(0x153)]('?')){let _0x3c8416=new RegExp('^'+_0x48746a[_0x18b065(0x154)](/\\./g,String['fromCharCode'](0x5c)+'.')[_0x18b065(0x154)](/\\*/g,'.*')[_0x18b065(0x154)](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x472a9d=>_0x3c8416[_0x18b065(0x10f)](_0x472a9d);}else return _0x2615bb=>_0x2615bb===_0x48746a;}}let _0x1eca1e=_0x3967e7[_0x4215b2(0x106)](_0x2b6750);return _0x59955b['_consoleNinjaAllowedToStart']=_0xf3157d||!_0x3967e7,!_0x59955b[_0x4215b2(0xfa)]&&((_0x4c6114=_0x59955b[_0x4215b2(0x101)])==null?void 0x0:_0x4c6114[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=_0x1eca1e['some'](_0x3ccb07=>_0x3ccb07(_0x59955b['location'][_0x4215b2(0x183)]))),_0x3b4db8&&!_0x59955b[_0x4215b2(0xfa)]&&!((_0xd96b4=_0x59955b[_0x4215b2(0x101)])!=null&&_0xd96b4[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=!0x0),_0x59955b['_consoleNinjaAllowedToStart'];}function J(_0x31f20b,_0x5c577b,_0x1f3bee,_0x4a0483,_0x469d82,_0x2514c8){var _0x4934b8=_0x54cc26;_0x31f20b=_0x31f20b,_0x5c577b=_0x5c577b,_0x1f3bee=_0x1f3bee,_0x4a0483=_0x4a0483,_0x469d82=_0x469d82,_0x469d82=_0x469d82||{},_0x469d82[_0x4934b8(0x1cc)]=_0x469d82[_0x4934b8(0x1cc)]||{},_0x469d82['reducedLimits']=_0x469d82[_0x4934b8(0x138)]||{},_0x469d82[_0x4934b8(0xe2)]=_0x469d82[_0x4934b8(0xe2)]||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)]=_0x469d82[_0x4934b8(0xe2)]['perLogpoint']||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]=_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]||{};let _0x141946={'perLogpoint':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0x12d)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint']['reduceOnAccumulatedProcessingTimeMs']||0x64,'resetWhenQuietMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0xe6)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint'][_0x4934b8(0x1b0)]||0x64},'global':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)]['global'][_0x4934b8(0x12d)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['reduceOnAccumulatedProcessingTimeMs']||0x12c,'resetWhenQuietMs':_0x469d82['reducePolicy'][_0x4934b8(0x13f)][_0x4934b8(0xe6)]||0x32,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['resetOnProcessingTimeAverageMs']||0x64}},_0x42f773=b(_0x31f20b),_0x42fb36=_0x42f773[_0x4934b8(0x168)],_0x223738=_0x42f773[_0x4934b8(0xd0)];function _0x568c0c(){var _0x1fa2cb=_0x4934b8;this[_0x1fa2cb(0x13a)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x1fa2cb(0x109)]=/^(0|[1-9][0-9]*)$/,this[_0x1fa2cb(0x159)]=/'([^\\\\']|\\\\')*'/,this[_0x1fa2cb(0x12f)]=_0x31f20b[_0x1fa2cb(0xc5)],this[_0x1fa2cb(0x161)]=_0x31f20b[_0x1fa2cb(0x1ab)],this[_0x1fa2cb(0xcf)]=Object[_0x1fa2cb(0x11a)],this[_0x1fa2cb(0x17a)]=Object[_0x1fa2cb(0x14e)],this[_0x1fa2cb(0x178)]=_0x31f20b[_0x1fa2cb(0x19f)],this[_0x1fa2cb(0xd5)]=RegExp[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)],this[_0x1fa2cb(0x132)]=Date[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)];}_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x158)]=function(_0x48d78e,_0x348dcf,_0x4a6d96,_0x5a5f89){var _0x19e5e6=_0x4934b8,_0xc6b12f=this,_0x55a7d2=_0x4a6d96['autoExpand'];function _0x42e97b(_0x3952f9,_0x2bc656,_0x8c85ef){var _0x2f1a2f=_0x4a90;_0x2bc656[_0x2f1a2f(0x151)]=_0x2f1a2f(0x16e),_0x2bc656[_0x2f1a2f(0x1bb)]=_0x3952f9[_0x2f1a2f(0x188)],_0x2b7b1a=_0x8c85ef[_0x2f1a2f(0x128)][_0x2f1a2f(0xea)],_0x8c85ef['node'][_0x2f1a2f(0xea)]=_0x2bc656,_0xc6b12f[_0x2f1a2f(0xc8)](_0x2bc656,_0x8c85ef);}let _0xcd7ba5,_0x5307f1,_0x34239a=_0x31f20b[_0x19e5e6(0xd9)];_0x31f20b[_0x19e5e6(0xd9)]=!0x0,_0x31f20b['console']&&(_0xcd7ba5=_0x31f20b[_0x19e5e6(0x176)]['error'],_0x5307f1=_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)],_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=function(){}),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)]=function(){}));try{try{_0x4a6d96[_0x19e5e6(0x115)]++,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96['autoExpandPreviousObjects'][_0x19e5e6(0xff)](_0x348dcf);var _0x6adee3,_0xa868ce,_0x4c1789,_0x127a28,_0x1bef2c=[],_0x4dd8f0=[],_0x47c5d8,_0x18b1eb=this[_0x19e5e6(0x1ad)](_0x348dcf),_0x481e55=_0x18b1eb==='array',_0x57133b=!0x1,_0x5ca399=_0x18b1eb===_0x19e5e6(0x196),_0xbd7d8f=this['_isPrimitiveType'](_0x18b1eb),_0x417ea6=this[_0x19e5e6(0x146)](_0x18b1eb),_0x273a7e=_0xbd7d8f||_0x417ea6,_0x2a289a={},_0xcd0938=0x0,_0x14ebf7=!0x1,_0x2b7b1a,_0x30046f=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x4a6d96[_0x19e5e6(0x15f)]){if(_0x481e55){if(_0xa868ce=_0x348dcf['length'],_0xa868ce>_0x4a6d96['elements']){for(_0x4c1789=0x0,_0x127a28=_0x4a6d96['elements'],_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0xcc)](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));_0x48d78e[_0x19e5e6(0x1b9)]=!0x0;}else{for(_0x4c1789=0x0,_0x127a28=_0xa868ce,_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f['_addProperty'](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));}_0x4a6d96[_0x19e5e6(0x186)]+=_0x4dd8f0[_0x19e5e6(0xfc)];}if(!(_0x18b1eb==='null'||_0x18b1eb===_0x19e5e6(0xc5))&&!_0xbd7d8f&&_0x18b1eb!==_0x19e5e6(0x1c8)&&_0x18b1eb!=='Buffer'&&_0x18b1eb!==_0x19e5e6(0xed)){var _0x482677=_0x5a5f89['props']||_0x4a6d96[_0x19e5e6(0xfd)];if(this[_0x19e5e6(0x119)](_0x348dcf)?(_0x6adee3=0x0,_0x348dcf[_0x19e5e6(0x1ba)](function(_0x316011){var _0x3d6007=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0x3d6007(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0x3d6007(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x3d6007(0x186)]>_0x4a6d96[_0x3d6007(0x1a7)]){_0x14ebf7=!0x0;return;}_0x4dd8f0[_0x3d6007(0xff)](_0xc6b12f[_0x3d6007(0xcc)](_0x1bef2c,_0x348dcf,_0x3d6007(0xeb),_0x6adee3++,_0x4a6d96,function(_0x2dd991){return function(){return _0x2dd991;};}(_0x316011)));})):this[_0x19e5e6(0x1a3)](_0x348dcf)&&_0x348dcf[_0x19e5e6(0x1ba)](function(_0x4e9669,_0x2865be){var _0xe99383=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0xe99383(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0xe99383(0x11c)]&&_0x4a6d96[_0xe99383(0x104)]&&_0x4a6d96[_0xe99383(0x186)]>_0x4a6d96[_0xe99383(0x1a7)]){_0x14ebf7=!0x0;return;}var _0x4c2eff=_0x2865be[_0xe99383(0xdf)]();_0x4c2eff[_0xe99383(0xfc)]>0x64&&(_0x4c2eff=_0x4c2eff[_0xe99383(0x162)](0x0,0x64)+_0xe99383(0xe4)),_0x4dd8f0[_0xe99383(0xff)](_0xc6b12f[_0xe99383(0xcc)](_0x1bef2c,_0x348dcf,_0xe99383(0xd7),_0x4c2eff,_0x4a6d96,function(_0x38d848){return function(){return _0x38d848;};}(_0x4e9669)));}),!_0x57133b){try{for(_0x47c5d8 in _0x348dcf)if(!(_0x481e55&&_0x30046f[_0x19e5e6(0x10f)](_0x47c5d8))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0['push'](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}catch{}if(_0x2a289a['_p_length']=!0x0,_0x5ca399&&(_0x2a289a[_0x19e5e6(0xfe)]=!0x0),!_0x14ebf7){var _0x507ca6=[][_0x19e5e6(0x112)](this['_getOwnPropertyNames'](_0x348dcf))[_0x19e5e6(0x112)](this['_getOwnPropertySymbols'](_0x348dcf));for(_0x6adee3=0x0,_0xa868ce=_0x507ca6['length'];_0x6adee3<_0xa868ce;_0x6adee3++)if(_0x47c5d8=_0x507ca6[_0x6adee3],!(_0x481e55&&_0x30046f['test'](_0x47c5d8[_0x19e5e6(0xdf)]()))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)&&!_0x2a289a[typeof _0x47c5d8!=_0x19e5e6(0x10b)?_0x19e5e6(0x17e)+_0x47c5d8[_0x19e5e6(0xdf)]():_0x47c5d8]){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}}}}if(_0x48d78e['type']=_0x18b1eb,_0x273a7e?(_0x48d78e['value']=_0x348dcf[_0x19e5e6(0x122)](),this[_0x19e5e6(0x139)](_0x18b1eb,_0x48d78e,_0x4a6d96,_0x5a5f89)):_0x18b1eb===_0x19e5e6(0x103)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x132)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0xed)?_0x48d78e[_0x19e5e6(0xc4)]=_0x348dcf[_0x19e5e6(0xdf)]():_0x18b1eb===_0x19e5e6(0x142)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0xd5)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0x10b)&&this[_0x19e5e6(0x178)]?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x178)][_0x19e5e6(0x18a)]['toString'][_0x19e5e6(0x195)](_0x348dcf):!_0x4a6d96[_0x19e5e6(0x15f)]&&!(_0x18b1eb===_0x19e5e6(0xd3)||_0x18b1eb==='undefined')&&(delete _0x48d78e[_0x19e5e6(0xc4)],_0x48d78e[_0x19e5e6(0x1ae)]=!0x0),_0x14ebf7&&(_0x48d78e[_0x19e5e6(0x13b)]=!0x0),_0x2b7b1a=_0x4a6d96[_0x19e5e6(0x128)][_0x19e5e6(0xea)],_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x48d78e,this[_0x19e5e6(0xc8)](_0x48d78e,_0x4a6d96),_0x4dd8f0['length']){for(_0x6adee3=0x0,_0xa868ce=_0x4dd8f0[_0x19e5e6(0xfc)];_0x6adee3<_0xa868ce;_0x6adee3++)_0x4dd8f0[_0x6adee3](_0x6adee3);}_0x1bef2c[_0x19e5e6(0xfc)]&&(_0x48d78e[_0x19e5e6(0xfd)]=_0x1bef2c);}catch(_0x3ae5b6){_0x42e97b(_0x3ae5b6,_0x48d78e,_0x4a6d96);}this[_0x19e5e6(0x1c9)](_0x348dcf,_0x48d78e),this[_0x19e5e6(0x136)](_0x48d78e,_0x4a6d96),_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x2b7b1a,_0x4a6d96[_0x19e5e6(0x115)]--,_0x4a6d96[_0x19e5e6(0x104)]=_0x55a7d2,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x1b4)]['pop']();}finally{_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=_0xcd7ba5),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)]['warn']=_0x5307f1),_0x31f20b[_0x19e5e6(0xd9)]=_0x34239a;}return _0x48d78e;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12e)]=function(_0x46f99b){var _0x55ee4f=_0x4934b8;return Object['getOwnPropertySymbols']?Object[_0x55ee4f(0x16b)](_0x46f99b):[];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x119)]=function(_0x259646){var _0x583570=_0x4934b8;return!!(_0x259646&&_0x31f20b[_0x583570(0xeb)]&&this['_objectToString'](_0x259646)===_0x583570(0x17f)&&_0x259646[_0x583570(0x1ba)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xce)]=function(_0x469950,_0x43a4d0,_0x3e7028){var _0x44d134=_0x4934b8;if(!_0x3e7028[_0x44d134(0xcb)]){let _0x5e446a=this[_0x44d134(0xcf)](_0x469950,_0x43a4d0);if(_0x5e446a&&_0x5e446a[_0x44d134(0xf5)])return!0x0;}return _0x3e7028[_0x44d134(0x1bf)]?typeof _0x469950[_0x43a4d0]==_0x44d134(0x196):!0x1;},_0x568c0c[_0x4934b8(0x18a)]['_type']=function(_0x21f464){var _0x5b73d0=_0x4934b8,_0x1012e4='';return _0x1012e4=typeof _0x21f464,_0x1012e4===_0x5b73d0(0x118)?this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x14c)?_0x1012e4=_0x5b73d0(0xfb):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x1b8)?_0x1012e4=_0x5b73d0(0x103):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x149)?_0x1012e4=_0x5b73d0(0xed):_0x21f464===null?_0x1012e4='null':_0x21f464[_0x5b73d0(0x14f)]&&(_0x1012e4=_0x21f464['constructor'][_0x5b73d0(0x1c3)]||_0x1012e4):_0x1012e4===_0x5b73d0(0xc5)&&this[_0x5b73d0(0x161)]&&_0x21f464 instanceof this['_HTMLAllCollection']&&(_0x1012e4='HTMLAllCollection'),_0x1012e4;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1c7)]=function(_0x23706a){var _0xb5b3ca=_0x4934b8;return Object[_0xb5b3ca(0x18a)][_0xb5b3ca(0xdf)]['call'](_0x23706a);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19d)]=function(_0x94e0c5){var _0x4b2537=_0x4934b8;return _0x94e0c5===_0x4b2537(0x157)||_0x94e0c5==='string'||_0x94e0c5===_0x4b2537(0x1b2);},_0x568c0c['prototype']['_isPrimitiveWrapperType']=function(_0x2f3e62){var _0x16ad9e=_0x4934b8;return _0x2f3e62===_0x16ad9e(0x199)||_0x2f3e62==='String'||_0x2f3e62===_0x16ad9e(0xe7);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xcc)]=function(_0x1db57d,_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7){var _0x2fcbd8=this;return function(_0x2a2b77){var _0xce493a=_0x4a90,_0x174862=_0x3015c5['node'][_0xce493a(0xea)],_0x4a97c=_0x3015c5[_0xce493a(0x128)]['index'],_0x2b4936=_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)];_0x3015c5['node'][_0xce493a(0x120)]=_0x174862,_0x3015c5['node'][_0xce493a(0x14a)]=typeof _0x19ed12==_0xce493a(0x1b2)?_0x19ed12:_0x2a2b77,_0x1db57d[_0xce493a(0xff)](_0x2fcbd8[_0xce493a(0x12c)](_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7)),_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)]=_0x2b4936,_0x3015c5['node']['index']=_0x4a97c;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x117)]=function(_0x4469e5,_0x3fa37e,_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f){var _0x516d33=_0x4934b8,_0x396018=this;return _0x3fa37e[typeof _0x2f3742!=_0x516d33(0x10b)?_0x516d33(0x17e)+_0x2f3742['toString']():_0x2f3742]=!0x0,function(_0xd7fcb0){var _0x3226db=_0x516d33,_0x39117a=_0x36532d[_0x3226db(0x128)][_0x3226db(0xea)],_0x50a11a=_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)],_0x4eb0c0=_0x36532d['node'][_0x3226db(0x120)];_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x39117a,_0x36532d['node'][_0x3226db(0x14a)]=_0xd7fcb0,_0x4469e5[_0x3226db(0xff)](_0x396018[_0x3226db(0x12c)](_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f)),_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x4eb0c0,_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)]=_0x50a11a;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12c)]=function(_0x453099,_0x4eadbd,_0x11f35a,_0x40815b,_0xa2b7cb){var _0x4b84a8=_0x4934b8,_0x5e86b1=this;_0xa2b7cb||(_0xa2b7cb=function(_0x5cea02,_0x58268c){return _0x5cea02[_0x58268c];});var _0x362525=_0x11f35a['toString'](),_0x3c06dc=_0x40815b[_0x4b84a8(0x1ce)]||{},_0x142239=_0x40815b['depth'],_0x26bf80=_0x40815b[_0x4b84a8(0x11c)];try{var _0x3aca2e=this[_0x4b84a8(0x1a3)](_0x453099),_0x4aabb3=_0x362525;_0x3aca2e&&_0x4aabb3[0x0]==='\\x27'&&(_0x4aabb3=_0x4aabb3[_0x4b84a8(0x172)](0x1,_0x4aabb3[_0x4b84a8(0xfc)]-0x2));var _0x12d722=_0x40815b['expressionsToEvaluate']=_0x3c06dc[_0x4b84a8(0x17e)+_0x4aabb3];_0x12d722&&(_0x40815b['depth']=_0x40815b['depth']+0x1),_0x40815b[_0x4b84a8(0x11c)]=!!_0x12d722;var _0x56e733=typeof _0x11f35a=='symbol',_0xa051ca={'name':_0x56e733||_0x3aca2e?_0x362525:this[_0x4b84a8(0x131)](_0x362525)};if(_0x56e733&&(_0xa051ca[_0x4b84a8(0x10b)]=!0x0),!(_0x4eadbd===_0x4b84a8(0xfb)||_0x4eadbd===_0x4b84a8(0x11b))){var _0x5b5697=this[_0x4b84a8(0xcf)](_0x453099,_0x11f35a);if(_0x5b5697&&(_0x5b5697[_0x4b84a8(0x185)]&&(_0xa051ca['setter']=!0x0),_0x5b5697[_0x4b84a8(0xf5)]&&!_0x12d722&&!_0x40815b[_0x4b84a8(0xcb)]))return _0xa051ca[_0x4b84a8(0x17b)]=!0x0,this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x51fae3;try{_0x51fae3=_0xa2b7cb(_0x453099,_0x11f35a);}catch(_0x4f78cc){return _0xa051ca={'name':_0x362525,'type':_0x4b84a8(0x16e),'error':_0x4f78cc[_0x4b84a8(0x188)]},this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x310e5a=this['_type'](_0x51fae3),_0x3e58ae=this[_0x4b84a8(0x19d)](_0x310e5a);if(_0xa051ca['type']=_0x310e5a,_0x3e58ae)this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x2623ba=_0x4b84a8;_0xa051ca[_0x2623ba(0xc4)]=_0x51fae3['valueOf'](),!_0x12d722&&_0x5e86b1[_0x2623ba(0x139)](_0x310e5a,_0xa051ca,_0x40815b,{});});else{var _0x87c7d8=_0x40815b[_0x4b84a8(0x104)]&&_0x40815b[_0x4b84a8(0x115)]<_0x40815b[_0x4b84a8(0x189)]&&_0x40815b[_0x4b84a8(0x1b4)][_0x4b84a8(0x121)](_0x51fae3)<0x0&&_0x310e5a!==_0x4b84a8(0x196)&&_0x40815b['autoExpandPropertyCount']<_0x40815b[_0x4b84a8(0x1a7)];_0x87c7d8||_0x40815b[_0x4b84a8(0x115)]<_0x142239||_0x12d722?this['serialize'](_0xa051ca,_0x51fae3,_0x40815b,_0x12d722||{}):this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x48a268=_0x4b84a8;_0x310e5a===_0x48a268(0xd3)||_0x310e5a===_0x48a268(0xc5)||(delete _0xa051ca[_0x48a268(0xc4)],_0xa051ca['capped']=!0x0);});}return _0xa051ca;}finally{_0x40815b[_0x4b84a8(0x1ce)]=_0x3c06dc,_0x40815b[_0x4b84a8(0x15f)]=_0x142239,_0x40815b[_0x4b84a8(0x11c)]=_0x26bf80;}},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x139)]=function(_0x5e0732,_0x1bfe86,_0xda28d7,_0x491a14){var _0x60e05=_0x4934b8,_0x33f831=_0x491a14[_0x60e05(0x110)]||_0xda28d7[_0x60e05(0x110)];if((_0x5e0732===_0x60e05(0x1a9)||_0x5e0732==='String')&&_0x1bfe86['value']){let _0x1eacb7=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0xfc)];_0xda28d7['allStrLength']+=_0x1eacb7,_0xda28d7[_0x60e05(0xd4)]>_0xda28d7[_0x60e05(0x191)]?(_0x1bfe86['capped']='',delete _0x1bfe86[_0x60e05(0xc4)]):_0x1eacb7>_0x33f831&&(_0x1bfe86[_0x60e05(0x1ae)]=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0x172)](0x0,_0x33f831),delete _0x1bfe86[_0x60e05(0xc4)]);}},_0x568c0c['prototype']['_isMap']=function(_0x251695){var _0x2d4790=_0x4934b8;return!!(_0x251695&&_0x31f20b[_0x2d4790(0xd7)]&&this[_0x2d4790(0x1c7)](_0x251695)===_0x2d4790(0x16d)&&_0x251695['forEach']);},_0x568c0c[_0x4934b8(0x18a)]['_propertyName']=function(_0x2e0688){var _0x2c8644=_0x4934b8;if(_0x2e0688[_0x2c8644(0x11f)](/^\\d+$/))return _0x2e0688;var _0x91094;try{_0x91094=JSON[_0x2c8644(0x175)](''+_0x2e0688);}catch{_0x91094='\\x22'+this['_objectToString'](_0x2e0688)+'\\x22';}return _0x91094[_0x2c8644(0x11f)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x91094=_0x91094['substr'](0x1,_0x91094[_0x2c8644(0xfc)]-0x2):_0x91094=_0x91094[_0x2c8644(0x154)](/'/g,'\\x5c\\x27')[_0x2c8644(0x154)](/\\\\\"/g,'\\x22')[_0x2c8644(0x154)](/(^\"|\"$)/g,'\\x27'),_0x91094;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1a0)]=function(_0x232cbb,_0x29085f,_0x1650af,_0x1c890e){var _0x16a2a5=_0x4934b8;this[_0x16a2a5(0xc8)](_0x232cbb,_0x29085f),_0x1c890e&&_0x1c890e(),this[_0x16a2a5(0x1c9)](_0x1650af,_0x232cbb),this[_0x16a2a5(0x136)](_0x232cbb,_0x29085f);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xc8)]=function(_0x49291a,_0x33bdc6){var _0x52d41e=_0x4934b8;this[_0x52d41e(0x127)](_0x49291a,_0x33bdc6),this['_setNodeQueryPath'](_0x49291a,_0x33bdc6),this[_0x52d41e(0x15a)](_0x49291a,_0x33bdc6),this[_0x52d41e(0xe0)](_0x49291a,_0x33bdc6);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x127)]=function(_0x3ffba9,_0x308291){},_0x568c0c[_0x4934b8(0x18a)]['_setNodeQueryPath']=function(_0x4befcf,_0x340320){},_0x568c0c['prototype'][_0x4934b8(0x19c)]=function(_0x6d004b,_0x3e0efe){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19e)]=function(_0x3b2948){var _0x1c5336=_0x4934b8;return _0x3b2948===this[_0x1c5336(0x12f)];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x136)]=function(_0x571a40,_0x11152b){var _0x17c82d=_0x4934b8;this[_0x17c82d(0x19c)](_0x571a40,_0x11152b),this[_0x17c82d(0x16c)](_0x571a40),_0x11152b['sortProps']&&this[_0x17c82d(0x1af)](_0x571a40),this['_addFunctionsNode'](_0x571a40,_0x11152b),this['_addLoadNode'](_0x571a40,_0x11152b),this['_cleanNode'](_0x571a40);},_0x568c0c[_0x4934b8(0x18a)]['_additionalMetadata']=function(_0x25d425,_0x376ba0){var _0x4c6175=_0x4934b8;try{_0x25d425&&typeof _0x25d425[_0x4c6175(0xfc)]==_0x4c6175(0x1b2)&&(_0x376ba0[_0x4c6175(0xfc)]=_0x25d425[_0x4c6175(0xfc)]);}catch{}if(_0x376ba0[_0x4c6175(0x151)]===_0x4c6175(0x1b2)||_0x376ba0['type']===_0x4c6175(0xe7)){if(isNaN(_0x376ba0['value']))_0x376ba0[_0x4c6175(0xe5)]=!0x0,delete _0x376ba0[_0x4c6175(0xc4)];else switch(_0x376ba0[_0x4c6175(0xc4)]){case Number[_0x4c6175(0x102)]:_0x376ba0[_0x4c6175(0x130)]=!0x0,delete _0x376ba0['value'];break;case Number[_0x4c6175(0xf6)]:_0x376ba0[_0x4c6175(0x184)]=!0x0,delete _0x376ba0['value'];break;case 0x0:this['_isNegativeZero'](_0x376ba0['value'])&&(_0x376ba0[_0x4c6175(0xc3)]=!0x0);break;}}else _0x376ba0['type']==='function'&&typeof _0x25d425[_0x4c6175(0x1c3)]=='string'&&_0x25d425['name']&&_0x376ba0[_0x4c6175(0x1c3)]&&_0x25d425[_0x4c6175(0x1c3)]!==_0x376ba0[_0x4c6175(0x1c3)]&&(_0x376ba0[_0x4c6175(0x145)]=_0x25d425[_0x4c6175(0x1c3)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x187)]=function(_0x3d5c0c){var _0x21909c=_0x4934b8;return 0x1/_0x3d5c0c===Number[_0x21909c(0xf6)];},_0x568c0c['prototype'][_0x4934b8(0x1af)]=function(_0xaf6d85){var _0x257f6e=_0x4934b8;!_0xaf6d85[_0x257f6e(0xfd)]||!_0xaf6d85['props'][_0x257f6e(0xfc)]||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xfb)||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xd7)||_0xaf6d85[_0x257f6e(0x151)]==='Set'||_0xaf6d85[_0x257f6e(0xfd)][_0x257f6e(0xee)](function(_0xcc5a49,_0x33a07){var _0x3d0ac0=_0x257f6e,_0x216c86=_0xcc5a49[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)](),_0x52e92d=_0x33a07[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)]();return _0x216c86<_0x52e92d?-0x1:_0x216c86>_0x52e92d?0x1:0x0;});},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x18c)]=function(_0x26dd9a,_0x367b0a){var _0x3fb806=_0x4934b8;if(!(_0x367b0a[_0x3fb806(0x1bf)]||!_0x26dd9a['props']||!_0x26dd9a[_0x3fb806(0xfd)]['length'])){for(var _0x558538=[],_0x1e34a7=[],_0x4cf6c3=0x0,_0x496b22=_0x26dd9a[_0x3fb806(0xfd)]['length'];_0x4cf6c3<_0x496b22;_0x4cf6c3++){var _0x286ad8=_0x26dd9a[_0x3fb806(0xfd)][_0x4cf6c3];_0x286ad8[_0x3fb806(0x151)]===_0x3fb806(0x196)?_0x558538[_0x3fb806(0xff)](_0x286ad8):_0x1e34a7[_0x3fb806(0xff)](_0x286ad8);}if(!(!_0x1e34a7[_0x3fb806(0xfc)]||_0x558538[_0x3fb806(0xfc)]<=0x1)){_0x26dd9a[_0x3fb806(0xfd)]=_0x1e34a7;var _0x589572={'functionsNode':!0x0,'props':_0x558538};this[_0x3fb806(0x127)](_0x589572,_0x367b0a),this[_0x3fb806(0x19c)](_0x589572,_0x367b0a),this['_setNodeExpandableState'](_0x589572),this[_0x3fb806(0xe0)](_0x589572,_0x367b0a),_0x589572['id']+='\\x20f',_0x26dd9a['props'][_0x3fb806(0x1ac)](_0x589572);}}},_0x568c0c['prototype'][_0x4934b8(0xf9)]=function(_0x3a8156,_0x31dbc6){},_0x568c0c['prototype']['_setNodeExpandableState']=function(_0x27a91c){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xdc)]=function(_0x309bc7){var _0x3eff3d=_0x4934b8;return Array[_0x3eff3d(0x173)](_0x309bc7)||typeof _0x309bc7=='object'&&this['_objectToString'](_0x309bc7)==='[object\\x20Array]';},_0x568c0c[_0x4934b8(0x18a)]['_setNodePermissions']=function(_0x33a0fd,_0x133d76){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xef)]=function(_0xd4834e){var _0x4c0797=_0x4934b8;delete _0xd4834e[_0x4c0797(0xe9)],delete _0xd4834e[_0x4c0797(0xf3)],delete _0xd4834e[_0x4c0797(0x1b7)];},_0x568c0c[_0x4934b8(0x18a)]['_setNodeExpressionPath']=function(_0x82227e,_0x5e328e){};let _0x4277ae=new _0x568c0c(),_0x578392={'props':_0x469d82[_0x4934b8(0x1cc)][_0x4934b8(0xfd)]||0x64,'elements':_0x469d82[_0x4934b8(0x1cc)]['elements']||0x64,'strLength':_0x469d82['defaultLimits']['strLength']||0x400*0x32,'totalStrLength':_0x469d82['defaultLimits'][_0x4934b8(0x191)]||0x400*0x32,'autoExpandLimit':_0x469d82['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x1cc)]['autoExpandMaxDepth']||0xa},_0x1f746a={'props':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xfd)]||0x5,'elements':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xd2)]||0x5,'strLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x110)]||0x100,'totalStrLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x191)]||0x100*0x3,'autoExpandLimit':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x1a7)]||0x1e,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x189)]||0x2};if(_0x2514c8){let _0x31c1e0=_0x4277ae['serialize'][_0x4934b8(0xf1)](_0x4277ae);_0x4277ae[_0x4934b8(0x158)]=function(_0x1957c4,_0xc0aeb7,_0x4ead78,_0x3625d6){return _0x31c1e0(_0x1957c4,_0x2514c8(_0xc0aeb7),_0x4ead78,_0x3625d6);};}function _0x1e6d74(_0x5afffa,_0x4a459c,_0x275938,_0x334fd3,_0x45c8dc,_0x17015d){var _0x490e67=_0x4934b8;let _0x97a821,_0x4538cb;try{_0x4538cb=_0x223738(),_0x97a821=_0x1f3bee[_0x4a459c],!_0x97a821||_0x4538cb-_0x97a821['ts']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0xe6)]&&_0x97a821[_0x490e67(0x180)]&&_0x97a821['time']/_0x97a821[_0x490e67(0x180)]<_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1b0)]?(_0x1f3bee[_0x4a459c]=_0x97a821={'count':0x0,'time':0x0,'ts':_0x4538cb},_0x1f3bee[_0x490e67(0x1cd)]={}):_0x4538cb-_0x1f3bee[_0x490e67(0x1cd)]['ts']>_0x141946[_0x490e67(0x13f)][_0x490e67(0xe6)]&&_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]&&_0x1f3bee['hits']['time']/_0x1f3bee['hits']['count']<_0x141946[_0x490e67(0x13f)]['resetOnProcessingTimeAverageMs']&&(_0x1f3bee[_0x490e67(0x1cd)]={});let _0x7ce882=[],_0x3afea7=_0x97a821['reduceLimits']||_0x1f3bee['hits']['reduceLimits']?_0x1f746a:_0x578392,_0x204f3a=_0x4e76b9=>{var _0x2f14d5=_0x490e67;let _0x5cb8da={};return _0x5cb8da[_0x2f14d5(0xfd)]=_0x4e76b9['props'],_0x5cb8da['elements']=_0x4e76b9[_0x2f14d5(0xd2)],_0x5cb8da[_0x2f14d5(0x110)]=_0x4e76b9[_0x2f14d5(0x110)],_0x5cb8da[_0x2f14d5(0x191)]=_0x4e76b9['totalStrLength'],_0x5cb8da['autoExpandLimit']=_0x4e76b9[_0x2f14d5(0x1a7)],_0x5cb8da[_0x2f14d5(0x189)]=_0x4e76b9[_0x2f14d5(0x189)],_0x5cb8da['sortProps']=!0x1,_0x5cb8da[_0x2f14d5(0x1bf)]=!_0x5c577b,_0x5cb8da[_0x2f14d5(0x15f)]=0x1,_0x5cb8da[_0x2f14d5(0x115)]=0x0,_0x5cb8da['expId']='root_exp_id',_0x5cb8da[_0x2f14d5(0xc6)]=_0x2f14d5(0x10d),_0x5cb8da[_0x2f14d5(0x104)]=!0x0,_0x5cb8da[_0x2f14d5(0x1b4)]=[],_0x5cb8da[_0x2f14d5(0x186)]=0x0,_0x5cb8da['resolveGetters']=_0x469d82[_0x2f14d5(0xcb)],_0x5cb8da[_0x2f14d5(0xd4)]=0x0,_0x5cb8da[_0x2f14d5(0x128)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x5cb8da;};for(var _0x7432f7=0x0;_0x7432f7<_0x45c8dc['length'];_0x7432f7++)_0x7ce882[_0x490e67(0xff)](_0x4277ae[_0x490e67(0x158)]({'timeNode':_0x5afffa===_0x490e67(0x15e)||void 0x0},_0x45c8dc[_0x7432f7],_0x204f3a(_0x3afea7),{}));if(_0x5afffa===_0x490e67(0x17c)||_0x5afffa===_0x490e67(0x1bb)){let _0x5b3615=Error[_0x490e67(0x16f)];try{Error['stackTraceLimit']=0x1/0x0,_0x7ce882['push'](_0x4277ae[_0x490e67(0x158)]({'stackNode':!0x0},new Error()[_0x490e67(0x123)],_0x204f3a(_0x3afea7),{'strLength':0x1/0x0}));}finally{Error[_0x490e67(0x16f)]=_0x5b3615;}}return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':_0x7ce882,'id':_0x4a459c,'context':_0x17015d}]};}catch(_0x84cbeb){return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':[{'type':_0x490e67(0x16e),'error':_0x84cbeb&&_0x84cbeb[_0x490e67(0x188)]}],'id':_0x4a459c,'context':_0x17015d}]};}finally{try{if(_0x97a821&&_0x4538cb){let _0x432ee2=_0x223738();_0x97a821['count']++,_0x97a821['time']+=_0x42fb36(_0x4538cb,_0x432ee2),_0x97a821['ts']=_0x432ee2,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]++,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]+=_0x42fb36(_0x4538cb,_0x432ee2),_0x1f3bee[_0x490e67(0x1cd)]['ts']=_0x432ee2,(_0x97a821[_0x490e67(0x180)]>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x12d)]||_0x97a821['time']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1bc)])&&(_0x97a821[_0x490e67(0x171)]=!0x0),(_0x1f3bee['hits']['count']>_0x141946[_0x490e67(0x13f)][_0x490e67(0x12d)]||_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]>_0x141946[_0x490e67(0x13f)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x1f3bee[_0x490e67(0x1cd)]['reduceLimits']=!0x0);}}catch{}}}return _0x1e6d74;}function _0x2214(){var _0x14499a=['value','undefined','rootExpression','path','_treeNodePropertiesBeforeFullValue','origin','data','resolveGetters','_addProperty','expo','_blacklistedProperty','_getOwnPropertyDescriptor','timeStamp','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','elements','null','allStrLength','_regExpToString','react-native','Map','2eFQllr','ninjaSuppressConsole',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','coverage','_isArray','_connected','hrtime','toString','_setNodePermissions','bound\\x20Promise','reducePolicy','_reconnectTimeout','...','nan','resetWhenQuietMs','Number','_ninjaIgnoreNextError','_hasSymbolPropertyOnItsPath','current','Set','import(\\x27url\\x27)','bigint','sort','_cleanNode','_connectToHostNow','bind','catch','_hasSetOnItsPath','\\x20server','get','NEGATIVE_INFINITY','1.0.0','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','_addLoadNode','_consoleNinjaAllowedToStart','array','length','props','_p_name','push','performance','location','POSITIVE_INFINITY','date','autoExpand','10162370kgItlO','map','disabledTrace','10.0.2.2','_numberRegExp','env','symbol','resolve','root_exp','onmessage','test','strLength','port','concat','_WebSocket','then','level','log','_addObjectProperty','object','_isSet','getOwnPropertyDescriptor','Error','isExpressionToEvaluate','edge','charAt','match','parent','indexOf','valueOf','stack','warn','_connecting','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_setNodeId','node','next.js','versions','1668317DHAXqx','_property','reduceOnCount','_getOwnPropertySymbols','_undefined','positiveInfinity','_propertyName','_dateToString','_sendErrorMessage','gateway.docker.internal','remix','_treeNodePropertiesAfterFullValue','984054cwWOKG','reducedLimits','_capIfString','_keyStrRegExp','cappedProps','_attemptToReconnectShortly','_socket','reload','global','endsWith','args','RegExp','_extendedWarning','onerror','funcName','_isPrimitiveWrapperType','_disposeWebsocket','next.js','[object\\x20BigInt]','index','_maxConnectAttemptCount','[object\\x20Array]',\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",'getOwnPropertyNames','constructor','dockerizedApp','type','142700orZAYJ','includes','replace','51827','hasOwnProperty','boolean','serialize','_quotedRegExp','_setNodeExpressionPath','unref','join','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','time','depth','modules','_HTMLAllCollection','slice','method','nodeModules','_console_ninja','parse','415197WHEhXo','elapsed','process','eventReceivedCallback','getOwnPropertySymbols','_setNodeExpandableState','[object\\x20Map]','unknown','stackTraceLimit','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','reduceLimits','substr','isArray','_allowedToSend','stringify','console','disabledLog','_Symbol','_webSocketErrorDocsLink','_getOwnPropertyNames','getter','trace','send','_p_','[object\\x20Set]','count','','_allowedToConnectOnSend','hostname','negativeInfinity','set','autoExpandPropertyCount','_isNegativeZero','message','autoExpandMaxDepth','prototype','iterator','_addFunctionsNode','https://tinyurl.com/37x8b79t','angular','127.0.0.1','import(\\x27path\\x27)','totalStrLength','host','NEXT_RUNTIME','_ws','call','function','5lYlfxC','56GExRSR','Boolean','1563852BMXApG',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'_setNodeLabel','_isPrimitiveType','_isUndefined','Symbol','_processTreeNodeResult','_WebSocketClass','ExpoDevice','_isMap','default','_console_ninja_session','now','autoExpandLimit','android','string','11djOgAe','HTMLAllCollection','unshift','_type','capped','_sortProps','resetOnProcessingTimeAverageMs','_inBrowser','number','url','autoExpandPreviousObjects','WebSocket','toUpperCase','_hasMapOnItsPath','[object\\x20Date]','cappedElements','forEach','error','reduceOnAccumulatedProcessingTimeMs','toLowerCase','_connectAttemptCount','noFunctions','207488XhRovp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','split','name','logger\\x20websocket\\x20error','getWebSocketClass',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'_objectToString','String','_additionalMetadata','readyState','perLogpoint','defaultLimits','hits','expressionsToEvaluate','negativeZero'];_0x2214=function(){return _0x14499a;};return _0x2214();}function G(_0x3130d3){var _0x84a520=_0x54cc26;if(_0x3130d3&&typeof _0x3130d3==_0x84a520(0x118)&&_0x3130d3[_0x84a520(0x14f)])switch(_0x3130d3[_0x84a520(0x14f)][_0x84a520(0x1c3)]){case'Promise':return _0x3130d3[_0x84a520(0x156)](Symbol[_0x84a520(0x18b)])?Promise['resolve']():_0x3130d3;case _0x84a520(0xe1):return Promise[_0x84a520(0x10c)]();}return _0x3130d3;}function _0x4a90(_0xbf85a4,_0x245df9){var _0x2214cf=_0x2214();return _0x4a90=function(_0x4a90b3,_0x346472){_0x4a90b3=_0x4a90b3-0xc3;var _0x3eefbb=_0x2214cf[_0x4a90b3];return _0x3eefbb;},_0x4a90(_0xbf85a4,_0x245df9);}((_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x269295,_0x304d0c,_0x56b187,_0x5799d3,_0x19f830,_0x5a3a2e,_0x231e3c)=>{var _0x4818fc=_0x54cc26;if(_0x3cca3d[_0x4818fc(0x165)])return _0x3cca3d[_0x4818fc(0x165)];let _0x52e3da={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x3cca3d,_0x56b187,_0x38abea))return _0x3cca3d[_0x4818fc(0x165)]=_0x52e3da,_0x3cca3d['_console_ninja'];let _0x44b593=b(_0x3cca3d),_0x48380c=_0x44b593[_0x4818fc(0x168)],_0x1338d8=_0x44b593[_0x4818fc(0xd0)],_0x29d139=_0x44b593[_0x4818fc(0x1a6)],_0x1ed58e={'hits':{},'ts':{}},_0x19f55c=J(_0x3cca3d,_0x5799d3,_0x1ed58e,_0x269295,_0x231e3c,_0x38abea===_0x4818fc(0x129)?G:void 0x0),_0x59946f=(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0)=>{var _0x40d17e=_0x4818fc;let _0x218bcb=_0x3cca3d['_console_ninja'];try{return _0x3cca3d['_console_ninja']=_0x52e3da,_0x19f55c(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0);}finally{_0x3cca3d[_0x40d17e(0x165)]=_0x218bcb;}},_0x22921d=_0x423627=>{_0x1ed58e['ts'][_0x423627]=_0x1338d8();},_0x45102e=(_0x88203,_0x370b7a)=>{var _0x9ec8e9=_0x4818fc;let _0x3d041a=_0x1ed58e['ts'][_0x370b7a];if(delete _0x1ed58e['ts'][_0x370b7a],_0x3d041a){let _0x52a6eb=_0x48380c(_0x3d041a,_0x1338d8());_0x312a62(_0x59946f(_0x9ec8e9(0x15e),_0x88203,_0x29d139(),_0x9b859d,[_0x52a6eb],_0x370b7a));}},_0x2ee867=_0x41fceb=>{var _0x5bbca8=_0x4818fc,_0x5ba44d;return _0x38abea==='next.js'&&_0x3cca3d[_0x5bbca8(0xc9)]&&((_0x5ba44d=_0x41fceb==null?void 0x0:_0x41fceb[_0x5bbca8(0x141)])==null?void 0x0:_0x5ba44d[_0x5bbca8(0xfc)])&&(_0x41fceb['args'][0x0][_0x5bbca8(0xc9)]=_0x3cca3d[_0x5bbca8(0xc9)]),_0x41fceb;};_0x3cca3d[_0x4818fc(0x165)]={'consoleLog':(_0x1d0443,_0x2f73e4)=>{var _0x97f6bc=_0x4818fc;_0x3cca3d[_0x97f6bc(0x176)][_0x97f6bc(0x116)][_0x97f6bc(0x1c3)]!==_0x97f6bc(0x177)&&_0x312a62(_0x59946f(_0x97f6bc(0x116),_0x1d0443,_0x29d139(),_0x9b859d,_0x2f73e4));},'consoleTrace':(_0x4f29ba,_0x40e0fb)=>{var _0x5ea07f=_0x4818fc,_0xb083e5,_0x274db5;_0x3cca3d[_0x5ea07f(0x176)][_0x5ea07f(0x116)][_0x5ea07f(0x1c3)]!==_0x5ea07f(0x107)&&((_0x274db5=(_0xb083e5=_0x3cca3d['process'])==null?void 0x0:_0xb083e5[_0x5ea07f(0x12a)])!=null&&_0x274db5[_0x5ea07f(0x128)]&&(_0x3cca3d[_0x5ea07f(0xe8)]=!0x0),_0x312a62(_0x2ee867(_0x59946f(_0x5ea07f(0x17c),_0x4f29ba,_0x29d139(),_0x9b859d,_0x40e0fb))));},'consoleError':(_0x2bc0da,_0x1c2aec)=>{var _0x1781f6=_0x4818fc;_0x3cca3d[_0x1781f6(0xe8)]=!0x0,_0x312a62(_0x2ee867(_0x59946f(_0x1781f6(0x1bb),_0x2bc0da,_0x29d139(),_0x9b859d,_0x1c2aec)));},'consoleTime':_0x39580d=>{_0x22921d(_0x39580d);},'consoleTimeEnd':(_0x3bc815,_0x207b89)=>{_0x45102e(_0x207b89,_0x3bc815);},'autoLog':(_0x1feae7,_0x412215)=>{var _0x28d3ed=_0x4818fc;_0x312a62(_0x59946f(_0x28d3ed(0x116),_0x412215,_0x29d139(),_0x9b859d,[_0x1feae7]));},'autoLogMany':(_0x2ec4aa,_0x3ebbc7)=>{_0x312a62(_0x59946f('log',_0x2ec4aa,_0x29d139(),_0x9b859d,_0x3ebbc7));},'autoTrace':(_0x1181a3,_0x59d6b5)=>{_0x312a62(_0x2ee867(_0x59946f('trace',_0x59d6b5,_0x29d139(),_0x9b859d,[_0x1181a3])));},'autoTraceMany':(_0x5d59ec,_0x321085)=>{var _0x254ed6=_0x4818fc;_0x312a62(_0x2ee867(_0x59946f(_0x254ed6(0x17c),_0x5d59ec,_0x29d139(),_0x9b859d,_0x321085)));},'autoTime':(_0x221590,_0x1740ad,_0x144e01)=>{_0x22921d(_0x144e01);},'autoTimeEnd':(_0x37d7ca,_0x1b7b6f,_0x52089f)=>{_0x45102e(_0x1b7b6f,_0x52089f);},'coverage':_0x2fe387=>{var _0xeb334b=_0x4818fc;_0x312a62({'method':_0xeb334b(0xdb),'version':_0x269295,'args':[{'id':_0x2fe387}]});}};let _0x312a62=H(_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x19f830,_0x5a3a2e),_0x9b859d=_0x3cca3d[_0x4818fc(0x1a5)];return _0x3cca3d[_0x4818fc(0x165)];})(globalThis,_0x54cc26(0x18f),_0x54cc26(0x155),_0x54cc26(0x14d),_0x54cc26(0x148),_0x54cc26(0xf7),'1763946797424',_0x54cc26(0x1c6),_0x54cc26(0x181),'','1',_0x54cc26(0x19b));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "ThemeEditorProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/context/GlobalThemeProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GlobalThemeProvider",
    ()=>GlobalThemeProvider,
    "useCompanyTheme",
    ()=>useCompanyTheme,
    "useGlobalTheme",
    ()=>useGlobalTheme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/core/context/ThemeEditorContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
function GlobalThemeProvider({ companyId, initialTheme, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeEditorProvider"], {
        companyId: companyId,
        initialTheme: initialTheme,
        isEditorMode: false,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/context/GlobalThemeProvider.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_c = GlobalThemeProvider;
function useGlobalTheme() {
    _s();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
}
_s(useGlobalTheme, "eMNfMH79wyKFUulPShQr3rNAfsM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
function useCompanyTheme() {
    _s1();
    const { state, setTheme, setThemeMode } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"])();
    return {
        theme: state.currentTheme,
        themeMode: state.themeMode,
        setTheme,
        setThemeMode,
        isLoading: state.isLoading,
        error: state.error
    };
}
_s1(useCompanyTheme, "Ielt/O0MI7+gathLLyVwx8Gjdr0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$core$2f$context$2f$ThemeEditorContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useThemeEditor"]
    ];
});
var _c;
__turbopack_context__.k.register(_c, "GlobalThemeProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ThemeErrorBoundary",
    ()=>ThemeErrorBoundary,
    "ThemeErrorBoundaryClass",
    ()=>ThemeErrorBoundaryClass
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$GlobalThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/context/GlobalThemeProvider.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
const ThemeErrorBoundary = ({ children, fallback })=>{
    _s();
    const { error, isLoading: loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$GlobalThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompanyTheme"])();
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center min-h-screen bg-background",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col items-center space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative w-16 h-16",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-0 left-0 w-full h-full rounded-full border-4 border-border animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute top-0 left-0 w-full h-full rounded-full border-4 border-primary border-t-transparent animate-spin"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                lineNumber: 21,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                        lineNumber: 19,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-muted-foreground animate-pulse",
                        children: "Loading theme..."
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                        lineNumber: 23,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                lineNumber: 18,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (error && !fallback) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center min-h-screen bg-background",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-md w-full mx-auto p-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-destructive/10 border border-destructive/20 rounded-lg p-6 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-12 mx-auto mb-4 text-destructive",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                viewBox: "0 0 24 24",
                                fill: "none",
                                stroke: "currentColor",
                                strokeWidth: "2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                                        cx: "12",
                                        cy: "12",
                                        r: "10"
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                        lineNumber: 36,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                        x1: "12",
                                        y1: "8",
                                        x2: "12",
                                        y2: "12"
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                        lineNumber: 37,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                        x1: "12",
                                        y1: "16",
                                        x2: "12.01",
                                        y2: "16"
                                    }, void 0, false, {
                                        fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                        lineNumber: 38,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                lineNumber: 35,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                            lineNumber: 34,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-lg font-semibold text-foreground mb-2",
                            children: "Theme Loading Error"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                            lineNumber: 41,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-muted-foreground mb-4",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                            lineNumber: 42,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>window.location.reload(),
                            className: "inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-primary-foreground bg-primary rounded-md hover:bg-primary/90 transition-colors",
                            children: "Retry"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                            lineNumber: 43,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                    lineNumber: 33,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (error && fallback) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: fallback
        }, void 0, false);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: children
    }, void 0, false);
};
_s(ThemeErrorBoundary, "stCt+0AJIPcMQzgDfs/ORrOafrQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$GlobalThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompanyTheme"]
    ];
});
_c = ThemeErrorBoundary;
class ThemeErrorBoundaryClass extends __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Component {
    constructor(props){
        super(props);
        this.state = {
            hasError: false,
            error: null
        };
    }
    static getDerivedStateFromError(error) {
        return {
            hasError: true,
            error
        };
    }
    componentDidCatch(error, errorInfo) {
        /* eslint-disable */ console.error(...oo_tx(`1321607888_82_4_82_73_11`, 'Theme Error Boundary caught error:', error, errorInfo));
    }
    render() {
        if (this.state.hasError) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center min-h-screen bg-gray-50",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-md w-full mx-auto p-6",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-red-50 border border-red-200 rounded-lg p-6 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold text-gray-900 mb-2",
                                children: "Something went wrong"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                lineNumber: 91,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-gray-600 mb-4",
                                children: this.state.error?.message || 'An unexpected error occurred'
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                lineNumber: 94,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    this.setState({
                                        hasError: false,
                                        error: null
                                    });
                                    window.location.reload();
                                },
                                className: "inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors",
                                children: "Reload Page"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                                lineNumber: 97,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                        lineNumber: 90,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                    lineNumber: 89,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx",
                lineNumber: 88,
                columnNumber: 9
            }, this);
        }
        return this.props.children;
    }
}
function oo_cm() {
    try {
        return (0, eval)("globalThis._console_ninja") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';var _0x54cc26=_0x4a90;(function(_0xfc324,_0x488d96){var _0x65efb7=_0x4a90,_0x533ce3=_0xfc324();while(!![]){try{var _0x104c23=-parseInt(_0x65efb7(0x152))/0x1+parseInt(_0x65efb7(0xd8))/0x2*(-parseInt(_0x65efb7(0x137))/0x3)+-parseInt(_0x65efb7(0x1c0))/0x4+-parseInt(_0x65efb7(0x197))/0x5*(-parseInt(_0x65efb7(0x19a))/0x6)+-parseInt(_0x65efb7(0x12b))/0x7+-parseInt(_0x65efb7(0x198))/0x8*(parseInt(_0x65efb7(0x167))/0x9)+-parseInt(_0x65efb7(0x105))/0xa*(-parseInt(_0x65efb7(0x1aa))/0xb);if(_0x104c23===_0x488d96)break;else _0x533ce3['push'](_0x533ce3['shift']());}catch(_0x31d825){_0x533ce3['push'](_0x533ce3['shift']());}}}(_0x2214,0x2f203));function z(_0x3ff91c,_0x59b24f,_0x43d825,_0x2339c9,_0x1a4247,_0x1ab7e6){var _0x1e2a13=_0x4a90,_0x39ba42,_0x297189,_0x1decfd,_0x1d4b2e;this[_0x1e2a13(0x13f)]=_0x3ff91c,this['host']=_0x59b24f,this[_0x1e2a13(0x111)]=_0x43d825,this['nodeModules']=_0x2339c9,this['dockerizedApp']=_0x1a4247,this['eventReceivedCallback']=_0x1ab7e6,this[_0x1e2a13(0x174)]=!0x0,this[_0x1e2a13(0x182)]=!0x0,this[_0x1e2a13(0xdd)]=!0x1,this['_connecting']=!0x1,this['_inNextEdge']=((_0x297189=(_0x39ba42=_0x3ff91c[_0x1e2a13(0x169)])==null?void 0x0:_0x39ba42[_0x1e2a13(0x10a)])==null?void 0x0:_0x297189[_0x1e2a13(0x193)])===_0x1e2a13(0x11d),this[_0x1e2a13(0x1b1)]=!((_0x1d4b2e=(_0x1decfd=this[_0x1e2a13(0x13f)][_0x1e2a13(0x169)])==null?void 0x0:_0x1decfd[_0x1e2a13(0x12a)])!=null&&_0x1d4b2e['node'])&&!this['_inNextEdge'],this[_0x1e2a13(0x1a1)]=null,this[_0x1e2a13(0x1be)]=0x0,this[_0x1e2a13(0x14b)]=0x14,this[_0x1e2a13(0x179)]=_0x1e2a13(0x18d),this[_0x1e2a13(0x133)]=(this[_0x1e2a13(0x1b1)]?_0x1e2a13(0x15d):'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this['_webSocketErrorDocsLink'];}z[_0x54cc26(0x18a)][_0x54cc26(0x1c5)]=async function(){var _0x2c61ab=_0x54cc26,_0x3e4a2e,_0x25368c;if(this['_WebSocketClass'])return this['_WebSocketClass'];let _0x4cbaf9;if(this[_0x2c61ab(0x1b1)]||this['_inNextEdge'])_0x4cbaf9=this[_0x2c61ab(0x13f)][_0x2c61ab(0x1b5)];else{if((_0x3e4a2e=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])!=null&&_0x3e4a2e[_0x2c61ab(0x113)])_0x4cbaf9=(_0x25368c=this[_0x2c61ab(0x13f)][_0x2c61ab(0x169)])==null?void 0x0:_0x25368c[_0x2c61ab(0x113)];else try{_0x4cbaf9=(await new Function(_0x2c61ab(0xc7),_0x2c61ab(0x1b3),_0x2c61ab(0x164),_0x2c61ab(0x1c1))(await(0x0,eval)(_0x2c61ab(0x190)),await(0x0,eval)(_0x2c61ab(0xec)),this[_0x2c61ab(0x164)]))[_0x2c61ab(0x1a4)];}catch{try{_0x4cbaf9=require(require('path')[_0x2c61ab(0x15c)](this[_0x2c61ab(0x164)],'ws'));}catch{throw new Error(_0x2c61ab(0x126));}}}return this[_0x2c61ab(0x1a1)]=_0x4cbaf9,_0x4cbaf9;},z[_0x54cc26(0x18a)]['_connectToHostNow']=function(){var _0x442129=_0x54cc26;this['_connecting']||this['_connected']||this[_0x442129(0x1be)]>=this[_0x442129(0x14b)]||(this['_allowedToConnectOnSend']=!0x1,this[_0x442129(0x125)]=!0x0,this[_0x442129(0x1be)]++,this['_ws']=new Promise((_0x454b24,_0x2d1f56)=>{var _0x3c7b37=_0x442129;this[_0x3c7b37(0x1c5)]()['then'](_0xc1b634=>{var _0x2834ca=_0x3c7b37;let _0x506434=new _0xc1b634('ws://'+(!this[_0x2834ca(0x1b1)]&&this[_0x2834ca(0x150)]?_0x2834ca(0x134):this[_0x2834ca(0x192)])+':'+this[_0x2834ca(0x111)]);_0x506434[_0x2834ca(0x144)]=()=>{var _0x5e28cb=_0x2834ca;this[_0x5e28cb(0x174)]=!0x1,this[_0x5e28cb(0x147)](_0x506434),this[_0x5e28cb(0x13c)](),_0x2d1f56(new Error(_0x5e28cb(0x1c4)));},_0x506434['onopen']=()=>{var _0x49bdba=_0x2834ca;this[_0x49bdba(0x1b1)]||_0x506434[_0x49bdba(0x13d)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)]&&_0x506434[_0x49bdba(0x13d)][_0x49bdba(0x15b)](),_0x454b24(_0x506434);},_0x506434['onclose']=()=>{var _0x15ef95=_0x2834ca;this[_0x15ef95(0x182)]=!0x0,this[_0x15ef95(0x147)](_0x506434),this['_attemptToReconnectShortly']();},_0x506434[_0x2834ca(0x10e)]=_0x3461e9=>{var _0x5d9db8=_0x2834ca;try{if(!(_0x3461e9!=null&&_0x3461e9[_0x5d9db8(0xca)])||!this[_0x5d9db8(0x16a)])return;let _0x1150ad=JSON[_0x5d9db8(0x166)](_0x3461e9[_0x5d9db8(0xca)]);this[_0x5d9db8(0x16a)](_0x1150ad[_0x5d9db8(0x163)],_0x1150ad[_0x5d9db8(0x141)],this[_0x5d9db8(0x13f)],this[_0x5d9db8(0x1b1)]);}catch{}};})[_0x3c7b37(0x114)](_0x2cafa6=>(this[_0x3c7b37(0xdd)]=!0x0,this[_0x3c7b37(0x125)]=!0x1,this[_0x3c7b37(0x182)]=!0x1,this[_0x3c7b37(0x174)]=!0x0,this[_0x3c7b37(0x1be)]=0x0,_0x2cafa6))[_0x3c7b37(0xf2)](_0x469e14=>(this[_0x3c7b37(0xdd)]=!0x1,this[_0x3c7b37(0x125)]=!0x1,console[_0x3c7b37(0x124)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x3c7b37(0x179)]),_0x2d1f56(new Error(_0x3c7b37(0xd1)+(_0x469e14&&_0x469e14[_0x3c7b37(0x188)])))));}));},z['prototype']['_disposeWebsocket']=function(_0x2849e3){var _0x2764c2=_0x54cc26;this[_0x2764c2(0xdd)]=!0x1,this[_0x2764c2(0x125)]=!0x1;try{_0x2849e3['onclose']=null,_0x2849e3[_0x2764c2(0x144)]=null,_0x2849e3['onopen']=null;}catch{}try{_0x2849e3[_0x2764c2(0x1ca)]<0x2&&_0x2849e3['close']();}catch{}},z[_0x54cc26(0x18a)]['_attemptToReconnectShortly']=function(){var _0x4b9fe0=_0x54cc26;clearTimeout(this[_0x4b9fe0(0xe3)]),!(this[_0x4b9fe0(0x1be)]>=this['_maxConnectAttemptCount'])&&(this[_0x4b9fe0(0xe3)]=setTimeout(()=>{var _0x3f71bc=_0x4b9fe0,_0x4f1396;this[_0x3f71bc(0xdd)]||this[_0x3f71bc(0x125)]||(this[_0x3f71bc(0xf0)](),(_0x4f1396=this[_0x3f71bc(0x194)])==null||_0x4f1396[_0x3f71bc(0xf2)](()=>this[_0x3f71bc(0x13c)]()));},0x1f4),this[_0x4b9fe0(0xe3)]['unref']&&this[_0x4b9fe0(0xe3)]['unref']());},z['prototype']['send']=async function(_0x1d08e5){var _0x4d9680=_0x54cc26;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this[_0x4d9680(0xf0)](),(await this[_0x4d9680(0x194)])[_0x4d9680(0x17d)](JSON['stringify'](_0x1d08e5));}catch(_0x15826e){this[_0x4d9680(0x143)]?console[_0x4d9680(0x124)](this['_sendErrorMessage']+':\\x20'+(_0x15826e&&_0x15826e['message'])):(this[_0x4d9680(0x143)]=!0x0,console[_0x4d9680(0x124)](this[_0x4d9680(0x133)]+':\\x20'+(_0x15826e&&_0x15826e[_0x4d9680(0x188)]),_0x1d08e5)),this[_0x4d9680(0x174)]=!0x1,this['_attemptToReconnectShortly']();}};function H(_0xaac806,_0x5ed5cc,_0x320235,_0x41fb4a,_0xb1b23a,_0x1d990d,_0x384cd6,_0x1ac656=ne){var _0x31e34b=_0x54cc26;let _0x134f7c=_0x320235[_0x31e34b(0x1c2)](',')[_0x31e34b(0x106)](_0x22f303=>{var _0x5a2d5a=_0x31e34b,_0x2a5e8e,_0x3fa0bd,_0xad4aad,_0x354175,_0x5817d6,_0x416e53,_0x1c19a5;try{if(!_0xaac806[_0x5a2d5a(0x1a5)]){let _0x3e5b68=((_0x3fa0bd=(_0x2a5e8e=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0x2a5e8e['versions'])==null?void 0x0:_0x3fa0bd[_0x5a2d5a(0x128)])||((_0x354175=(_0xad4aad=_0xaac806[_0x5a2d5a(0x169)])==null?void 0x0:_0xad4aad[_0x5a2d5a(0x10a)])==null?void 0x0:_0x354175['NEXT_RUNTIME'])==='edge';(_0xb1b23a===_0x5a2d5a(0x129)||_0xb1b23a===_0x5a2d5a(0x135)||_0xb1b23a==='astro'||_0xb1b23a===_0x5a2d5a(0x18e))&&(_0xb1b23a+=_0x3e5b68?_0x5a2d5a(0xf4):'\\x20browser');let _0x3dcbaf='';_0xb1b23a==='react-native'&&(_0x3dcbaf=(((_0x1c19a5=(_0x416e53=(_0x5817d6=_0xaac806['expo'])==null?void 0x0:_0x5817d6['modules'])==null?void 0x0:_0x416e53[_0x5a2d5a(0x1a2)])==null?void 0x0:_0x1c19a5['osName'])||'')['toLowerCase'](),_0x3dcbaf&&(_0xb1b23a+='\\x20'+_0x3dcbaf,_0x3dcbaf===_0x5a2d5a(0x1a8)&&(_0x5ed5cc=_0x5a2d5a(0x108)))),_0xaac806[_0x5a2d5a(0x1a5)]={'id':+new Date(),'tool':_0xb1b23a},_0x384cd6&&_0xb1b23a&&!_0x3e5b68&&(_0x3dcbaf?console[_0x5a2d5a(0x116)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x3dcbaf+_0x5a2d5a(0xda)):console[_0x5a2d5a(0x116)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0xb1b23a[_0x5a2d5a(0x11e)](0x0)[_0x5a2d5a(0x1b6)]()+_0xb1b23a[_0x5a2d5a(0x172)](0x1))+',','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)',_0x5a2d5a(0x170)));}let _0x31b88=new z(_0xaac806,_0x5ed5cc,_0x22f303,_0x41fb4a,_0x1d990d,_0x1ac656);return _0x31b88['send']['bind'](_0x31b88);}catch(_0x1dd37f){return console['warn'](_0x5a2d5a(0xf8),_0x1dd37f&&_0x1dd37f['message']),()=>{};}});return _0x1bab8d=>_0x134f7c['forEach'](_0xf9f6fe=>_0xf9f6fe(_0x1bab8d));}function ne(_0x215577,_0x1d2815,_0x27483d,_0x2f114f){var _0xdebb60=_0x54cc26;_0x2f114f&&_0x215577===_0xdebb60(0x13e)&&_0x27483d[_0xdebb60(0x101)][_0xdebb60(0x13e)]();}function b(_0x4bf85c){var _0x402023=_0x54cc26,_0x39f3be,_0x1b82fe;let _0xcdf938=function(_0x5b8299,_0x5b1c4e){return _0x5b1c4e-_0x5b8299;},_0xa22518;if(_0x4bf85c[_0x402023(0x100)])_0xa22518=function(){var _0x1b3c2a=_0x402023;return _0x4bf85c[_0x1b3c2a(0x100)][_0x1b3c2a(0x1a6)]();};else{if(_0x4bf85c[_0x402023(0x169)]&&_0x4bf85c[_0x402023(0x169)][_0x402023(0xde)]&&((_0x1b82fe=(_0x39f3be=_0x4bf85c[_0x402023(0x169)])==null?void 0x0:_0x39f3be[_0x402023(0x10a)])==null?void 0x0:_0x1b82fe['NEXT_RUNTIME'])!==_0x402023(0x11d))_0xa22518=function(){var _0xdb951a=_0x402023;return _0x4bf85c[_0xdb951a(0x169)][_0xdb951a(0xde)]();},_0xcdf938=function(_0xbcdac7,_0x1f8e63){return 0x3e8*(_0x1f8e63[0x0]-_0xbcdac7[0x0])+(_0x1f8e63[0x1]-_0xbcdac7[0x1])/0xf4240;};else try{let {performance:_0x4cdf5e}=require('perf_hooks');_0xa22518=function(){var _0x194844=_0x402023;return _0x4cdf5e[_0x194844(0x1a6)]();};}catch{_0xa22518=function(){return+new Date();};}}return{'elapsed':_0xcdf938,'timeStamp':_0xa22518,'now':()=>Date[_0x402023(0x1a6)]()};}function X(_0x59955b,_0x3967e7,_0x2cce88){var _0x4215b2=_0x54cc26,_0x244b03,_0x3c8740,_0x47936d,_0x52231b,_0x3b5f0a,_0x4a40d4,_0x5240c0,_0x4c6114,_0xd96b4;if(_0x59955b[_0x4215b2(0xfa)]!==void 0x0)return _0x59955b[_0x4215b2(0xfa)];let _0xf3157d=((_0x3c8740=(_0x244b03=_0x59955b['process'])==null?void 0x0:_0x244b03[_0x4215b2(0x12a)])==null?void 0x0:_0x3c8740['node'])||((_0x52231b=(_0x47936d=_0x59955b[_0x4215b2(0x169)])==null?void 0x0:_0x47936d['env'])==null?void 0x0:_0x52231b[_0x4215b2(0x193)])===_0x4215b2(0x11d),_0x3b4db8=!!(_0x2cce88===_0x4215b2(0xd6)&&((_0x5240c0=(_0x4a40d4=(_0x3b5f0a=_0x59955b[_0x4215b2(0xcd)])==null?void 0x0:_0x3b5f0a[_0x4215b2(0x160)])==null?void 0x0:_0x4a40d4[_0x4215b2(0x1a2)])==null?void 0x0:_0x5240c0['osName']));function _0x2b6750(_0x48746a){var _0x18b065=_0x4215b2;if(_0x48746a['startsWith']('/')&&_0x48746a[_0x18b065(0x140)]('/')){let _0x45480e=new RegExp(_0x48746a[_0x18b065(0x162)](0x1,-0x1));return _0x496074=>_0x45480e['test'](_0x496074);}else{if(_0x48746a['includes']('*')||_0x48746a[_0x18b065(0x153)]('?')){let _0x3c8416=new RegExp('^'+_0x48746a[_0x18b065(0x154)](/\\./g,String['fromCharCode'](0x5c)+'.')[_0x18b065(0x154)](/\\*/g,'.*')[_0x18b065(0x154)](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x472a9d=>_0x3c8416[_0x18b065(0x10f)](_0x472a9d);}else return _0x2615bb=>_0x2615bb===_0x48746a;}}let _0x1eca1e=_0x3967e7[_0x4215b2(0x106)](_0x2b6750);return _0x59955b['_consoleNinjaAllowedToStart']=_0xf3157d||!_0x3967e7,!_0x59955b[_0x4215b2(0xfa)]&&((_0x4c6114=_0x59955b[_0x4215b2(0x101)])==null?void 0x0:_0x4c6114[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=_0x1eca1e['some'](_0x3ccb07=>_0x3ccb07(_0x59955b['location'][_0x4215b2(0x183)]))),_0x3b4db8&&!_0x59955b[_0x4215b2(0xfa)]&&!((_0xd96b4=_0x59955b[_0x4215b2(0x101)])!=null&&_0xd96b4[_0x4215b2(0x183)])&&(_0x59955b[_0x4215b2(0xfa)]=!0x0),_0x59955b['_consoleNinjaAllowedToStart'];}function J(_0x31f20b,_0x5c577b,_0x1f3bee,_0x4a0483,_0x469d82,_0x2514c8){var _0x4934b8=_0x54cc26;_0x31f20b=_0x31f20b,_0x5c577b=_0x5c577b,_0x1f3bee=_0x1f3bee,_0x4a0483=_0x4a0483,_0x469d82=_0x469d82,_0x469d82=_0x469d82||{},_0x469d82[_0x4934b8(0x1cc)]=_0x469d82[_0x4934b8(0x1cc)]||{},_0x469d82['reducedLimits']=_0x469d82[_0x4934b8(0x138)]||{},_0x469d82[_0x4934b8(0xe2)]=_0x469d82[_0x4934b8(0xe2)]||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)]=_0x469d82[_0x4934b8(0xe2)]['perLogpoint']||{},_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]=_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]||{};let _0x141946={'perLogpoint':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0x12d)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint']['reduceOnAccumulatedProcessingTimeMs']||0x64,'resetWhenQuietMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x1cb)][_0x4934b8(0xe6)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)]['perLogpoint'][_0x4934b8(0x1b0)]||0x64},'global':{'reduceOnCount':_0x469d82[_0x4934b8(0xe2)]['global'][_0x4934b8(0x12d)]||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['reduceOnAccumulatedProcessingTimeMs']||0x12c,'resetWhenQuietMs':_0x469d82['reducePolicy'][_0x4934b8(0x13f)][_0x4934b8(0xe6)]||0x32,'resetOnProcessingTimeAverageMs':_0x469d82[_0x4934b8(0xe2)][_0x4934b8(0x13f)]['resetOnProcessingTimeAverageMs']||0x64}},_0x42f773=b(_0x31f20b),_0x42fb36=_0x42f773[_0x4934b8(0x168)],_0x223738=_0x42f773[_0x4934b8(0xd0)];function _0x568c0c(){var _0x1fa2cb=_0x4934b8;this[_0x1fa2cb(0x13a)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this[_0x1fa2cb(0x109)]=/^(0|[1-9][0-9]*)$/,this[_0x1fa2cb(0x159)]=/'([^\\\\']|\\\\')*'/,this[_0x1fa2cb(0x12f)]=_0x31f20b[_0x1fa2cb(0xc5)],this[_0x1fa2cb(0x161)]=_0x31f20b[_0x1fa2cb(0x1ab)],this[_0x1fa2cb(0xcf)]=Object[_0x1fa2cb(0x11a)],this[_0x1fa2cb(0x17a)]=Object[_0x1fa2cb(0x14e)],this[_0x1fa2cb(0x178)]=_0x31f20b[_0x1fa2cb(0x19f)],this[_0x1fa2cb(0xd5)]=RegExp[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)],this[_0x1fa2cb(0x132)]=Date[_0x1fa2cb(0x18a)][_0x1fa2cb(0xdf)];}_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x158)]=function(_0x48d78e,_0x348dcf,_0x4a6d96,_0x5a5f89){var _0x19e5e6=_0x4934b8,_0xc6b12f=this,_0x55a7d2=_0x4a6d96['autoExpand'];function _0x42e97b(_0x3952f9,_0x2bc656,_0x8c85ef){var _0x2f1a2f=_0x4a90;_0x2bc656[_0x2f1a2f(0x151)]=_0x2f1a2f(0x16e),_0x2bc656[_0x2f1a2f(0x1bb)]=_0x3952f9[_0x2f1a2f(0x188)],_0x2b7b1a=_0x8c85ef[_0x2f1a2f(0x128)][_0x2f1a2f(0xea)],_0x8c85ef['node'][_0x2f1a2f(0xea)]=_0x2bc656,_0xc6b12f[_0x2f1a2f(0xc8)](_0x2bc656,_0x8c85ef);}let _0xcd7ba5,_0x5307f1,_0x34239a=_0x31f20b[_0x19e5e6(0xd9)];_0x31f20b[_0x19e5e6(0xd9)]=!0x0,_0x31f20b['console']&&(_0xcd7ba5=_0x31f20b[_0x19e5e6(0x176)]['error'],_0x5307f1=_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)],_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=function(){}),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x124)]=function(){}));try{try{_0x4a6d96[_0x19e5e6(0x115)]++,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96['autoExpandPreviousObjects'][_0x19e5e6(0xff)](_0x348dcf);var _0x6adee3,_0xa868ce,_0x4c1789,_0x127a28,_0x1bef2c=[],_0x4dd8f0=[],_0x47c5d8,_0x18b1eb=this[_0x19e5e6(0x1ad)](_0x348dcf),_0x481e55=_0x18b1eb==='array',_0x57133b=!0x1,_0x5ca399=_0x18b1eb===_0x19e5e6(0x196),_0xbd7d8f=this['_isPrimitiveType'](_0x18b1eb),_0x417ea6=this[_0x19e5e6(0x146)](_0x18b1eb),_0x273a7e=_0xbd7d8f||_0x417ea6,_0x2a289a={},_0xcd0938=0x0,_0x14ebf7=!0x1,_0x2b7b1a,_0x30046f=/^(([1-9]{1}[0-9]*)|0)$/;if(_0x4a6d96[_0x19e5e6(0x15f)]){if(_0x481e55){if(_0xa868ce=_0x348dcf['length'],_0xa868ce>_0x4a6d96['elements']){for(_0x4c1789=0x0,_0x127a28=_0x4a6d96['elements'],_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0xcc)](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));_0x48d78e[_0x19e5e6(0x1b9)]=!0x0;}else{for(_0x4c1789=0x0,_0x127a28=_0xa868ce,_0x6adee3=_0x4c1789;_0x6adee3<_0x127a28;_0x6adee3++)_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f['_addProperty'](_0x1bef2c,_0x348dcf,_0x18b1eb,_0x6adee3,_0x4a6d96));}_0x4a6d96[_0x19e5e6(0x186)]+=_0x4dd8f0[_0x19e5e6(0xfc)];}if(!(_0x18b1eb==='null'||_0x18b1eb===_0x19e5e6(0xc5))&&!_0xbd7d8f&&_0x18b1eb!==_0x19e5e6(0x1c8)&&_0x18b1eb!=='Buffer'&&_0x18b1eb!==_0x19e5e6(0xed)){var _0x482677=_0x5a5f89['props']||_0x4a6d96[_0x19e5e6(0xfd)];if(this[_0x19e5e6(0x119)](_0x348dcf)?(_0x6adee3=0x0,_0x348dcf[_0x19e5e6(0x1ba)](function(_0x316011){var _0x3d6007=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0x3d6007(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0x3d6007(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x3d6007(0x186)]>_0x4a6d96[_0x3d6007(0x1a7)]){_0x14ebf7=!0x0;return;}_0x4dd8f0[_0x3d6007(0xff)](_0xc6b12f[_0x3d6007(0xcc)](_0x1bef2c,_0x348dcf,_0x3d6007(0xeb),_0x6adee3++,_0x4a6d96,function(_0x2dd991){return function(){return _0x2dd991;};}(_0x316011)));})):this[_0x19e5e6(0x1a3)](_0x348dcf)&&_0x348dcf[_0x19e5e6(0x1ba)](function(_0x4e9669,_0x2865be){var _0xe99383=_0x19e5e6;if(_0xcd0938++,_0x4a6d96[_0xe99383(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;return;}if(!_0x4a6d96[_0xe99383(0x11c)]&&_0x4a6d96[_0xe99383(0x104)]&&_0x4a6d96[_0xe99383(0x186)]>_0x4a6d96[_0xe99383(0x1a7)]){_0x14ebf7=!0x0;return;}var _0x4c2eff=_0x2865be[_0xe99383(0xdf)]();_0x4c2eff[_0xe99383(0xfc)]>0x64&&(_0x4c2eff=_0x4c2eff[_0xe99383(0x162)](0x0,0x64)+_0xe99383(0xe4)),_0x4dd8f0[_0xe99383(0xff)](_0xc6b12f[_0xe99383(0xcc)](_0x1bef2c,_0x348dcf,_0xe99383(0xd7),_0x4c2eff,_0x4a6d96,function(_0x38d848){return function(){return _0x38d848;};}(_0x4e9669)));}),!_0x57133b){try{for(_0x47c5d8 in _0x348dcf)if(!(_0x481e55&&_0x30046f[_0x19e5e6(0x10f)](_0x47c5d8))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0['push'](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}catch{}if(_0x2a289a['_p_length']=!0x0,_0x5ca399&&(_0x2a289a[_0x19e5e6(0xfe)]=!0x0),!_0x14ebf7){var _0x507ca6=[][_0x19e5e6(0x112)](this['_getOwnPropertyNames'](_0x348dcf))[_0x19e5e6(0x112)](this['_getOwnPropertySymbols'](_0x348dcf));for(_0x6adee3=0x0,_0xa868ce=_0x507ca6['length'];_0x6adee3<_0xa868ce;_0x6adee3++)if(_0x47c5d8=_0x507ca6[_0x6adee3],!(_0x481e55&&_0x30046f['test'](_0x47c5d8[_0x19e5e6(0xdf)]()))&&!this[_0x19e5e6(0xce)](_0x348dcf,_0x47c5d8,_0x4a6d96)&&!_0x2a289a[typeof _0x47c5d8!=_0x19e5e6(0x10b)?_0x19e5e6(0x17e)+_0x47c5d8[_0x19e5e6(0xdf)]():_0x47c5d8]){if(_0xcd0938++,_0x4a6d96[_0x19e5e6(0x186)]++,_0xcd0938>_0x482677){_0x14ebf7=!0x0;break;}if(!_0x4a6d96[_0x19e5e6(0x11c)]&&_0x4a6d96['autoExpand']&&_0x4a6d96[_0x19e5e6(0x186)]>_0x4a6d96[_0x19e5e6(0x1a7)]){_0x14ebf7=!0x0;break;}_0x4dd8f0[_0x19e5e6(0xff)](_0xc6b12f[_0x19e5e6(0x117)](_0x1bef2c,_0x2a289a,_0x348dcf,_0x18b1eb,_0x47c5d8,_0x4a6d96));}}}}}if(_0x48d78e['type']=_0x18b1eb,_0x273a7e?(_0x48d78e['value']=_0x348dcf[_0x19e5e6(0x122)](),this[_0x19e5e6(0x139)](_0x18b1eb,_0x48d78e,_0x4a6d96,_0x5a5f89)):_0x18b1eb===_0x19e5e6(0x103)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x132)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0xed)?_0x48d78e[_0x19e5e6(0xc4)]=_0x348dcf[_0x19e5e6(0xdf)]():_0x18b1eb===_0x19e5e6(0x142)?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0xd5)][_0x19e5e6(0x195)](_0x348dcf):_0x18b1eb===_0x19e5e6(0x10b)&&this[_0x19e5e6(0x178)]?_0x48d78e[_0x19e5e6(0xc4)]=this[_0x19e5e6(0x178)][_0x19e5e6(0x18a)]['toString'][_0x19e5e6(0x195)](_0x348dcf):!_0x4a6d96[_0x19e5e6(0x15f)]&&!(_0x18b1eb===_0x19e5e6(0xd3)||_0x18b1eb==='undefined')&&(delete _0x48d78e[_0x19e5e6(0xc4)],_0x48d78e[_0x19e5e6(0x1ae)]=!0x0),_0x14ebf7&&(_0x48d78e[_0x19e5e6(0x13b)]=!0x0),_0x2b7b1a=_0x4a6d96[_0x19e5e6(0x128)][_0x19e5e6(0xea)],_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x48d78e,this[_0x19e5e6(0xc8)](_0x48d78e,_0x4a6d96),_0x4dd8f0['length']){for(_0x6adee3=0x0,_0xa868ce=_0x4dd8f0[_0x19e5e6(0xfc)];_0x6adee3<_0xa868ce;_0x6adee3++)_0x4dd8f0[_0x6adee3](_0x6adee3);}_0x1bef2c[_0x19e5e6(0xfc)]&&(_0x48d78e[_0x19e5e6(0xfd)]=_0x1bef2c);}catch(_0x3ae5b6){_0x42e97b(_0x3ae5b6,_0x48d78e,_0x4a6d96);}this[_0x19e5e6(0x1c9)](_0x348dcf,_0x48d78e),this[_0x19e5e6(0x136)](_0x48d78e,_0x4a6d96),_0x4a6d96['node'][_0x19e5e6(0xea)]=_0x2b7b1a,_0x4a6d96[_0x19e5e6(0x115)]--,_0x4a6d96[_0x19e5e6(0x104)]=_0x55a7d2,_0x4a6d96[_0x19e5e6(0x104)]&&_0x4a6d96[_0x19e5e6(0x1b4)]['pop']();}finally{_0xcd7ba5&&(_0x31f20b[_0x19e5e6(0x176)][_0x19e5e6(0x1bb)]=_0xcd7ba5),_0x5307f1&&(_0x31f20b[_0x19e5e6(0x176)]['warn']=_0x5307f1),_0x31f20b[_0x19e5e6(0xd9)]=_0x34239a;}return _0x48d78e;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12e)]=function(_0x46f99b){var _0x55ee4f=_0x4934b8;return Object['getOwnPropertySymbols']?Object[_0x55ee4f(0x16b)](_0x46f99b):[];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x119)]=function(_0x259646){var _0x583570=_0x4934b8;return!!(_0x259646&&_0x31f20b[_0x583570(0xeb)]&&this['_objectToString'](_0x259646)===_0x583570(0x17f)&&_0x259646[_0x583570(0x1ba)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xce)]=function(_0x469950,_0x43a4d0,_0x3e7028){var _0x44d134=_0x4934b8;if(!_0x3e7028[_0x44d134(0xcb)]){let _0x5e446a=this[_0x44d134(0xcf)](_0x469950,_0x43a4d0);if(_0x5e446a&&_0x5e446a[_0x44d134(0xf5)])return!0x0;}return _0x3e7028[_0x44d134(0x1bf)]?typeof _0x469950[_0x43a4d0]==_0x44d134(0x196):!0x1;},_0x568c0c[_0x4934b8(0x18a)]['_type']=function(_0x21f464){var _0x5b73d0=_0x4934b8,_0x1012e4='';return _0x1012e4=typeof _0x21f464,_0x1012e4===_0x5b73d0(0x118)?this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x14c)?_0x1012e4=_0x5b73d0(0xfb):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x1b8)?_0x1012e4=_0x5b73d0(0x103):this[_0x5b73d0(0x1c7)](_0x21f464)===_0x5b73d0(0x149)?_0x1012e4=_0x5b73d0(0xed):_0x21f464===null?_0x1012e4='null':_0x21f464[_0x5b73d0(0x14f)]&&(_0x1012e4=_0x21f464['constructor'][_0x5b73d0(0x1c3)]||_0x1012e4):_0x1012e4===_0x5b73d0(0xc5)&&this[_0x5b73d0(0x161)]&&_0x21f464 instanceof this['_HTMLAllCollection']&&(_0x1012e4='HTMLAllCollection'),_0x1012e4;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1c7)]=function(_0x23706a){var _0xb5b3ca=_0x4934b8;return Object[_0xb5b3ca(0x18a)][_0xb5b3ca(0xdf)]['call'](_0x23706a);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19d)]=function(_0x94e0c5){var _0x4b2537=_0x4934b8;return _0x94e0c5===_0x4b2537(0x157)||_0x94e0c5==='string'||_0x94e0c5===_0x4b2537(0x1b2);},_0x568c0c['prototype']['_isPrimitiveWrapperType']=function(_0x2f3e62){var _0x16ad9e=_0x4934b8;return _0x2f3e62===_0x16ad9e(0x199)||_0x2f3e62==='String'||_0x2f3e62===_0x16ad9e(0xe7);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xcc)]=function(_0x1db57d,_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7){var _0x2fcbd8=this;return function(_0x2a2b77){var _0xce493a=_0x4a90,_0x174862=_0x3015c5['node'][_0xce493a(0xea)],_0x4a97c=_0x3015c5[_0xce493a(0x128)]['index'],_0x2b4936=_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)];_0x3015c5['node'][_0xce493a(0x120)]=_0x174862,_0x3015c5['node'][_0xce493a(0x14a)]=typeof _0x19ed12==_0xce493a(0x1b2)?_0x19ed12:_0x2a2b77,_0x1db57d[_0xce493a(0xff)](_0x2fcbd8[_0xce493a(0x12c)](_0x27dec7,_0x5b27b1,_0x19ed12,_0x3015c5,_0x18e0f7)),_0x3015c5[_0xce493a(0x128)][_0xce493a(0x120)]=_0x2b4936,_0x3015c5['node']['index']=_0x4a97c;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x117)]=function(_0x4469e5,_0x3fa37e,_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f){var _0x516d33=_0x4934b8,_0x396018=this;return _0x3fa37e[typeof _0x2f3742!=_0x516d33(0x10b)?_0x516d33(0x17e)+_0x2f3742['toString']():_0x2f3742]=!0x0,function(_0xd7fcb0){var _0x3226db=_0x516d33,_0x39117a=_0x36532d[_0x3226db(0x128)][_0x3226db(0xea)],_0x50a11a=_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)],_0x4eb0c0=_0x36532d['node'][_0x3226db(0x120)];_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x39117a,_0x36532d['node'][_0x3226db(0x14a)]=_0xd7fcb0,_0x4469e5[_0x3226db(0xff)](_0x396018[_0x3226db(0x12c)](_0xeef05b,_0x125913,_0x2f3742,_0x36532d,_0x49d55f)),_0x36532d[_0x3226db(0x128)][_0x3226db(0x120)]=_0x4eb0c0,_0x36532d[_0x3226db(0x128)][_0x3226db(0x14a)]=_0x50a11a;};},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x12c)]=function(_0x453099,_0x4eadbd,_0x11f35a,_0x40815b,_0xa2b7cb){var _0x4b84a8=_0x4934b8,_0x5e86b1=this;_0xa2b7cb||(_0xa2b7cb=function(_0x5cea02,_0x58268c){return _0x5cea02[_0x58268c];});var _0x362525=_0x11f35a['toString'](),_0x3c06dc=_0x40815b[_0x4b84a8(0x1ce)]||{},_0x142239=_0x40815b['depth'],_0x26bf80=_0x40815b[_0x4b84a8(0x11c)];try{var _0x3aca2e=this[_0x4b84a8(0x1a3)](_0x453099),_0x4aabb3=_0x362525;_0x3aca2e&&_0x4aabb3[0x0]==='\\x27'&&(_0x4aabb3=_0x4aabb3[_0x4b84a8(0x172)](0x1,_0x4aabb3[_0x4b84a8(0xfc)]-0x2));var _0x12d722=_0x40815b['expressionsToEvaluate']=_0x3c06dc[_0x4b84a8(0x17e)+_0x4aabb3];_0x12d722&&(_0x40815b['depth']=_0x40815b['depth']+0x1),_0x40815b[_0x4b84a8(0x11c)]=!!_0x12d722;var _0x56e733=typeof _0x11f35a=='symbol',_0xa051ca={'name':_0x56e733||_0x3aca2e?_0x362525:this[_0x4b84a8(0x131)](_0x362525)};if(_0x56e733&&(_0xa051ca[_0x4b84a8(0x10b)]=!0x0),!(_0x4eadbd===_0x4b84a8(0xfb)||_0x4eadbd===_0x4b84a8(0x11b))){var _0x5b5697=this[_0x4b84a8(0xcf)](_0x453099,_0x11f35a);if(_0x5b5697&&(_0x5b5697[_0x4b84a8(0x185)]&&(_0xa051ca['setter']=!0x0),_0x5b5697[_0x4b84a8(0xf5)]&&!_0x12d722&&!_0x40815b[_0x4b84a8(0xcb)]))return _0xa051ca[_0x4b84a8(0x17b)]=!0x0,this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x51fae3;try{_0x51fae3=_0xa2b7cb(_0x453099,_0x11f35a);}catch(_0x4f78cc){return _0xa051ca={'name':_0x362525,'type':_0x4b84a8(0x16e),'error':_0x4f78cc[_0x4b84a8(0x188)]},this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b),_0xa051ca;}var _0x310e5a=this['_type'](_0x51fae3),_0x3e58ae=this[_0x4b84a8(0x19d)](_0x310e5a);if(_0xa051ca['type']=_0x310e5a,_0x3e58ae)this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x2623ba=_0x4b84a8;_0xa051ca[_0x2623ba(0xc4)]=_0x51fae3['valueOf'](),!_0x12d722&&_0x5e86b1[_0x2623ba(0x139)](_0x310e5a,_0xa051ca,_0x40815b,{});});else{var _0x87c7d8=_0x40815b[_0x4b84a8(0x104)]&&_0x40815b[_0x4b84a8(0x115)]<_0x40815b[_0x4b84a8(0x189)]&&_0x40815b[_0x4b84a8(0x1b4)][_0x4b84a8(0x121)](_0x51fae3)<0x0&&_0x310e5a!==_0x4b84a8(0x196)&&_0x40815b['autoExpandPropertyCount']<_0x40815b[_0x4b84a8(0x1a7)];_0x87c7d8||_0x40815b[_0x4b84a8(0x115)]<_0x142239||_0x12d722?this['serialize'](_0xa051ca,_0x51fae3,_0x40815b,_0x12d722||{}):this[_0x4b84a8(0x1a0)](_0xa051ca,_0x40815b,_0x51fae3,function(){var _0x48a268=_0x4b84a8;_0x310e5a===_0x48a268(0xd3)||_0x310e5a===_0x48a268(0xc5)||(delete _0xa051ca[_0x48a268(0xc4)],_0xa051ca['capped']=!0x0);});}return _0xa051ca;}finally{_0x40815b[_0x4b84a8(0x1ce)]=_0x3c06dc,_0x40815b[_0x4b84a8(0x15f)]=_0x142239,_0x40815b[_0x4b84a8(0x11c)]=_0x26bf80;}},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x139)]=function(_0x5e0732,_0x1bfe86,_0xda28d7,_0x491a14){var _0x60e05=_0x4934b8,_0x33f831=_0x491a14[_0x60e05(0x110)]||_0xda28d7[_0x60e05(0x110)];if((_0x5e0732===_0x60e05(0x1a9)||_0x5e0732==='String')&&_0x1bfe86['value']){let _0x1eacb7=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0xfc)];_0xda28d7['allStrLength']+=_0x1eacb7,_0xda28d7[_0x60e05(0xd4)]>_0xda28d7[_0x60e05(0x191)]?(_0x1bfe86['capped']='',delete _0x1bfe86[_0x60e05(0xc4)]):_0x1eacb7>_0x33f831&&(_0x1bfe86[_0x60e05(0x1ae)]=_0x1bfe86[_0x60e05(0xc4)][_0x60e05(0x172)](0x0,_0x33f831),delete _0x1bfe86[_0x60e05(0xc4)]);}},_0x568c0c['prototype']['_isMap']=function(_0x251695){var _0x2d4790=_0x4934b8;return!!(_0x251695&&_0x31f20b[_0x2d4790(0xd7)]&&this[_0x2d4790(0x1c7)](_0x251695)===_0x2d4790(0x16d)&&_0x251695['forEach']);},_0x568c0c[_0x4934b8(0x18a)]['_propertyName']=function(_0x2e0688){var _0x2c8644=_0x4934b8;if(_0x2e0688[_0x2c8644(0x11f)](/^\\d+$/))return _0x2e0688;var _0x91094;try{_0x91094=JSON[_0x2c8644(0x175)](''+_0x2e0688);}catch{_0x91094='\\x22'+this['_objectToString'](_0x2e0688)+'\\x22';}return _0x91094[_0x2c8644(0x11f)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x91094=_0x91094['substr'](0x1,_0x91094[_0x2c8644(0xfc)]-0x2):_0x91094=_0x91094[_0x2c8644(0x154)](/'/g,'\\x5c\\x27')[_0x2c8644(0x154)](/\\\\\"/g,'\\x22')[_0x2c8644(0x154)](/(^\"|\"$)/g,'\\x27'),_0x91094;},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x1a0)]=function(_0x232cbb,_0x29085f,_0x1650af,_0x1c890e){var _0x16a2a5=_0x4934b8;this[_0x16a2a5(0xc8)](_0x232cbb,_0x29085f),_0x1c890e&&_0x1c890e(),this[_0x16a2a5(0x1c9)](_0x1650af,_0x232cbb),this[_0x16a2a5(0x136)](_0x232cbb,_0x29085f);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xc8)]=function(_0x49291a,_0x33bdc6){var _0x52d41e=_0x4934b8;this[_0x52d41e(0x127)](_0x49291a,_0x33bdc6),this['_setNodeQueryPath'](_0x49291a,_0x33bdc6),this[_0x52d41e(0x15a)](_0x49291a,_0x33bdc6),this[_0x52d41e(0xe0)](_0x49291a,_0x33bdc6);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x127)]=function(_0x3ffba9,_0x308291){},_0x568c0c[_0x4934b8(0x18a)]['_setNodeQueryPath']=function(_0x4befcf,_0x340320){},_0x568c0c['prototype'][_0x4934b8(0x19c)]=function(_0x6d004b,_0x3e0efe){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x19e)]=function(_0x3b2948){var _0x1c5336=_0x4934b8;return _0x3b2948===this[_0x1c5336(0x12f)];},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x136)]=function(_0x571a40,_0x11152b){var _0x17c82d=_0x4934b8;this[_0x17c82d(0x19c)](_0x571a40,_0x11152b),this[_0x17c82d(0x16c)](_0x571a40),_0x11152b['sortProps']&&this[_0x17c82d(0x1af)](_0x571a40),this['_addFunctionsNode'](_0x571a40,_0x11152b),this['_addLoadNode'](_0x571a40,_0x11152b),this['_cleanNode'](_0x571a40);},_0x568c0c[_0x4934b8(0x18a)]['_additionalMetadata']=function(_0x25d425,_0x376ba0){var _0x4c6175=_0x4934b8;try{_0x25d425&&typeof _0x25d425[_0x4c6175(0xfc)]==_0x4c6175(0x1b2)&&(_0x376ba0[_0x4c6175(0xfc)]=_0x25d425[_0x4c6175(0xfc)]);}catch{}if(_0x376ba0[_0x4c6175(0x151)]===_0x4c6175(0x1b2)||_0x376ba0['type']===_0x4c6175(0xe7)){if(isNaN(_0x376ba0['value']))_0x376ba0[_0x4c6175(0xe5)]=!0x0,delete _0x376ba0[_0x4c6175(0xc4)];else switch(_0x376ba0[_0x4c6175(0xc4)]){case Number[_0x4c6175(0x102)]:_0x376ba0[_0x4c6175(0x130)]=!0x0,delete _0x376ba0['value'];break;case Number[_0x4c6175(0xf6)]:_0x376ba0[_0x4c6175(0x184)]=!0x0,delete _0x376ba0['value'];break;case 0x0:this['_isNegativeZero'](_0x376ba0['value'])&&(_0x376ba0[_0x4c6175(0xc3)]=!0x0);break;}}else _0x376ba0['type']==='function'&&typeof _0x25d425[_0x4c6175(0x1c3)]=='string'&&_0x25d425['name']&&_0x376ba0[_0x4c6175(0x1c3)]&&_0x25d425[_0x4c6175(0x1c3)]!==_0x376ba0[_0x4c6175(0x1c3)]&&(_0x376ba0[_0x4c6175(0x145)]=_0x25d425[_0x4c6175(0x1c3)]);},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x187)]=function(_0x3d5c0c){var _0x21909c=_0x4934b8;return 0x1/_0x3d5c0c===Number[_0x21909c(0xf6)];},_0x568c0c['prototype'][_0x4934b8(0x1af)]=function(_0xaf6d85){var _0x257f6e=_0x4934b8;!_0xaf6d85[_0x257f6e(0xfd)]||!_0xaf6d85['props'][_0x257f6e(0xfc)]||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xfb)||_0xaf6d85[_0x257f6e(0x151)]===_0x257f6e(0xd7)||_0xaf6d85[_0x257f6e(0x151)]==='Set'||_0xaf6d85[_0x257f6e(0xfd)][_0x257f6e(0xee)](function(_0xcc5a49,_0x33a07){var _0x3d0ac0=_0x257f6e,_0x216c86=_0xcc5a49[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)](),_0x52e92d=_0x33a07[_0x3d0ac0(0x1c3)][_0x3d0ac0(0x1bd)]();return _0x216c86<_0x52e92d?-0x1:_0x216c86>_0x52e92d?0x1:0x0;});},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0x18c)]=function(_0x26dd9a,_0x367b0a){var _0x3fb806=_0x4934b8;if(!(_0x367b0a[_0x3fb806(0x1bf)]||!_0x26dd9a['props']||!_0x26dd9a[_0x3fb806(0xfd)]['length'])){for(var _0x558538=[],_0x1e34a7=[],_0x4cf6c3=0x0,_0x496b22=_0x26dd9a[_0x3fb806(0xfd)]['length'];_0x4cf6c3<_0x496b22;_0x4cf6c3++){var _0x286ad8=_0x26dd9a[_0x3fb806(0xfd)][_0x4cf6c3];_0x286ad8[_0x3fb806(0x151)]===_0x3fb806(0x196)?_0x558538[_0x3fb806(0xff)](_0x286ad8):_0x1e34a7[_0x3fb806(0xff)](_0x286ad8);}if(!(!_0x1e34a7[_0x3fb806(0xfc)]||_0x558538[_0x3fb806(0xfc)]<=0x1)){_0x26dd9a[_0x3fb806(0xfd)]=_0x1e34a7;var _0x589572={'functionsNode':!0x0,'props':_0x558538};this[_0x3fb806(0x127)](_0x589572,_0x367b0a),this[_0x3fb806(0x19c)](_0x589572,_0x367b0a),this['_setNodeExpandableState'](_0x589572),this[_0x3fb806(0xe0)](_0x589572,_0x367b0a),_0x589572['id']+='\\x20f',_0x26dd9a['props'][_0x3fb806(0x1ac)](_0x589572);}}},_0x568c0c['prototype'][_0x4934b8(0xf9)]=function(_0x3a8156,_0x31dbc6){},_0x568c0c['prototype']['_setNodeExpandableState']=function(_0x27a91c){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xdc)]=function(_0x309bc7){var _0x3eff3d=_0x4934b8;return Array[_0x3eff3d(0x173)](_0x309bc7)||typeof _0x309bc7=='object'&&this['_objectToString'](_0x309bc7)==='[object\\x20Array]';},_0x568c0c[_0x4934b8(0x18a)]['_setNodePermissions']=function(_0x33a0fd,_0x133d76){},_0x568c0c[_0x4934b8(0x18a)][_0x4934b8(0xef)]=function(_0xd4834e){var _0x4c0797=_0x4934b8;delete _0xd4834e[_0x4c0797(0xe9)],delete _0xd4834e[_0x4c0797(0xf3)],delete _0xd4834e[_0x4c0797(0x1b7)];},_0x568c0c[_0x4934b8(0x18a)]['_setNodeExpressionPath']=function(_0x82227e,_0x5e328e){};let _0x4277ae=new _0x568c0c(),_0x578392={'props':_0x469d82[_0x4934b8(0x1cc)][_0x4934b8(0xfd)]||0x64,'elements':_0x469d82[_0x4934b8(0x1cc)]['elements']||0x64,'strLength':_0x469d82['defaultLimits']['strLength']||0x400*0x32,'totalStrLength':_0x469d82['defaultLimits'][_0x4934b8(0x191)]||0x400*0x32,'autoExpandLimit':_0x469d82['defaultLimits']['autoExpandLimit']||0x1388,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x1cc)]['autoExpandMaxDepth']||0xa},_0x1f746a={'props':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xfd)]||0x5,'elements':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0xd2)]||0x5,'strLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x110)]||0x100,'totalStrLength':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x191)]||0x100*0x3,'autoExpandLimit':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x1a7)]||0x1e,'autoExpandMaxDepth':_0x469d82[_0x4934b8(0x138)][_0x4934b8(0x189)]||0x2};if(_0x2514c8){let _0x31c1e0=_0x4277ae['serialize'][_0x4934b8(0xf1)](_0x4277ae);_0x4277ae[_0x4934b8(0x158)]=function(_0x1957c4,_0xc0aeb7,_0x4ead78,_0x3625d6){return _0x31c1e0(_0x1957c4,_0x2514c8(_0xc0aeb7),_0x4ead78,_0x3625d6);};}function _0x1e6d74(_0x5afffa,_0x4a459c,_0x275938,_0x334fd3,_0x45c8dc,_0x17015d){var _0x490e67=_0x4934b8;let _0x97a821,_0x4538cb;try{_0x4538cb=_0x223738(),_0x97a821=_0x1f3bee[_0x4a459c],!_0x97a821||_0x4538cb-_0x97a821['ts']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0xe6)]&&_0x97a821[_0x490e67(0x180)]&&_0x97a821['time']/_0x97a821[_0x490e67(0x180)]<_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1b0)]?(_0x1f3bee[_0x4a459c]=_0x97a821={'count':0x0,'time':0x0,'ts':_0x4538cb},_0x1f3bee[_0x490e67(0x1cd)]={}):_0x4538cb-_0x1f3bee[_0x490e67(0x1cd)]['ts']>_0x141946[_0x490e67(0x13f)][_0x490e67(0xe6)]&&_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]&&_0x1f3bee['hits']['time']/_0x1f3bee['hits']['count']<_0x141946[_0x490e67(0x13f)]['resetOnProcessingTimeAverageMs']&&(_0x1f3bee[_0x490e67(0x1cd)]={});let _0x7ce882=[],_0x3afea7=_0x97a821['reduceLimits']||_0x1f3bee['hits']['reduceLimits']?_0x1f746a:_0x578392,_0x204f3a=_0x4e76b9=>{var _0x2f14d5=_0x490e67;let _0x5cb8da={};return _0x5cb8da[_0x2f14d5(0xfd)]=_0x4e76b9['props'],_0x5cb8da['elements']=_0x4e76b9[_0x2f14d5(0xd2)],_0x5cb8da[_0x2f14d5(0x110)]=_0x4e76b9[_0x2f14d5(0x110)],_0x5cb8da[_0x2f14d5(0x191)]=_0x4e76b9['totalStrLength'],_0x5cb8da['autoExpandLimit']=_0x4e76b9[_0x2f14d5(0x1a7)],_0x5cb8da[_0x2f14d5(0x189)]=_0x4e76b9[_0x2f14d5(0x189)],_0x5cb8da['sortProps']=!0x1,_0x5cb8da[_0x2f14d5(0x1bf)]=!_0x5c577b,_0x5cb8da[_0x2f14d5(0x15f)]=0x1,_0x5cb8da[_0x2f14d5(0x115)]=0x0,_0x5cb8da['expId']='root_exp_id',_0x5cb8da[_0x2f14d5(0xc6)]=_0x2f14d5(0x10d),_0x5cb8da[_0x2f14d5(0x104)]=!0x0,_0x5cb8da[_0x2f14d5(0x1b4)]=[],_0x5cb8da[_0x2f14d5(0x186)]=0x0,_0x5cb8da['resolveGetters']=_0x469d82[_0x2f14d5(0xcb)],_0x5cb8da[_0x2f14d5(0xd4)]=0x0,_0x5cb8da[_0x2f14d5(0x128)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x5cb8da;};for(var _0x7432f7=0x0;_0x7432f7<_0x45c8dc['length'];_0x7432f7++)_0x7ce882[_0x490e67(0xff)](_0x4277ae[_0x490e67(0x158)]({'timeNode':_0x5afffa===_0x490e67(0x15e)||void 0x0},_0x45c8dc[_0x7432f7],_0x204f3a(_0x3afea7),{}));if(_0x5afffa===_0x490e67(0x17c)||_0x5afffa===_0x490e67(0x1bb)){let _0x5b3615=Error[_0x490e67(0x16f)];try{Error['stackTraceLimit']=0x1/0x0,_0x7ce882['push'](_0x4277ae[_0x490e67(0x158)]({'stackNode':!0x0},new Error()[_0x490e67(0x123)],_0x204f3a(_0x3afea7),{'strLength':0x1/0x0}));}finally{Error[_0x490e67(0x16f)]=_0x5b3615;}}return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':_0x7ce882,'id':_0x4a459c,'context':_0x17015d}]};}catch(_0x84cbeb){return{'method':_0x490e67(0x116),'version':_0x4a0483,'args':[{'ts':_0x275938,'session':_0x334fd3,'args':[{'type':_0x490e67(0x16e),'error':_0x84cbeb&&_0x84cbeb[_0x490e67(0x188)]}],'id':_0x4a459c,'context':_0x17015d}]};}finally{try{if(_0x97a821&&_0x4538cb){let _0x432ee2=_0x223738();_0x97a821['count']++,_0x97a821['time']+=_0x42fb36(_0x4538cb,_0x432ee2),_0x97a821['ts']=_0x432ee2,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x180)]++,_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]+=_0x42fb36(_0x4538cb,_0x432ee2),_0x1f3bee[_0x490e67(0x1cd)]['ts']=_0x432ee2,(_0x97a821[_0x490e67(0x180)]>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x12d)]||_0x97a821['time']>_0x141946[_0x490e67(0x1cb)][_0x490e67(0x1bc)])&&(_0x97a821[_0x490e67(0x171)]=!0x0),(_0x1f3bee['hits']['count']>_0x141946[_0x490e67(0x13f)][_0x490e67(0x12d)]||_0x1f3bee[_0x490e67(0x1cd)][_0x490e67(0x15e)]>_0x141946[_0x490e67(0x13f)]['reduceOnAccumulatedProcessingTimeMs'])&&(_0x1f3bee[_0x490e67(0x1cd)]['reduceLimits']=!0x0);}}catch{}}}return _0x1e6d74;}function _0x2214(){var _0x14499a=['value','undefined','rootExpression','path','_treeNodePropertiesBeforeFullValue','origin','data','resolveGetters','_addProperty','expo','_blacklistedProperty','_getOwnPropertyDescriptor','timeStamp','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','elements','null','allStrLength','_regExpToString','react-native','Map','2eFQllr','ninjaSuppressConsole',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','coverage','_isArray','_connected','hrtime','toString','_setNodePermissions','bound\\x20Promise','reducePolicy','_reconnectTimeout','...','nan','resetWhenQuietMs','Number','_ninjaIgnoreNextError','_hasSymbolPropertyOnItsPath','current','Set','import(\\x27url\\x27)','bigint','sort','_cleanNode','_connectToHostNow','bind','catch','_hasSetOnItsPath','\\x20server','get','NEGATIVE_INFINITY','1.0.0','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','_addLoadNode','_consoleNinjaAllowedToStart','array','length','props','_p_name','push','performance','location','POSITIVE_INFINITY','date','autoExpand','10162370kgItlO','map','disabledTrace','10.0.2.2','_numberRegExp','env','symbol','resolve','root_exp','onmessage','test','strLength','port','concat','_WebSocket','then','level','log','_addObjectProperty','object','_isSet','getOwnPropertyDescriptor','Error','isExpressionToEvaluate','edge','charAt','match','parent','indexOf','valueOf','stack','warn','_connecting','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','_setNodeId','node','next.js','versions','1668317DHAXqx','_property','reduceOnCount','_getOwnPropertySymbols','_undefined','positiveInfinity','_propertyName','_dateToString','_sendErrorMessage','gateway.docker.internal','remix','_treeNodePropertiesAfterFullValue','984054cwWOKG','reducedLimits','_capIfString','_keyStrRegExp','cappedProps','_attemptToReconnectShortly','_socket','reload','global','endsWith','args','RegExp','_extendedWarning','onerror','funcName','_isPrimitiveWrapperType','_disposeWebsocket','next.js','[object\\x20BigInt]','index','_maxConnectAttemptCount','[object\\x20Array]',\"/Users/luiseurdanetamartucci/.cursor/extensions/wallabyjs.console-ninja-1.0.493-universal/node_modules\",'getOwnPropertyNames','constructor','dockerizedApp','type','142700orZAYJ','includes','replace','51827','hasOwnProperty','boolean','serialize','_quotedRegExp','_setNodeExpressionPath','unref','join','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','time','depth','modules','_HTMLAllCollection','slice','method','nodeModules','_console_ninja','parse','415197WHEhXo','elapsed','process','eventReceivedCallback','getOwnPropertySymbols','_setNodeExpandableState','[object\\x20Map]','unknown','stackTraceLimit','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','reduceLimits','substr','isArray','_allowedToSend','stringify','console','disabledLog','_Symbol','_webSocketErrorDocsLink','_getOwnPropertyNames','getter','trace','send','_p_','[object\\x20Set]','count','','_allowedToConnectOnSend','hostname','negativeInfinity','set','autoExpandPropertyCount','_isNegativeZero','message','autoExpandMaxDepth','prototype','iterator','_addFunctionsNode','https://tinyurl.com/37x8b79t','angular','127.0.0.1','import(\\x27path\\x27)','totalStrLength','host','NEXT_RUNTIME','_ws','call','function','5lYlfxC','56GExRSR','Boolean','1563852BMXApG',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'_setNodeLabel','_isPrimitiveType','_isUndefined','Symbol','_processTreeNodeResult','_WebSocketClass','ExpoDevice','_isMap','default','_console_ninja_session','now','autoExpandLimit','android','string','11djOgAe','HTMLAllCollection','unshift','_type','capped','_sortProps','resetOnProcessingTimeAverageMs','_inBrowser','number','url','autoExpandPreviousObjects','WebSocket','toUpperCase','_hasMapOnItsPath','[object\\x20Date]','cappedElements','forEach','error','reduceOnAccumulatedProcessingTimeMs','toLowerCase','_connectAttemptCount','noFunctions','207488XhRovp','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','split','name','logger\\x20websocket\\x20error','getWebSocketClass',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"Mac-mini-de-Luis.local\",\"192.168.1.19\"],'_objectToString','String','_additionalMetadata','readyState','perLogpoint','defaultLimits','hits','expressionsToEvaluate','negativeZero'];_0x2214=function(){return _0x14499a;};return _0x2214();}function G(_0x3130d3){var _0x84a520=_0x54cc26;if(_0x3130d3&&typeof _0x3130d3==_0x84a520(0x118)&&_0x3130d3[_0x84a520(0x14f)])switch(_0x3130d3[_0x84a520(0x14f)][_0x84a520(0x1c3)]){case'Promise':return _0x3130d3[_0x84a520(0x156)](Symbol[_0x84a520(0x18b)])?Promise['resolve']():_0x3130d3;case _0x84a520(0xe1):return Promise[_0x84a520(0x10c)]();}return _0x3130d3;}function _0x4a90(_0xbf85a4,_0x245df9){var _0x2214cf=_0x2214();return _0x4a90=function(_0x4a90b3,_0x346472){_0x4a90b3=_0x4a90b3-0xc3;var _0x3eefbb=_0x2214cf[_0x4a90b3];return _0x3eefbb;},_0x4a90(_0xbf85a4,_0x245df9);}((_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x269295,_0x304d0c,_0x56b187,_0x5799d3,_0x19f830,_0x5a3a2e,_0x231e3c)=>{var _0x4818fc=_0x54cc26;if(_0x3cca3d[_0x4818fc(0x165)])return _0x3cca3d[_0x4818fc(0x165)];let _0x52e3da={'consoleLog':()=>{},'consoleTrace':()=>{},'consoleTime':()=>{},'consoleTimeEnd':()=>{},'autoLog':()=>{},'autoLogMany':()=>{},'autoTraceMany':()=>{},'coverage':()=>{},'autoTrace':()=>{},'autoTime':()=>{},'autoTimeEnd':()=>{}};if(!X(_0x3cca3d,_0x56b187,_0x38abea))return _0x3cca3d[_0x4818fc(0x165)]=_0x52e3da,_0x3cca3d['_console_ninja'];let _0x44b593=b(_0x3cca3d),_0x48380c=_0x44b593[_0x4818fc(0x168)],_0x1338d8=_0x44b593[_0x4818fc(0xd0)],_0x29d139=_0x44b593[_0x4818fc(0x1a6)],_0x1ed58e={'hits':{},'ts':{}},_0x19f55c=J(_0x3cca3d,_0x5799d3,_0x1ed58e,_0x269295,_0x231e3c,_0x38abea===_0x4818fc(0x129)?G:void 0x0),_0x59946f=(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0)=>{var _0x40d17e=_0x4818fc;let _0x218bcb=_0x3cca3d['_console_ninja'];try{return _0x3cca3d['_console_ninja']=_0x52e3da,_0x19f55c(_0x57c8c4,_0x2ff1c0,_0x1589b0,_0x5826e5,_0xd0311c,_0x2786a0);}finally{_0x3cca3d[_0x40d17e(0x165)]=_0x218bcb;}},_0x22921d=_0x423627=>{_0x1ed58e['ts'][_0x423627]=_0x1338d8();},_0x45102e=(_0x88203,_0x370b7a)=>{var _0x9ec8e9=_0x4818fc;let _0x3d041a=_0x1ed58e['ts'][_0x370b7a];if(delete _0x1ed58e['ts'][_0x370b7a],_0x3d041a){let _0x52a6eb=_0x48380c(_0x3d041a,_0x1338d8());_0x312a62(_0x59946f(_0x9ec8e9(0x15e),_0x88203,_0x29d139(),_0x9b859d,[_0x52a6eb],_0x370b7a));}},_0x2ee867=_0x41fceb=>{var _0x5bbca8=_0x4818fc,_0x5ba44d;return _0x38abea==='next.js'&&_0x3cca3d[_0x5bbca8(0xc9)]&&((_0x5ba44d=_0x41fceb==null?void 0x0:_0x41fceb[_0x5bbca8(0x141)])==null?void 0x0:_0x5ba44d[_0x5bbca8(0xfc)])&&(_0x41fceb['args'][0x0][_0x5bbca8(0xc9)]=_0x3cca3d[_0x5bbca8(0xc9)]),_0x41fceb;};_0x3cca3d[_0x4818fc(0x165)]={'consoleLog':(_0x1d0443,_0x2f73e4)=>{var _0x97f6bc=_0x4818fc;_0x3cca3d[_0x97f6bc(0x176)][_0x97f6bc(0x116)][_0x97f6bc(0x1c3)]!==_0x97f6bc(0x177)&&_0x312a62(_0x59946f(_0x97f6bc(0x116),_0x1d0443,_0x29d139(),_0x9b859d,_0x2f73e4));},'consoleTrace':(_0x4f29ba,_0x40e0fb)=>{var _0x5ea07f=_0x4818fc,_0xb083e5,_0x274db5;_0x3cca3d[_0x5ea07f(0x176)][_0x5ea07f(0x116)][_0x5ea07f(0x1c3)]!==_0x5ea07f(0x107)&&((_0x274db5=(_0xb083e5=_0x3cca3d['process'])==null?void 0x0:_0xb083e5[_0x5ea07f(0x12a)])!=null&&_0x274db5[_0x5ea07f(0x128)]&&(_0x3cca3d[_0x5ea07f(0xe8)]=!0x0),_0x312a62(_0x2ee867(_0x59946f(_0x5ea07f(0x17c),_0x4f29ba,_0x29d139(),_0x9b859d,_0x40e0fb))));},'consoleError':(_0x2bc0da,_0x1c2aec)=>{var _0x1781f6=_0x4818fc;_0x3cca3d[_0x1781f6(0xe8)]=!0x0,_0x312a62(_0x2ee867(_0x59946f(_0x1781f6(0x1bb),_0x2bc0da,_0x29d139(),_0x9b859d,_0x1c2aec)));},'consoleTime':_0x39580d=>{_0x22921d(_0x39580d);},'consoleTimeEnd':(_0x3bc815,_0x207b89)=>{_0x45102e(_0x207b89,_0x3bc815);},'autoLog':(_0x1feae7,_0x412215)=>{var _0x28d3ed=_0x4818fc;_0x312a62(_0x59946f(_0x28d3ed(0x116),_0x412215,_0x29d139(),_0x9b859d,[_0x1feae7]));},'autoLogMany':(_0x2ec4aa,_0x3ebbc7)=>{_0x312a62(_0x59946f('log',_0x2ec4aa,_0x29d139(),_0x9b859d,_0x3ebbc7));},'autoTrace':(_0x1181a3,_0x59d6b5)=>{_0x312a62(_0x2ee867(_0x59946f('trace',_0x59d6b5,_0x29d139(),_0x9b859d,[_0x1181a3])));},'autoTraceMany':(_0x5d59ec,_0x321085)=>{var _0x254ed6=_0x4818fc;_0x312a62(_0x2ee867(_0x59946f(_0x254ed6(0x17c),_0x5d59ec,_0x29d139(),_0x9b859d,_0x321085)));},'autoTime':(_0x221590,_0x1740ad,_0x144e01)=>{_0x22921d(_0x144e01);},'autoTimeEnd':(_0x37d7ca,_0x1b7b6f,_0x52089f)=>{_0x45102e(_0x1b7b6f,_0x52089f);},'coverage':_0x2fe387=>{var _0xeb334b=_0x4818fc;_0x312a62({'method':_0xeb334b(0xdb),'version':_0x269295,'args':[{'id':_0x2fe387}]});}};let _0x312a62=H(_0x3cca3d,_0xf824c0,_0x3e0a9b,_0x5c058d,_0x38abea,_0x19f830,_0x5a3a2e),_0x9b859d=_0x3cca3d[_0x4818fc(0x1a5)];return _0x3cca3d[_0x4818fc(0x165)];})(globalThis,_0x54cc26(0x18f),_0x54cc26(0x155),_0x54cc26(0x14d),_0x54cc26(0x148),_0x54cc26(0xf7),'1763946797424',_0x54cc26(0x1c6),_0x54cc26(0x181),'','1',_0x54cc26(0x19b));");
    } catch (e) {
        console.error(e);
    }
}
function oo_oo(i, ...v) {
    try {
        oo_cm().consoleLog(i, v);
    } catch (e) {}
    return v;
}
oo_oo; /* istanbul ignore next */ 
function oo_tr(i, ...v) {
    try {
        oo_cm().consoleTrace(i, v);
    } catch (e) {}
    return v;
}
oo_tr; /* istanbul ignore next */ 
function oo_tx(i, ...v) {
    try {
        oo_cm().consoleError(i, v);
    } catch (e) {}
    return v;
}
oo_tx; /* istanbul ignore next */ 
function oo_ts(v) {
    try {
        oo_cm().consoleTime(v);
    } catch (e) {}
    return v;
}
oo_ts; /* istanbul ignore next */ 
function oo_te(v, i) {
    try {
        oo_cm().consoleTimeEnd(v, i);
    } catch (e) {}
    return v;
}
oo_te; /*eslint unicorn/no-abusive-eslint-disable:,eslint-comments/disable-enable-pair:,eslint-comments/no-unlimited-disable:,eslint-comments/no-aggregating-enable:,eslint-comments/no-duplicate-disable:,eslint-comments/no-unused-disable:,eslint-comments/no-unused-enable:,*/ 
var _c;
__turbopack_context__.k.register(_c, "ThemeErrorBoundary");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/tooltip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Tooltip",
    ()=>Tooltip,
    "TooltipContent",
    ()=>TooltipContent,
    "TooltipProvider",
    ()=>TooltipProvider,
    "TooltipTrigger",
    ()=>TooltipTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-tooltip/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
function TooltipProvider({ delayDuration = 0, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Provider"], {
        "data-slot": "tooltip-provider",
        delayDuration: delayDuration,
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = TooltipProvider;
function Tooltip({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TooltipProvider, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
            "data-slot": "tooltip",
            ...props
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c1 = Tooltip;
function TooltipTrigger({ ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Trigger"], {
        "data-slot": "tooltip-trigger",
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
        lineNumber: 34,
        columnNumber: 10
    }, this);
}
_c2 = TooltipTrigger;
function TooltipContent({ className, sideOffset = 0, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Portal"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Content"], {
            "data-slot": "tooltip-content",
            sideOffset: sideOffset,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('bg-primary text-primary-foreground animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) rounded-md px-3 py-1.5 text-xs text-balance', className),
            ...props,
            children: [
                children,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$tooltip$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Arrow"], {
                    className: "bg-primary fill-primary z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]"
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
            lineNumber: 45,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/tooltip.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c3 = TooltipContent;
;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "TooltipProvider");
__turbopack_context__.k.register(_c1, "Tooltip");
__turbopack_context__.k.register(_c2, "TooltipTrigger");
__turbopack_context__.k.register(_c3, "TooltipContent");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/context/providers/index.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$providers$2f$ReactQueryProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/context/providers/ReactQueryProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$TranslationsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/context/TranslationsContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$providers$2f$TrpcProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/context/providers/TrpcProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$GlobalThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/context/GlobalThemeProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$providers$2f$ThemeErrorBoundary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/context/providers/ThemeErrorBoundary.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/tooltip.tsx [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function Providers({ children, initialLocale, initialTranslations, companyId, themeId, initialTheme }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$providers$2f$ReactQueryProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$providers$2f$TrpcProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TrpcProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$providers$2f$ThemeErrorBoundary$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeErrorBoundaryClass"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$GlobalThemeProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GlobalThemeProvider"], {
                    companyId: companyId,
                    initialTheme: initialTheme,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TooltipProvider"], {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$context$2f$TranslationsContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TranslationsProvider"], {
                            initialLocale: initialLocale,
                            initialTranslations: initialTranslations,
                            children: children
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/context/providers/index.tsx",
                            lineNumber: 33,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/context/providers/index.tsx",
                        lineNumber: 32,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/context/providers/index.tsx",
                    lineNumber: 31,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/context/providers/index.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/web/src/context/providers/index.tsx",
            lineNumber: 29,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/context/providers/index.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_c = Providers;
var _c;
__turbopack_context__.k.register(_c, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/toast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toast",
    ()=>Toast,
    "ToastAction",
    ()=>ToastAction,
    "ToastClose",
    ()=>ToastClose,
    "ToastDescription",
    ()=>ToastDescription,
    "ToastProvider",
    ()=>ToastProvider,
    "ToastTitle",
    ()=>ToastTitle,
    "ToastViewport",
    ()=>ToastViewport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-toast/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/utils.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
const ToastProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Provider"];
const ToastViewport = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
        lineNumber: 16,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = ToastViewport;
ToastViewport.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"].displayName;
const toastVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full", {
    variants: {
        variant: {
            default: "border bg-background text-foreground",
            destructive: "destructive group border-destructive bg-destructive text-destructive-foreground",
            success: "border border-green-600 bg-green-50 text-green-800",
            error: "border border-red-600 bg-red-50 text-red-800"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Toast = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = ({ className, variant, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(toastVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = Toast;
Toast.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
const ToastAction = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
        lineNumber: 64,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = ToastAction;
ToastAction.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].displayName;
const ToastClose = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Close"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600", className),
        "toast-close": "",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
            lineNumber: 88,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
        lineNumber: 79,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c7 = ToastClose;
ToastClose.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Close"].displayName;
const ToastTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
        lineNumber: 97,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c9 = ToastTitle;
ToastTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"].displayName;
const ToastDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm opacity-90", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toast.tsx",
        lineNumber: 109,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0)));
_c11 = ToastDescription;
ToastDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "ToastViewport$React.forwardRef");
__turbopack_context__.k.register(_c1, "ToastViewport");
__turbopack_context__.k.register(_c2, "Toast$React.forwardRef");
__turbopack_context__.k.register(_c3, "Toast");
__turbopack_context__.k.register(_c4, "ToastAction$React.forwardRef");
__turbopack_context__.k.register(_c5, "ToastAction");
__turbopack_context__.k.register(_c6, "ToastClose$React.forwardRef");
__turbopack_context__.k.register(_c7, "ToastClose");
__turbopack_context__.k.register(_c8, "ToastTitle$React.forwardRef");
__turbopack_context__.k.register(_c9, "ToastTitle");
__turbopack_context__.k.register(_c10, "ToastDescription$React.forwardRef");
__turbopack_context__.k.register(_c11, "ToastDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/use-toast.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reducer",
    ()=>reducer,
    "toast",
    ()=>toast,
    "useToast",
    ()=>useToast
]);
// Inspired by react-hot-toast library
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1000000;
const actionTypes = {
    ADD_TOAST: 'ADD_TOAST',
    UPDATE_TOAST: 'UPDATE_TOAST',
    DISMISS_TOAST: 'DISMISS_TOAST',
    REMOVE_TOAST: 'REMOVE_TOAST'
};
let count = 0;
function genId() {
    count = (count + 1) % Number.MAX_SAFE_INTEGER;
    return count.toString();
}
const toastTimeouts = new Map();
const addToRemoveQueue = (toastId)=>{
    if (toastTimeouts.has(toastId)) {
        return;
    }
    const timeout = setTimeout(()=>{
        toastTimeouts.delete(toastId);
        dispatch({
            type: 'REMOVE_TOAST',
            toastId: toastId
        });
    }, TOAST_REMOVE_DELAY);
    toastTimeouts.set(toastId, timeout);
};
const reducer = (state, action)=>{
    switch(action.type){
        case 'ADD_TOAST':
            return {
                ...state,
                toasts: [
                    action.toast,
                    ...state.toasts
                ].slice(0, TOAST_LIMIT)
            };
        case 'UPDATE_TOAST':
            return {
                ...state,
                toasts: state.toasts.map((t)=>t.id === action.toast.id ? {
                        ...t,
                        ...action.toast
                    } : t)
            };
        case 'DISMISS_TOAST':
            {
                const { toastId } = action;
                // ! Side effects ! - This could be extracted into a dismissToast() action,
                // but I'll keep it here for simplicity
                if (toastId) {
                    addToRemoveQueue(toastId);
                } else {
                    state.toasts.forEach((toast)=>{
                        addToRemoveQueue(toast.id);
                    });
                }
                return {
                    ...state,
                    toasts: state.toasts.map((t)=>t.id === toastId || toastId === undefined ? {
                            ...t,
                            open: false
                        } : t)
                };
            }
        case 'REMOVE_TOAST':
            if (action.toastId === undefined) {
                return {
                    ...state,
                    toasts: []
                };
            }
            return {
                ...state,
                toasts: state.toasts.filter((t)=>t.id !== action.toastId)
            };
    }
};
const listeners = [];
let memoryState = {
    toasts: []
};
function dispatch(action) {
    memoryState = reducer(memoryState, action);
    listeners.forEach((listener)=>{
        listener(memoryState);
    });
}
function toast({ ...props }) {
    const id = genId();
    const update = (props)=>dispatch({
            type: 'UPDATE_TOAST',
            toast: {
                ...props,
                id
            }
        });
    const dismiss = ()=>dispatch({
            type: 'DISMISS_TOAST',
            toastId: id
        });
    dispatch({
        type: 'ADD_TOAST',
        toast: {
            ...props,
            id,
            open: true,
            onOpenChange: (open)=>{
                if (!open) dismiss();
            }
        }
    });
    return {
        id: id,
        dismiss,
        update
    };
}
function useToast() {
    _s();
    const [state, setState] = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](memoryState);
    __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useToast.useEffect": ()=>{
            listeners.push(setState);
            return ({
                "useToast.useEffect": ()=>{
                    const index = listeners.indexOf(setState);
                    if (index > -1) {
                        listeners.splice(index, 1);
                    }
                }
            })["useToast.useEffect"];
        }
    }["useToast.useEffect"], [
        state
    ]);
    return {
        ...state,
        toast,
        dismiss: (toastId)=>dispatch({
                type: 'DISMISS_TOAST',
                toastId
            })
    };
}
_s(useToast, "SPWE98mLGnlsnNfIwu/IAKTSZtk=");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/toaster.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Toaster() {
    _s();
    const { toasts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastProvider"], {
        children: [
            toasts.map(function({ id, title, description, action, ...props }) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toast"], {
                    ...props,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid gap-1",
                            children: [
                                title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastTitle"], {
                                    children: title
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
                                    lineNumber: 22,
                                    columnNumber: 25
                                }, this),
                                description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastDescription"], {
                                    children: description
                                }, void 0, false, {
                                    fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
                                    lineNumber: 24,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
                            lineNumber: 21,
                            columnNumber: 13
                        }, this),
                        action,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastClose"], {}, void 0, false, {
                            fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
                            lineNumber: 28,
                            columnNumber: 13
                        }, this)
                    ]
                }, id, true, {
                    fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
                    lineNumber: 20,
                    columnNumber: 11
                }, this);
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastViewport"], {}, void 0, false, {
                fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
                lineNumber: 32,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/primitives/ui/toaster.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(Toaster, "1YTCnXrq2qRowe0H/LBWLjtXoYc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = Toaster;
var _c;
__turbopack_context__.k.register(_c, "Toaster");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/ChatWidget/hooks/useChat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useChat",
    ()=>useChat
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/trpc.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/socket.io-client/build/esm/index.js [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function useChat() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const [conversation, setConversation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { data: messages = [], refetch: refetchMessages } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'chatMessages',
            conversation?.id
        ],
        queryFn: {
            "useChat.useQuery": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].chat.getConversations.query({
                    conversationId: conversation.id
                })
        }["useChat.useQuery"],
        enabled: !!conversation,
        select: {
            "useChat.useQuery": (data)=>data?.messages || []
        }["useChat.useQuery"]
    });
    const startConversationMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useChat.useMutation[startConversationMutation]": (data)=>__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].chat.startConversation.mutate(data)
        }["useChat.useMutation[startConversationMutation]"],
        onSuccess: {
            "useChat.useMutation[startConversationMutation]": (data)=>{
                setConversation(data.conversation);
            }
        }["useChat.useMutation[startConversationMutation]"]
    });
    const sendMessageMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useChat.useMutation[sendMessageMutation]": (content)=>__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].chat.sendMessage.mutate({
                    conversationId: conversation.id,
                    content,
                    isFromVisitor: true
                })
        }["useChat.useMutation[sendMessageMutation]"],
        onSuccess: {
            "useChat.useMutation[sendMessageMutation]": ()=>{
                queryClient.invalidateQueries({
                    queryKey: [
                        'chatMessages',
                        conversation.id
                    ]
                });
            }
        }["useChat.useMutation[sendMessageMutation]"]
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useChat.useEffect": ()=>{
            if (conversation) {
                const socket = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$socket$2e$io$2d$client$2f$build$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["io"])(); // Replace with your socket server URL
                socket.on('newMessage', {
                    "useChat.useEffect": (message)=>{
                        if (message.conversationId === conversation.id) {
                            queryClient.invalidateQueries({
                                queryKey: [
                                    'chatMessages',
                                    conversation.id
                                ]
                            });
                        }
                    }
                }["useChat.useEffect"]);
                return ({
                    "useChat.useEffect": ()=>{
                        socket.disconnect();
                    }
                })["useChat.useEffect"];
            }
        }
    }["useChat.useEffect"], [
        conversation,
        queryClient
    ]);
    return {
        conversation,
        messages,
        isLoading: startConversationMutation.isPending || sendMessageMutation.isPending,
        startConversation: startConversationMutation.mutateAsync,
        sendMessage: (content)=>sendMessageMutation.mutateAsync(content)
    };
}
_s(useChat, "PxlOs5T+LdzS9TRQK/kD3+7HzP4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn,
    "html",
    ()=>html,
    "inter",
    ()=>inter,
    "merriweather",
    ()=>merriweather,
    "text",
    ()=>text
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
const inter = {
    className: "font-inter"
};
const merriweather = {
    className: "font-merriweather"
};
function html({ url, host, email, label }) {
    return `
  <body style="background: #f9f9f9;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="center" style="padding: 10px 0px 20px 0px; font-size: 22px; font-family: Helvetica, Arial, sans-serif; color: #444444;">
        <strong>${host.replace(/\./g, "&#8203;.")}</strong>
      </td>
    </tr>
  </table>
  <table width="100%" border="0" cellspacing="20" cellpadding="0" style="background: #ffffff; max-width: 600px; margin: auto; border-radius: 10px;">
    <tr>
      <td align="center" style="padding: 10px 0px 0px 0px; font-size: 18px; font-family: Helvetica, Arial, sans-serif; color: #444444;">
        ${label} as <strong>${email.replace(/\./g, "&#8203;.")}</strong>
      </td>
    </tr>
    <tr>
      <td align="center" style="padding: 20px 0;">
        <table border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td align="center" style="border-radius: 5px;" bgcolor="#ff0000"><a href="${url}" target="_blank" style="font-size: 18px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; border-radius: 5px; padding: 10px 20px; border: 1px solid #ff0000; display: inline-block; font-weight: bold;">${label}</a></td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td align="center" style="padding: 0px 0px 10px 0px; font-size: 16px; line-height: 22px; font-family: Helvetica, Arial, sans-serif; color: #444444;">
        If you did not request this email you can safely ignore it.
      </td>
    </tr>
  </table>
</body>
`;
}
function text({ url, host }) {
    return `Sign in to ${host}\n${url}\n\n`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "MemoizedButton",
    ()=>MemoizedButton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * Button Component - Theme-Aware Implementation
 *
 * Uses comprehensive CSS variable system for dynamic theming:
 * - Typography: --typography-button-* variables
 * - Border Radius: --radius-button
 * - Shadows: --shadow-button
 * - Spacing: --spacing-* variables
 * - Transitions: --transition-fast
 * - Colors: Tailwind classes with CSS variables (--primary, --destructive, etc.)
 *
 * All variables automatically respond to theme changes via DynamicThemeProvider.
 *
 * @see docs/CSS-VARIABLES-REFERENCE.md for complete variable documentation
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript)");
'use client';
;
;
;
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = (props, ref)=>{
    const { className = '', variant = 'default', size = 'default', loading = false, icon, style, asChild = false, ...restProps } = props;
    // Base button styles using comprehensive CSS variable system
    const baseStyles = {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        outline: 'none',
        cursor: props.disabled ? 'not-allowed' : 'pointer',
        // Typography - Use component-specific button typography variables
        fontFamily: 'var(--typography-button-family, var(--font-sans))',
        fontSize: 'var(--typography-button-size, 0.875rem)',
        fontWeight: 'var(--typography-button-weight, 500)',
        lineHeight: 'var(--typography-button-line-height, 1.25rem)',
        letterSpacing: 'var(--typography-button-letter-spacing, 0.01em)',
        // Border radius - Use component-specific button radius
        borderRadius: 'var(--radius-button, var(--radius, 0.375rem))',
        // Transitions - Use standardized transition variables
        transition: 'all var(--transition-fast, 150ms cubic-bezier(0.4, 0, 0.2, 1))',
        // Size variants using spacing system
        ...size === 'sm' && {
            height: '32px',
            paddingLeft: 'var(--spacing-sm, 0.5rem)',
            paddingRight: 'var(--spacing-sm, 0.5rem)',
            fontSize: '0.8125rem'
        },
        ...size === 'default' && {
            height: '40px',
            paddingLeft: 'var(--spacing-md, 1rem)',
            paddingRight: 'var(--spacing-md, 1rem)'
        },
        ...size === 'lg' && {
            height: '44px',
            paddingLeft: 'var(--spacing-lg, 1.5rem)',
            paddingRight: 'var(--spacing-lg, 1.5rem)',
            fontSize: '0.9375rem'
        },
        ...size === 'icon' && {
            height: '40px',
            width: '40px',
            padding: '0'
        },
        // Disabled state
        ...props.disabled && {
            opacity: 0.5,
            cursor: 'not-allowed'
        }
    };
    // Variant classes using global color system
    const getVariantClasses = ()=>{
        switch(variant){
            case 'default':
                return 'bg-primary text-primary-foreground border-primary hover:bg-primary/90';
            case 'outline':
                return 'bg-transparent text-primary border-primary hover:bg-primary/10';
            case 'ghost':
                return 'bg-transparent text-primary border-transparent hover:bg-muted';
            case 'destructive':
                return 'bg-destructive text-destructive-foreground border-destructive hover:bg-destructive/90';
            case 'secondary':
                return 'bg-secondary text-secondary-foreground border-secondary hover:bg-secondary/80';
            case 'loading':
                return 'bg-primary text-primary-foreground border-primary opacity-70 cursor-not-allowed';
            case 'icon':
                return 'bg-primary text-primary-foreground border-primary hover:bg-primary/90';
            default:
                return 'bg-primary text-primary-foreground border-primary hover:bg-primary/90';
        }
    };
    // Accessibility props
    const getAccessibilityProps = ()=>{
        const accessibilityProps = {
            'data-focus-visible': true,
            'aria-busy': loading ? 'true' : undefined,
            'aria-disabled': restProps.disabled || loading ? 'true' : undefined
        };
        // Add aria-label for icon-only buttons
        if (variant === 'icon' && !restProps.children && !restProps['aria-label']) {
            accessibilityProps['aria-label'] = 'Button';
        }
        // Add aria-live for loading state changes
        if (loading && !restProps['aria-live']) {
            accessibilityProps['aria-live'] = 'polite';
        }
        return accessibilityProps;
    };
    // Disable asChild when button has decorations (icon/loading)
    // because Slot expects exactly one child element
    const hasMultipleChildren = __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Children.count(restProps.children) > 1;
    const shouldUseSlot = asChild && !icon && !loading && !hasMultipleChildren;
    const Comp = shouldUseSlot ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    // When using asChild with valid single child, render with minimal decoration
    if (shouldUseSlot) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
            ref: ref,
            className: `${getVariantClasses()} ${className} border`,
            style: {
                ...baseStyles,
                ...style,
                outline: '2px solid transparent',
                outlineOffset: '2px',
                '--focus-ring-color': 'var(--ring, var(--primary))',
                boxShadow: loading ? 'none' : 'var(--shadow-button, var(--shadow-sm))'
            },
            onFocus: (e)=>{
                e.currentTarget.style.outline = '2px solid var(--focus-ring-color)';
                e.currentTarget.style.outlineOffset = '2px';
                if (restProps.onFocus) restProps.onFocus(e);
            },
            onBlur: (e)=>{
                e.currentTarget.style.outline = '2px solid transparent';
                if (restProps.onBlur) restProps.onBlur(e);
            },
            onKeyDown: (e)=>{
                if ((e.key === 'Enter' || e.key === ' ') && !restProps.disabled && !loading) {
                    e.preventDefault();
                    if (restProps.onClick) {
                        restProps.onClick(e);
                    }
                }
                if (restProps.onKeyDown) restProps.onKeyDown(e);
            },
            ...getAccessibilityProps(),
            ...restProps,
            children: restProps.children
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx",
            lineNumber: 147,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        ref: ref,
        className: `${getVariantClasses()} ${className} border`,
        style: {
            ...baseStyles,
            ...style,
            outline: '2px solid transparent',
            outlineOffset: '2px',
            '--focus-ring-color': 'var(--ring, var(--primary))',
            boxShadow: loading ? 'none' : 'var(--shadow-button, var(--shadow-sm))'
        },
        onFocus: (e)=>{
            e.currentTarget.style.outline = '2px solid var(--focus-ring-color)';
            e.currentTarget.style.outlineOffset = '2px';
            if (restProps.onFocus) restProps.onFocus(e);
        },
        onBlur: (e)=>{
            e.currentTarget.style.outline = '2px solid transparent';
            if (restProps.onBlur) restProps.onBlur(e);
        },
        onKeyDown: (e)=>{
            if ((e.key === 'Enter' || e.key === ' ') && !restProps.disabled && !loading) {
                e.preventDefault();
                if (restProps.onClick) {
                    restProps.onClick(e);
                }
            }
            if (restProps.onKeyDown) restProps.onKeyDown(e);
        },
        disabled: restProps.disabled || loading,
        ...getAccessibilityProps(),
        ...restProps,
        children: [
            loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                className: "animate-spin -ml-1 mr-2 h-4 w-4",
                fill: "none",
                viewBox: "0 0 24 24",
                style: {
                    marginRight: restProps.children ? '8px' : '0'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                        className: "opacity-25",
                        cx: "12",
                        cy: "12",
                        r: "10",
                        stroke: "currentColor",
                        strokeWidth: "4"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx",
                        lineNumber: 225,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        className: "opacity-75",
                        fill: "currentColor",
                        d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx",
                        lineNumber: 233,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx",
                lineNumber: 219,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            icon && !loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                style: {
                    marginRight: restProps.children ? '8px' : '0'
                },
                children: icon
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx",
                lineNumber: 241,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            restProps.children
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx",
        lineNumber: 185,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Button;
Button.displayName = 'Button';
const MemoizedButton = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(Button, (prevProps, nextProps)=>{
    if (prevProps.loading !== nextProps.loading) return false;
    if (prevProps.disabled !== nextProps.disabled) return false;
    if (prevProps.variant !== nextProps.variant) return false;
    if (prevProps.size !== nextProps.size) return false;
    if (prevProps.className !== nextProps.className) return false;
    if (JSON.stringify(prevProps.children) !== JSON.stringify(nextProps.children)) return false;
    return true;
});
_c2 = MemoizedButton;
MemoizedButton.displayName = 'MemoizedButton';
const __TURBOPACK__default__export__ = Button;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Button$React.forwardRef");
__turbopack_context__.k.register(_c1, "Button");
__turbopack_context__.k.register(_c2, "MemoizedButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/button.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * MIGRATION NOTE: This file now re-exports from the unified design system
 * All Button functionality has been consolidated into design-system/primitives/Button
 * This re-export maintains backward compatibility with existing imports
 */ __turbopack_context__.s([
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/index.ts [app-client] (ecmascript) <locals>");
;
;
const buttonVariants = ({ variant = 'default', size = 'default', className = '' } = {})=>{
    const baseStyles = 'inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50';
    const variants = {
        default: 'bg-primary text-primary-foreground shadow hover:bg-primary/90',
        destructive: 'bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90',
        outline: 'border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground',
        secondary: 'bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80',
        ghost: 'hover:bg-accent hover:text-accent-foreground',
        link: 'text-primary underline-offset-4 hover:underline'
    };
    const sizes = {
        default: 'h-9 px-4 py-2',
        sm: 'h-8 rounded-md px-3 text-xs',
        lg: 'h-10 rounded-md px-8',
        icon: 'h-9 w-9'
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(baseStyles, variants[variant], sizes[size], className);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/Card/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Card",
    ()=>Card,
    "CardAction",
    ()=>CardAction,
    "CardContent",
    ()=>CardContent,
    "CardDescription",
    ()=>CardDescription,
    "CardFooter",
    ()=>CardFooter,
    "CardHeader",
    ()=>CardHeader,
    "CardTitle",
    ()=>CardTitle,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
const Card = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ variant = 'default', padding = 'md', className, children, style, ...props }, ref)=>{
    // Variant classes
    const variantClasses = {
        default: 'border border-border bg-card text-card-foreground',
        bordered: 'border-2 border-border bg-card text-card-foreground',
        elevated: 'bg-card text-card-foreground shadow-md hover:shadow-lg transition-shadow duration-300',
        flat: 'bg-card text-card-foreground'
    }[variant];
    // Padding classes
    const paddingClasses = {
        none: 'p-0',
        sm: 'p-4',
        md: 'p-6',
        lg: 'p-8'
    }[padding];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        "data-slot": "card",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-col rounded-lg transition-all duration-300', variantClasses, paddingClasses, className),
        style: {
            borderRadius: 'var(--radius-card, 12px)',
            ...style
        },
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 57,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Card;
Card.displayName = 'Card';
const CardHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c2 = ({ className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        "data-slot": "card-header",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex flex-col gap-2', className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 96,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = CardHeader;
CardHeader.displayName = 'CardHeader';
const CardTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c4 = ({ className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
        ref: ref,
        "data-slot": "card-title",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-lg font-semibold leading-tight tracking-tight', className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 123,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c5 = CardTitle;
CardTitle.displayName = 'CardTitle';
const CardDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c6 = ({ className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        ref: ref,
        "data-slot": "card-description",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('text-sm text-muted-foreground', className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 150,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c7 = CardDescription;
CardDescription.displayName = 'CardDescription';
const CardContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c8 = ({ className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        "data-slot": "card-content",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex-1', className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 179,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c9 = CardContent;
CardContent.displayName = 'CardContent';
const CardFooter = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c10 = ({ className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        "data-slot": "card-footer",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center gap-2', className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 208,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c11 = CardFooter;
CardFooter.displayName = 'CardFooter';
const CardAction = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c12 = ({ className, children, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        ref: ref,
        "data-slot": "card-action",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('col-start-2 row-span-2 row-start-1 self-start justify-self-end', className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Card/Card.tsx",
        lineNumber: 241,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c13 = CardAction;
CardAction.displayName = 'CardAction';
const __TURBOPACK__default__export__ = Card;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13;
__turbopack_context__.k.register(_c, "Card$React.forwardRef");
__turbopack_context__.k.register(_c1, "Card");
__turbopack_context__.k.register(_c2, "CardHeader$React.forwardRef");
__turbopack_context__.k.register(_c3, "CardHeader");
__turbopack_context__.k.register(_c4, "CardTitle$React.forwardRef");
__turbopack_context__.k.register(_c5, "CardTitle");
__turbopack_context__.k.register(_c6, "CardDescription$React.forwardRef");
__turbopack_context__.k.register(_c7, "CardDescription");
__turbopack_context__.k.register(_c8, "CardContent$React.forwardRef");
__turbopack_context__.k.register(_c9, "CardContent");
__turbopack_context__.k.register(_c10, "CardFooter$React.forwardRef");
__turbopack_context__.k.register(_c11, "CardFooter");
__turbopack_context__.k.register(_c12, "CardAction$React.forwardRef");
__turbopack_context__.k.register(_c13, "CardAction");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/Card/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Card/Card.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/Input/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
/**
 * Input Component - Theme-Aware Implementation
 *
 * Uses comprehensive CSS variable system for dynamic theming:
 * - Typography: --typography-input-* variables
 * - Border Radius: --radius-input
 * - Spacing: --spacing-* variables
 * - Transitions: --transition-base
 * - Colors: Tailwind classes with CSS variables (--input, --ring, etc.)
 *
 * All variables automatically respond to theme changes via DynamicThemeProvider.
 *
 * @see docs/CSS-VARIABLES-REFERENCE.md for complete variable documentation
 *
 * @example
 * ```tsx
 * <Input type="text" placeholder="Enter text..." />
 * <Input type="email" placeholder="your@email.com" />
 * <Input type="password" placeholder="Password" />
 * ```
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, type = 'text', style, ...props }, ref)=>{
    // Base input styles using comprehensive CSS variable system
    const baseStyles = {
        // Typography - Use component-specific input typography variables
        fontFamily: 'var(--typography-input-family, var(--font-sans))',
        fontSize: 'var(--typography-input-size, 0.875rem)',
        fontWeight: 'var(--typography-input-weight, 400)',
        lineHeight: 'var(--typography-input-line-height, 1.25rem)',
        // Border radius - Use component-specific input radius
        borderRadius: 'var(--radius-input, var(--radius, 0.375rem))',
        // Transitions - Use standardized transition variables
        transition: 'all var(--transition-base, 200ms cubic-bezier(0.4, 0, 0.2, 1))'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        type: type,
        "data-slot": "input",
        style: {
            ...baseStyles,
            ...style
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(// Base styles
        'flex h-9 w-full min-w-0 border px-3 py-1 text-base outline-none', // Border and background
        'border-input bg-input-background', // Text colors
        'text-foreground placeholder:text-muted-foreground', // Selection
        'selection:bg-primary selection:text-primary-foreground', // Focus states
        'focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]', // Invalid states
        'aria-invalid:ring-destructive/20 aria-invalid:border-destructive', 'dark:aria-invalid:ring-destructive/40', // Disabled states
        'disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50', // File input specific styles
        'file:inline-flex file:h-7 file:border-0 file:bg-transparent', 'file:text-sm file:font-medium file:text-foreground', // Dark mode
        'dark:bg-input/30', // Custom className
        className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/Input/Input.tsx",
        lineNumber: 47,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = 'Input';
const __TURBOPACK__default__export__ = Input;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$React.forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/Input/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Input/Input.tsx [app-client] (ecmascript)");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Label",
    ()=>Label
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-label/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/utils.ts [app-client] (ecmascript)");
'use client';
;
;
;
function Label({ className, style, ...props }) {
    // Base label styles using comprehensive CSS variable system
    const baseStyles = {
        // Typography - Use component-specific label typography variables
        fontFamily: 'var(--typography-label-family, var(--font-sans))',
        fontSize: 'var(--typography-label-size, 0.875rem)',
        fontWeight: 'var(--typography-label-weight, 500)',
        lineHeight: 'var(--typography-label-line-height, 1.25rem)',
        // Transitions - Use standardized transition variables
        transition: 'all var(--transition-base, 200ms cubic-bezier(0.4, 0, 0.2, 1))'
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$label$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        "data-slot": "label",
        style: {
            ...baseStyles,
            ...style
        },
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])('flex items-center gap-2 leading-none select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/label.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_c = Label;
;
var _c;
__turbopack_context__.k.register(_c, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/primitives/ui/textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Textarea",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/utils.ts [app-client] (ecmascript)");
;
;
function Textarea({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        "data-slot": "textarea",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("resize-none border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-input-background px-3 py-2 text-base transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/primitives/ui/textarea.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
_c = Textarea;
;
var _c;
__turbopack_context__.k.register(_c, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContactForm",
    ()=>ContactForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/button.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Input/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Input/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/textarea.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function ContactForm({ onSubmit, isLoading, config }) {
    _s();
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        email: '',
        phone: '',
        message: ''
    });
    const handleSubmit = (e)=>{
        e.preventDefault();
        if (formData.name && formData.email) {
            onSubmit(formData);
        }
    };
    const handleChange = (field, value)=>{
        setFormData((prev)=>({
                ...prev,
                [field]: value
            }));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-4 space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "font-semibold text-lg",
                        children: config?.welcomeMessage || 'Start a conversation'
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-gray-600 mt-1",
                        children: config?.contactFormMessage || 'Please provide your contact information to start chatting with us.'
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "name",
                                children: "Name *"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 56,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                id: "name",
                                type: "text",
                                value: formData.name,
                                onChange: (e)=>handleChange('name', e.target.value),
                                placeholder: "Your name",
                                required: true,
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "email",
                                children: "Email *"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 69,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                id: "email",
                                type: "email",
                                value: formData.email,
                                onChange: (e)=>handleChange('email', e.target.value),
                                placeholder: "your@email.com",
                                required: true,
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 70,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 68,
                        columnNumber: 9
                    }, this),
                    config?.showPhoneField && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "phone",
                                children: "Phone"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 83,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                                id: "phone",
                                type: "tel",
                                value: formData.phone,
                                onChange: (e)=>handleChange('phone', e.target.value),
                                placeholder: "Your phone number",
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this),
                    config?.showMessageField && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Label"], {
                                htmlFor: "message",
                                children: "Initial Message"
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Textarea"], {
                                id: "message",
                                value: formData.message,
                                onChange: (e)=>handleChange('message', e.target.value),
                                placeholder: "How can we help you?",
                                rows: 3,
                                disabled: isLoading
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        className: "w-full",
                        disabled: isLoading || !formData.name || !formData.email,
                        style: {
                            backgroundColor: config?.primaryColor || '#007ee6',
                            color: config?.textColor || '#FFFFFF'
                        },
                        children: isLoading ? 'Starting chat...' : 'Start Chat'
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                lineNumber: 54,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-gray-500 text-center",
                children: config?.privacyMessage || 'Your information is secure and will not be shared.'
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
                lineNumber: 122,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_s(ContactForm, "5cOIQaweiY/ugVXi0L4klWKL4us=");
_c = ContactForm;
var _c;
__turbopack_context__.k.register(_c, "ContactForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatInterface",
    ()=>ChatInterface
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/button.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Input/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Input/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/send.js [app-client] (ecmascript) <export default as Send>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function ChatInterface({ messages, onSendMessage, isLoading, config }) {
    _s();
    const [newMessage, setNewMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const scrollToBottom = ()=>{
        messagesEndRef.current?.scrollIntoView({
            behavior: 'smooth'
        });
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(scrollToBottom, [
        messages
    ]);
    const handleSendMessage = (e)=>{
        e.preventDefault();
        if (newMessage.trim()) {
            onSendMessage(newMessage);
            setNewMessage('');
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col h-full",
        style: {
            backgroundColor: config?.backgroundColor || '#FFFFFF'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 p-4 overflow-y-auto",
                children: [
                    messages.map((msg, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `mb-2 ${msg.isFromVisitor ? 'text-left' : 'text-right'}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `inline-block p-2 rounded-lg ${msg.isFromVisitor ? 'bg-gray-200' : 'bg-blue-500 text-white'}`,
                                children: msg.content
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                                lineNumber: 49,
                                columnNumber: 13
                            }, this)
                        }, index, false, {
                            fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                            lineNumber: 45,
                            columnNumber: 11
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: messagesEndRef
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSendMessage,
                className: "p-4 border-t flex items-center space-x-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Input$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Input"], {
                        value: newMessage,
                        onChange: (e)=>setNewMessage(e.target.value),
                        placeholder: "Type a message...",
                        disabled: isLoading,
                        className: "flex-1"
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        type: "submit",
                        disabled: isLoading || !newMessage.trim(),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$send$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Send$3e$__["Send"], {
                            className: "h-4 w-4"
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                            lineNumber: 70,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
                lineNumber: 58,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_s(ChatInterface, "YdSvd8q7Hk6Mw9odOhCODJVjT50=");
_c = ChatInterface;
var _c;
__turbopack_context__.k.register(_c, "ChatInterface");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatWidget",
    ()=>ChatWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/lib/trpc.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$hooks$2f$useChat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/ChatWidget/hooks/useChat.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/ui/button.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/theme-editor-3.0/design-system/primitives/Button/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Card/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/primitives/Card/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/message-circle.js [app-client] (ecmascript) <export default as MessageCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$ContactForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/ChatWidget/ContactForm.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$ChatInterface$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/packages/web/src/components/features/ChatWidget/ChatInterface.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
function ChatWidget() {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [step, setStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('contact');
    const { data: config } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'chatbotConfig'
        ],
        queryFn: {
            "ChatWidget.useQuery": ()=>__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$lib$2f$trpc$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["trpc"].chatbotConfig.get.query()
        }["ChatWidget.useQuery"]
    });
    const { conversation, messages, isLoading, sendMessage, startConversation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$hooks$2f$useChat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChat"])();
    const handleStartChat = async (contactData)=>{
        await startConversation(contactData);
        setStep('chat');
    };
    if (!isOpen) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed z-40",
            style: {
                bottom: config?.position === 'bottom-left' ? '1rem' : '1rem',
                right: config?.position === 'bottom-right' ? '1rem' : 'auto',
                left: config?.position === 'bottom-left' ? '1rem' : 'auto'
            },
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: ()=>setIsOpen(true),
                className: "rounded-full w-14 h-14 shadow-lg",
                style: {
                    backgroundColor: config?.primaryColor || '#007ee6'
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$message$2d$circle$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MessageCircle$3e$__["MessageCircle"], {
                    className: "h-6 w-6",
                    style: {
                        color: config?.textColor || '#FFFFFF'
                    }
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                    lineNumber: 50,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                lineNumber: 45,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
            lineNumber: 37,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed z-40 w-80 h-96",
        style: {
            bottom: config?.position === 'bottom-left' ? '1rem' : '1rem',
            right: config?.position === 'bottom-right' ? '1rem' : 'auto',
            left: config?.position === 'bottom-left' ? '1rem' : 'auto'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Card"], {
            className: "h-full flex flex-col shadow-2xl",
            style: {
                borderRadius: config?.borderRadius ? `${config.borderRadius}px` : '8px'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardHeader"], {
                    className: "flex-row items-center justify-between p-4",
                    style: {
                        backgroundColor: config?.primaryColor || '#007ee6',
                        color: config?.textColor || '#FFFFFF'
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardTitle"], {
                            className: "text-sm",
                            children: config?.welcomeMessage || 'Chat with us'
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                            lineNumber: 83,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$theme$2d$editor$2d$3$2e$0$2f$design$2d$system$2f$primitives$2f$Button$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "ghost",
                            size: "sm",
                            onClick: ()=>setIsOpen(false),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                className: "h-4 w-4",
                                style: {
                                    color: config?.textColor || '#FFFFFF'
                                }
                            }, void 0, false, {
                                fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                                lineNumber: 87,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                            lineNumber: 86,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$primitives$2f$Card$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CardContent"], {
                    className: "flex-1 p-0",
                    style: {
                        backgroundColor: config?.backgroundColor || '#FFFFFF'
                    },
                    children: step === 'contact' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$ContactForm$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContactForm"], {
                        onSubmit: handleStartChat,
                        isLoading: isLoading,
                        config: config
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                        lineNumber: 99,
                        columnNumber: 13
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$ChatInterface$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ChatInterface"], {
                        messages: messages,
                        onSendMessage: sendMessage,
                        isLoading: isLoading,
                        config: config
                    }, void 0, false, {
                        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                        lineNumber: 105,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
                    lineNumber: 94,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
            lineNumber: 68,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/packages/web/src/components/features/ChatWidget/ChatWidget.tsx",
        lineNumber: 60,
        columnNumber: 5
    }, this);
}
_s(ChatWidget, "ruWBDpMUEX4SjK6SacLbRkEKW10=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$packages$2f$web$2f$src$2f$components$2f$features$2f$ChatWidget$2f$hooks$2f$useChat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useChat"]
    ];
});
_c = ChatWidget;
var _c;
__turbopack_context__.k.register(_c, "ChatWidget");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=packages_web_src_b558976a._.js.map